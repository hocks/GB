#!/bin/sh
#
# bbchkwarnrules.cfg
#
# BB4 Technologies Inc.
# Version 1.5d3
# Nov 09th, 2000
#
# This program is Copyright (c) 1997-2001
# BB4 Technologies Inc.
# All Rights Reserved
#
# Check integrity of the bbwarnrules.cfg file
#

if [ ! -r bbwarnrules.cfg ]
then
	echo "Cannot read bbwarnrules.cfg"
	exit 1
fi

rc=0

cat ./bbwarnrules.cfg | grep -v "^#" | \
while read line
do
	set -f		disable globber

	line=`echo $line | sed 's/;;/; ;/g'`
	if [ -z "$line" ]
	then
		continue
	fi


	OLDIFS=$IFS
	IFS=';'
	set $line
	IFS=$OLDIFS

	if [ "$#" -ne 7 ]
	then
		echo "invalid rule: <$line>"
		rc=2
	fi
	
	set +f		#reenable globber
done

exit $rc
