/*
 *
 * getipaddr.c
 *
 * Robert-Andre Croteau - BB4 Technologies Inc.
 * Version 1.6
 * Dec 18th, 2000
 *
 * This program is Copyright (c) 1997-2001
 * BB4 Technologies Inc.
 * All Rights Reserved
 *
 * Return the IP address associated with a host name
 *
 */


#include "bb.h"		/* THE BIG BROTHER INCLUDE FILE */

char bbprog[] = "getipaddr";

int main(argc, argv)
int argc;       
char *argv[];
{
char hostname[MAXLINE];
int rc = 1;
int argvnum = 1;

	if( argc != 2  && argc != 3 ) {
		exit(rc);
	} 

	if( !strcmp(argv[1],"-f") ) {
		argvnum = 2;
	}

	rc = 2;
	/* if -f not set then argvnum == 1, forceip == 0 */
	/* if -f is  set then argvnum == 2, forceip == 1 */
	if( getipaddr(argv[argvnum],hostname,sizeof(hostname),argvnum-1) == 0 ) {
		rc = 0;
	}

	printf("%s",hostname);

	exit(rc);
}
