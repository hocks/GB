/*
 * bb.h 
 * BIG BROTHER INCLUDE FILE
 * Sean MacGuire - BB4 Technologies Inc.
 * Version 1.8b3
 * Jun 21st, 2001
 *
 * This program is Copyright (c) 1997-2001
 * BB4 Technologies Inc.
 * All Rights Reserved
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#ifdef BSDI4
#include <arpa/inet.h>
#endif
#include <sys/signal.h>                 /* FOR ALARMS */
#include <sys/wait.h>                 	/* FOR STUPID FREEBSD */
#include <syslog.h>                     /* FOR LOGGING */
#include <setjmp.h>                     /* FOR NON-LOCAL GOTO */

#define MAXLINE  8192			/* CHANGED FROM 256 - MAX LINE SIZE */

#ifndef DEBUG
#define DEBUG	0
#endif

#define debug   printf

#define PORT    1984                    /* OBVIOUSLY BIG BROTHER'S PORT # */

#ifdef BZERO
#define bzero(a,b) memset(a,0,b)
#endif /* BZERO */
#ifdef SYSLOG
#define LOG_DAEMON      (3<<3)
#endif /* SYSLOG */

#define BBREL	"1.8b3"
#define BBRELDATE "Thu, 21 Jun 2001 11:00:00 GMT"

#define PAGELEVELSDEFAULT "red purple"	/* Make sure same value is in bbdef.sh */

#define VALIDFILENAMECHARS	"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.,:"

#define REG_FULL        1
#define REG_BOL         2
#define REG_EOL         4
#define REG_IGN_CASE    8
#define REG_PATHEXP	16
 
#define PAGE_DEFAULT            1
#define PAGE_BASIC              2
#define PAGE_ESCALATE           4
#define PAGE_INITDELAY          8
        
#define GETDIR_FILE     1
#define GETDIR_DIR      2
#define GETDIR_OTHER    4
#define GETDIR_ALL      8

#define LINEBBHOSTS_ALL		1
#define LINEBBHOSTS_IPADDR	2

#define BB_DISABLEMSG	1
#define BB_ENABLEMSG	2

#ifdef __GNUC__
#define FUNCINFUNCOK	1
#endif
