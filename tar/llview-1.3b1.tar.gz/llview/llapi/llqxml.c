/**************************************************************************/
/* FZJ: llqxml  generates XML file with LoadLeveler informations          */
/* changed: 01.03.2005 WF                                                 */
/*                                                                        */
/**************************************************************************/

/**************************************************************************/
/*
   Copyright (C) 2005, Forschungszentrum Juelich GmbH, Federal Republic of
   Germany. All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are met:

   Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

     - Redistributions of source code must retain the above copyright notice,
       this list of conditions and the following disclaimer.

     - Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in the
       documentation and/or other materials provided with the distribution.

     - Any publications that result from the use of this software shall
       reasonably refer to the Research Centre's development.

     - All advertising materials mentioning features or use of this software
       must display the following acknowledgement:

           This product includes software developed by Forschungszentrum
           Juelich GmbH, Federal Republic of Germany.

     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
       any support, consulting, training or assistance of any kind with regard
       to the use, operation and performance of this software or to provide
       the user with any updates, revisions or new versions.


   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.       */
/**************************************************************************/

#include "stdlib.h"
#include "stdio.h"
/*  #include "/usr/lpp/LoadL/full/include/llapi.h" */
#include "llapi.h"
/* Get lib calls, data types and structures */

#include <time.h> 
#include <string.h> 

#define MATCH 0 
#define B_SIZE 1000
#define HEXDOT 46 
#define ALL 0 
#define TRUE 1 
#define FALSE 0
#define WAITING 1 
#define RUNNING 2

#define MAX_MACHINES 1000

#define RCRET if(rc!=0) return(-1)

char *machine_list[MAX_MACHINES];
int act_num_machines=0;

#ifdef DEMO
#define MAX_NUMBER_OF_USERS 1000
int act_num_users=0;
char *user_list[MAX_NUMBER_OF_USERS];
#endif

char *StepStateStr[] = { "IDLE", "PENDING", "STARTING", "RUNNING",
		      "COMPLETE_PENDING", "REJECT_PENDING", "REMOVE_PENDING",
		      "VACATE_PENDING", "COMPLETED", "REJECTED", "REMOVED",
		      "VACATED", "CANCELED", "NOTRUN", "TERMINATED",
		      "UNEXPANDED", "SUBMISSION_ERR", "HOLD", "DEFERRED",
		      "NOTQUEUED", "PREEMPTED", "PREEMPT_PENDING",
		      "RESUME_PENDING" };

char *StepNodeUsageV[] = { "SHARED", "NOT_SHARED", "SLICE_NOT_SHARED" };

/* for usagestr */
char  DateStr[B_SIZE*5];
int count_cpus=0,count_cpus_running=0,count_cpus_alloc=0;


/* subroutine to exit on error */
int report(int rc, char *Message) { 
  exit (rc);                               
} 

/* subroutine to exit on error */
int prtime(char *format, time_t *t) { 
  struct tm  *helptime;           
  char TextTime[B_SIZE];
  size_t smax=B_SIZE;   

  helptime = localtime(t); 
  strftime(TextTime,smax,"%m/%d/%y %H:%M:%S",helptime); 
  printf(format, TextTime);

  return(1);
} 

/* subroutine to query informations from LoadLeveler */
int getdata(LL_element *elem, enum LLAPI_Specification spec, void *target, char *name) { 
  int rc=0;
  rc = ll_get_data(elem, spec, target);
  if (rc != 0) {
    fprintf (stderr,"ll_get_data failed for %s. rc = %d\n",name,rc);
    exit(rc);
  }
  return(rc);
} 

int _getdata(LL_element *elem, enum LLAPI_Specification spec, void *target, char *name) { 
  int rc=0;
  rc = ll_get_data(elem, spec, target);
  return(rc);
} 

int stripID(char* id, char *LocalMach) {
  int i, Junk;
  char *TempPtr, NewBuff[B_SIZE], LLID[B_SIZE], LLStep[B_SIZE];
  for (i=0 ; i<B_SIZE ; ++i) { 
    *(LocalMach+i) = *(LLStep+i) = *(NewBuff+i) = *(LLID+i) = 0;
  }            
  TempPtr = strchr(id,HEXDOT);                   /* Format to use only local machine ID */
  Junk = TempPtr-id;            
  strncpy(LocalMach,id,Junk);
  TempPtr = strrchr(id,HEXDOT);            
  strcpy(LLStep,TempPtr);
  strncpy(NewBuff,id,(TempPtr-id));              /* hack off step ID */
  TempPtr = strrchr(NewBuff,HEXDOT);
  strcpy(LLID, TempPtr);                         /* save LL id value */
  strcat(LocalMach,LLID);                        /* these 2 steps add in LL job and step id's */
  strcat(LocalMach,LLStep);
  return(1);
}


int query_system() {
  FILE       *staticinffile;
  char        TempBuff[B_SIZE*5];
  char        TextTime[B_SIZE];
  time_t      thisTime;
  struct tm  *LocalTime;           
  size_t smax=(size_t) B_SIZE;   


/*    printf("malloc: %d %d\n",sizeof(struct tm),sizeof(LocalTime)); */
  LocalTime       = (struct tm *) malloc(sizeof(struct tm)); 

  printf("<system \n");

  if(staticinffile=fopen("machineinf.xml","r")) {
    while(fgets(TempBuff,B_SIZE,staticinffile)) {
      printf("\t %s",TempBuff);
    }
    fclose(staticinffile);
  } else {
#ifndef JUMP    
    gethostname( TempBuff, B_SIZE);
    printf("     \t system_name=\"%s\"\n", TempBuff);
    printf("     \t system_mem=\"%s\"\n", "unknown");
    printf("     \t system_cpucount=\"%s\"\n", "unknown");
    printf("     \t system_cpuspeed=\"%s\"\n", "unknown");
    printf("     \t system_cputype=\"%s\"\n", "unknown");
    printf("     \t system_type=\"%s\"\n", "unknown");
    printf("     \t system_frames=\"%s\"\n", "unknown");
    printf("     \t system_perform=\"%s\"\n", "unknown");
#else
    printf("     \t system_name=\"%s\"\n", "jump");
    printf("     \t system_mem=\"%s\"\n", "5.2 TB");
    printf("     \t system_cpucount=\"%s\"\n", "1312");
    printf("     \t system_cpuspeed=\"%s\"\n", "1.7 GHz");
    printf("     \t system_cputype=\"%s\"\n", "Power4+");
    printf("     \t system_type=\"%s\"\n", "4");
    printf("     \t system_frames=\"%s\"\n", "41");
    printf("     \t system_perform=\"%s\"\n", "8.9 TFLOPS");
#endif
  }
  thisTime  = time(NULL);
  LocalTime = localtime(&thisTime); 
  strftime(TextTime,smax,"%m/%d/%y-%H:%M:%S",LocalTime); 
/*    free(LocalTime); */
  sprintf(DateStr,"%s",TextTime);
  printf("     \t system_time=\"%s\"\n", DateStr);
  printf("       >\n");
  return(1);
}

int query_classes(enum LL_Daemon daemon, char *scheddhost) {
  LL_element *queryObject=NULL,*a_class=NULL, *a_user=NULL;
  int i, j, rc, num, err;
  char Message[B_SIZE];
  char *class_name = NULL; 
  int maximum_slots;
  int user_maxjobs;

  /* Initialize the query for CLASS */   
  queryObject = ll_query(CLASSES);

  /* I want to query all jobs */
  rc = ll_set_request(queryObject,QUERY_ALL,NULL,ALL_DATA);
  if (rc != 0) { 
    sprintf(Message, "ll_set_request failed"); 
    report(rc, Message); 
  }

  /* Get the requested a_class from the central manager daemon */
  a_class = ll_get_objs(queryObject,daemon,scheddhost,&num,&err);

  printf("<classes \n");
  printf("     \t ConfiguredClasses=\"");
  i=0;
  while (a_class) {
    rc=getdata(a_class, LL_ClassName, &class_name,"LL_ClassName"); RCRET;
    rc=getdata(a_class, LL_ClassMaximumSlots, &maximum_slots,"LL_ClassMaximumSlots"); RCRET;
    rc=getdata(a_class, LL_ClassGetFirstUser, &a_user,"LL_ClassGetFirstUser"); RCRET;
    if(a_user) {
      rc=getdata(a_user, LL_ClassUserMaxJobs, &user_maxjobs,"LL_ClassUserMaxJobs"); RCRET;
    } else {
      user_maxjobs=-1;
    }
    printf("%s%s(%d,%d)",(i>0)?" ":"",class_name,maximum_slots,user_maxjobs);
    i++;
    /* get next class */
    a_class = ll_next_obj(queryObject);
  }
  printf("\"\n");
  printf("       />\n");
}

int query_jobs(enum LL_Daemon daemon, char *scheddhost) {
  LL_element *queryObject=NULL,*job=NULL, *JobCredential=NULL,*step=NULL, *node=NULL;
  LL_element *task=NULL, *resource_req=NULL,*instance=NULL, *machine = NULL;
  int i, j, rc, num, err, StepState, StepWallClockLimitHard, StepWallClockLimitSoft;
  int StepSystemPriority, numtasks, StepCpuStepLimitHard, StepCpuStepLimitSoft;
  int StepMachineCount, TotalNodesR_min, TotalNodesR_max, mystate, nnodes, cnt;
  int conscpu, consmem, totaltasks,taskspernode, TaskIsMaster, TaskTaskInstanceCount;
  int StepTotalTasksRequested, StepTasksPerNodeRequested, StepTaskInstanceCount, StepImmediate;
  int StepBlocking, StepRestart, StepNodeUsage,StepUserSystemPriority;
  int NodeMinInstances, NodeInitiatorCount; 
  char Message[B_SIZE];
  char LocalMach[B_SIZE];
  char instnames[5*B_SIZE];
  char TempBuff[5*B_SIZE];
  char lastname[B_SIZE];
  char *JobName=NULL,*CredentialUserName=NULL,*StepID=NULL, *StepJobClass=NULL, *StepComment=NULL;
  char *StepTotalNodesRequested=NULL, *StepTaskGeometry=NULL, *resname=NULL;
  char *TaskExecutable, *TaskExecutableArguments, *NodeRequirements=NULL;
  char *instance_machname;
  char *machname=NULL;
  int cpus;

#ifdef BGL
  char *StepBgPartitionAllocated=NULL,*StepBgPartitionRequested=NULL;
  char *StepBgShapeAllocated=NULL,*StepBgShapeRequested=NULL;
  int  StepBgSizeRequested;
#endif
  time_t StepDispatchTime, StepEndTime, JobSubmitTime;
  int64_t value64,StepStepSystemTime64,StepStepUserTime64;



  /* Initialize the query for jobs */   
  queryObject = ll_query(JOBS);

  /* I want to query all jobs */
  rc = ll_set_request(queryObject,QUERY_ALL,NULL,ALL_DATA);
  if (rc != 0) { 
    sprintf(Message, "ll_set_request failed"); 
    report(rc, Message); 
  }

  
  /* Request the objects from the Negotiator daemon */
  /*    job = ll_get_objs(queryObject,LL_CM,NULL,&num,&err); */
  job = ll_get_objs(queryObject,daemon,scheddhost,&num,&err);
  /* Loop through the list and process */      
  while(job) {
    rc=getdata(job,LL_JobName,&JobName,"LL_JobName"); RCRET;
    rc=getdata(job,LL_JobSubmitTime,&JobSubmitTime,"JobSubmitTime"); RCRET;
    rc=getdata(job,LL_JobCredential,   &JobCredential,   "LL_JobCredential"); RCRET;
    rc=getdata(JobCredential,LL_CredentialUserName,   &CredentialUserName,   "LL_CredentialUserName"); RCRET;

    /* Loop through the steps of the job */
    rc=getdata(job,LL_JobGetFirstStep,&step,"LL_JobGetFirstStep"); RCRET;
    while (step) {
      rc=getdata(step,LL_StepState,&StepState,"LL_StepState"); RCRET;
      rc=getdata(step,LL_StepID,   &StepID,   "LL_StepID"); RCRET;
      stripID(StepID,LocalMach);	
      rc=getdata(step,LL_StepWallClockLimitHard,   &StepWallClockLimitHard,   "LL_StepWallClockLimitHard"); RCRET;
      rc=getdata(step,LL_StepWallClockLimitSoft,   &StepWallClockLimitSoft,   "LL_StepWallClockLimitSoft"); RCRET;

      rc=getdata(step,LL_StepCpuStepLimitHard,   &StepCpuStepLimitHard,   "LL_StepCpuStepLimitHard"); RCRET;
      rc=getdata(step,LL_StepCpuStepLimitSoft,   &StepCpuStepLimitSoft,   "LL_StepCpuStepLimitSoft"); RCRET;

      node=NULL;
      rc=getdata(step,LL_StepGetFirstNode,   &node,                 "LL_StepGetFirstNode"); RCRET;
      rc=getdata(node,LL_NodeMinInstances,   &NodeMinInstances,     "LL_NodeMinInstances"); RCRET;
      rc=getdata(node,LL_NodeInitiatorCount, &NodeInitiatorCount,   "LL_NodeInitiatorCount"); RCRET;

      numtasks = NodeMinInstances * NodeInitiatorCount;

      rc=getdata(step,LL_StepJobClass,                &StepJobClass,              "LL_StepJobClass"); RCRET;
      rc=getdata(step,LL_StepTaskInstanceCount,       &StepTaskInstanceCount,     "LL_StepTaskInstanceCount"); RCRET;
      rc=getdata(step,LL_StepTotalTasksRequested,     &StepTotalTasksRequested,   "LL_StepTotalTasksRequested"); RCRET;
      rc=getdata(step,LL_StepTasksPerNodeRequested,   &StepTasksPerNodeRequested, "LL_StepTasksPerNodeRequested"); RCRET;
      rc=getdata(step,LL_StepTotalNodesRequested,     &StepTotalNodesRequested,   "LL_StepTasksPerNodeRequested"); RCRET;

      TotalNodesR_min=1;TotalNodesR_max=1; 
      if (StepTotalNodesRequested) {
	if(sscanf(StepTotalNodesRequested,"%d,%d",&TotalNodesR_min,&TotalNodesR_max)!=2) {
	  TotalNodesR_min=1;TotalNodesR_max=1; 
	} 
      }
      rc=getdata(step,LL_StepBlocking,        &StepBlocking,       "LL_StepBlocking"); RCRET;
      rc=getdata(step,LL_StepRestart,         &StepRestart,        "LL_StepRestart"); RCRET;
      rc=getdata(step,LL_StepNodeUsage,       &StepNodeUsage,      "LL_StepNodeUsage"); RCRET;
      rc=getdata(step,LL_StepTaskGeometry,    &StepTaskGeometry,   "LL_StepTaskGeometry"); RCRET;
      rc=getdata(step,LL_StepSystemPriority,  &StepSystemPriority, "LL_StepSystemPriority"); RCRET;

      StepStepSystemTime64=StepStepUserTime64=0;
      StepUserSystemPriority=1;
      if (StepState == STATE_RUNNING) { 
	rc=getdata(step,LL_StepDispatchTime,   &StepDispatchTime,   "LL_StepDispatchTime"); RCRET;
	rc=getdata(step,LL_StepMachineCount,   &StepMachineCount,   "LL_StepMachineCount");  RCRET;

	rc=getdata(step,LL_StepUserSystemPriority, &StepUserSystemPriority,   "LL_StepUserSystemPriority"); RCRET;
	rc=getdata(step,LL_StepStepSystemTime64, &StepStepSystemTime64,   "LL_StepStepSystemTime64"); RCRET;
	rc=getdata(step,LL_StepStepUserTime64, &StepStepUserTime64,   "LL_StepStepUserTime64"); RCRET;
	StepEndTime=StepDispatchTime;
	StepEndTime += StepWallClockLimitHard;
	  
      }  
#ifdef BGL
      rc=getdata(step,LL_StepBgPartitionRequested, &StepBgPartitionRequested,   "LL_StepBgPartitionRequested"); RCRET;
      rc=getdata(step,LL_StepBgSizeRequested,      &StepBgSizeRequested,        "LL_StepBgSizeRequested"); RCRET;
      rc=getdata(step,LL_StepBgPartitionAllocated, &StepBgPartitionAllocated,   "LL_StepBgPartitionAllocated"); RCRET;
      rc=getdata(step,LL_StepBgShapeRequested, &StepBgShapeRequested,   "LL_StepBgShapeRequested"); RCRET;
      rc=getdata(step,LL_StepBgShapeAllocated, &StepBgShapeAllocated,   "LL_StepBgShapeAllocated"); RCRET;
#endif
      mystate=2;
      if (StepState == STATE_IDLE) mystate=0;
      if (StepState == STATE_RUNNING) mystate=1;
	
      taskspernode=0;
      totaltasks=0;

      if ((StepState != STATE_RUNNING) ) {
	/* no machines given if job not running */
	StepMachineCount=TotalNodesR_max;
      }
	
      if((StepTotalTasksRequested==0) && (StepTasksPerNodeRequested==0)) {
	taskspernode=1;
	totaltasks=taskspernode*StepMachineCount;
      } else {
	if(StepTotalTasksRequested>0) {
	  totaltasks=StepTotalTasksRequested;
	  if(StepMachineCount>0) {
	    taskspernode=totaltasks/StepMachineCount;
	  } else {
	    taskspernode=1;
	  }
	} else {
	  taskspernode=StepTasksPerNodeRequested;
	  totaltasks=StepMachineCount*StepTasksPerNodeRequested;
	}
      }
        
	
      consmem=conscpu=1;

      cnt=0;strcpy(lastname,"notinit");
      strcpy(instnames,"");
      while(node) {
	task=NULL;
	rc=_getdata(node,LL_NodeRequirements,   &NodeRequirements,     "LL_NodeRequirements"); RCRET;
	rc=_getdata(node,LL_NodeGetFirstTask,   &task,                 "LL_NodeGetFirstTask"); RCRET;
	while(task) {
	  resource_req = NULL;
	  rc=_getdata(task,LL_TaskExecutable,                    &TaskExecutable,          "LL_TaskExecutable"); RCRET;
	  rc=_getdata(task,LL_TaskExecutableArguments,           &TaskExecutableArguments, "LL_TaskExecutableArguments"); RCRET;
	  rc=_getdata(task,LL_TaskGetFirstResourceRequirement,   &resource_req,     "LL_TaskGetFirstResourceRequirement"); RCRET;
	  while(resource_req) {
	    rc=getdata(resource_req,LL_ResourceRequirementName,    &resname,   "LL_ResourceRequirementName"); RCRET;
	    rc=getdata(resource_req,LL_ResourceRequirementValue64, &value64,   "LL_ResourceRequirementValue64"); RCRET;
	    if(!strcmp(resname,"Consumablecpus")) {conscpu=(int) value64;}
	    if(!strcmp(resname,"Consumablememory")) {consmem=(int) value64;}
	    free(resname);
	    rc=getdata(task,LL_TaskGetNextResourceRequirement,   &resource_req,     "LL_TaskGetNextResourceRequirement"); RCRET;
	  }
	  /* Machines and number of tasks */
	  if ((StepState == STATE_RUNNING) && (totaltasks>1)) { 
	    rc=getdata(task, LL_TaskIsMaster,   &TaskIsMaster,     "LL_TaskIsMaster");
	    nnodes=0;
	    if(!TaskIsMaster) {
	      rc=getdata(task, LL_TaskTaskInstanceCount,   &TaskTaskInstanceCount,     "LL_TaskTaskInstanceCount"); RCRET;

	      for (j=0 ; j<TaskTaskInstanceCount ; ++j) { 
		if (j==0) rc=getdata(task, LL_TaskGetFirstTaskInstance,   &instance,     "LL_TaskGetFirstTaskInstance"); RCRET;
		if (j>0)  rc=getdata(task, LL_TaskGetNextTaskInstance,    &instance,     "LL_TaskGetNextTaskInstance"); RCRET;

		rc=getdata(instance,LL_TaskInstanceMachineName,   &instance_machname,   "LL_TaskInstanceMachineName"); RCRET;
		  
		if(strcmp(lastname,instance_machname)==0) {
		  cnt++;
		} else {
		  if(cnt>0) {
		    if(nnodes>0) strcat(instnames,","); 
		    sprintf(TempBuff,"(%s,%d)",lastname,cnt*conscpu);
		    strcat(instnames,TempBuff);  
		    nnodes++;
		  }
		  strcpy(lastname,instance_machname);cnt=1;
		}
		free(instance_machname);
	      } /* for instances */

	      if(cnt>0) {
		if(nnodes>0) strcat(instnames,","); 
		sprintf(TempBuff,"(%s,%d)",lastname,cnt*conscpu);
		strcat(instnames,TempBuff);  
		strcpy(lastname,instance_machname);cnt=0;
		nnodes++;
	      }
	    } /* not master task */
	  } /* step is running */

	  rc=getdata(node, LL_NodeGetNextTask, &task, "LL_NodeGetNextTask");
	} /* while task */

	rc=getdata(step, LL_StepGetNextNode, &node, "LL_StepGetNextNode");
      } /* while node */

      rc=getdata(step,LL_StepComment,   &StepComment,   "LL_StepComment");	

      /* serial job steps */
      if ((StepState == STATE_RUNNING) && (totaltasks==1) && (StepMachineCount==1) ) {
	strcpy(instnames,"");
	rc=getdata(step,LL_StepGetFirstMachine,   &machine,   "LL_StepGetFirstMachine"); RCRET;
	rc=getdata(machine,LL_MachineName,        &machname,  "LL_MachineName"); RCRET;
	sprintf(TempBuff,"(%s,%d)",machname,1*conscpu);
	strcat(instnames,TempBuff);  
	free(machname);               
      }
	
      printf("\n");
      printf("<job\n");
      printf("     \t job_step=\"%s\"\n",         LocalMach);
      printf("     \t job_name=\"%s\"\n",         JobName);
      prtime("     \t job_queuedate=\"%s\"\n",    &JobSubmitTime);
#ifndef DEMO
      printf("     \t job_owner=\"%s\"\n",        CredentialUserName);
#else
      for(i=0;i<act_num_users;i++) {
	if(!strcmp(CredentialUserName,user_list[i])) {
	  break;
	}
      }
      if(i>=act_num_users) {
	user_list[act_num_users++] = strdup(CredentialUserName);
	i=act_num_users;
      }
      printf("     \t job_owner=\"User#%03d\"\n",        i);
#endif
      printf("     \t job_queue=\"%s\"\n",        StepJobClass);
      printf("     \t job_status=\"%d\"\n",       mystate);
      printf("     \t job_statusnr=\"%d\"\n",     StepState);
      printf("     \t job_statuslong=\"%s\"\n",   StepStateStr[StepState]);
      printf("     \t job_sysprio=\"%d\"\n",      StepSystemPriority);
      printf("     \t job_totaltasks=\"%d\"\n",   totaltasks);
      printf("     \t job_taskspernode=\"%d\"\n", taskspernode);
      printf("     \t job_totaltasksR=\"%d\"\n",  StepTotalTasksRequested);
      printf("     \t job_taskspernodeR=\"%d\"\n",StepTasksPerNodeRequested);
      printf("     \t job_nummachines=\"%d\"\n",  StepMachineCount);
      printf("     \t job_conscpu=\"%d\"\n",      conscpu);
      printf("     \t job_consmem=\"%d\"\n",      consmem);

      {
	char *p;
	for(p=StepComment;(*p!='\0');p++) 	{
	  if (*p=='\"') {*p=' ';}
	}
      }
      printf("     \t job_comment=\"%s\"\n",      StepComment);
#ifndef DEMO
      printf("     \t job_taskexec=\"%s\"\n",     TaskExecutable);
#else
      printf("     \t job_taskexec=\"%s\"\n",     "path to executable");
#endif
      printf("     \t job_exargs=\"%s\"\n",       TaskExecutableArguments);
      printf("     \t job_node_usage=\"%s\"\n",   StepNodeUsageV[StepNodeUsage]);
      printf("     \t job_wall=\"%d\"\n",         StepWallClockLimitHard);
      printf("     \t job_wallsoft=\"%d\"\n",     StepWallClockLimitSoft);
      printf("     \t job_cpu=\"%d\"\n",         StepCpuStepLimitHard);
      printf("     \t job_cpusoft=\"%d\"\n",     StepCpuStepLimitSoft);
      if(StepTotalNodesRequested) printf("     \t job_totalnodesR=\"%s\"\n", StepTotalNodesRequested);
      if(StepRestart==0) 	    printf("     \t job_restart=\"no\"\n");
      else             	    printf("     \t job_restart=\"yes\"\n");

#ifdef BGL
      printf("     \t job_bgl_partrequ=\"%s\"\n",      StepBgPartitionRequested);
      printf("     \t job_bgl_partalloc=\"%s\"\n",     StepBgPartitionAllocated);
      printf("     \t job_bgl_sizerequ=\"%d\"\n",      StepBgSizeRequested);
      printf("     \t job_bgl_shaperequ=\"%s\"\n",     StepBgShapeRequested);
      printf("     \t job_bgl_shapealloc=\"%s\"\n",    StepBgShapeAllocated);
#endif

      if (StepState == STATE_RUNNING) { 
	printf("     \t job_userprio=\"%d\"\n",        StepUserSystemPriority);
	printf("     \t job_usertime=\"%ld\"\n",        StepStepUserTime64/1000000);
	printf("     \t job_cputime=\"%ld\"\n",        StepStepSystemTime64/1000000);
	prtime("     \t job_dispatchdate=\"%s\"\n",    &StepDispatchTime);
	prtime("     \t job_enddate=\"%s\"\n",         &StepEndTime);
	printf("     \t job_nodelist=\"%s\"\n",        instnames);
      } else {
	printf("     \t job_dispatchdate=\"-\"\n");
	printf("     \t job_enddate=\"-\"\n");
	printf("     \t job_nodelist=\"-\"\n");
      }
      printf("     />\n");

      if (StepState == STATE_RUNNING) { 
	cpus=taskspernode*StepMachineCount*conscpu;
	if(cpus>=32) count_cpus_running+=cpus;
	else         count_cpus_alloc+=cpus;

      }
	
#ifdef BGL
      if (StepBgPartitionRequested) {free(StepBgPartitionRequested);StepBgPartitionRequested=NULL;}
      if (StepBgPartitionAllocated) {free(StepBgPartitionAllocated);StepBgPartitionAllocated=NULL;}
      if (StepBgShapeRequested) {free(StepBgShapeRequested);StepBgShapeRequested=NULL;}
      if (StepBgShapeAllocated) {free(StepBgShapeAllocated);StepBgShapeAllocated=NULL;}
#endif
      if (StepJobClass) {free(StepJobClass);StepJobClass=NULL;}
      if (TaskExecutable) {free(StepComment);StepComment=NULL;}
      if (TaskExecutable) {free(TaskExecutable);TaskExecutable=NULL;}
      if (TaskExecutableArguments) {free(TaskExecutableArguments);TaskExecutableArguments=NULL;}
      if (StepID) {free(StepID);StepID=NULL;}
      if (StepTotalNodesRequested) {free(StepTotalNodesRequested);StepTotalNodesRequested=NULL;}
      if (StepTaskGeometry) {free(StepTaskGeometry);StepTaskGeometry=NULL;}
      if (NodeRequirements) {free(NodeRequirements);NodeRequirements=NULL;}
      if (resource_req) {free(resource_req);resource_req=NULL;}

      rc=getdata(job,LL_JobGetNextStep,&step,"LL_JobGetNextStep");
    } /* while step */

    if (CredentialUserName) {free(CredentialUserName);CredentialUserName=NULL;}                   
    if (JobName) {free(JobName);JobName=NULL;}

    job = ll_next_obj(queryObject); 
  } /* while job */


  /*    if () {free();=NULL;} */

  /* free objects obtained from Negotiator */
  rc = ll_free_objs(queryObject);   if (rc != 0) {sprintf(Message, "LL_freeobjs failed");   report(rc, Message);}
  rc = ll_deallocate(queryObject);  if (rc != 0) {sprintf(Message, "LL_deallocate failed"); report(rc, Message);}

  return(1);
}


int query_machines() {
  LL_element *queryObject=NULL,*job=NULL, *node=NULL;
  LL_element *machine = NULL, *resource=NULL;        
  int rc, cnt, nnodes; 
  int obj_count,err_code;
  char lastname[B_SIZE];
  char instnames[36*B_SIZE];
  char *MachineName=NULL, *resname=NULL;
  char *MachineStartdState, *MachineArchitecture;
  char **MachineConfiguredClassList;
  int64_t value64;
  int MachineScheddState,MachineScheddTotalJobs;
  double load_avg;
  char **p;

  /* init counter for usagestr */
  count_cpus=count_cpus_running=count_cpus_alloc=0;

    /* MACHINE INFORMATION */
  queryObject = ll_query(MACHINES);
  if (!queryObject) { fprintf(stderr,"Query JOBS: ll_query() returns NULL.\n");   exit(1);  }

  rc = ll_set_request(queryObject, QUERY_ALL,NULL,ALL_DATA);
  if (rc) {    fprintf(stderr,"Query MACHINES: ll_set_request() return code is non-zero.\n"); exit(1);  }

  /* Get the machine objects from the LoadL_negotiator (central manager) daemon */
  machine = ll_get_objs(queryObject, LL_CM, NULL, &obj_count, &err_code);
  if (machine == NULL) { fprintf(stderr,"Query MACHINES: ll_get_objs() returns NULL. Error code = %d\n", err_code); }

  /* Process the machine objects */
  while(machine) {
    int realmem_total=0;
    int realmem_avail=0;
    int realmem_used=0;
    int consmem_total=0;
    int consmem_avail=0;
    int consmem_used=0;
    int swapspace=0;
    int cpu_total=0;
    int cpu_avail=0;
    int cpu_run=0;
    int MachineCPUs=0;
    int MachineMaxTasks=0;
    double MachineSpeed=0;

    printf("\n");
    printf("<node \n");

/*      rc=getdata(machine,LL_,   &,   "LL_"); */

    rc=getdata(machine,LL_MachineName,   &MachineName,   "LL_MachineName");
    if(rc!=0) return(0);
    printf("     \t node_name=\"%s\"\n", MachineName);
    rc=getdata(machine,LL_MachineStartdState,   &MachineStartdState,   "LL_MachineStartdState");
    printf("     \t node_state=\"%s\"\n", MachineStartdState);
    rc=getdata(machine,LL_MachineArchitecture,   &MachineArchitecture,   "LL_MachineArchitecture");
    printf("     \t node_arch=\"%s\"\n", MachineArchitecture);
    rc=getdata(machine,LL_MachineCPUs,   &MachineCPUs,   "LL_MachineStartdState");
    printf("     \t node_cpus=\"%d\"\n", MachineCPUs);
    rc=getdata(machine,LL_MachineMaxTasks,   &MachineMaxTasks,   "LL_MachineMaxTasks");
    printf("     \t node_maxtasks=\"%d\"\n", MachineMaxTasks);
    rc=getdata(machine,LL_MachineSpeed,   &MachineSpeed,   "LL_MachineSpeed");
    printf("     \t node_speed=\"%f\"\n", MachineSpeed);
    rc=getdata(machine,LL_MachineScheddState,   &MachineScheddState,   "LL_MachineScheddState");
    printf("     \t node_schedd=\"%d\"\n", MachineScheddState);
    rc=getdata(machine,LL_MachineScheddTotalJobs,   &MachineScheddTotalJobs,   "LL_MachineScheddTotalJobs");
    printf("     \t node_scheddjobs=\"%d\"\n", MachineScheddTotalJobs);
    if((MachineScheddState==0) && (MachineScheddTotalJobs>0)) {
	machine_list[act_num_machines] = strdup(MachineName);
	act_num_machines++;

    }

#ifdef DOCLASSLIST
    rc=getdata(machine,LL_MachineConfiguredClassList,   &MachineConfiguredClassList,   "LL_MachineConfiguredClassList");
    if((rc==0) && (MachineConfiguredClassList!=NULL)) {
      printf("     \t node_avail_classes=\"");
      cnt=0;strcpy(lastname,"notinit");
      strcpy(instnames,"");
      p=MachineConfiguredClassList;
      while((*p) && (**p!='\0')) { 
	if(strcmp(lastname,*p)==0) {
	  cnt++;
	} else {
	  if(cnt>0) {
	    if(nnodes>0) strcat(instnames,","); 
	    printf("(%s,%d)",lastname,cnt);
	  }
	  strncpy(lastname,*p,B_SIZE-2);cnt=1;
	}
	/*	fprintf(stderr,"address: %d %s %s\n",p,MachineName,*p); */
	p++;
	
      }
      if(cnt>0) {
	if(nnodes>0) strcat(instnames,","); 
	printf("(%s,%d)",lastname,cnt);
      }
      printf("\"\n");
    } else {
      printf("     \t node_avail_classes=\"\"\n");
    }
#else
    printf("     \t node_avail_classes=\"\"\n");
#endif
    printf("      >\n");

   if (strcmp(MachineStartdState, "Down") != 0) {
      rc=getdata(machine,LL_MachineRealMemory64,   &value64,   "LL_MachineRealMemory64");
      if (!rc) realmem_total=value64;
      rc=getdata(machine,LL_MachineFreeRealMemory64,   &value64,   "LL_MachineFreeRealMemory64");
      if (!rc) realmem_avail=value64;
      realmem_used=realmem_total-realmem_avail;
      rc=getdata(machine,LL_MachineVirtualMemory64,   &value64,   "LL_MachineVirtualMemory64");
      if (!rc) swapspace=value64;
      rc=getdata(machine,LL_MachineLoadAverage,   &load_avg,   "LL_MachineLoadAverage");
    }

    /* Consumable Resources associated with this machine */
    consmem_total=consmem_avail=-1;
    cpu_total=cpu_avail=-1;
    resource = NULL;
    rc=getdata(machine,LL_MachineGetFirstResource,   &resource,   "LL_MachineGetFirstResource");
    while(resource) {
      rc=getdata(resource,LL_ResourceName,   &resname,   "LL_ResourceName");
/*        if (!rc) {printf("Resource Name = %s\n", resname);}  */
      rc=_getdata(resource,LL_ResourceInitialValue64,   &value64,   "LL_ResourceInitialValue64");
      if (!rc) {
	if(strcmp(resname,"ConsumableMemory")==0) consmem_total=value64;
	if(strcmp(resname,"ConsumableCpus")==0) cpu_total=value64;
      }
      rc=_getdata(resource,LL_ResourceAvailableValue64,   &value64,   "LL_ResourceAvailableValue64");
      if (!rc) {
	if(strcmp(resname,"ConsumableMemory")==0) consmem_avail=value64;
	if(strcmp(resname,"ConsumableCpus")==0) cpu_avail=value64;
      }
      resource = NULL;
      free(resname);
      rc=getdata(machine,LL_MachineGetNextResource,   &resource,   "LL_MachineGetNextResource");
    }

    consmem_used=consmem_total-consmem_avail;
    cpu_run=cpu_total-cpu_avail;

    printf("   <mem\n");
    printf("     \t mem_total=\"%d\"\n", realmem_total);
    printf("     \t mem_avail=\"%d\"\n", realmem_avail);
    printf("     \t mem_used=\"%d\"\n", realmem_used);
    printf("     \t consmem_total=\"%d\"\n", consmem_total);
    printf("     \t consmem_avail=\"%d\"\n", consmem_avail);
    printf("     \t consmem_used=\"%d\"\n", consmem_used);
    printf("     \t mem_unit=\"mb\"\n");
    printf("    />\n");

    printf("   <cpu\n");
    printf("     \t cpu_total=\"%d\"\n", cpu_total);
    printf("     \t cpu_avail=\"%d\"\n", cpu_avail);
    printf("     \t cpu_run=\"%d\"\n", cpu_run);
    printf("    />\n");

    count_cpus+=cpu_total;
 
    printf("   <load\n");
    printf("     \t load_avg=\"%f\"\n", load_avg);
    printf("    />\n");

    printf("</node>\n");

    free(MachineStartdState);
    free(MachineArchitecture);

    machine = ll_next_obj(queryObject);
  }



  /* Free objects obtained from Negotiator */
  ll_free_objs(queryObject);
  /* Free query element */
  ll_deallocate(queryObject);

}

/* information is in  count_cpus,count_cpus_running,count_cpus_alloc */
int print_usagestr() {

  printf("<usage date=\"%s\" nodes=\"%d\" running=\"%d\" alloc=\"%d\"\n",
	 DateStr,count_cpus,count_cpus_running,count_cpus_alloc);
  printf("       usagestr=\"%s,%d,%d,%d\">\n",
	 DateStr,count_cpus,count_cpus_running,count_cpus_alloc);
  printf("</usage>\n");

}


int main(int argc, char *argv[]) {   
  /* Define local variables */
  LL_element *queryObject=NULL, *mcluster=NULL;
  int i,j, num, rc, err, parm; 
  int instance_taskid;
  int do_master=1;
  char **cluster_list = NULL;
  char *cluster_name = NULL;
#ifdef MULTICLUSTER
  LL_element *errObj=NULL;
  LL_cluster_param cluster;
#endif

/*    fprintf(stderr,"number of options: %d\n",argc); */
/*    for(i=0;i<argc;i++) { */
/*      fprintf(stderr," option[%d]: %s\n",i,argv[i]); */
/*    } */

  printf("<?xml version=\"1.0\"?>\n");

  parm=1;
  if(argc>1) {
    if( argv[parm][0] == '-' ) {
      if ((argv[parm][1] == 's' ) || (argv[parm][1] == 'x'))  {
	do_master=0;
	parm++;
      }
    }
  }
/*    fprintf(stderr,"master_mode= %d [%d] argc=%d %s >%c<>%c<\n",do_master,parm,argc,argv[0],argv[1][0],argv[1][1]); */

#ifdef MULTICLUSTER
  if(argc==0) {
#endif

    act_num_machines=0;
    query_system();
    query_machines();
    if(do_master) {
      query_classes(LL_CM,NULL);
      query_jobs(LL_CM,NULL);
      print_usagestr();
    } else {
      for(i=0;i<act_num_machines;i++) {
	fprintf(stderr,"llqxml: query schedd on host %s\n",machine_list[i]);
	query_classes(LL_SCHEDD,machine_list[i]);
	query_jobs(LL_SCHEDD,machine_list[i]);
	print_usagestr();
      }
    }

#ifdef MULTICLUSTER
  } else {

    if(!strcmp(argv[parm],"any")) {
/*        fprintf(stderr,"WF: any\n"); */
      /* Initialize the query for MClusters */
      queryObject = ll_query(MCLUSTERS);
      rc = ll_set_request(queryObject,QUERY_ALL,NULL,ALL_DATA);
      /* Request the objects from the Schedd daemon */
      mcluster = ll_get_objs(queryObject,LL_SCHEDD,NULL,&num,&err);

      /* Malloc cluster_list according to the number of mclusters */
      cluster_list=(char **)calloc(num,sizeof(char *));	
      i = 0;
      if (mcluster == NULL) {
	fprintf(stderr,"cluster_metric_job_class: Unable to obtain cluster objects for metric request of \"any\".\n");
	free(cluster_list);exit(-1);
      } else {
	/* Loop through the list and process */
	while(mcluster) {
	  if (ll_get_data(mcluster, LL_MClusterName, &cluster_name)==0) {
	    if (cluster_name) {
	      cluster_list[i++] = strdup(cluster_name);
	      free(cluster_name);
	      cluster_name=NULL;
	    }
	  }
	  mcluster = ll_next_obj(queryObject);
	}
      }
    } else {			/* not any */
      num=argc-1;
      cluster_list=(char **)calloc(num,sizeof(char *));	
      j = 0;
      for (i=parm; i <= num; i++) {
	cluster_list[j] = strdup(argv[i]);
	j++;
      }
    }

    cluster.cluster_list = (char **)calloc(2,sizeof(char *));

    query_system();

    for (i=0; i<num; i++) {
      cluster.cluster_list[0] = cluster_list[i];
      cluster.cluster_list[1] = NULL;
      cluster.action = CLUSTER_SET;
      
      rc = ll_cluster(LL_API_VERSION,&errObj,&cluster);
      fprintf(stderr,"WF: query of cluster %s\n",cluster_list[i]);

      act_num_machines=0;
      query_machines();
      if(do_master) {
	query_classes(LL_CM,NULL);
	query_jobs(LL_CM,NULL);
	print_usagestr();
      } else {
	for(i=0;i<act_num_machines;i++) {
	  fprintf(stderr,"llqxml: query schedd on host %s\n",machine_list[i]);
	query_classes(LL_SCHEDD,machine_list[i]);
	query_jobs(LL_SCHEDD,machine_list[i]);
	print_usagestr();
	}
      }
      
      cluster.action = CLUSTER_UNSET;
      rc = ll_cluster(LL_API_VERSION,&errObj,&cluster);
    }
  }
#endif
  
  printf("</system>\n");
  

  exit(0); 
} /* end main */

