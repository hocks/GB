#!/usr/local/bin/perl

#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2005, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#

# $Author: zdv087 $
# $Revision: 1.1 $
# $Date: 2005/05/19 14:41:52 $
# $Source: /cvs/cvsroot/llview/util/getllqxml_template.pl,v $

use Time::HiRes qw ( time );

$LOGPATH="/usr/users/frings/crontab";
$DATAPATH="/www/kfa/llview/.data";

printf( "getllqxml.pl: start at ".`date`);
if (-f "$LOGPATH/RUNNING") {
	printf( "getllqxml.pl: another getllqxml process is running ... exiting\n");
	exit(1);
}

$SSHCMD="ssh -x userid\@host pathtollqxml/llqxml > $LOGPATH/llqxml.dat";
open(RUNNING,">$LOGPATH/RUNNING");
print RUNNING "$$\n";
close(RUNNING);

printf(  "getllqxml.pl: executing \"$SSHCMD\"\n");
$tstart=time;
system($SSHCMD);
$tdiff=time-$tstart;
printf( "getllqxml.pl: executing rc=$? in %10.4f s\n",$tdiff);

if($?==0) {
	$CMD="mv $LOGPATH/llqxml.dat $DATAPATH/llqxml.dat";
	printf(  "getllqxml.pl: executing \"$CMD\"\n");
	system($CMD);
	printf(  "getllqxml.pl: executing rc=$?\n");
}

unlink("$LOGPATH/RUNNING");
printf( "getllqxml.pl: end at ".`date`);
