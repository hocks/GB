#!/usr/local/bin/perl -w

#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2005, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#

# $Author: zdv087 $
# $Revision: 1.1 $
# $Date: 2005/05/19 14:49:18 $
# $Source: /cvs/cvsroot/llview/util/getwwwdata_template.pl,v $

use LWP::UserAgent;
use Time::HiRes qw ( time );
use Compress::Zlib;

$WWWSERVER    = "wwwserver";
$PATHTOFILE   = "/data/llqxml.dat";
$PATHTOTARFILE="~/data/llview";
$FILENAMEMASK = "llqxml_%08d.xml.gz";
$AUTUSERID="userid";
$AUTPASSWD="password";

$ua = LWP::UserAgent->new;
$ua->timeout(10);
$ua->credentials(
		 $WWWSERVER.":80",
		 'LLview',
		 $AUTUSERID => $AUTPASSWD
		 );
$tstart=time;
$response = $ua->get("http://".$WWWSERVER."/".$PATHTOFILE);
$data=$response->content;  # or whatever
$tend=time;
$tdiff=$tend-$tstart;

if($data) {
    $data=~/system_time=\"(\d+)\/(\d+)\/(\d+)-(\d+):(\d+):(\d+)\"/s;
    ($month,$day,$year,$hour,$min,$sec)=($1,$2,$3,$4,$5,$6);
    
    $tarfilename=sprintf("llview_data_%02d.%02d.%02d.tar",$year,$month,$day);
    $tarfile="$PATHTOTARFILE/$tarfilename";
    
    $nr=0;
    if(-f $tarfile) {
	open(IN,"tar tf $tarfile|");
	while($fn=<IN>) {
	    if($fn=~/_(\d+)./) {
		$nr=$1 if ($1>$nr);
	    }
	}
	close(IN);
	$tarcmd="tar uf "; 
    } else {
	$nr=0;
	$tarcmd="tar cf "; 
    }
    $nr++;
    $filename=sprintf($FILENAMEMASK,$nr);
    $gz=gzopen("$PATHTOTARFILE/$filename","wb") ;
     $gz->gzwrite($data);
    $gz->gzclose();
    $cmd="(cd $PATHTOTARFILE;$tarcmd $tarfilename $filename)";
    printf("llview: got data for (%02d/%02d/%02d %02d:%02d:%02d) in %10.4f sec ",$month,$day,$year,$hour,$min,$sec,$tdiff);
    print $cmd,"\n";
    system($cmd);
    unlink("$PATHTOTARFILE/$filename");
} else {
    printf("llview: errors while getting data from http://$WWWSERVER/$PATHTOFILE\n");
}


