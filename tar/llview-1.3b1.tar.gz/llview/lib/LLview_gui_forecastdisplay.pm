# $Source: /cvs/cvsroot/llview/lib/LLview_gui_forecastdisplay.pm,v $
# $Author: zdv087 $
# $Revision: 1.16 $
# $Date: 2007/07/23 07:25:31 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
#
# on BGL: nodes will be counted (1 node are 2 CPUs, -> 1 CO, 2 VN processes) 
#
#

package LLview_gui_forecastdisplay;
use strict;
use Time::Local;
use Time::HiRes qw ( time );
use Data::Dumper;
use Tk;
use LLview_schedsim;
use LLview_gui_jobstackhull;
use LLview_gui_jobstackhullv;

# for callback functions
my($selfref)=-1;

my($debug)=0;
my($ISNOTOPEN)=0;
my($ISOPEN)=1;

my @hex = ("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
my %hextod = ("0" => 0,"1" => 1,"2" => 2,"3" => 3,"4" => 4,"5" => 5,"6" => 6,"7" => 7,
	      "8" => 8,"9" => 9,"A" => 10,"B" => 11,"C" => 12,"D" => 13,"E" => 14,"F" => 15);

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_gui_forecastdisplay: new %s\n",ref($proto)) if($debug>=3);
    $self->{POSX}       = 485;
    $self->{POSY}       = 730;
    $self->{WIDTH}      = 435;
    $self->{HEIGHT}     = 130;
    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}     = "-*-Helvetica-Bold-R-Normal--*-80-*-*-*-*-*-*";
    $self->{ITEMS}      = [];
    $self->{LEFTPAD}    = 30;
    $self->{RIGHTPAD}    = 0;
    $self->{BOTTOMPAD}     = 40;
    $self->{BOTTOMPADTOP}  = 15;
    $self->{MINNODES}   = 8;
    $self->{TIMEBACK}    = 24;
    $self->{TIMEFORWARD} = 48;
    $self->{COLORMODE}   = "byuser";
    $self->{SHOWWEEKDAY} = 1;
    $self->{SPLITSTACK}  = 1;
    $self->{SPLITSTACKREGSMALLNODES}  = "R00-M[01]";
#    $self->{SPLITSTACKREGLARGENODES}  = "R(01|10|11|20|21|30|31)-M[01]";
    $self->{NOCONTSELECT} = 1;
    $self->{NOCONTREG}           = "(nocont|nocsmall)";
    $self->{NOCONTCOMMENTREG}    = "NOCONT";
    $self->{BUILDREADY}   = 0;
    $self->{SHOWID}       = 1;
    $self->{CLUSTERNAME}  = shift||"-"; # needed for button callback function 
    $self->{VERBOSE}      = 1;
    $self->{WAITARRANGEVERT}=1;
    $self->{CHECKMAXSTARTER}=0;
    $self->{NUMJOBS}=0; 
    $self->{MAXNUMJOBS}=100000; 
    $self->{SHOWMARKERPERMANENT}=0; 
    $self->{DOSCREENSHOT}=0; 
    $self->{DOSCREENLOOP}=0; 
    $self->{SCREENSHOTCOUNTER}=0; 
    $self->{USESCREENSHOTCOUNTER}=0; 
    $self->{SCREENSHOTTIMEPOS}=0; 
    $self->{SEARCHSTR}       = "";

    $self->{DOSCHEDSIM}  = 0;
    $self->{SCHEDSIMOBJ} = undef;
    $self->{SCHEDSIMLASTDATE}="-";
    $self->{PROTO}       = 0; # 1 = generate proto
    $self->{PROTOFN}     = "simulate.log"; 
    $self->{PRINTPROGRESS}  = 1;
    $self->{PRINTSTAT}      = 1;
    $self->{CALCPRIO}       = 0;
    $self->{PRIOFORMULA}    = "-";
    $self->{PRIOMACHINEFORMULA}    = "-";
    
    $self->{BACKFILLING} = 1;
    $self->{SCHEDNUMTD}  = 1; 

    $self->{LASTPARMS}  = "-";
    
    bless $self, $class;
    if($selfref==-1)  {
	$selfref=\$self;
    } else {
	printf("WARNING: double constructor call to LLview_gui_forecast ...\n")
    }
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($i,$name,$subtype);
    my $frames=$dataobj->{FRAMES};
    
    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;
    $self->{OPTIONOBJECT}=$optobj;

    $subtype="General";
    $optobj->register_option("Forecast","POSX", -label => "posx", 
			     -caller => $self,-pack => 2,-subtype => $subtype,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option("Forecast","POSY", -label => "posy", 
			     -caller => $self,-pack => 2, -subtype => $subtype,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSY}, -step => 10);

    $optobj->register_option("Forecast","HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2, -subtype => $subtype,
			     -type => "int", -min => 50, -max => 1200, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option("Forecast","WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2, -subtype => $subtype,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option("Forecast","TIMEBACK", -label => "History Time (h)", 
			     -caller => $self,-pack => 2, -subtype => $subtype,
			     -type => "int", -min => 0, -max => 1240, -default => $self->{TIMEBACK}, -step => 4);
    $optobj->register_option("Forecast","TIMEFORWARD", -label => "Future Time (h)", 
			     -caller => $self,-pack => 2, -subtype => $subtype,
			     -type => "int", -min => 0, -max => 1240, -default => $self->{TIMEFORWARD}, -step => 4);

    $optobj->register_option("Forecast","COLOROBJ", -label => "color mode", 
			     -caller => $self, -pack => 1, -subtype => $subtype,
			     -values => ["byuser","byres"],
			     -labels => ["by user","by reservation"],
			     -type => "radiogroup", -default => $self->{COLORMODE});

    $optobj->register_option("Forecast","SHOWWEEKDAY", -label => "Show day of week", 
			     -caller => $self,-pack => 1, -subtype => $subtype,
			     -type => "radio", -default => $self->{SHOWWEEKDAY});

    $optobj->register_option("Forecast","WAITARRANGEVERT", -label => "Vertically Arrangement", 
			     -caller => $self,-pack => 1, -subtype => $subtype,
			     -type => "radio", -default => $self->{WAITARRANGEVERT});

#    $optobj->register_option("Forecast","SHOWID", -label => "Show ID", 
#			     -caller => $self,-pack => 1,
#			     -type => "radio", -default => $self->{SHOWID});
#    $optobj->register_option("Forecast","SPLITSTACK", -label => "Split Stack", 
#			     -caller => $self,-pack => 1,
#			     -type => "radio", -default => $self->{SPLITSTACK});

    $optobj->register_option("Forecast","SPLITSTACKREGSMALLNODES", -label => "Reg.Exp Small nodes", 
			     -caller => $self,-pack => 1, -subtype => $subtype,
			     -type => "string", -default => $self->{SPLITSTACKREGSMALLNODES});

    $optobj->register_option("Forecast","NOCONTSELECT", -label => "select nocont jobs", 
			     -caller => $self,-pack => 1, -subtype => $subtype,
			     -type => "radio", -default => $self->{NOCONTSELECT});
    $optobj->register_option("Forecast","NOCONTREG", -label => "Reg.Exp. NOCONT Jobs (class)", 
			     -caller => $self,-pack => 1, -labelwidth => 25, -subtype => $subtype,
			     -type => "string", -default => $self->{NOCONTREG});
    $optobj->register_option("Forecast","NOCONTCOMMENTREG", -label => "Reg.Exp. NOCONT Jobs (comment)", 
			     -caller => $self,-pack => 1, -labelwidth => 25, -subtype => $subtype,
			     -type => "string", -default => $self->{NOCONTCOMMENTREG});

    $optobj->register_option("Forecast","Font", -label => "Font", 
			     -caller => $self,-pack => 1, -subtype => $subtype,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option("Forecast","BoldFont", -label => "BoldFont",  -subtype => $subtype,
			     -caller => $self,-pack => 1,-subtype => $subtype, 
			     -type => "string", -default => $self->{BFONT1});

    $subtype="Snapshot";

    $optobj->register_option("Forecast","DOSCREENSHOT", -label => "Screenshot after update", 
			     -caller => $self,-pack => 1, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{DOSCREENSHOT});

    $optobj->register_option("Forecast","DOSCREENLOOP", -label => "loop over maxnum", 
			     -caller => $self,-pack => 2, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{DOSCREENLOOP});

    $optobj->register_option("Forecast","USESCREENSHOTCOUNTER", -label => "use counter for fn", 
			     -caller => $self,-pack => 1, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{USESCREENSHOTCOUNTER});

    $optobj->register_option("Forecast","SHOWMARKERPERMANENT", -label => "permanent marker line", 
			     -caller => $self,-pack => 2, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{SHOWMARKERPERMANENT});


    $subtype="Simulator";
    $optobj->register_option("Forecast","DOSCHEDSIM", -label => "use simulator (expert mode)", 
			     -caller => $self,-pack => 1, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{DOSCHEDSIM});

    $optobj->register_option("Forecast","PROTO", -label => "DEBUG: write protocol", 
			     -caller => $self,-pack => 1, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{PROTO});
    $optobj->register_option("Forecast","PROTOFN", -label => "protocol filename", 
			     -caller => $self,-pack => 2, -subtype => $subtype,
			     -type => "string", -default => $self->{PROTOFN});
    $optobj->register_option("Forecast","PRINTPROGRESS", -label => "DEBUG: print progress", 
			     -caller => $self,-pack => 1, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{PRINTPROGRESS});
    $optobj->register_option("Forecast","PRINTSTAT", -label => "DEBUG: print statistics", 
			     -caller => $self,-pack => 2, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{PRINTSTAT});

    $optobj->register_option("Forecast","CALCPRIO", -label => "calculate prio", 
			     -caller => $self,-pack => 2, -labelwidth => 25, -subtype => $subtype,
			     -type => "radio", -default => $self->{CALCPRIO});

    $optobj->register_option("Forecast","PRIOMACHINEFORMULA", -label => "system formula", 
			     -caller => $self,-pack => 1, -fieldwidth => 95, -subtype => $subtype,
			     -type => "string", -default => $self->{PRIOMACHINEFORMULA});

    $optobj->register_option("Forecast","PRIOFORMULA", -label => "formula", 
			     -caller => $self,-pack => 1, -fieldwidth => 95, -subtype => $subtype,
			     -type => "string", -default => $self->{PRIOFORMULA});




    $optobj->register_option("Forecast","BACKFILLING", -label => "enable backfilling", 
			     -caller => $self,-pack => 1, -subtype => $subtype,
			     -type => "radio", -labelwidth => 20,
			     -default => $self->{BACKFILLING}, -step => 1);
    $optobj->register_option("Forecast","SCHEDNUMTD", -label => "number of topdogs", 
			     -caller => $self,-pack => 2, -subtype => $subtype,
			     -type => "int", -min => 0, -max => 10, -labelwidth => 20,
			     -default => $self->{SCHEDNUMTD}, -step => 1);

    $optobj->register_option("Forecast","MAXNUMJOBS", -label => "max. number of jobs", 
			     -caller => $self,-pack => 1, -subtype => $subtype,
			     -type => "int", -min => 1, -max => 100000, 
			     -default => $self->{MAXNUMJOBS}, -step => 10);
   
    

    if($self->{WAITARRANGEVERT}) {
	$self->{TOPHULLOBJ}=LLview_gui_jobstackhullv->new() if(!$self->{TOPHULLOBJ});
	$self->{TOPHULLOBJSMALL}=LLview_gui_jobstackhullv->new() if(!$self->{TOPHULLOBJSMALL});
    } else {
	$self->{TOPHULLOBJ}=LLview_gui_jobstackhull->new() if(!$self->{TOPHULLOBJ});
	$self->{TOPHULLOBJSMALL}=LLview_gui_jobstackhull->new() if(!$self->{TOPHULLOBJSMALL});
    }
    $self->{BOTTOMHULLOBJ}=LLview_gui_jobstackhull->new() if(!$self->{BOTTOMHULLOBJ});
    $self->{BOTTOMHULLOBJSMALL}=LLview_gui_jobstackhull->new() if(!$self->{BOTTOMHULLOBJSMALL});
  
   
    $self->{TOPHULLOBJ}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj);
    $self->{BOTTOMHULLOBJ}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj);
    $self->{TOPHULLOBJSMALL}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj);
    $self->{BOTTOMHULLOBJSMALL}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj);

    $self->{SCHEDSIMOBJ}=LLview_schedsim->new() if(!$self->{SCHEDSIMOBJ});


    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{MAINWIN}->register_steptimer_function("forecastupdate",\&update_screenshot);

    $self->{BUILDREADY}=1;

    return();
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val,$subtype)=@_;
    my($diffx,$diffy,$id);

    print "forecast_sb,optvalchanged: $section,$subtype,$name -> $val ($self->{BUILDREADY}) \#$#{$self->{USAGE}}\n";
    return() if($name eq "PRIOMACHINEFORMULA");
    if ($name eq "Font") {
	$self->{FONT1}=$val;
    } elsif ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
    } elsif ($name eq "WAITARRANGEVERT") {
	$self->{WAITARRANGEVERT}=$val;
	if($self->{WAITARRANGEVERT}) {
	    $self->{TOPHULLOBJ}=LLview_gui_jobstackhullv->new();
	    $self->{TOPHULLOBJSMALL}=LLview_gui_jobstackhullv->new();
	} else {
	    $self->{TOPHULLOBJ}=LLview_gui_jobstackhull->new();
	    $self->{TOPHULLOBJSMALL}=LLview_gui_jobstackhull->new();
	}
	$self->{TOPHULLOBJ}->build($self->{DATAOBJECT},$self->{COLOROBJECT},
				   $self->{INFOOBJECT},$self->{CANVAS},$self->{OPTIONOBJECT});
	$self->{TOPHULLOBJSMALL}->build($self->{DATAOBJECT},$self->{COLOROBJECT},
					$self->{INFOOBJECT},$self->{CANVAS},$self->{OPTIONOBJECT});
    } else {
	$self->{$name}=$val;
    }

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});

    if($self->{DOSCHEDSIM}) {
	if($name=~/(PROTO|PROTOFN|PRINTPROGRESS|PRINTSTAT|BACKFILLING|SCHEDNUMTD|MAXNUMJOBS|CALCPRIO|PRIOFORMULA)/) {
	    printf("WF, optvalchanged: rerun simulator for %s\n",$self->{DATAOBJECT}->{MACHSTATE}->{"system_time"});
	    $self->update_schedsim() if ($self->{BUILDREADY});
	}
    }

    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
 
}

sub set_searchstr {
    my($self) = shift;
    my($str) = @_;
    $self->{SEARCHSTR}=$str;
    return 1;
}

sub register_color_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{COLOROBJECT}=$objref;
    return 1;
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }

    $self->{NODESTARTERS}=[];
    $self->{NODEACTSTARTERS}=[];
    $self->{NODEACTSTARTERSTOPDOG}=[];
    $self->{FREECPUS}=[];
    $self->{FREECPUSTOPDOG}=[];
    $self->{TIMELINE_TS}=[];
    $self->{TIMELINE_FREE}=[];
    $self->{TIMELINE_STARTERS}=[];
    $self->{TIMELINE_JEND}=[];
    $self->{MAINTENANCE_START}=[];
    $self->{MAINTENANCE_END}=[];
    $self->{ACTSTARTERCLASSUSER}={};
    $self->{ACTSTARTERCLASSUSERTOP}={};
    $self->{MAXSTARTERCLASS}={};
    $self->{MAXSTARTERCLASSUSER}={};
    $self->{CLASS2NR}={};
    $self->{NR2CLASS}=[];
    $self->{WAITINGSTEPNAMES}={};
    $self->{WAITINGJOBSTATE}={};
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name);
    my($LEFT_ICON,$left,$leftsubwidget,$leftframe);
    my($RIGHT_ICON,$right,$rightsubwidget,$rightframe);

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    $id=$canvas->createRectangle($self->{POSX},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH},
				 $self->{POSY}+$self->{HEIGHT},
				 -fill => "grey80", -tags => ["forecast"]);
    push(@{$self->{FIXEDITEMS}},$id);
#    $canvas->bind("forecast", '<ButtonRelease-1>' => [sub { my ($c) = @_;
#								  &update_left_cb($Tk::event->x,$Tk::event->y,1)}]);
#    $canvas->bind("forecast", '<ButtonRelease-3>' => [sub { my ($c) = @_;
#								  &update_right_cb($Tk::event->x,$Tk::event->y,1)}]);
    $canvas->bind("forecast", '<Control-ButtonRelease-1>' => [sub { my ($c) = @_;
							    &update_left_cb($Tk::event->x,$Tk::event->y,8)}]);
    $canvas->bind("forecast", '<Control-ButtonRelease-3>' => [sub { my ($c) = @_;
							    &update_right_cb($Tk::event->x,$Tk::event->y,8)}]);

    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				 -fill => "LightSkyBlue2", -tags => ["forecast"]);
    push(@{$self->{FIXEDITEMS}},$id);

    $LEFT_ICON=$self->{INSTPATH}."/lib/images/button-left-small.gif";
    $left = $self->{CANVAS}->Photo(-file => $LEFT_ICON, -format => 'gif');
    $RIGHT_ICON=$self->{INSTPATH}."/lib/images/button-right-small.gif";
    $right = $self->{CANVAS}->Photo(-file => $RIGHT_ICON, -format => 'gif');

    $leftframe=$canvas->Frame( 
			       -relief => "flat", 
			       -borderwidth => 0);
    $id=$leftframe->Button(-text => 'Update',
			   -image => $left,
			   -command => sub { &update_left_left_cb();},
			   -width => 10,
			   -height => 10,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $id=$leftframe->Button(-text => 'Update',
			   -image => $right,
			   -command => sub { &update_left_right_cb();},
			   -width => 10,
			   -height => 10,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $leftsubwidget = $canvas->createWindow($self->{POSX}+$self->{LEFTPAD}+1,$self->{POSY}+19, 
					   -window =>$leftframe, -anchor => "sw");
    push(@{$self->{FIXEDITEMS}},$leftsubwidget);

    $rightframe=$canvas->Frame( 
			       -relief => "flat", 
			       -borderwidth => 0);
    $id=$rightframe->Button(-text => 'Update',
			   -image => $left,
			   -command => sub { &update_right_left_cb();},
			   -width => 10,
			   -height => 10,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $id=$rightframe->Button(-text => 'Update',
			   -image => $right,
			   -command => sub { &update_right_right_cb();},
			   -width => 10,
			   -height => 10,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $rightsubwidget = $canvas->createWindow($self->{POSX}+$self->{WIDTH},$self->{POSY}+19, 
					    -window =>$rightframe, -anchor => "se");
    push(@{$self->{FIXEDITEMS}},$rightsubwidget);


    # for marker line
    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}+$self->{BOTTOMPADTOP},
				 -fill => "grey80");
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}+$self->{BOTTOMPADTOP},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT},
				 -fill => "grey50", -tags => ["forecastmarkerarea"]);
    push(@{$self->{FIXEDITEMS}},$id);
    $self->{INFOOBJECT}->register_bind_motion("forecastmarkerarea",$self);
    $self->{INFOOBJECT}->register_bind_enter("forecastmarkerarea",$self);
    $self->{INFOOBJECT}->register_bind_leave("forecastmarkerarea",$self);
    $self->{INFOOBJECT}->register_category("RESERVATION",$self);
    $self->{INFOOBJECT}->register_category("WAIT",$self);
    $self->{INFOOBJECT}->register_category("WAITNOCONT",$self);
    $self->{INFOOBJECT}->register_category("OWNJOBS",$self);

    $self->{COLOROBJECT}->register_external_updater("WAIT",$self);
    $self->{COLOROBJECT}->register_external_updater("WAITNOCONT",$self);
    $self->{COLOROBJECT}->register_external_updater("RESERVATION",$self);
    $self->{COLOROBJECT}->register_external_updater("OWNJOBS",$self);

}

# starts local simulator of schedsim
sub update_schedsim {
    my($self) = shift;
    my($jobid,$key,$resid);
    my $dataobj=$self->{DATAOBJECT};
    my ($protofn,$help,$actualparms);
    $protofn=$self->{PROTOFN};
    print "WF: $protofn\n";
    if($protofn=~/\%date/) {
	$help=$dataobj->{MACHSTATE}->{"system_time"};
	$help=~s/\//_/gs;
	$help=~s/:/_/gs;
	$help=~s/\./_/gs;
	$protofn=~s/\%date/$help/;
    }
    $actualparms=$dataobj->{MACHSTATE}->{"system_time"}.
	$self->{PROTO}.$protofn.$self->{PRINTPROGRESS}.$self->{PRINTSTAT}.
	    $self->{BACKFILLING}.$self->{SCHEDNUMTD}.$self->{MAXNUMJOBS};
    if(exists($self->{DATAOBJECT}->{MACHSTATE}->{"LLview_prediction"})) {
	return if($actualparms eq $self->{LASTPARMS});
    }
    $self->{LASTPARMS}=$actualparms;

    if(exists($dataobj->{CLASSES})) {
	if(exists($dataobj->{CLASSES}->{"system_sysprio"})) 
	{
	    $self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast",
							   "Simulator","PRIOMACHINEFORMULA",
							   $dataobj->{CLASSES}->{"system_sysprio"});
	}
    }
    foreach $resid (keys(%{$dataobj->{RESERVATION}})) {
	printf( "WF: update_schedsim: a resid=%s\n",$resid);
    }
    printf("WF: update_schedsim: a resid=%s\n",$dataobj->{RESERVATION});
    printf("WF, starting simulator for %s ...\n",$dataobj->{MACHSTATE}->{"system_time"});
    my $tstart=time;
    my $outdata=$self->{SCHEDSIMOBJ}->simulate($dataobj,
					       PROTO          => $self->{PROTO},
					       PROTO_FILENAME => $protofn, 
					       PRINTPROGRESS  => $self->{PRINTPROGRESS},
					       PRINTSTAT      => $self->{PRINTSTAT},
					       BACKFILLING    => $self->{BACKFILLING},
					       NUMTOPDOGS     => $self->{SCHEDNUMTD},
					       MAXNUMJOBS     => $self->{MAXNUMJOBS}
					       );
    my $tdiff=time-$tstart;
    printf("WF, run simulator in %6.4f sec for %s\n",$tdiff,$dataobj->{MACHSTATE}->{"system_time"});

    # store scheduler information in data structure of parser
    foreach $jobid (keys(%{$dataobj->{JOBSTATE}})) {
	foreach $key (keys(%{$outdata->{JOBINFO}->{$jobid}})) {
	    $dataobj->{JOBSTATE}->{$jobid}->{$key}=$outdata->{JOBINFO}->{$jobid}->{$key};
	}
    }

    foreach $resid (keys(%{$dataobj->{RESERVATION}})) {
	printf( "WF: update_schedsim: resid=%s\n",$resid);

	foreach $key (keys(%{$outdata->{RESINFO}->{$resid}})) {
	    $dataobj->{RESERVATION}->{$resid}->{$key}=$outdata->{RESINFO}->{$resid}->{$key};
	}
    }

    $self->{DATAOBJECT}->{MACHSTATE}->{"LLview_prediction"}="inline";
    # for check if simulator is already ran on this data
    $self->{SCHEDSIMLASTDATE}=$self->{DATAOBJECT}->{MACHSTATE}->{"system_time"};
}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$nonewdata)=@_;
    my($i,$cpus,$jobid,$id,$maxnodes,$maxnumber,$nodes,$nodelist,$spec,$node,$book);
    my($px,$py,@py,$dx,$dy,$n,$name,$color,$nr,$ucolor,$unr,$rcolor,$rnr,$usedh,$usedhcut,$starth,$endh);
    my($endx,$numnodes,$nodecnt,$lstarty,$lendy,$user,$endy,$midx);
    my($textcolor,$wall,$cpu,$pair);
    my($tstart,$tdiff);
    my($numnodessmall,$numnodeslarge);
    my $frames=$dataobj->{FRAMES};
    $self->{NUMJOBS}=0; 

    return() if ($frames==0);
    return() if (($self->{TIMEBACK}+$self->{TIMEFORWARD})<=0);
    
    $self->{DX}  =$dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    $self->{DY}  =$dy=($self->{HEIGHT}-$self->{BOTTOMPAD})/($frames);
    $self->{MIDX}=$midx=$self->{POSX} + $self->{LEFTPAD} + ($self->{TIMEBACK}*$dx);
    $self->{MIDXX}=($self->{TIMEBACK}*$dx);
    $dataobj->printsize("forecastupdate: start") if($debug==5);

    $self->clean($dataobj,$colorobj,$canvas);
    $dataobj->printsize("forecastupdate: after clean") if($debug==5);

    # check if simulator must be run, update will be called directly if new data is available
    # update can also be called from optvalchanged if a option has been changed, then the simulator
    # was already called by optvalchanged, only if some expert option was changed
    if($self->{DOSCHEDSIM}) {
	$self->update_schedsim();
    }
   
    $self->{CPUS}=0;
    $self->{NODESIZE}=0;
    $self->{SMALLCPUS}=0;
    $numnodessmall=$numnodeslarge=0;
    for($n=1;$n<=$frames;$n++) {
 	$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$cpus=$dataobj->{NODESTATE}->[$n]->{"cpu_total"};
	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}=~/BGL/) {
	    $cpus/=2;
	}
	$self->{NODESIZE}=$cpus if($cpus>$self->{NODESIZE});
	$self->{CPUS}+=$cpus;
	$self->{FREECPUS}->[$n]=$cpus;
	if($name=~/$self->{SPLITSTACKREGSMALLNODES}/) {
	    $numnodessmall++; 
	    $self->{SMALLCPUS}+=$cpus;
	} else {
	    $numnodeslarge++;
	}
    }
    $px=$self->{POSX};
#    printf("WF: splitstack: numnodessmall,numnodeslarge: %d,%d\n",$numnodessmall,$numnodeslarge);
    
    # initialize hull objects
    if($self->{SPLITSTACK}) {
	my $fraction=$numnodessmall/($numnodessmall+$numnodeslarge);
	my $height=$self->{HEIGHT}-$self->{BOTTOMPAD};
	
	$self->{TOPHULLOBJ}->setsize($self->{POSX}+$self->{LEFTPAD}, int($self->{POSY}+$fraction*$height),
				     $self->{WIDTH}-$self->{LEFTPAD}, $height*(1.0-$fraction));
	$self->{TOPHULLOBJ}->setdirection("top");
	$self->{TOPHULLOBJ}->settag("forecast");
	$self->{TOPHULLOBJ}->init("TOPHULLOBJ");  # clean and default hull
	$self->{TOPHULLOBJ}->setautogrey(60,90,14);
	$self->{TOPHULLOBJSMALL}->setsize($self->{POSX}+$self->{LEFTPAD}, int($self->{POSY}),
					  $self->{WIDTH}-$self->{LEFTPAD}, $height*$fraction);
	$self->{TOPHULLOBJSMALL}->setdirection("top");
	$self->{TOPHULLOBJSMALL}->settag("forecast");
	$self->{TOPHULLOBJSMALL}->init("TOPHULLOBJSMALL");  # clean and default hull
	$self->{TOPHULLOBJSMALL}->setautogrey(60,90,14);
	$self->{TOPHULLOBJ}->{FONT1}=$self->{TOPHULLOBJSMALL}->{FONT1}=$self->{FONT1};
	$self->{TOPHULLOBJ}->{BFONT1}=$self->{TOPHULLOBJSMALL}->{BFONT1}=$self->{BFONT1};
	
	$self->{BOTTOMHULLOBJ}->setsize($self->{POSX}+$self->{LEFTPAD}, $self->{POSY}+$fraction*$height,
					$self->{WIDTH}-$self->{LEFTPAD}, $height*(1.0-$fraction));
	$self->{BOTTOMHULLOBJ}->setdirection("bottom");
	$self->{BOTTOMHULLOBJ}->settag("forecast"); 
	$self->{BOTTOMHULLOBJ}->init("BOTTOMHULLOBJ"); # clean and default hull
	$self->{BOTTOMHULLOBJ}->setautogrey(30,60,17);
	$self->{BOTTOMHULLOBJSMALL}->setsize($self->{POSX}+$self->{LEFTPAD}, $self->{POSY},
					$self->{WIDTH}-$self->{LEFTPAD}, $height*$fraction);
	$self->{BOTTOMHULLOBJSMALL}->setdirection("bottom");
	$self->{BOTTOMHULLOBJSMALL}->settag("forecast"); 
	$self->{BOTTOMHULLOBJSMALL}->init("BOTTOMHULLOBJSMALL"); # clean and default hull
	$self->{BOTTOMHULLOBJSMALL}->setautogrey(30,60,17);

	$self->{BOTTOMHULLOBJ}->{FONT1}=$self->{BOTTOMHULLOBJSMALL}->{FONT1}=$self->{FONT1};
	$self->{BOTTOMHULLOBJ}->{BFONT1}=$self->{BOTTOMHULLOBJSMALL}->{BFONT1}=$self->{BFONT1};
	
	$id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY},
				     $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				     $self->{POSY}+$fraction*$height,
				     -fill => "LightSkyBlue3", -tags => ["forecast"]);
	push(@{$self->{FIXEDITEMS}},$id);

    } else {
	$self->{TOPHULLOBJ}->setsize($self->{POSX}+$self->{LEFTPAD}, $self->{POSY},
				     $self->{WIDTH}-$self->{LEFTPAD}, $self->{HEIGHT}-$self->{BOTTOMPAD});
	$self->{BOTTOMHULLOBJ}->setsize($self->{POSX}+$self->{LEFTPAD}, $self->{POSY},
					$self->{WIDTH}-$self->{LEFTPAD}, $self->{HEIGHT}-$self->{BOTTOMPAD});
	$self->{TOPHULLOBJ}->setdirection("top");    $self->{BOTTOMHULLOBJ}->setdirection("bottom");
	$self->{TOPHULLOBJ}->settag("forecast");     $self->{BOTTOMHULLOBJ}->settag("forecast"); 
	$self->{TOPHULLOBJ}->init("TOPHULLOBJ");       # clean and default hull          
	$self->{BOTTOMHULLOBJ}->init("BOTTOMHULLOBJ"); # clean and default hull
	$self->{TOPHULLOBJ}->setautogrey(60,90,14);
	$self->{BOTTOMHULLOBJ}->setautogrey(30,60,17);
	$self->{TOPHULLOBJ}->{FONT1}=$self->{BOTTOMHULLOBJ}->{FONT1}=$self->{FONT1};
	$self->{TOPHULLOBJ}->{BFONT1}=$self->{BOTTOMHULLOBJ}->{BFONT1}=$self->{BFONT1};
    }

    for($n=1;$n<=$frames;$n++) {
 	$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};

	$py[$n]=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($n-1)*$dy;
	
	if(($dx>5) || ($n%5==0)) {
	    $id=$canvas->createText($px+15,$py[$n]+0,
				-text => sprintf("%02d", $n),
				    -anchor => 'sw',
				    -font => $self->{FONT1},
				    -tags => ["NODE${n}", "forecast"]);
	    push(@{$self->{ITEMS}},$id);
	}
#	$id=$canvas->createRectangle($self->{POSX},int($py[$n]-$dy)+1,
#				     $self->{POSX}+$self->{LEFTPAD},int($py[$n]),
#				     -fill => "DarkOrange3", -outline => "black");
#	push(@{$self->{FIXEDITEMS}},$id);
#	printf("WF: line %f %f %f %f\n",$self->{POSX}, 
#	       $py[$n],
#	       $self->{POSX}+$self->{WIDTH},
#	       $py[$n]);

	if($n>1) { # not on first item
	    $id=$canvas->createLine(      $self->{POSX}+$self->{LEFTPAD}, $py[$n],
					  $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
					  $py[$n],
					  -width => 1,
					  -fill => (($n%2)==0)?"grey":"darkblue",
					  -tags => ["forecast"]
					  );
	    push(@{$self->{ITEMS}},$id);
	}
    }

    { # legend
	my $ytxt="#of nodes";
	$ytxt=~s/(.)/$1\n/gs;
	$id=$canvas->createText($px+5,($py[1]+$py[$frames])/2+40,
#				-text => "#\nn\no\nd\ne\ns",
				-text => $ytxt,
				-anchor => 'sw',
				-font => $self->{BFONT1},
				-tags => ["forecast","forecastmarkerarea"]);
	push(@{$self->{ITEMS}},$id);
	$id=$canvas->createText($px+$self->{LEFTPAD}+1,$self->{POSY}+$self->{HEIGHT},
				-text => "Job Scheduling Prediction ",
				-anchor => 'sw',
				-font => $self->{BFONT1},
				-tags => ["forecast","forecastmarkerarea"]);
	push(@{$self->{ITEMS}},$id);
	$id=$canvas->createText($px+$self->{WIDTH},$self->{POSY}+$self->{HEIGHT},
				-text => "Job Type: color -> running, blue -> waiting, gray -> nocont ",
				-anchor => 'se',
				-font => $self->{FONT1},
				-tags => ["forecast","forecastmarkerarea"]);
	push(@{$self->{ITEMS}},$id);
    }

    { # mark not usable cpus
	my $maxn=$frames;
	my $actn=$self->{CPUS}/$self->{NODESIZE};

	$id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},                  
				     $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($maxn)*$dy,
				     $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD}-1,
				     $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($actn)*$dy,
				     -fill => "grey80", -outline => "grey80");
	push(@{$self->{ITEMS}},$id);
	$id=$canvas->createLine(      $self->{POSX},                                  
				      $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($actn)*$dy,
				      $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD}, 
				      $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($actn)*$dy,
				      -width => 1,
				      -fill => "LightSkyBlue4"
				      );
	push(@{$self->{ITEMS}},$id);

    }

    $self->create_timescale($canvas,$dataobj->{MACHSTATE}->{"system_time"},$dx,$dy);

    $tstart=time;
    $self->update_running_jobs_stack();
    $tdiff=time-$tstart;
    printf("llview: forecast update running jobs in %10.4f sec\n",$tdiff) if($self->{VERBOSE});

    $tstart=time;
    $self->update_reservations_stack();
    $tdiff=time-$tstart;
    printf("llview: forecast update reservations in %10.4f sec\n",$tdiff) if($self->{VERBOSE});

    $tstart=time;
    $self->update_waiting_jobs_stack();
    $tdiff=time-$tstart;
    printf("llview: forecast update waiting jobs in %10.4f sec\n",$tdiff) if($self->{VERBOSE});

    $id=$canvas->createLine(      $midx, $self->{POSY},
				  $midx, $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				  -width => 2,
				  -fill => "blue", 
				  -tags => ["forecast"]
				  );
    push(@{$self->{ITEMS}},$id);


    $dataobj->printsize("forecastupdate: end") if($debug==5);

    # reset marker line
    my($oldx,$oldy);
    if($self->{MARKERLINE}){
	($oldx,$oldy)=$self->{CANVAS}->coords('FOREMARKERLINE');
    } else {
	($oldx,$oldy)=($self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx),0);
    }
    $self->generateinfo($dataobj,$colorobj,$infoobj,$canvas,"forecastmarkerarea",$oldx,$oldy,"");


    if($self->{DOSCREENSHOT}) {
	my $fn;
	if($self->{USESCREENSHOTCOUNTER}) {
	    $self->{SCREENSHOTCOUNTER}++;
	    $fn=sprintf("screenshots/forecast%03d.png",$self->{SCREENSHOTCOUNTER});
	} else {
	    ($oldx,$oldy)=($self->{POSX} 
			   + $self->{LEFTPAD}  
			   + ($self->{TIMEBACK}*$dx) 
			   + ($self->{SCREENSHOTTIMEPOS}*$dx),0);
	    my $infostr=$self->generateinfo($dataobj,$colorobj,$infoobj,$canvas,"forecastmarkerarea",$oldx,$oldy,"");
	    $self->{INFOOBJECT}->setinfo($infostr);

	    $fn=sprintf("screenshots/forecast%03d.png",$self->{MAXNUMJOBS});
	}
	printf(STDERR "Screenshot of X-window id=%10s fn=%-20s time %6.2fh %s\n" ,
	       $self->{MAINWIN}->{MAIN}->id(),$fn,$self->{SCREENSHOTTIMEPOS},$self->{MARKERLINE});
	system("import -window ".$self->{MAINWIN}->{MAIN}->id()." -frame $fn");
    }

   
    return();
}

sub update_screenshot {
    my $self=$$selfref;
    if($self->{DOSCREENLOOP}) {
	$self->{MAXNUMJOBS}++;
	printf(STDERR "Screenshot maxnum=$self->{MAXNUMJOBS}\n");
#	sleep(1);
	printf(STDERR "Screenshot maxnum=$self->{MAXNUMJOBS}, sleep ready\n");
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","MAXNUMJOBS",$self->{MAXNUMJOBS});
    }
}


sub update_running_jobs_stack {
    my($self) = shift;
    my($cpu,$cpus,$jobid,$usedhcut,$nodelist,$user,$usedh,$startx,$wall,$dx,$endx,$color,$nr,$jclass);
    my($starty,$py,$dy,$endy,$cpuh,$cpuhcut,$j,$helpref,$helpreft,$category,$destdate);
    my $dataobj=$self->{DATAOBJECT};
    my $canvas=$self->{CANVAS};
    my $infoobj=$self->{INFOOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my $cpustart=0;
    my $cpustartsmall=0;
    my $cpumax=$self->{CPUS};
    my @current_starters;
    my $actdate=$dataobj->{MACHSTATE}->{"system_time"};
    my($sjobid,$stepname);
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    $dx=$self->{DX};
    $dy=$self->{DY};

    $self->{SCREENSHOTTIMEPOS}=0;

    $j=0;
    foreach $jobid (sort
		    { &sort_for_forecast_running_jobs($dataobj) }
		    (keys( %{$dataobj->{RUNNINGDATA}} ))) {
	$j++;
	$self->{NUMJOBS}++;
	last if($self->{NUMJOBS}>$self->{MAXNUMJOBS});

	# data from scheduler
	$user=$dataobj->{RUNNINGDATA}->{$jobid}{FL_USER};
	$wall=$dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600;
	$jclass=$dataobj->{JOBSTATE}->{$jobid}{"job_queue"};

	# data from schedsim
	$cpus=$dataobj->{JOBSTATE}->{$jobid}{"cpus"};
	$usedhcut=$usedh=$dataobj->{JOBSTATE}->{$jobid}{"usedH"};
	$cpuhcut=$cpuh=$dataobj->{JOBSTATE}->{$jobid}{"endtimeH"};
	$destdate=&sec_to_date(&date_to_sec($actdate)+$cpuh*3600);

	# reduce range of job to display window
	$usedhcut=$self->{TIMEBACK} if ($usedhcut>$self->{TIMEBACK});
	$cpuhcut=$self->{TIMEFORWARD} if ($cpuhcut>$self->{TIMEFORWARD});

	# coordinates of job start and end
	$startx=$self->{MIDXX} - $usedhcut*$dx;
	$endx  =$self->{MIDXX} + $cpuhcut *$dx;

	# determine color of job
	$category="RUN";
	if($self->{SEARCHSTR}) {
	    $category="OWNJOBS" if ($user=~/$self->{SEARCHSTR}/);
	}
	$color=$colorobj->get_color($category,$jobid);
	$nr=$colorobj->colortonr($category,$color);

	# display top or bottom (small, large, if enable), or is it a overlapping job
	$cpumax-=$cpus;
	my $overlap=0;
	if($self->{SPLITSTACK}) {
	    if ($dataobj->{JOBSTATE}->{$jobid}{"job_nodelist"}=~/$self->{SPLITSTACKREGSMALLNODES}/) {
		$helpref=$self->{BOTTOMHULLOBJSMALL}; 
		$helpreft=$self->{TOPHULLOBJSMALL};
		$starty=$cpustartsmall*$dy/$self->{NODESIZE};
		if($cpus>$self->{SMALLCPUS}) {
		    # seems to be a overlapping job, e.g.whole machine
		    $overlap=1; 
		    $cpustartsmall+=$self->{SMALLCPUS};
		    $cpustart+=$cpus-$self->{SMALLCPUS};
		} else {
		    $cpustartsmall+=$cpus;
		}
	    } else {
		$helpref=$self->{BOTTOMHULLOBJ};
		$helpreft=$self->{TOPHULLOBJ};
		$starty=$cpustart*$dy/$self->{NODESIZE};
		$cpustart+=$cpus;
	    }
	} else {
	    $starty=$cpustart*$dy/$self->{NODESIZE};
	    $cpustart+=$cpus;
	}

	if(!$overlap) {
	    $helpref->put(0,$startx,
			  $cpus*$dy/$self->{NODESIZE},
			  "DUMMYF","DUMMYT","grey60","","",1,"blue");
	    $helpref->put($startx,$endx,
			  $cpus*$dy/$self->{NODESIZE},
			  "T${nr}R","T${nr}B",$color,"$user","$user");
	    if($self->{WAITARRANGEVERT}) {
		# inform tophull object about starting vertical hull
		$helpreft->insert_segment_abs($endx,$helpreft->get_height()-$starty-$cpus*$dy/$self->{NODESIZE},
					      $cpus*$dy/$self->{NODESIZE});
	    }
	} else {
	    $self->{BOTTOMHULLOBJSMALL}->put(0,$startx,
			  $self->{SMALLCPUS}*$dy/$self->{NODESIZE},
			  "DUMMYF","DUMMYT","grey60","","",1,"blue");
	    $self->{BOTTOMHULLOBJSMALL}->put($startx,$endx,
			  $self->{SMALLCPUS}*$dy/$self->{NODESIZE},
			  "T${nr}R","T${nr}B",$color,"$user","$user");

	    $self->{BOTTOMHULLOBJ}->put(0,$startx,
			  ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE},
			  "DUMMYF","DUMMYT","grey60","","",1,"blue");
	    $self->{BOTTOMHULLOBJ}->put($startx,$endx,
			  ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE},
			  "T${nr}R","T${nr}B",$color,"$user","$user");

	    if($self->{WAITARRANGEVERT}) {
		# inform tophull object about starting vertical hull
		$starty=$cpustartsmall*$dy/$self->{NODESIZE};
		$self->{TOPHULLOBJSMALL}->insert_segment_abs($endx,
							     $helpreft->get_height()-$starty
							     *$dy/$self->{NODESIZE},
							     ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE});
		$starty=$cpustart*$dy/$self->{NODESIZE};
		$self->{TOPHULLOBJ}->insert_segment_abs($endx,
							$helpreft->get_height()-$starty*$dy/$self->{NODESIZE},
							($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE});
	    }
	}
	printf("WF, insert_running_jobs:%2d %-16s %8.2f->%8.2f cpus=%4d %10.4fh,%10.4fh user=%s\n",$j,
	       $jobid,$startx,$endx,$cpus,$usedh,$cpuh,$user) if($self->{VERBOSE});

    }
    return();
}


sub update_waiting_jobs_stack {
    my($self) = shift;
    my($cpu,$cpus,$jobid,$usedhcut,$nodelist,$user,$usedh,$startx,$wall,$dx,$endx,$color,$nr,$unr);
    my($starty,$py,$dy,$endy,$cpuh,$jcolor,$jnr,$class,$nodenr,$ucolor,$comment,$textcolor);
    my($starttime,$endtime,$starttimetopdog,$endtimetopdog,$startts,$endts,$ts,$classnr,$j,$rc);
    my($interactwithtopdog);
    my $dataobj=$self->{DATAOBJECT};
    my $canvas=$self->{CANVAS};
    my $infoobj=$self->{INFOOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my @nodes_freecpus;
    my $cpustart=0;
    my $cpumax=$self->{CPUS};
    my $frames=$dataobj->{FRAMES};
    my $reason;

    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    $dx=$self->{DX};
    $dy=$self->{DY};
    $self->{MIDX}=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);


    return if($self->{NUMJOBS}>$self->{MAXNUMJOBS});
    $j=0;
    foreach $jobid (sort
		     { &sort_for_forecast_waiting_jobs($dataobj) }
		    (keys( %{$dataobj->{WAITINGJOBS}} ))) {

	# skip, if job could not be scheduled by schedsim
	next if($dataobj->{JOBSTATE}->{$jobid}{"starttimeH"} eq "-");
	$j++;

	# data from scheduler
	$user=$dataobj->{JOBSTATE}->{$jobid}{"job_owner"};
	$wall=$dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600;

	# data from schedsim
	$cpus     =$dataobj->{JOBSTATE}->{$jobid}{"cpus"};
	$starttime=$dataobj->{JOBSTATE}->{$jobid}{"starttimeH"};
	$endtime  =$dataobj->{JOBSTATE}->{$jobid}{"endtimeH"};

	# reduce range of job to display window
	$endtime=$self->{TIMEFORWARD} if ($endtime>$self->{TIMEFORWARD});

	# skip if job outside window
	next if($starttime>$self->{TIMEFORWARD});

	# coordinates of job start and end
	$startx=$self->{MIDXX} + $starttime*$dx;
	$endx  =$self->{MIDXX}   + $endtime*$dx;

	my $nocont=0;
	$nocont=1 if(($class=~/$self->{NOCONTREG}/) && ($self->{NOCONTSELECT}));
	$nocont=1 if(($comment=~/$self->{NOCONTCOMMENTREG}/) && ($self->{NOCONTSELECT}));
	
	my $category=(!$nocont)?"WAIT":"WAITNOCONT";
	if($self->{SEARCHSTR}) {
	    $category="OWNJOBS" if ($user=~/$self->{SEARCHSTR}/);
	}

	# get nr for user and job
	$color=$colorobj->get_color($category,$jobid);
	$unr=$colorobj->colortonr($category,$color);
	$textcolor="black";

#       has to be implemented on another way
	if(exists($dataobj->{JOBSTATE}->{$jobid}{"TopDogLevel"})) {
	    $textcolor="red"    if($dataobj->{JOBSTATE}->{$jobid}{"TopDogLevel"} eq 1);
	    $textcolor="orange" if($dataobj->{JOBSTATE}->{$jobid}{"TopDogLevel"} > 1);
	}

	# display top or bottom (small, large, if enable), or is it a overlapping job
	my $helpref=$self->{TOPHULLOBJ};
	my $overlap=0;
	if($self->{SPLITSTACK}) {
	    if($dataobj->{JOBSTATE}->{$jobid}{"prednodelist"}=~/$self->{SPLITSTACKREGSMALLNODES}/) {
		$helpref=$self->{TOPHULLOBJSMALL};
		if($cpus>$self->{SMALLCPUS}) {
		    # seems to be a overlapping job, e.g.whole machine
		    $helpref=$self->{TOPHULLOBJ};
		    $overlap=1; 
		}
	    }
	}

	if($overlap) {
	    # seems to be a overlapping job, e.g.whole machine
	    # plot it also on small job region
	    $helpref=$self->{TOPHULLOBJ};
	    $helpref->put($self->{MIDXX}+$starttime*$dx,$self->{MIDXX}+$endtime*$dx,
			  ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE},
			  "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
	    $helpref=$self->{TOPHULLOBJSMALL};
	    $helpref->put($self->{MIDXX}+$starttime*$dx,$self->{MIDXX}+$endtime*$dx,
			  $self->{SMALLCPUS}*$dy/$self->{NODESIZE},
			  "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
	} else {
	    $helpref->put($self->{MIDXX}+$starttime*$dx,$self->{MIDXX}+$endtime*$dx,
			  $cpus*$dy/$self->{NODESIZE},
			  "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
	}

	printf("WF, insert_waiting_jobs:%2d %-16s %8.2f->%8.2f cpus=%4d %10.4fh,%10.4fh user=%s\n",$j,
	       $jobid,$startx,$endx,$cpus,$starttime,$endtime,$user) if($self->{VERBOSE});

	$self->{NUMJOBS}++;
	last if($self->{NUMJOBS}>$self->{MAXNUMJOBS});
	
    }
    return();
}


sub create_timescale {
    my($self) = shift;
    my($canvas,$now,$dx,$dy)=@_;
    my($id,$px,$py,$h,$step,$diffh);
    my($now2l,$now0,$daysb,$d);
    $px=$self->{POSX}+$self->{LEFTPAD}+$self->{TIMEBACK}*$dx;
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};

    # adjust step width
    $step=1;
    if($dx<20) {
	for($step=2;$step<($self->{TIMEBACK}+$self->{TIMEFORWARD});$step+=2) {
	    last if ($step*$dx>20);
	}
    }

    # print hour marker
    for($h=-$self->{TIMEBACK};$h<$self->{TIMEFORWARD};$h++) {
	if($h%$step==0) {
	    $id=$canvas->createLine( $px+$h*$dx, $py+1,
				     $px+$h*$dx, $py+5,
				     -width => 1,
				     -fill => "grey10", 
				     -tags => ["forecast","forecastmarkerarea"]
				     );
	    push(@{$self->{ITEMS}},$id);
	    $id=$canvas->createText( $px+$h*$dx, $py+9,
				     -text => ($h<=0)?"${h}h":"+${h}h",
				     -anchor => 'c',
				     -font => $self->{FONT1}, 
				     -tags => ["forecast","forecastmarkerarea"]);
	    push(@{$self->{ITEMS}},$id);
	} else {
	    $id=$canvas->createLine( $px+$h*$dx, $py+1,
				     $px+$h*$dx, $py+2,
				     -width => 1,
				     -fill => "grey10", 
				     -tags => ["forecast","forecastmarkerarea"]
				     );
	    push(@{$self->{ITEMS}},$id);
	}
    }
    # time/date at 0-marker
#    $now2l=$now;$now2l=~s/-/\n/g;
    $now2l=$now;$now2l=~s/-/|/g;
    $id=$canvas->createText( $px, $py+$self->{BOTTOMPADTOP}+8,
			     -text => $now2l,
			     -anchor => 'c',
			     -font => $self->{FONT1}, 
			     -tags => ["forecast","forecastmarkerarea"]);
    push(@{$self->{ITEMS}},$id);

    $now0=$now;$now0=~s/\d\d:\d\d:\d\d/00:00:00/gs;
    $diffh=&timediff($now,$now0)/3600;
    $daysb=0;  $daysb++ while($diffh+24*$daysb<$self->{TIMEBACK}); $daysb--;
    for($d=-($diffh+24*$daysb);$d<$self->{TIMEFORWARD};$d+=24) {
	$id=$canvas->createLine( $px+$d*$dx, $py+00,
				 $px+$d*$dx, $py+40,
				 -width => 2,
				 -fill => "grey40",
				 , -tags => ["forecast","forecastmarkerarea"]
				 );
	push(@{$self->{ITEMS}},$id);

	if($self->{SHOWWEEKDAY}) {
	    if($px+$d*$dx+2+25<$self->{POSX}+$self->{WIDTH}) {
		$id=$canvas->createRectangle($px+$d*$dx+2, $py-2+30,
					     $px+$d*$dx+2+25, $py-3-10+30, -outline => "black",
					     -fill => "DarkGoldenrod", -tags => ["forecast","forecastmarkerarea"]);
		push(@{$self->{ITEMS}},$id);
		# +2*3600 fix problem with summer time shift
		my $wdaystr=&sec_to_day(&date_to_sec($now)+$d*3600+2*3600);
		$id=$canvas->createText( $px+$d*$dx+2, $py-7+30,
					 -text => " $wdaystr ->",
					 -anchor => 'w',
					 -font => $self->{FONT1}, -tags => ["forecast","forecastmarkerarea"]);
		push(@{$self->{ITEMS}},$id);
	    }
	}
    }
}

sub update_reservations_stack {
    my($self) = shift;
    my($starth,$endh,$cpus,$resid,$user,$ucolor,$unr,$j,$textcolor,$color);
    my($helpref,$helpreft,$starty,$cpustartsmall,$overlap,$cpustart);
    my $dataobj=$self->{DATAOBJECT};
    my $canvas=$self->{CANVAS};
    my $infoobj=$self->{INFOOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my $frames=$dataobj->{FRAMES};
    my $dx=$self->{DX};
    my $dy=$self->{DY};
    my $sectoh=1.0/(60*60);
    my $htosec=(60*60);


    # get information about all reservations
    $j=0;
    foreach $resid (keys( %{$dataobj->{RESERVATION}} )) {
	$cpus      = $dataobj->{RESERVATION}->{$resid}->{'cpus'};
	$starth    = $dataobj->{RESERVATION}->{$resid}{"starttimeH"};
	$endh      = $dataobj->{RESERVATION}->{$resid}{"endtimeH"};

	
	printf( "WF: update_reservation_stack: %s\n",$resid);
	# reduce range of reservation to display window
	$starth=0.0 if ($starth<0);

	# skip if job outside window
	next if ($starth>=$self->{TIMEFORWARD});

	# reduce range of job to display window
	$endh=$self->{TIMEFORWARD} if ($endh>$self->{TIMEFORWARD});

	$j++;
	    
	$user=$dataobj->{RESERVATION}->{$resid}->{'user'};
	    
	# get nr for user and reservation
	$color=$colorobj->get_color("RESERVATION",$resid);
	$unr=$colorobj->colortonr("RESERVATION",$color);
	
	$textcolor="black";

	if( ($user=~/(loadl|root)/)  && ($cpus==$self->{CPUS}) )  {
	    # it's a maintenance
	    $user="Maintenence";
	}

	if($self->{SPLITSTACK}) {
	    if ($dataobj->{RESINFO}->{$resid}->{"prednodelist"}=~/$self->{SPLITSTACKREGSMALLNODES}/) {
		$helpref=$self->{BOTTOMHULLOBJSMALL}; 
		$helpreft=$self->{TOPHULLOBJSMALL};
		$starty=$cpustartsmall*$dy/$self->{NODESIZE};
		if($cpus>$self->{SMALLCPUS}) {
		    # seems to be a overlapping job, e.g.whole machine
		    $overlap=1; 
		    $cpustartsmall+=$self->{SMALLCPUS};
		    $cpustart+=$cpus-$self->{SMALLCPUS};
		} else {
		    $cpustartsmall+=$cpus;
		}
	    } else {
		$helpref=$self->{BOTTOMHULLOBJ};
		$helpreft=$self->{TOPHULLOBJ};
		$starty=$cpustart*$dy/$self->{NODESIZE};
		$cpustart+=$cpus;
	    }
	} else {
	    $starty=$cpustart*$dy/$self->{NODESIZE};
	    $cpustart+=$cpus;
	}
	
	if($overlap) {
	    # seems to be a overlapping job, e.g.whole machine
	    # plot it also on small job region
	    $helpref=$self->{TOPHULLOBJ};
	    $helpref->put($self->{MIDXX}+$starth*$dx,$self->{MIDXX}+$endh*$dx,
			  ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE},
			  "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
	    $helpref=$self->{TOPHULLOBJSMALL};
	    $helpref->put($self->{MIDXX}+$starth*$dx,$self->{MIDXX}+$endh*$dx,
			  $self->{SMALLCPUS}*$dy/$self->{NODESIZE},
			  "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
	} else {
	    $helpref->put($self->{MIDXX}+$starth*$dx,$self->{MIDXX}+$endh*$dx,
			  $cpus*$dy/$self->{NODESIZE},
			  "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
	}
    }
}

sub generateinfo {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$name,$xpos,$ypos,$category)=@_;
    my($runtime);
    my $infostr="forecast: no info for $name in $category\n";
    
    
    ###########################################################################
    # reservation
    ###########################################################################
    if($category eq "RES") {
	my $resid=$name;
	$infostr=sprintf("Reservation: %5d:\n",$resid);
	$infostr.=sprintf("-------------------------------\n");
	if(exists($dataobj->{RESERVATION}->{$resid})) {
	    my $o=$dataobj->{RESERVATION}->{$resid};
	    my $duration=&timediff($o->{"endtime"},$o->{"starttime"});
	    $infostr.=sprintf("  User:        %s\n", $o->{"user"});
	    $infostr.=sprintf("  Priority:    %s\n", $o->{"priority"});
	    $infostr.=sprintf("  Nodelist:    %s\n", $o->{"nodelist"});
	    $infostr.=sprintf("  start time:  %s\n", $o->{"starttime"});
	    $infostr.=sprintf("  end   time:  %s\n", $o->{"endtime"});
	    $infostr.=sprintf("  duration:    %5.2fh  (%4.2f days)\n",
			      $duration/3600,$duration/3600/24);
	    $runtime=&timediff($o->{"starttime"},$dataobj->{MACHSTATE}->{"system_time"});
	    if($runtime<0) {
		$infostr.=sprintf("  running:     %5.2fh  (%4.2f days)\n",
				  -$runtime/3600,-$runtime/3600/24);
		$infostr.=sprintf("  rest time:   %5.2fh  (%4.2f days)\n",
				  ($duration+$runtime)/3600,($duration+$runtime)/3600/24);
	    } else {
		$infostr.=sprintf("  starting in: %5.2fh  (%4.2f days)\n",
				  $runtime/3600,$runtime/3600/24);
	    }
	    if($o->{"user"}=~/^ERROR/) {
		$infostr.=sprintf("  Color:       red\n");
	    } else {
		$infostr.=sprintf("  Color:       %s\n",$self->{COLOROBJECT}->get("WAIT",$o->{"user"}));
	    }
	}
	return($infostr);
    }
    
    ###########################################################################
    # Waiting job
    ###########################################################################
    if(($category eq "WAIT") || ($category eq "WAITNOCONT") || $category eq "OWNJOBS") {
	my $jobid=$name;
	
	$infostr=sprintf("Info for Waiting Jobstep %8s [%s] (%s)\n",
			 $jobid,substr($dataobj->{JOBSTATE}->{$jobid}{"job_name"},0,30),$jobid);
	$infostr.=sprintf("--------------------------------------------------------------\n");
	$infostr.=sprintf("  User: %s (%s) ", $dataobj->{JOBSTATE}->{$jobid}{"job_owner"},lc($category));
	$infostr.=sprintf("  CPUs: %d ", $dataobj->{JOBSTATE}->{$jobid}{"cpus"});
	$infostr.=sprintf("  Wall: %6.2f h\n", $dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600);
	my $unicore=($dataobj->{JOBSTATE}->{$jobid}{"job_comment"}=~/NOT\s?Unicore/);
	$infostr.=sprintf("  Class:   %s    restart=%s %s\n", $dataobj->{JOBSTATE}->{$jobid}{"job_queue"},
			  $dataobj->{JOBSTATE}->{$jobid}{"job_restart"},
			  ($unicore)?"submitted by Unicore":"");
	$infostr.=sprintf("  Exec:      ...%s \n", substr($dataobj->{JOBSTATE}->{$jobid}{"job_taskexec"},-30));
	
	$infostr.=sprintf("  Prediction\n");
	$infostr.=sprintf("   last reason: '%s'\n",
                          $dataobj->{JOBSTATE}->{$jobid}{"lastreason"});
	my $actdate=$dataobj->{MACHSTATE}->{"system_time"};
	if($dataobj->{JOBSTATE}->{$jobid}{"starttimeH"} ne "-") {
	    $infostr.=sprintf("   Time: start %s, in %6.2f h\n",
			      &sec_to_date(&date_to_sec($actdate)+$dataobj->{JOBSTATE}->{$jobid}{"starttimeH"}*3600),
			      $dataobj->{JOBSTATE}->{$jobid}{"starttimeH"});
	    $infostr.=sprintf("   Time: end   %s, in %6.2f h\n", 
			      &sec_to_date(&date_to_sec($actdate)+$dataobj->{JOBSTATE}->{$jobid}{"endtimeH"}*3600),
			      $dataobj->{JOBSTATE}->{$jobid}{"endtimeH"});
	    $infostr.=sprintf("   Nodelist:  %s\n", 
			      format_bracket_list($dataobj->{JOBSTATE}->{$jobid}{"prednodelist"},$self->{WIDTH}-18,
						  "\n           ") );
	    if(exists($dataobj->{JOBSTATE}->{$jobid}{"TopDogLevel"})) {
		$infostr.=sprintf("   TopDogLevel:  %d\n",$dataobj->{JOBSTATE}->{$jobid}{"TopDogLevel"}); 
            }
	}
        return($infostr);
    }

    return($infostr) if (!$self->{DX}); # not ready for callback
    return($infostr) if ($xpos<$self->{POSX}+$self->{LEFTPAD});
    return($infostr) if ($xpos>$self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD});
#    print "WF: generateinfo $name $xpos,$ypos ",caller(),"\n";

    ###########################################################################
    # marker line
    ###########################################################################
    if($name eq "forecastmarkerarea") {
        my $showit=1;
        # check border
        $showit=0 if($xpos<=($self->{POSX}+$self->{LEFTPAD}+1));
        $showit=0 if($xpos>=($self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD})-1);
        $showit=0 if($ypos<=($self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD})+$self->{BOTTOMPADTOP});
        $showit=0 if($ypos>=($self->{POSY}+$self->{HEIGHT})-1);

        $showit=1 if($self->{SHOWMARKERPERMANENT});

        if(!$showit) {
          $canvas->delete($self->{MARKERLINE}) if($self->{MARKERLINE});
          $self->{MARKERLINE}=undef;
          return;
        }
 	if(!$self->{MARKERLINE}) {
	    $self->{MARKERLINE}=$canvas->createLine(      $xpos, $self->{POSY},
							  $xpos, $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
							  -width => 2,
						          -fill => "red", 
							  -tags => ["FOREMARKERLINE"]
							  );
#	push(@{$self->{FIXEDITEMS}},$id);
	} else {
	    my($oldx,$oldy)=$self->{CANVAS}->coords('FOREMARKERLINE');
	    $self->{CANVAS}->move('FOREMARKERLINE',$xpos-$oldx,0);
	    $self->{CANVAS}->raise('FOREMARKERLINE');
	}

	my $disth=($xpos-$self->{MIDX})/$self->{DX};
	my $actdate=$dataobj->{MACHSTATE}->{"system_time"};
	my $destdate=&sec_to_date(&date_to_sec($actdate)+$disth*3600);
	my $i=0;
	while( ($self->{TIMELINE_TS}->[$i]<$disth) && ($i < $#{$self->{TIMELINE_TS}}) ) {
#	    print "WF: $i -> $self->{TIMELINE_TS}->[$i]<$disth\n";
	    $i++;
	}
        print "WF: disth $i -> $self->{TIMELINE_TS}->[$i]<$disth\n";
	$infostr= sprintf("  Node Usage at:        %5.2f h -> %s [#%d of %d] %12.8f %12.8f\n", 
                          $disth,$destdate,$i,$#{$self->{TIMELINE_TS}},$xpos,$ypos);
	$infostr.=sprintf("  Used CPUS:            %6d of %d (%d free)\n", 
			  $self->{CPUS}-$self->{TIMELINE_FREE}->[$i],
			  $self->{CPUS},
			  $self->{TIMELINE_FREE}->[$i]);
	foreach my $class (sort {$self->{NODESTARTERS}->[0]->{$b} 
				 <=> $self->{NODESTARTERS}->[0]->{$a} } (keys(%{$self->{NODESTARTERS}->[0]}))) {
	    $infostr.=sprintf("   Starter in %-8s: %6d of %6d\n",$class,
			      $self->{TIMELINE_STARTERS}->[$i]->[$self->{CLASS2NR}->{$class}],
			      $self->{NODESTARTERS}->[0]->{$class}
			      );
	}

    }


    if($name=~/R(\d+)[RB]/) {
	my $nr=$1;
	my $resid=$colorobj->nrtoid("WAIT",$nr);
#	print "WF: generateinfo forecast $nr,$resid\n";
	$infostr=sprintf("Info for reservation %4d\n",$resid);
	$infostr.=sprintf("-------------------------------\n");
	if(exists($dataobj->{RESERVATION}->{$resid})) {
	    my $o=$dataobj->{RESERVATION}->{$resid};
	    my $duration=&timediff($o->{"endtime"},$o->{"starttime"});
	    $infostr.=sprintf("  User:        %s\n", $o->{"user"});
	    $infostr.=sprintf("  Priority:    %s\n", $o->{"priority"});
	    $infostr.=sprintf("  Nodelist:    %s\n", $o->{"nodelist"});
	    $infostr.=sprintf("  start time:  %s\n", $o->{"starttime"});
	    $infostr.=sprintf("  end   time:  %s\n", $o->{"endtime"});
	    $infostr.=sprintf("  duration:    %5.2fh  (%4.2f days)\n",
			      $duration/3600,$duration/3600/24);
	    $runtime=&timediff($o->{"starttime"},$dataobj->{MACHSTATE}->{"system_time"});
	    if($runtime<0) {
		$infostr.=sprintf("  running:     %5.2fh  (%4.2f days)\n",
				  -$runtime/3600,-$runtime/3600/24);
		$infostr.=sprintf("  rest time:   %5.2fh  (%4.2f days)\n",
				  ($duration+$runtime)/3600,($duration+$runtime)/3600/24);
	    } else {
		$infostr.=sprintf("  starting in: %5.2fh  (%4.2f days)\n",
				  $runtime/3600,$runtime/3600/24);
	    }
	    if($o->{"user"}=~/^ERROR/) {
		$infostr.=sprintf("  Color:       red\n");
	    } else {
		$infostr.=sprintf("  Color:       %s\n",$self->{COLOROBJECT}->get($o->{"WAIT","user"}));
	    }

	}
    }

    return($infostr);
}

# will bwe called by colorobject if the color mapping was changed
sub updatecoloredobjects {
    my($self) = shift;
    my($category)=@_;
    my($nr,$color);

#    print "WF: updatecoloredobjects in forecast was called for category $category\n";
    foreach $nr ($self->{COLOROBJECT}->getusednrs($category)) {
	$color=$self->{COLOROBJECT}->nrtocolor($category,$nr);
	$self->{CANVAS}->itemconfigure("T${nr}R", -fill => "$color"); 
#	print "   updatecoloredobjects T${nr}R -> $color\n";

    }

}

sub scale {
    my($n)=@_;
#    return($n);
#    printf("log: %2d -> %f\n",$n,log($n)/log(10));
    return(log($n+1)/log(10));
}


sub sec_to_day {
    my ($lsec)=@_;
    my($wdaystr);
    my ($sec,$min,$hours,$mday,$mon,$year,$wday,$rest)=localtime($lsec);
    $wdaystr=("Su","Mo","Tu","We","Th","Fr","Sa")[$wday];
#    my $llsec=$lsec/3600;
#    print "WF: sec_to_day $lsec $llsec -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> wday=$wday wdaystr=$wdaystr\n";
    return($wdaystr);
}

sub format_bracket_list {
    my($in,$width,$delim)=@_;
    my $out="";
    my $len=0;
    while($in=~s/^([^\)]+\))//) {
	$out.=$1;
	$len+=length($1);
	if($len>$width) {
	    $out.=$delim;
	    $len=0;
	}
    }
    return($out);
}

sub date_to_sec {
    my ($date)=@_;
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year $^O\n";
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
    return($timesec);
}

sub sec_to_date {
    my ($lsec)=@_;
    my($date);
    my ($sec,$min,$hours,$mday,$mon,$year,$rest)=localtime($lsec);
    $year=sprintf("%02d",$year % 100);
    $mon++;
    $date=sprintf("%02d/%02d/%02d-%02d:%02d:%02d",$mon,$mday,$year,$hours,$min,$sec);
#    print "WF: sec_to_date $lsec -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $date\n";
    return($date);
}

sub timediff {
    my ($date1,$date2)=@_;
#    print"WF: timediff $date1 $date2\n";
    my $timesec1=&date_to_sec($date1);
    my $timesec2=&date_to_sec($date2);
    return($timesec1-$timesec2);
}


sub update_left_cb {
    my($x,$y,$amount)=@_;
    my $self=$$selfref;
    my $dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    my $midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
#    print "WF: update_left_cb: $x,$y\n";
    if($x<$midx) {
	$self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast","General",
							       "TIMEBACK",$self->{TIMEBACK}+$amount);
    } else {
	if($self->{TIMEBACK}-$amount>=0) {
	    $self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast","General",
								   "TIMEFORWARD",$self->{TIMEFORWARD}-$amount);
	}
    }
}

sub update_right_cb {
    my($x,$y,$amount)=@_;
    my $self=$$selfref;
    my $dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    my $midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
#    print "WF: update_right_cb: $x,$y\n";
    if($x<$midx) {
	if($self->{TIMEBACK}-$amount>=0) {
	    $self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast","General",
								   "TIMEBACK",$self->{TIMEBACK}-$amount);
	}
    } else {
	$self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast","General",
							       "TIMEFORWARD",$self->{TIMEFORWARD}+$amount);
    }
}

sub update_left_left_cb {
    my $self=$$selfref;
    print "WF: update_left_left_cb: $self->{TIMEBACK}\n";
    $self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast","General","TIMEBACK",$self->{TIMEBACK}+2);
}
sub update_left_right_cb {
    my $self=$$selfref;
    if($self->{TIMEBACK}-2>=0) {
	$self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast","General","TIMEBACK",$self->{TIMEBACK}-2);
    }
}

sub update_right_left_cb {
    my $self=$$selfref;
    if($self->{TIMEFORWARD}-2>=0) {
	$self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast","General","TIMEFORWARD",$self->{TIMEFORWARD}-2);
    }
}
sub update_right_right_cb {
    my $self=$$selfref;
    $self->{OPTIONOBJECT}->update_optval_direct_subsection($self->{CLUSTERNAME},"Forecast","General","TIMEFORWARD",$self->{TIMEFORWARD}+2);
}

sub sort_for_forecast_running_jobs   {    
    my($o)=@_;
    my($enda,$endb)=($o->{JOBSTATE}->{$a}{"endtimeH"},$o->{JOBSTATE}->{$b}{"endtimeH"});
    $enda=0 if($enda eq "-");
    $endb=0 if($endb eq "-");
    if($enda == $endb) {
	if($o->{RUNNINGDATA}->{$b}{FL_ALLCPU} == $o->{RUNNINGDATA}->{$a}{FL_ALLCPU}) {
	    $o->{JOBSTATE}->{$a}{"job_wall"} <=> $o->{JOBSTATE}->{$b}{"job_wall"};
	} else {
	    $o->{RUNNINGDATA}->{$b}{FL_ALLCPU} <=> $o->{RUNNINGDATA}->{$a}{FL_ALLCPU};
	}
    } else {
	$endb <=> $enda;
    }
}

sub sort_for_forecast_waiting_jobs   {    
    my($o)=@_;
    my($starta,$startb)=($o->{JOBSTATE}->{$a}{"starttimeH"},$o->{JOBSTATE}->{$b}{"starttimeH"});
    $starta=0 if($starta eq "-");
    $startb=0 if($startb eq "-");
    if($starta == $startb) {
	if($o->{JOBSTATE}->{$b}{"cpus"} == $o->{JOBSTATE}->{$a}{"cpus"}) {
	    $o->{JOBSTATE}->{$a}{"job_wall"} <=> $o->{JOBSTATE}->{$b}{"job_wall"};
	} else {
	    $o->{JOBSTATE}->{$b}{"cpus"} <=> $o->{JOBSTATE}->{$a}{"cpus"};
	}
    } else {
	$starta <=> $startb;
    }
}

1;

