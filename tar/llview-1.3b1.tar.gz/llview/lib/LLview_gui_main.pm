# $Source: /cvs/cvsroot/llview/lib/LLview_gui_main.pm,v $
# $Author: zdv087 $
# $Revision: 1.84 $
# $Date: 2007/07/17 09:31:25 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_main;
use strict;
use Tk;
use Tk::NoteBook;
#use Tk::Clock;

use LLview_gui_options;

my($debug)=0;
my($instancecnt)=-1;
my(@selfref)=(-1);


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_gui_main: new %s\n",ref($proto)) if($debug>=3);
    $self->{INSTPATH}      = shift;
    $self->{INIFILE}       = shift;
    $self->{MULTICLUSTER}  = shift;
    $self->{CLUSTERNR}     = shift;
    $self->{CLUSTERNAME}   = shift;
    $self->{PREFIX}        = shift; # for ini files (e.g. for two different llview setups on one machine)
    $self->{VERBOSE}       = 0;
    $self->{VERSION}       = "1.3";
    $self->{HEIGHT}        = 1024;
#    $self->{WIDTH}         = 950;
#    $self->{HEIGHT}        = 768-268;
#    $self->{HEIGHT}        = 768;
    $self->{WIDTH}         = 1024-20-60;
    $self->{GEOMETRY}      = "-";
    $self->{MAIN}          = "";
    $self->{MENU}          = "";
    $self->{MENUFILE}      = "";
    $self->{MENUOPTIONS}   = "";
    $self->{NODES}         = "";
    $self->{CANVAS}        = "";

    $self->{HEIGHTLINES}   = 67;

    $self->{UPDATETIMEREST}  = 0;
    $self->{UPDATESTATE}     = 1;
    $self->{UPDATETIMEREST}  = 1;
    $self->{UPDATETIMESTEP}  = 1;
#    $self->{UPDATETIME}      = 30;
    $self->{UPDATETIME}      = 60;
    $self->{UPDATETIMESTR}   = "-";
    $self->{DATATYPE}        = "-";
    $self->{UPDATECOMMENT}   = sprintf("%02d s",$self->{UPDATETIMEREST});

    $self->{DATAOBJECT}      = "";
    $self->{COLOROBJECT}     = "";

    $self->{OPTIONOBJECT}    = "";

    $self->{TIMEROBJECTS}    = [];
    $self->{TIMERFUNCTIONS}  = [];
    $self->{CANVASOBJECTS}   = [];
    $self->{UPDATEOBJECTS}   = [];
    $self->{INFOOBJECT}         = undef;
    $self->{OBJECTS}         = {};
    $self->{FUNCTIONS}       = {};

    $self->{NOTEBOOK}      =  undef;
    $self->{NOTEBOOKOBJECTS} = []; # notebook objects
    $self->{NOTEBOOKFRAMES}  = {};
    $self->{TWOBJECTS}       = []; # top window objects

    $self->{BUILDREADY}=0;
    $self->{AUTOPLAY}=0;    
    $self->{ACTIVENRS}       = [];
    $self->{AUTOPLAYNR}      = 0;
    $self->{AUTOPLAYSTEP}    = 3;

    $self->{WITHOUTFRAME}=0;

    $self->{USEDNRS}         = [];

    $self->{FONT1}       = "-*-Courier-Medium-R-Normal--*-120-*-*-*-*-*-*";
    $self->{BFONT1}      = "-*-Courier-Bold-R-Normal--*-100-*-*-*-*-*-*";
    $self->{FONT2}       = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT2}      = "-*-Helvetica-Bold-R-Normal--*-100-*-*-*-*-*-*";
    $self->{BFONT3}      = "-*-Helvetica-Bold-R-Normal--*-220-*-*-*-*-*-*";
#    $self->{FONT1}       = "6x13";
#    $self->{BFONT1}      = "6x13bold";
    $self->{MARKCOLOR} = "red";
    $self->{MARKWIDTH} = 3;
    $self->{CANVASCOLOR}="grey85";

    $self->{LASTHIGHLIGHTEDNR} = -1;
    $self->{HIGHLIGHTITEMSR}   = [];
    $self->{HIGHLIGHTITEMST}   = [];

    $self->{SEARCHSTR}   = "";
    $self->{SEARCHSTRLAST}   = "__INIT__";

    $self->{EVX} = -1; # Position of last Mouse Event
    $self->{EVY} = -1;

    if(!$self->{MULTICLUSTER} || ( $self->{MULTICLUSTER} && ($self->{CLUSTERNR}==0) ) ) {
	$self->{OPTIONOBJECT}=LLview_gui_options->new($self->{INIFILE},$self->{INSTPATH},$self->{MULTICLUSTER},
						      $self->{VERSION},$self->{PREFIX});
	$self->{OPTIONOBJECT}->register_caller($self);
    }

    bless $self, $class;
    $instancecnt++;
    $self->{INSTANCENR} = $instancecnt;
    $selfref[$instancecnt]=\$self;

    return $self;
}

sub register_data_object {
    my($self) = shift;
    my($name,$objref) = @_;
#    print "WF: in Main register_data_object:  $self->{MULTICLUSTER},$self->{CLUSTERNR},$self->{CLUSTERNAME} ",ref($objref),"\n";
    $self->{DATAOBJECT}=$objref;
    return 1;
}

sub register_color_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{COLOROBJECT}=$objref;
    return 1;
}

sub register_canvas_object {
    my($self) = shift;
    my($name,$objref) = @_;
    push(@{$self->{CANVASOBJECTS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    return 1;
}

sub register_canvas_object_on_overviewcanvas {
    my($self) = shift;
    my($name,$objref,$canvasref,$tabname) = @_;
    push(@{$self->{CANVASOBJECTSONCANVAS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    $self->{CANVASFOROBJECT}->{$name}=$canvasref;
    $self->{TABNAMEFOROBJECT}->{$name}=$tabname;
    return 1;
}

sub register_subcanvas_object {
    my($self) = shift;
    my($name,$objref) = @_;
    push(@{$self->{SUBCANVASOBJECTS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    return 1;
}

sub register_scroll_object {
    my($self) = shift;
    my($name,$objref) = @_;
    push(@{$self->{SCROLLEDOBJECTS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    return 1;
}

sub register_search_object {
    my($self) = shift;
    my($name,$objref) = @_;
    push(@{$self->{SEARCHOBJECTS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    return 1;
}

sub register_subcanvas_entry {
    my($self) = shift;
    my($name,$subcanvas) = @_;
    push(@{$self->{SUBCANVASLIST}},$subcanvas);
    return 1;
}

sub register_info_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{INFOOBJECT}=$objref;
    return 1;
}

sub register_update_object {
    my($self) = shift;
    my($name,$objref) = @_;
    push(@{$self->{UPDATEOBJECTS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    return 1;
}

sub register_timer_entry {
    my($self) = shift;
    my($name,$objref) = @_;
    push(@{$self->{TIMEROBJECTS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    return 1;
}

sub register_timer_function {
    my($self) = shift;
    my($name,$funcref) = @_;
    push(@{$self->{TIMERFUNCTIONS}},$name);
    $self->{FUNCTIONS}->{$name}=$funcref;
    return 1;
}

sub register_steptimer_function {
    my($self) = shift;
    my($name,$funcref) = @_;
#    print "register_steptimer_function: $name $instancecnt\n";
    push(@{$self->{STEPTIMERFUNCTIONS}},$name);
    $self->{FUNCTIONS}->{$name}=$funcref;
    return 1;
}

sub register_notebook_object {
    my($self) = shift;
    my($name,$objref) = @_;
    push(@{$self->{NOTEBOOKOBJECTS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    
    return 1;
}

sub register_notebookcanvas_object {
    my($self) = shift;
    my($name,$objref) = @_;
    push(@{$self->{NOTEBOOKCANVASOBJECTS}},$name);
    $self->{OBJECTS}->{$name}=$objref;
    
    return 1;
}

sub build_gui {
    my($self) = shift;
    my($objname,$objref);
    my($nb,$cv,$cvn,$cvo,$optobj);
    my($n,$t,$nb_nodes,$mw,$cluster);
    my $dataobject=$self->{DATAOBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my $colorobject=$self->{COLOROBJECT};

    $optobj=$self->{OPTIONOBJECT};

    $optobj->register_option("General","HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 50, -max => 1200, -default => $self->{HEIGHT}, -step => 10);
    $optobj->register_option("General","WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2048, -default => $self->{WIDTH}, -step => 10);
    $optobj->register_option("General","HEIGHTLINES", -label => "Height (Lines)", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 20, -max => 400, -default => $self->{HEIGHTLINES}, -step => 10);
    $optobj->register_option("General","GEOMETRY", -label => "Geometry", 
			     -caller => $self,-pack => 1,
			     -type => "string",, -default => $self->{GEOMETRY});
    $optobj->register_option("General","CANVASCOLOR", -label => "Canvas Color", 
			     -caller => $self, -pack => 1,
			     -type => "string", -default => $self->{CANVASCOLOR});
    $optobj->register_option("General","UPDATESTATE", -label => "Update", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{UPDATESTATE});
    $optobj->register_option("General","UPDATETIME", -label => "Update time (s)", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 1, -max => 360, -default => $self->{UPDATETIME}, -step => 5);
    $optobj->register_option("General","AUTOPLAY", -label => "auto play", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{AUTOPLAY});
    $optobj->register_option("General","AUTOPLAYSTEP", -label => "Autoplay Step (s)", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 1, -max => 60, -default => $self->{AUTOPLAYSTEP}, -step => 5);
    $optobj->register_option("General","MARKCOLOR", -label => "Mark Color", 
			     -caller => $self, -pack => 1,
			     -type => "string", -default => $self->{MARKCOLOR});
    $optobj->register_option("General","MARKWIDTH", -label => "Mark Width", 
			     -caller => $self, -pack => 1,
			     -type => "int", , -min => 1, -max => 10, -default => $self->{MARKWIDTH}, -step => 1);
    $optobj->register_option("General","VERSION", -label => "version", 
			     -caller => $self, -pack => 1,
			     -type => "string", -default => $self->{VERSION});

    $optobj->register_option("General","WITHOUTFRAME", -label => "no frame for mainwindow (after restart)", 
			     -caller => $self,-pack => 1, -labelwidth => 40,
			     -type => "radio", -default => $self->{WITHOUTFRAME});


    if($self->{MULTICLUSTER}) {
	if($self->{CLUSTERNR}==0) {
#	    print "WF: in Main:  $self->{MULTICLUSTER},$self->{CLUSTERNR},$self->{CLUSTERNAME}\n";
	    $self->{MASTERWINDOW} = new MainWindow(-title => 'llview', -background => "grey85");
	    # menues and button only once in master window
	    $self->{MAIN}=$self->{MASTERWINDOW};
	    $self->build_keybindings();
	    $self->build_menu();
	    $self->build_buttons();
	    $self->{MASTER_NB}=$self->{MASTERWINDOW}->NoteBook(qw/-ipadx 6 -ipady 6/)->pack;
	    if($self->{GEOMETRY}!~/^\s*\-\s*$/) {
		$self->{MASTERWINDOW}->geometry($self->{GEOMETRY});
	    }
	}
	$cluster=$self->{CLUSTERNAME};
#	print "WF: in main add cluster tab for $cluster\n"; 
	$self->{PANEL_CLUSTERS}->{$cluster}=$self->{MASTER_NB}->add( "$cluster", -label=> "Cluster $cluster", 
								     -underline=>7+$self->{CLUSTERNR});
	$self->{MAIN}=$self->{PANEL_CLUSTERS}->{$cluster};
    } else {
	$self->{MASTERWINDOW}=$mw = new MainWindow(-title => 'llview', -background => "grey85");
	if($self->{GEOMETRY}!~/^\s*\-\s*$/) {
	    $mw->geometry($self->{GEOMETRY});
	}
	$self->{MAIN}=$mw;
	$self->build_keybindings();
	$self->build_menu();
	$self->build_buttons();
	$cluster="-";
    }


#    if (($#{$self->{NOTEBOOKOBJECTS}}>-1) || ($#{$self->{NOTEBOOKCANVASOBJECTS}}>-1)) {
# changed because only history panel display not worked
    if (($#{$self->{NOTEBOOKOBJECTS}}>-1)) {
	$n = $self->{MAIN}->NoteBook(-ipadx => 2, -ipady => 2, -background => "grey85", -backpagecolor => "grey80" )->pack;
	$nb_nodes = $n->add( 'Nodes', -label=>'Nodes', -underline=>0);
	$t = $nb_nodes->Scrolled('Canvas', -scrollbars => 'oe', -relief => 'sunken', -bd => 1, 
				    -height => $self->{HEIGHT}, -width => $self->{WIDTH},
				    -background =>  $self->{CANVASCOLOR}
				    )->pack(-side => 'top', -expand => 1, -fill => 'both');
	$self->{NOTEBOOK}      = $n;
#    $self->BindMouseWheel($t);
	$self->{NODES}         = $t;
	$self->{CANVAS} = $t->Subwidget("canvas");
    } else {
	$t = $self->{MAIN}->Scrolled('Canvas', -scrollbars => '', -relief => 'sunken', -bd => 0, 
			      -height => $self->{HEIGHT}, -width => $self->{WIDTH},
			      -background =>  $self->{CANVASCOLOR}
			      )->pack(-side => 'top', -expand => 1, -fill => 'both');
	$self->{NOTEBOOK}      = $t;
#    $self->BindMouseWheel($t);
	$self->{NODES}         = $t;
	$self->{CANVAS} = $t->Subwidget("canvas");
	
#       WF debug
#	$self->{CANVAS}->createRectangle(10,10,100,100, -fill => "grey70", -outline => "red" );

    }


# Executing build method of canvas objects
    foreach $objname (@{$self->{CANVASOBJECTS}}) {
	print "#	build -> $objname->build(); $self->{CLUSTERNAME}\n" if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
	$objref->build($dataobject,$colorobject,$infoobject,$self->{CANVAS},$self->{OPTIONOBJECT});
    }

# Executing build method of canvas objects on other canvas (for multicluster overview)
    $self->{OPTIONOBJECT}->set_cluster("-");
    foreach $objname (@{$self->{CANVASOBJECTSONCANVAS}}) {
	print "#	build -> $objname->build(); $self->{CLUSTERNAME}\n" if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
	$objref->build($dataobject,$colorobject,$infoobject,$self->{CANVASFOROBJECT}->{$objname},
		       $self->{OPTIONOBJECT},$self->{TABNAMEFOROBJECT}->{$objname});
    }
    $self->{OPTIONOBJECT}->set_cluster($cluster);


#    $self->{MAIN}->after($self->{UPDATETIMESTEP}*1000,\&timestep);
    $self->register_update_object("GUI",$self);

    foreach $objname (@{$self->{NOTEBOOKOBJECTS}}) {
	print "#	build -> $objname->build();\n"  if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
	$nb = $n->add( "$objname", -label=>"$objname", -underline=>0);
	$t = $nb->Scrolled('Text', -scrollbars => 'w', -width => 124, -height => $self->{HEIGHTLINES},
			   -background => "grey85"
				 )->pack(-side => 'top', -expand => 1, -fill => 'both');
	$self->BindMouseWheel($t);
	$self->{NOTEBOOKFRAMES}->{$objname}=$t;
	$objref->build($dataobject,$colorobject,$infoobject,$t,$self->{OPTIONOBJECT});
    }

 
    foreach $objname (@{$self->{NOTEBOOKCANVASOBJECTS}}) {
	print "#	build -> $objname->build();\n"  if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
	if(($#{$self->{NOTEBOOKOBJECTS}}>-1)) {
	    $nb = $n->add( "$objname", -label=>"$objname", -underline=>0);
	    $t = $nb->Scrolled('Canvas', -scrollbars => 'se', -relief => 'sunken', -bd => 1, 
			       -height => $self->{HEIGHT}, -width => $self->{WIDTH},
			       )->pack(-side => 'top', -expand => 1, -fill => 'both');
#	$self->BindMouseWheel($t);
	} else {
	    $t=$self->{CANVAS}; # default canvas 
	}
	$self->{NOTEBOOKFRAMES}->{$objname}=$t;
	$objref->build($dataobject,$colorobject,$infoobject,$t,$self->{OPTIONOBJECT});
    }


    $self->register_subcanvas_entry("maincanvas",$self->{CANVAS});
    foreach $cvn (@{$self->{SUBCANVASOBJECTS}}) {
	$cvo=$self->{OBJECTS}->{$cvn};
	$self->register_subcanvas_entry("$cvn",$cvo->{SUBCANVAS});
    }
    
    foreach $cv (@{$self->{SUBCANVASLIST}}) {
#	print "WF: ",ref($cv),"<\n";
#	$cv->CanvasBind('<ButtonRelease-3>' => sub { $ { $selfref }->{UPDATETIMEREST}=0;} );
#	$cv->CanvasBind('<ButtonRelease-2>' => [ \&print_xy, Ev('x'), Ev('y') ]);
#	$cv->CanvasBind('<ButtonRelease-2>' => [ \&print_postscript, Ev('x'), Ev('y') ]);
#	$cv->CanvasBind('<Key-p>' => [ \&print_postscript, Ev('x'), Ev('y') ]);
#	$cv->CanvasBind('<KeyPress>' => [ \&print_xy, Ev('x'), Ev('y') ]);
#	$cv->CanvasBind('<ButtonRelease-2>' => [ \&print_xy, Ev('x'), Ev('y') ]);
    }
    $infoobject->defaultinfo() if ($infoobject);

    foreach $cv (@{$self->{SUBCANVASLIST}}) {
	$cv->bind("free", "<Enter>", sub { &highlightfreeitems("ON","free",$self->{INSTANCENR}); });
	$cv->bind("free", "<Leave>", sub { &highlightfreeitems("OFF","free",$self->{INSTANCENR}); });
    }

    # build options from colorobject
    print "WF: generate color object ($cluster)\n";
    $colorobject->build($dataobject,$colorobject,$infoobject,$t,$self->{OPTIONOBJECT}) if($colorobject);

    print "#	build -> options->build();\n" if($debug==3);
    $self->{OPTIONOBJECT}->build($self->{MAIN},$self->{MENUOPTIONS},
				 $dataobject,$colorobject,$infoobject,$self->{CANVAS});
    $dataobject->printsize("build: after gui init") if($debug==5);

    $colorobject->register_external_updater("RUN",$self) if($colorobject);

    $self->{BUILDREADY}=1;
    if($self->{SEARCHSTR} eq "") {
	$self->{SEARCHSTR}=getlogin();
	print "LLview_gui_main: set search string to $self->{SEARCHSTR}\n";
    }

    if($self->{WITHOUTFRAME}) {
    	$self->{MASTERWINDOW}->overrideredirect(1);
    }

    # starting timer
    if($self->{INSTANCENR}==0) {
	&timestep($self->{INSTANCENR});
    }
}

sub print_xy {
    my ($canv, $x, $y, $instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    print "(x,y) = ", $self->{CANVAS}->canvasx($x), ", ", $self->{CANVAS}->canvasy($y), "\n";
}

sub print_postscript {
    my ($canv, $x, $y, $instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    print "printing Postscript File llview.ps\n";
    $self->{CANVAS}->postscript(-file => "llview.ps");
}

sub refresh_display {
    my ($canv, $x, $y, $instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    my($canvas)=$self->{CANVAS};  
    my(@bbox)=$canvas->bbox("all"); 
    if($self->{VERBOSE}) {
	print "refresh_display @bbox\n";
	$canvas->delete($self->{BBOXOBJ}) if(Exists($self->{BBOXOBJ}));
	$self->{BBOXOBJ}=$canvas->createRectangle(@bbox, -outline => "blue" ) ;
    }
    # twice for adjusting additional scrollbar
    $canvas->configure(-scrollregion => [ $self->{CANVAS}->bbox("all") ]); 
    $canvas->configure(-scrollregion => [ $self->{CANVAS}->bbox("all") ]);
}


sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id,$objname);
    print "main,optvalchanged: $section,$name -> $val ($self->{BUILDREADY}) ...\n"  if($self->{VERBOSE});
    if($name eq "CANVASCOLOR") {
	$self->{$name}=$val;
	foreach $objname (@{$self->{NOTEBOOKCANVASOBJECTS}}) {
	    $self->{NOTEBOOKFRAMES}->{$objname}->configure(-background => $self->{CANVASCOLOR} ) if($self->{BUILDREADY});
	}
	$self->{CANVAS}->configure(-background => $self->{CANVASCOLOR}) if($self->{BUILDREADY});
	$self->{CANVAS}->configure(-scrollregion => [ $self->{CANVAS}->bbox("all") ]) if($self->{BUILDREADY});
    }
    if($name eq "WIDTH") {
	$self->{$name}=$val;
	foreach $objname (@{$self->{NOTEBOOKCANVASOBJECTS}}) {
	    $self->{NOTEBOOKFRAMES}->{$objname}->configure(-width => $self->{WIDTH} ) if($self->{BUILDREADY});
	}
	$self->{CANVAS}->configure(-width => $self->{WIDTH} ) if($self->{BUILDREADY});
	$self->{CANVAS}->configure(-scrollregion => [ $self->{CANVAS}->bbox("all") ]) if($self->{BUILDREADY});
    }
    if($name eq "HEIGHT") {
	$self->{$name}=$val;
	foreach $objname (@{$self->{NOTEBOOKCANVASOBJECTS}}) {
	    $self->{NOTEBOOKFRAMES}->{$objname}->configure(-height => $self->{HEIGHT} ) if($self->{BUILDREADY});
	}
	$self->{CANVAS}->configure(-scrollregion => [ $self->{CANVAS}->bbox("all") ]) if($self->{BUILDREADY});
    }
    if($name eq "HEIGHTLINES") {
	$self->{$name}=$val;
	foreach $objname (keys(%{$self->{NOTEBOOKFRAMES}})) {
	    $self->{NOTEBOOKFRAMES}->{$objname}->configure(-height => $self->{HEIGHTLINES} ) if($self->{BUILDREADY});
	}
	$self->{CANVAS}->configure(-scrollregion => [ $self->{CANVAS}->bbox("all") ]) if($self->{BUILDREADY});
    }
    if($name eq "AUTOPLAY") {
	$self->{$name}=$val;
	$self->{AUTOPLAYNR} = 0;
    }
    if($name eq "AUTOPLAYSTEP") {
	$self->{$name}=$val;
    }
    if($name eq "MARKCOLOR") {
	$self->{$name}=$val;
    }
    if($name eq "MARKWIDTH") {
	$self->{$name}=$val;
    }
    if(($name eq "UPDATETIME") || ($name eq "UPDATESTATE")) {
	$self->{$name}=$val;
    }

    if($name eq "GEOMETRY") {
	$self->{$name}=$val;
	if($self->{BUILDREADY}) {
	    if($self->{GEOMETRY}!~/^\s*\-\s*$/) {
		$self->{MAIN}->geometry($self->{GEOMETRY});
	    }
	}
    }

    if($name eq "WITHOUTFRAME") {
	$self->{$name}=$val;
	$self->{MASTERWINDOW}->overrideredirect(($self->{WITHOUTFRAME}?1:0)) if($self->{BUILDREADY});
    } 

}

sub raiseNoteBook {
    my($self) = shift;
    my($name) = shift;
    $self->{MASTER_NB}->raise($name);
}


sub doMainLoop {
    my($self) = shift;
    MainLoop;
}

sub build_menu {
    my($self) = shift;
    my $top=$self->{MAIN};

    my $menu = $top->Frame(-relief => 'raised', -bd => 2, -background => "grey85"); 
    $self->{MENU}=$menu;

    # Eintraege im Menubar
    my $menu_pulldown1 = $menu->Menubutton(-text => "File", 
					-underline => 0, -background => "grey85"); 
    my $menu_pulldown2 = $menu->Menubutton(-text => "Options", 
					-underline => 0, -background => "grey85"); 

    # Normaler Pulldown Eintrag
    $menu_pulldown1->command(-label => "Exit", 
			     -command => [ \&exit_cb ]);
    $menu_pulldown1->command(-label => "Exit (all)", 
			     -command => [ \&realexit_cb ]);


    my $menu_pulldown3 = $menu->Menubutton(-text => "Help", 
					-underline => 0, -background => "grey85"); 
    $menu_pulldown3->command(-label => "Copyright", 
			     -command => sub {&start_disclaimer_cb($self->{INSTANCENR});},
			     -underline => 0, -background => "grey85"); 
    $menu_pulldown3->command(-label => "About LLview", 
			     -command => sub {&start_about_cb($self->{INSTANCENR});},
			     -underline => 0, -background => "grey85"); 

    
    $menu->pack(-side => 'top', -fill => 'x');
    $menu_pulldown1->pack(-side, 'left');
    $menu_pulldown2->pack(-side, 'left');
    $menu_pulldown3->pack(-side, 'right');

    $self->{MENUFILE}=$menu_pulldown1;
    $self->{MENUOPTIONS}=$menu_pulldown2;
    $self->{MENUHELP}=$menu_pulldown3;

    return;


}

sub build_keybindings {
    my($self) = shift;
    my $top=$self->{MAIN};

    $top->bind('<Control-KeyPress-z>' => [ \&realexit_cb ]);
    $top->bind('<Control-KeyPress-c>' => [ \&realexit_cb ]);
    $top->bind('<Control-KeyPress-q>' => [ \&exit_cb ]);
    $top->bind('<Control-KeyPress-w>' => [ \&exit_cb ]);

    $top->bind('<Control-KeyPress-w>' => [ \&print_xy, Ev('x'), Ev('y'), $self->{INSTANCENR} ]);

    $top->bind('<Control-KeyPress-l>' => [ \&refresh_display, Ev('x'), Ev('y'), $self->{INSTANCENR} ]);

    $top->bind('<Control-KeyPress-o>' => [ \&open_option_panel_cb, $self->{INSTANCENR}]);
    
    $top->bind('<Control-KeyPress-p>' => [ \&print_postscript, Ev('x'), Ev('y'), $self->{INSTANCENR} ]);

    $top->bind('<Control-KeyPress-u>' => [ \&update_cb, $self->{INSTANCENR} ]);
    $top->bind('<ButtonRelease-3>' => [ \&update_cb, $self->{INSTANCENR} ]);

    $top->bind('<Control-KeyPress-G>' => [ \&switch_data_src_to_grid, $self->{INSTANCENR} ]);
    $top->bind('<Control-KeyPress-W>' => [ \&switch_data_src_to_www,  $self->{INSTANCENR} ]);
    $top->bind('<Control-KeyPress-F>' => [ \&switch_data_src_to_file, $self->{INSTANCENR} ]);
    $top->bind('<Control-KeyPress-E>' => [ \&switch_data_src_to_exec, $self->{INSTANCENR} ]);



}

sub switch_data_src_to_www {
    my ($canv,$instancenr) = @_;
    my $self=${$selfref[$instancenr]}; 
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"General","SOURCE","www");
}

sub switch_data_src_to_file {
    my ($canv,$instancenr) = @_;
    my $self=${$selfref[$instancenr]}; 
#    print "WF: switch_data_src_to_file\n";
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"General","SOURCE","locdata");
}

sub switch_data_src_to_exec {
    my ($canv,$instancenr) = @_;
    my $self=${$selfref[$instancenr]}; 
#    print "WF: switch_data_src_to_exec\n";
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"General","SOURCE","exec");
}

sub switch_data_src_to_grid {
    my ($canv,$instancenr) = @_;
    my $self=${$selfref[$instancenr]}; 
    print "WF: switch_data_src_to_grid\n";
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"General","SOURCE","grid");
}

sub update_cb {
    my ($canv,$instancenr) = @_;
#    print "WF update_cb: $instancenr<\n";
    my $self=${$selfref[$instancenr]}; 
    $self->direct_update_no_timer();
}

sub active_cb {
    my ($canv,$instancenr) = @_;
    my $self=${$selfref[$instancenr]}; 
    # start timer only if switched to active
    if($self->{UPDATESTATE}==1) {
	&timestep($self->{INSTANCENR});
    }
}

sub exit_cb {
    exit(0);
}

sub realexit_cb {
    exit(100);
}

sub open_option_panel_cb {
    my ($canv,$instancenr) = @_;
    my $self=${$selfref[$instancenr]}; 
    $self->{OPTIONOBJECT}->toggle_option_panel();
}

sub build_buttons {
    my($self) = shift;
    my($RELOAD_ICON,$reload,$field);
    my $top=$self->{MENU};

    my $tf = $top->Frame(-borderwidth => 2, -relief => 'raised', -background => "grey85"
			)->pack(-padx=>10, -expand => 0, -fill=>'x');

    $RELOAD_ICON=$self->{INSTPATH}."/lib/images/reload.gif";
    $reload = $self->{MAIN}->Photo(-file => $RELOAD_ICON, -format => 'gif');

    
    $tf->Label(-text => "Step", -justify => 'left', -background => "grey85")->pack(-side => 'left');
    $tf->Entry(-textvariable => \$self->{UPDATETIME}, 
	       -width => 3,
	       -background => "grey95",
	       -foreground => "blue",
	       )->pack(-side => 'left');
    $tf->Label(-text => "s", -justify => 'left', -background => "grey85")->pack(-side => 'left');

    $tf->Checkbutton(-text => 'active  ',
		     -variable => \$self->{UPDATESTATE},
		     -onvalue => "1",
		     -offvalue => "0",
		     -background => "grey85",
#		     -font => $self->{BFONT2},
		     -command => sub { &active_cb($self->{INSTANCENR});},
		     )->pack(-side => 'left');

    $tf->Button(-text => 'Update',
		-image => $reload,
		-command => sub { &update_cb($self->{INSTANCENR});},
		-width => 18,
		-height => 18,
		-font => $self->{BFONT2},
		, -background => "grey85"
		)->pack(-side => 'left');
    
    $tf->Label(-text => "     Search", -justify => 'left', -background => "grey85")->pack(-side => 'left');
    $field=$tf->Entry(-textvariable => \$self->{SEARCHSTR}, 
		      -width => 15,
		      -foreground => "blue",
		      -background => "grey95",
		      )->pack(-side => 'left');
    $field->bind( "<Key-Return>" => [\&updatesearch_cb,$self->{INSTANCENR}] );
    $field->bind( "<FocusOut>" => [\&updatesearch_cb,$self->{INSTANCENR}] );


    $self->{DATATYPEWIDGET}=$tf->Label(-textvariable => \$self->{DATATYPE}, 
	       -justify => 'left', -width => 5,
	       -relief => "sunken",
	       -foreground => "blue",
	       -background => "white",
	       )->pack(-side => 'right');
    $tf->Label(-text => "Source", -justify => 'left', -background => "grey85")->pack(-side => 'right');
    $self->{UPDATEWIDGET}=$tf->Label(-textvariable => \$self->{UPDATECOMMENT}, 
	       -justify => 'left', -width => 5,
	       -relief => "sunken",
	       -foreground => "blue",
	       -background => "white",
	       )->pack(-side => 'right');
    $tf->Label(-text => "next in", -justify => 'left', -background => "grey85")->pack(-side => 'right');
    $self->{UPDATETIMESTRWIDGET}=$tf->Label(-textvariable => \$self->{UPDATETIMESTR}, 
	       -justify => 'left', -width => 16,
	       -relief => "sunken",
	       -foreground => "blue",
	       -background => "white",
	       )->pack(-side => 'right');
    $tf->Label(-text => " Last Update", -justify => 'left', -width => 11, -background => "grey85")->pack(-side => 'right');

# WF 20.03.07:  changed to color because older Perl/Tk 
#               version does not support -state and -disableforeground
#
#    $self->{UPDATELABEL}=$tf->Label(-text => "[Update ...]", -justify => 'left', -width => 20,
#				    -foreground => "red", -background => "grey85",-disabledforeground => "grey85",
#				    -state => "disabled")->pack(-side => 'right');
#
    $self->{UPDATELABEL}=$tf->Label(-text => "[Update ...]", -justify => 'left', -width => 20,
				    -foreground => "red", -background => "grey85",
				    )->pack(-side => 'right');

#    $tf->Clock(-useAnalog => 0)->pack();

#    $tf->Button(-text => 'Clear',
#		-command => sub { $GUI{"prototext"}->delete('1.0', 'end'); }
#		)->pack(-side => 'left');



}

sub set_normal_display {
    my($self) = shift;
    $self->{UPDATETIMESTRWIDGET}->configure(-foreground => "blue");
}

sub set_error_display {
    my($self) = shift;
    $self->{UPDATETIMESTRWIDGET}->configure(-foreground => "red");
}

sub set_time_text {
    my($self) = shift;
    $self->{UPDATETIMESTR}=shift;
}

sub set_error_text {
    my($self) = shift;
    $self->{UPDATETIMESTR}=shift;
}

sub set_datatype_text {
    my($self) = shift;
    $self->{DATATYPE}=shift;
}

sub set_window_name {
    my($self) = shift;
    my($name)=shift;
    $self->{MASTERWINDOW}->configure(-title => "llview: $name");
}

sub raisenotebookpage {
    my($self) = shift;
    $self->{NOTEBOOK}->raise(shift) if($#{$self->{NOTEBOOKOBJECTS}}>-1);
}

# updates data and gui elements
sub direct_update_no_timer {
    my($self) = shift;
    my($rc);
    print "LLview_gui_main: direct_update_no_timer\n" if($debug==3);
    
    # delayed to event manager, singnaling update ...
#    $self->{UPDATELABEL}->configure(-state => "normal");
    $self->{UPDATELABEL}->configure(-foreground => "red");
    $self->{MAIN}->after(80, sub { &calltimermethods_cb($self->{INSTANCENR});} );

#    $rc=$self->calltimermethods();
#    $rc=$self->callupdatemethods() if($rc);
    return($rc);
}

# updates gui elements
sub direct_update_gui {
    my($self) = shift;
    my($rc);
   $self->{UPDATETIMEREST}=0;
    print "LLview_gui_main: direct_update_gui\n"  if($debug==3);
    $rc=$self->callupdatemethods();
    return($rc);
}

sub update {
    my($self) = shift;
    my($dataobj) = shift;
    if($dataobj) {
	$self->{UPDATETIMESTR}=$dataobj->{TIMESTR};
#    print "WF: update ,",ref($dataobj),"<",$dataobj->{TIMESTR},"<\n";
    }
    return 1;
}

sub checkbindings {
    my($self) = shift;
    my($nr,$cv);
    my $canvas=$self->{CANVAS};
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $infoobject=$self->{INFOOBJECT};
    return(1) if (!$dataobject);
    foreach $nr ($colorobject->getusednrs_all()) {
	if(!($self->{USEDNRS}->[$nr])) {
	    $self->{USEDNRS}->[$nr]=1;
	    foreach $cv (@{$self->{SUBCANVASLIST}}) {
		$cv->bind("T${nr}R", "<ButtonPress-1>", sub { &markitems("ON",$nr,$self->{INSTANCENR}); });
		$cv->bind("T${nr}R", "<ButtonRelease-1>", sub { &markitems("OFF",$nr,$self->{INSTANCENR}); });
		$cv->bind("T${nr}RNF", "<ButtonPress-1>", sub { &markitems("ON",$nr,$self->{INSTANCENR}); });
		$cv->bind("T${nr}RNF", "<ButtonRelease-1>", sub { &markitems("OFF",$nr,$self->{INSTANCENR}); });
		$cv->bind("T${nr}B", "<ButtonPress-1>", sub { &markitems("ON",$nr,$self->{INSTANCENR}); });
		$cv->bind("T${nr}B", "<ButtonRelease-1>", sub { &markitems("OFF",$nr,$self->{INSTANCENR}); });
		$cv->bind("T${nr}R", '<Enter>' => [sub { my ($c, $id) = @_;
							 &highlightitems("ON",$id,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR})}, $nr]);
		$cv->bind("T${nr}R", '<Leave>' => [sub { my ($c, $id) = @_;
							 &highlightitems("OFF",$id,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR})}, $nr]);
		$cv->bind("T${nr}RNF", '<Enter>' => [sub { my ($c, $id) = @_;
							 &highlightitems("ON",$id,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR})}, $nr]);
		$cv->bind("T${nr}RNF", '<Leave>' => [sub { my ($c, $id) = @_;
							 &highlightitems("OFF",$id,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR})}, $nr]);
		$cv->bind("T${nr}B", '<Enter>' => [sub { my ($c, $id) = @_;
							 &highlightitems("ON",$id,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR})}, $nr]);
		$cv->bind("T${nr}B", '<Leave>' => [sub { my ($c, $id) = @_;
							 &highlightitems("OFF",$id,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR})}, $nr]);
#	         printf("%2d: check %s\n",$nr,"T${nr}R");
	    }
	}
    }

    return 1;
}


# will bwe called by colorobject if the color mapping was changed
sub updatecoloredobjects {
    my($self) = shift;
    my($category)=@_;
    my($nr,$color);

#    print "WF: updatecoloredobjects in forecast was called for category $category\n";
    foreach $nr ($self->{COLOROBJECT}->getusednrs($category)) {
	$color=$self->{COLOROBJECT}->nrtocolor($category,$nr);
	$self->{CANVAS}->itemconfigure("T${nr}R", -fill => "$color"); 
#	print "   updatecoloredobjects T${nr}R -> $color\n";

    }

}


sub autoplay {
    my($self) = shift;
    my $dataobject=$self->{DATAOBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $nr;
#    return() if(!($self->{AUTOPLAY} && ($self->{UPDATETIMEREST}%$self->{AUTOPLAYSTEP}==0)));

    $self->{AUTOPLAYNR}=0 if($self->{AUTOPLAYNR}>=$#{$self->{ACTIVENRS}});
    highlightitems("OFF",$self->{LASTHIGHLIGHTEDNR},0,0,$self->{INSTANCENR}) if($self->{LASTHIGHLIGHTEDNR}>=0);
    $nr=$self->{ACTIVENRS}->[$self->{AUTOPLAYNR}];
    highlightitems("ON",$nr,0,0,,$self->{INSTANCENR});
    my $aa=$colorobject->nrtoid("RUN",$nr);
    
#    print "main: autoplay on $self->{AUTOPLAYNR} $nr $aa $dataobject->{RUNNINGDATA}->{$aa}{FL_ALLCPU} $dataobject->{RUNNINGDATA}->{$aa}{FL_WALLSEC} \n";
    $self->{AUTOPLAYNR}+=1;

}

sub timestep {
    my ($instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    my($funcref,$funcname);
    my $dataobject=$self->{DATAOBJECT};
    my ($rc);
    print "#	timestep updatetime=$self->{UPDATETIME} rest=$self->{UPDATETIMEREST}\n"  if($debug==3);

    # reduce UPDATETIMEREST if UPDATETIME is descreased since last call 
    $self->{UPDATETIMEREST}=$self->{UPDATETIME} if($self->{UPDATETIMEREST}>$self->{UPDATETIME});

    
    if($self->{UPDATETIMEREST}<$self->{UPDATETIMESTEP}) {
	# start timer and gui update
	$dataobject->printsize("timestep: start") if($debug==5);

	# Executing timer functions
#	$rc=$self->calltimermethods();

#	$self->{UPDATELABEL}->configure(-state => "normal");
	$self->{UPDATELABEL}->configure(-foreground => "red");
	$self->{MAIN}->after(80, sub { &calltimermethods_cb($self->{INSTANCENR});} );
	$self->{UPDATETIMEREST}=$self->{UPDATETIME};

#	$self->{UPDATETIMEREST}=$self->{UPDATETIME};
#	if($rc) {
#	    # Executing update method of gui objects
#	    $self->callupdatemethods();
#	}
    } else {
	# decrease time counter
	$self->{UPDATETIMEREST}-=$self->{UPDATETIMESTEP};
    }
    
    foreach $funcname (@{$self->{STEPTIMERFUNCTIONS}}) {
	print "#	steptimestep -> $funcname();\n"  if($debug==3);
	$funcref=$self->{FUNCTIONS}->{$funcname};
	$rc=&$funcref($self->{UPDATETIME},$self->{UPDATETIME}-$self->{UPDATETIMEREST});
	$dataobject->printsize("timestep: after $funcname") if($debug==5);
	print "#	steptimestep -> $funcname(); ready\n"  if($debug==3);
	last if(!$rc);
    }

    # some every time step updates
    $self->autoplay() if($self->{AUTOPLAY} && ($self->{UPDATETIMEREST}%$self->{AUTOPLAYSTEP}==0));
    
    # will be done by a binded routine
#    print "WF: SEARCHSTR $self->{SEARCHSTR} ($self->{SEARCHSTRLAST})\n";
#    $self->updatesearch() if($self->{SEARCHSTR} ne $self->{SEARCHSTRLAST});

    # restart timer
    if($self->{UPDATESTATE} eq 1) {
#	print "WF: restart time with delay",$self->{UPDATETIMESTEP}*1000," ms \n";
	$self->{MAIN}->after($self->{UPDATETIMESTEP}*1000, sub { &timestep($self->{INSTANCENR});} );
    }

    $self->{UPDATECOMMENT}   = sprintf("%02d s",$self->{UPDATETIMEREST});

#    print "WF: timestep end,",ref($self),"\n";

}

sub calltimermethods_cb {
    my ($instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    my $rc=$self->calltimermethods();
    if($rc) {
	# Executing update method of gui objects
	$self->callupdatemethods();
    }
#    $self->{UPDATELABEL}->configure(-state => "disabled");
    $self->{UPDATELABEL}->configure(-foreground => "grey85");
}

sub calltimermethods {
    my $self=shift;
    my($funcname,$funcref,$rc);
    my $dataobject=$self->{DATAOBJECT};

    foreach $funcname (@{$self->{TIMERFUNCTIONS}}) {
	print "#	timestep -> $funcname();\n"  if($debug==3);
	$funcref=$self->{FUNCTIONS}->{$funcname};
	$self->{MAIN}->Busy();
		$rc=&$funcref;
	$self->{MAIN}->Unbusy();
	$dataobject->printsize("timestep: after $funcname") if($debug==5);
	last if(!$rc);
    }
    return($rc);
}

sub callupdatemethods {
    my $self=shift;
    my($funcname,$funcref,$rc);
    my($objref,$objname);
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my (@ulist,$resid);
    my($nr,$jobid);
    my($package, $filename, $line) = caller;

    if($dataobject) {
#	print "WF: in main:callupdatemethods from $package, $filename, $line) $self->{INSTANCENR} frames=",
#	$dataobject->{FRAMES},"\n";

	# from reservation
	foreach $resid (keys( %{$dataobject->{RESERVATION}} )) {
	    push(@ulist,$dataobject->{RESERVATION}->{$resid}{'user'});
	    push(@ulist,$resid);
	}
	# from forecast
	foreach $jobid 	(keys( %{$dataobject->{WAITINGJOBS}} )) {
	    next if($dataobject->{JOBSTATE}->{$jobid}{"job_statuslong"} eq "HOLD");
	    push(@ulist,$jobid);
	}


	$colorobject->free_unused("RUN",keys(%{$dataobject->{RUNNINGDATA}}));
	$colorobject->free_unused("WAIT",@ulist);
	$dataobject->printsize("timestep: after free_unused") if($debug==5);
    }

    foreach $objname (@{$self->{UPDATEOBJECTS}}) {
	print "#	update -> $objname->update();\n" if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
	$objref->update($dataobject);
	$dataobject->printsize("timestep: after update $objname") if($debug==5);
    }
    
    $self->unhighlightallitems();
    $dataobject->printsize("timestep: after unhighlightallitems") if($debug==5);
    
    # Executing update method of canvas objects
    foreach $objname (@{$self->{CANVASOBJECTS}}) {
	print "#	update -> $objname->update();\n" if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
	$objref->update($dataobject,$colorobject,$infoobject,$self->{CANVAS});
	$dataobject->printsize("timestep: after update $objname") if($debug==5);
    }

    # Executing update method of canvas objects on other canvas (multicluster overview)
    foreach $objname (@{$self->{CANVASOBJECTSONCANVAS}}) {
	print "#	update -> $objname->update();\n" if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
	$objref->update($dataobject,$colorobject,$infoobject,$self->{CANVASFOROBJECT}->{$objname});
	$dataobject->printsize("timestep: after update $objname") if($debug==5);
    }
    
    
    # Executing update method of notebook objects
    foreach $objname (@{$self->{NOTEBOOKOBJECTS}}) {
	print "#	update -> $objname->update();\n" if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
		$objref->update($dataobject,$colorobject,$infoobject,$self->{NOTEBOOKFRAMES}->{$objname});
	$dataobject->printsize("timestep: after update $objname") if($debug==5);
    }
    
    # Executing update method of notebook canvas objects
    foreach $objname (@{$self->{NOTEBOOKCANVASOBJECTS}}) {
	print "#	update -> $objname->update();\n" if($debug==3);
	$objref=$self->{OBJECTS}->{$objname};
	$objref->update($dataobject,$colorobject,$infoobject,$self->{NOTEBOOKFRAMES}->{$objname});
	$dataobject->printsize("timestep: after update $objname") if($debug==5);
    }
    
    # only if a valid dataobject exists (not in General panel, Multicluster)
    if ($dataobject) {
	$self->checkbindings();
	$dataobject->printsize("timestep: after checkbindings") if($debug==5);
	
	$self->highlightolditems();
	$dataobject->printsize("timestep: end of routine") if($debug==5);
	
	$dataobject->reportsize() if($debug==5);
	
	@{$self->{ACTIVENRS}}=($colorobject->getusednrs("RUN"));
#	foreach $nr (sort {sort_jobs_allcpu_up($dataobject,$colorobject)} ($colorobject->getusednrs("RUN"))) {
#	    $jobid=$colorobject->nrtoid("RUN",$nr);
#	    if(exists($dataobject->{JOBSTATE}->{$jobid})) {
#		push(@{$self->{ACTIVENRS}},$nr);
#	    }
#	}
    }
    return($rc);
}


sub updatesearch_cb {
    my ($canv,$instancenr)=@_;
#    print "WF: updatesearch_cb: instancenr=$instancenr \n";
    my $self=${$selfref[$instancenr]};
    $self->updatesearch() if($self->{SEARCHSTR} ne $self->{SEARCHSTRLAST});
}

sub updatesearch {
    my $self=shift;
    my($funcref,$funcname);
    my($objref,$objname,$cvn,$cvo);
    my $dataobject=$self->{DATAOBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    print "update search:",$self->{SEARCHSTR},"\n"  if($debug==3);
    foreach $cvn (@{$self->{SEARCHOBJECTS}}) {
	$cvo=$self->{OBJECTS}->{$cvn};
	$cvo->set_searchstr($self->{SEARCHSTR}); 
    }
    $self->{SEARCHSTRLAST}=$self->{SEARCHSTR};
    $self->direct_update_gui();
}

sub markitems {
    my ($state,$nr,$instancenr)=@_;
    my $self=${$selfref[$instancenr]};
    my($funcref,$funcname);
    my($objref,$objname);
    my($color,$cv,$cvn,$cvo);
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my $canvas=$self->{CANVAS};
    my ($inr);
    return() if (!$colorobject->nrtoid("RUN",$nr));
    my $jobid=$colorobject->nrtoid("RUN",$nr);

    print "markitems: >$state<>$jobid< $nr start\n" if($debug==4);

    if($state eq "ON") {
	foreach $inr ($colorobject->getusednrs("RUN")) {
	    if($inr ne $nr) {
		foreach $cv (@{$self->{SUBCANVASLIST}}) {
		    $cv->itemconfigure("T${inr}R", -fill => "grey80", 
				       -tags => ["markR","T${inr}R"]); 
		}
	    }
	}
    } else {
	foreach $inr ($colorobject->getusednrs("RUN")) {
	    my $jobid=$colorobject->nrtoid("RUN",$inr);
	    my $color=$colorobject->get_color("RUN",$jobid);
	    foreach $cv (@{$self->{SUBCANVASLIST}}) {
		$cv->itemconfigure("T${inr}R", -fill => "$color", 
				   -tags => ["markR","T${inr}R"]); 
	    }
	}
    }    
    Tk->break();
}

sub highlightitems {
    my ($state,$nr,$x,$y,$instancenr)=@_;
    my $self=${$selfref[$instancenr]};
    my($funcref,$funcname);
    my($objref,$objname);
    my($color,$cv,$cvn,$cvo);
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my $canvas=$self->{CANVAS};
    $dataobject->printsize("highlight: start of routine") if($debug==5);
    return() if (!$colorobject);
    my $category=$colorobject->nrtocat($nr);
    my $jobid=$colorobject->nrtoid($category,$nr);

    return if(!$jobid); # suppress highlighting before real startup ready

    #    return() if (!$colorobject->nrtoid("RUN",$nr));

    # no changes if positions not changes, prevent deadlock
    print "highlightitems: >$state< >$category< >$jobid< $nr start $x,$y <>$self->{EVX},$self->{EVY}","\n" if($debug==4);
    return if(($self->{EVX}==$x) && ($self->{EVY}==$y) && $state eq "OFF");
    $self->{EVX}=$x;$self->{EVY}=$y;

    if($state eq "ON") {
	$self->unhighlightallitems();
	foreach $cv (@{$self->{SUBCANVASLIST}}) {
	    $cv->itemconfigure("T${nr}R", -outline => "grey10", 
			                  -width => $self->{MARKWIDTH}, 
			                  -tags => ["highlightR","T${nr}R"]); 
	}
	foreach $cvn (@{$self->{SUBCANVASOBJECTS}}) {
	    $cvo=$self->{OBJECTS}->{$cvn};
	    $cv=$cvo->{SUBCANVAS};
	    $cv->itemconfigure("T${nr}B", -font => $cvo->{BFONT1}, 
			                  -tags => ["highlightB","T${nr}B"]);
	    $cv->itemconfigure("T${nr}F", -fill => $self->{MARKCOLOR},  
			                  -tags => ["highlightF","T${nr}F"]);

	}
	foreach $cvn (@{$self->{SCROLLEDOBJECTS}}) {
	    $cvo=$self->{OBJECTS}->{$cvn};
	    $cvo->scroll_to($jobid); 
	}
	$infoobject->jobinfo($category,$jobid);
	$color=$colorobject->get_color($category,$jobid);
	print "highlightitems: ---> $jobid undefined\n" if(!defined($dataobject->{RUNNINGDATA}->{$jobid})) && ($debug==4);
	print "WF: $jobid->$nr\n" if($debug==4);
	$self->{LASTHIGHLIGHTEDNR}=$nr;
    } else {
	foreach $cv (@{$self->{SUBCANVASLIST}}) {
	    $cv->itemconfigure("T${nr}R", -outline => "black", 
			                  -width => 1, 
			                  -tags => ["T${nr}R"]);
	}
	foreach $cvn (@{$self->{SUBCANVASOBJECTS}}) {
	    $cvo=$self->{OBJECTS}->{$cvn};
	    $cv=$cvo->{SUBCANVAS};
	    $cv->itemconfigure("T${nr}B",   -font => $cvo->{FONT1}, 
			                    -tags => ["T${nr}B"]); 
	    $cv->itemconfigure("T${nr}F", -fill => "grey85", 
			                  -tags => ["highlightF","T${nr}F"]);
	}
	$infoobject->defaultinfo();
	$self->{LASTHIGHLIGHTEDNR}=-1;
    }
    $dataobject->printsize("highlight: end of routine") if($debug==5);

}

sub highlightfreeitems {
    my ($state,$name,$instancenr)=@_;
    my $self=${$selfref[$instancenr]};
    my($funcref,$funcname);
    my($objref,$objname);
    my($color,$cv);
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my $canvas=$self->{CANVAS};

    $dataobject->printsize("highlightfreeitems: start of routine") if($debug==5);
    print "highlightfreeitems: >$state<>$name< start\n" if($debug==4);
    if($state eq "ON") {
	$self->unhighlightallitems();
	foreach $cv (@{$self->{SUBCANVASLIST}}) {
	    $cv->itemconfigure("free", -width => $self->{MARKWIDTH}, -tags => ["highlightR","free"]); 
	}
	$infoobject->freeinfo($name);
	$self->{LASTHIGHLIGHTEDNR}="free";
    } else {
	foreach $cv (@{$self->{SUBCANVASLIST}}) {
	    $cv->itemconfigure("free", -outline => "black", -width => 1, -tags => ["free"]);
	}
	$infoobject->defaultinfo();
	$self->{LASTHIGHLIGHTEDNR}=-1;
    }
    print "highlightfreeitems: >$state<>$name< end\n" if($debug==4);
    $dataobject->printsize("highlightfreeitems: end of routine") if($debug==5);
}

sub unhighlightallitems {
    my($self) = shift;
    my $canvas=$self->{CANVAS};
    my($id,@list,$cv);
    foreach $cv (@{$self->{SUBCANVASLIST}}) {
	@list=$cv->find("withtag","highlightR");
	foreach $id (@list) {
#	    printf("unhighlightallitems: id found %s\n",$id);
	    $cv->itemconfigure($id, -outline => "black", -width => 1); 
	    $cv->dtag($id ,"highlightR"); 
	}
	@list=$cv->find("withtag","highlightB");
	foreach $id (@list) {
	    $cv->itemconfigure($id, -font => $self->{FONT1}); 
	    $cv->dtag($id ,"highlightB"); 
	}
	@list=$cv->find("withtag","highlightF");
	foreach $id (@list) {
	    $cv->itemconfigure($id, -fill => "grey85"); 
	    $cv->dtag($id ,"highlightF"); 
	}
    }
}

sub highlightolditems {
    my($self) = shift;
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $lastjobid;
    $dataobject->printsize("highlightolditems: start of routine") if($debug==5);
    if($self->{LASTHIGHLIGHTEDNR} eq "free") {
	&highlightfreeitems("ON","free",$self->{INSTANCENR});
    } else {
	if($self->{LASTHIGHLIGHTEDNR}>=0) {
	    $lastjobid=$colorobject->nrtoid("RUN",$self->{LASTHIGHLIGHTEDNR});
	    if($lastjobid) {
		if(defined($dataobject->{RUNNINGDATA}->{$lastjobid}{FL_ALLCPU})) {
		    &highlightitems("ON",$self->{LASTHIGHLIGHTEDNR});
		}
	    }
	}
    }
    $dataobject->printsize("highlightolditems: end of routine") if($debug==5);
}

sub sort_jobs_allcpu_up   { 
    my($dataobj,$colobj) = @_;
    my $aa=$colobj->nrtoid($a);
    my $bb=$colobj->nrtoid($b);
    if((exists($dataobj->{RUNNINGDATA}->{$aa})) && exists($dataobj->{RUNNINGDATA}->{$bb})) {
	if($dataobj->{RUNNINGDATA}->{$bb}{FL_ALLCPU} == $dataobj->{RUNNINGDATA}->{$aa}{FL_ALLCPU}) {
	    if($dataobj->{RUNNINGDATA}->{$bb}{FL_WALLSEC} == $dataobj->{RUNNINGDATA}->{$aa}{FL_WALLSEC}) {
		$dataobj->{RUNNINGDATA}->{$bb}{FL_RESTSEC} <=> $dataobj->{RUNNINGDATA}->{$aa}{FL_RESTSEC};
	    } else {
		$dataobj->{RUNNINGDATA}->{$bb}{FL_WALLSEC} <=> $dataobj->{RUNNINGDATA}->{$aa}{FL_WALLSEC};
	    }
	} else {
	    $dataobj->{RUNNINGDATA}->{$bb}{FL_ALLCPU} <=> $dataobj->{RUNNINGDATA}->{$aa}{FL_ALLCPU};
	}
    } else {
	return(0);
    }
}

sub start_about_cb {
    my ($instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    my($text,$FZJ_LOGO,$logo);
    if(!Exists($self->{ABOUTWIN})) {
	$self->{ABOUTWIN}=$self->{MAIN}->Toplevel();
	$self->{ABOUTWIN}->title("About LLview");

	$self->{ABOUTWIN}->Button(-text => "Close",-command => sub {&close_about_cb($self->{INSTANCENR});}
				  )->pack (-side =>"bottom");

	$text="\nLLVIEW";
	$self->{ABOUTWIN}->Label(-text => $text, -foreground => "blue", -font => $self->{BFONT3} )->pack();

	$text="Version ".$self->{VERSION}."\n\n\n";
	$text.="graphical monitoring of\n";
	$text.="LoadLeveler controlled cluster\n\n";
	$text.="Copyright (C) 2004-2007\n";
	$text.="Developed at\n";
	$text.="Central Institute for Applied Mathematics,\n";
	$text.="Research Center Juelich\n";
	$text.="All Right reserved";
	$self->{ABOUTWIN}->Label(-text => $text )->pack();

	$FZJ_LOGO=$self->{INSTPATH}."/lib/images/Logo-ohne-Schrift-Blau.small.gif";
	$logo = $self->{MAIN}->Photo(-file => $FZJ_LOGO, -format => 'gif');
	$self->{ABOUTWIN}->Label(-image => $logo)->pack();

	$text ="Contact: llview.zam.kfa-juelich.de\n";
	$text.="WWW:     http://www.fz-juelich.de/zam/llview\n";
	$self->{ABOUTWIN}->Label(-text => $text, -justify => "left" )->pack(-side => 'right');
	
    } else {
	$self->{ABOUTWIN}->deiconify();
	$self->{ABOUTWIN}->raise();
    }

}

sub close_about_cb {
    my ($instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    if(Exists($self->{ABOUTWIN})) {
	$self->{ABOUTWIN}->withdraw();
    }

}

sub start_disclaimer_cb {
    my ($instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    my($text,$FZJ_LOGO,$logo);
    if(!Exists($self->{DISCLAIMERWIN})) {
	$self->{DISCLAIMERWIN}=$self->{MAIN}->Toplevel();
	$self->{DISCLAIMERWIN}->title("Copyright and Disclaimer");

	$self->{DISCLAIMERWIN}->Button(-text => "Close",-command => sub {&close_disclaimer_cb($self->{INSTANCENR});}
				  )->pack (-side =>"bottom");

	$text="\nCopyright and Disclaimer\n";
	$self->{DISCLAIMERWIN}->Label(-text => $text, -foreground => "blue", -font => $self->{BFONT3} )->pack();

$text="\n";
$text.="   Copyright (C) 2004-2005, Forschungszentrum Juelich GmbH, Federal Republic of\n";
$text.="   Germany. All rights reserved.\n";
$text.="   Redistribution and use in source and binary forms, with or without\n";
$text.="   modification, are permitted provided that the following conditions are met:\n";
$text.="\n";
$text.="   Redistributions of source code must retain the above copyright notice, this\n";
$text.="   list of conditions and the following disclaimer.\n";
$text.="\n";
$text.="     - Redistributions of source code must retain the above copyright notice,\n";
$text.="       this list of conditions and the following disclaimer.\n";
$text.="\n";
$text.="     - Redistributions in binary form must reproduce the above copyright\n";
$text.="       notice, this list of conditions and the following disclaimer in the\n";
$text.="       documentation and/or other materials provided with the distribution.\n";
$text.="\n";
$text.="     - Any publications that result from the use of this software shall\n";
$text.="       reasonably refer to the Research Centre's development.\n";
$text.="\n";
$text.="     - All advertising materials mentioning features or use of this software\n";
$text.="       must display the following acknowledgement:\n";
$text.="\n";
$text.="           This product includes software developed by Forschungszentrum\n";
$text.="           Juelich GmbH, Federal Republic of Germany.\n";
$text.="\n";
$text.="     - Forschungszentrum Juelich GmbH is not obligated to provide the user with\n";
$text.="       any support, consulting, training or assistance of any kind with regard\n";
$text.="       to the use, operation and performance of this software or to provide\n";
$text.="       the user with any updates, revisions or new versions.\n";
$text.="\n";
$text.="\n";
$text.="   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH \"AS IS\" AND ANY\n";
$text.="   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED\n";
$text.="   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE\n";
$text.="   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR\n";
$text.="   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER\n";
$text.="   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF\n";
$text.="   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN\n";
$text.="   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.\n";

	$self->{DISCLAIMERWIN}->Label(-text => $text )->pack();

	
    } else {
	$self->{DISCLAIMERWIN}->deiconify();
	$self->{DISCLAIMERWIN}->raise();
    }

}

sub close_disclaimer_cb {
    my ($instancenr) = @_;
    my $self=${$selfref[$instancenr]};
    if(Exists($self->{DISCLAIMERWIN})) {
	$self->{DISCLAIMERWIN}->withdraw();
    }

}


sub BindMouseWheel {
     my($self) = shift;
     my($w) = @_;
 
     if ($^O eq 'MSWin32') {
	 $w->bind('<MouseWheel>' =>
		  [ sub { $_[0]->yview('scroll', -($_[1] / 120) * 3, 'units') },
		    Ev('D') ]
		  );
     } else {
	 
       # Support for mousewheels on Linux commonly comes through
       # mapping the wheel to buttons 4 and 5.  If you have a
       # mousewheel ensure that the mouse protocol is set to
       # "IMPS/2" in your /etc/X11/XF86Config (or XF86Config-4)
       # file:
       #
       # Section "InputDevice"
       #     Identifier  "Mouse0"
       #     Driver      "mouse"
       #     Option      "Device" "/dev/mouse"
       #     Option      "Protocol" "IMPS/2"
       #     Option      "Emulate3Buttons" "off"
       #     Option      "ZAxisMapping" "4 5"
       # EndSection
	 
	 $w->bind('<4>' => sub {
	     $_[0]->yview('scroll', -3, 'units') unless $Tk::strictMotif;
	 });
 
	 $w->bind('<5>' => sub {
	     $_[0]->yview('scroll', +3, 'units') unless $Tk::strictMotif;
	 });
    }
 
} # end BindMouseWheel

1;




