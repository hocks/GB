# $Source: /cvs/cvsroot/llview/lib/LLview_manage_elements_mc.pm,v $
# $Author: zdv087 $
# $Revision: 1.29 $
# $Date: 2007/07/24 07:54:31 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2005, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_manage_elements_mc;
use strict;

use LLview_manage_colors;

use LLview_get_locdata;
use LLview_get_www;
use LLview_get_ssh;
use LLview_get_exec;

#my $enable_grid=1;
#use LLview_get_grid;

my $enable_grid=0;

use LLview_parse_xml;

use LLview_gui_main;
use LLview_gui_scala;
use LLview_gui_nodes;
use LLview_gui_joblist;
use LLview_gui_waiting;
use LLview_gui_running;
use LLview_gui_graph;
use LLview_gui_histogram;
use LLview_gui_info;
use LLview_gui_status;

use LLview_gui_scalahist;

use LLview_gui_partlist;
use LLview_gui_resgraph;
use LLview_gui_forecast;
use LLview_gui_usage;

my($debug)=0;
my($selfref)=-1;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_manage_elements_mc: new %s\n",ref($proto)) if($debug>=3);

    $self->{INSTPATH}= "";
    $self->{INIFILE}->{"-"}= "";
    $self->{VERBOSE}->{"-"}= 1;
    $self->{SHOWPM}->{"-"} = 0;
    $self->{MAXCLUSTER}    = 4;

    $self->{MAINCOLORMANAGER}  = undef;
    $self->{COLORMANAGER}  = undef;
    $self->{RECEIVER}      = undef;
    $self->{PARSER}        = undef;
    $self->{MAINWIN}       = undef;
    $self->{INFO}          = undef;
    $self->{STATUS}        = undef;
    $self->{SCALA}         = undef;
    $self->{NODES}         = undef;
    $self->{JOBLIST}       = undef;
    $self->{RUNNING}       = undef;
    $self->{WAITING}       = undef;
    $self->{GRAPH}         = undef;
    $self->{HISTOGRAM}     = undef;
    $self->{SCALAHIST}     = undef;

    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}     = "-*-Helvetica-Bold-R-Normal--*-160-*-*-*-*-*-*";

    $self->{SOURCE}->{"-"}        = "locdata";
    $self->{DOINFO}->{"-"}        = 1;
    $self->{DOSTATUS}->{"-"}      = 1;
    $self->{DOSCALA}->{"-"}       = 1;
    $self->{DONODES}->{"-"}       = 1;
    $self->{DOJOBLIST}->{"-"}     = 1;
    $self->{DORUNNING}->{"-"}     = 1;
    $self->{DOWAITING}->{"-"}     = 1;
    $self->{DOGRAPH}->{"-"}       = 0;
    $self->{DOHISTOGRAM}->{"-"}   = 1;
    $self->{DOHISTORY}->{"-"}     = 1;
    $self->{DOPARTLIST}->{"-"}    = 0;
    $self->{DORESGRAPH}->{"-"}    = 0;
    $self->{DOUSAGEGRAPH}->{"-"}  = 0;
    $self->{REMOTECONTROL}->{"-"} = 0;
    $self->{TIMER}->{"-"}         = -1;
    $self->{SEARCHSTR}->{"-"}     = "";
    $self->{SELECTNODES}->{"-"}   = ".*";
    $self->{SELECTUID}->{"-"}     = ".*";
    $self->{DEMOVERSION}->{"-"}   = 0;
    $self->{ERRFILE}       = undef;
    $self->{PREFIX}        = "";
    
    $self->{CLUSTERACTIVE0}->{"-"}       = 1;
    $self->{"CLUSTERNAME0"}->{"-"}       = "Jump";
    $self->{"CLUSTERPREFIX0"}->{"-"}     = "jump";
    $self->{"CLUSTERDESC0"}->{"-"}       = "";

    $self->{CLUSTERACTIVE1}->{"-"}       = 1;
    $self->{"CLUSTERNAME1"}->{"-"}       = "Jubl";
    $self->{"CLUSTERPREFIX1"}->{"-"}     = "jubl";
    $self->{"CLUSTERDESC1"}->{"-"}       = "";

    $self->{CLUSTERACTIVE2}->{"-"}       = 1;
    $self->{"CLUSTERNAME2"}->{"-"}       = "Idris";
    $self->{"CLUSTERPREFIX2"}->{"-"}     = "idr";
    $self->{"CLUSTERDESC2"}->{"-"}       = "";

    $self->{CLUSTERACTIVE3}->{"-"}       = 0;
    $self->{"CLUSTERNAME3"}->{"-"}       = "-";
    $self->{"CLUSTERPREFIX3"}->{"-"}     = "-";
    $self->{"CLUSTERDESC3"}->{"-"}       = "";

    $self->{CLUSTERACTIVE4}->{"-"}       = 0;
    $self->{"CLUSTERNAME4"}->{"-"}       = "-";
    $self->{"CLUSTERPREFIX4"}->{"-"}     = "-";
    $self->{"CLUSTERDESC4"}->{"-"}       = "";

    $self->{DOSWITCHCLUSTER}->{"-"}      = 1;


    bless $self, $class;
    if($selfref==-1)  {
	$selfref=\$self;
    } else {
	printf("WARNING: double constructor call to LLview_manage_elements_mc ...\n")
    }
    return $self;
}

sub settings {
    my($self) = shift;
    my($instpath,$verbose,$source,$inifile,$history,$timer,$search,$errfile,$prefix)=@_;
#    print "settings: ($instpath,$verbose,$source,$inifile,$history,$timer,$search,$errfile,$prefix) $self->{INIFILE}\n";
    $self->{INSTPATH}=$instpath if($instpath);
    $self->{VERBOSE}->{"-"}=$verbose if($verbose);
    $self->{SOURCE}->{"-"}=$source if($source);
    $self->{INIFILE}->{"-"}=$inifile if($inifile);
    $self->{DOHISTORY}->{"-"}=$history if($history);
    $self->{TIMER}->{"-"}=$timer if($timer);
    $self->{SEARCHSTR}->{"-"}=$search if($search);
    $self->{ERRFILE}->{"-"}=$errfile if($errfile);
    $self->{PREFIX}=$prefix if($prefix);
    return 1;
}


sub build {
    my($self) = shift;
    my($objname,$objref,$section);
    my($mainwin,$instpath,$optobj,$i,$cluster,$nextcluster);
    $instpath=$self->{INSTPATH};
    my $multicluster=1;
    my $clusternr=0;

    $self->{MAINCOLORMANAGER}=LLview_manage_colors->new();

    $mainwin=$self->{MAINWIN} = LLview_gui_main->new($self->{INSTPATH},$self->{INIFILE}->{"-"},$multicluster,$clusternr,"Overview",
						     $self->{PREFIX});
    # creates also the option object
    $optobj=$self->{OPTIONOBJECT}=$mainwin->{OPTIONOBJECT};
    $self->{MAINWIN}->register_steptimer_function("getdata",\&update_steptimer);
    $self->{MAINWIN}->register_timer_function("steptimer",\&update_data);

    $optobj->set_cluster("-");

# WF todo
#    push(@{$self->{CLUSTERLIST}},"Cluster Overview");
    
    $section="Multi_Cluster";
    for($i=0;$i<$self->{MAXCLUSTER};$i++) {
	$optobj->register_option($section,"CLUSTERACTIVE$i", -label => "Cluster $i active", 
				 -caller => $self, -pack => 3,
				 -type => "radio", -default => $self->{"CLUSTERACTIVE$i"}->{"-"});
	$optobj->register_option($section,"CLUSTERNAME$i", -label => "ClusterName", -fieldwidth => 10,
 				 -caller => $self, -pack => 3,
				 -type => "string", -default => $self->{"CLUSTERNAME$i"}->{"-"});
	$optobj->register_option($section,"CLUSTERPREFIX$i", -label => "Prefix", -fieldwidth => 10,
				 -caller => $self, -pack => 3,-labelwidth => 6,
				 -type => "string", -default => $self->{"CLUSTERPREFIX$i"}->{"-"});
	$optobj->register_option($section,"CLUSTERDESC$i", -label => "Desc.", -fieldwidth => 10,
				 -caller => $self, -pack => 4, -labelwidth => 5,
				 -type => "string", -default => $self->{"CLUSTERDESC$i"}->{"-"});

	$optobj->register_cluster($self->{"CLUSTERNAME$i"}->{"-"},$self->{"CLUSTERPREFIX$i"}->{"-"}) if($self->{"CLUSTERACTIVE$i"}->{"-"});

    }
    $optobj->register_comment($section,"COMMENT1", 
			      -text => "\n!!! changes on following options have only effect !!!\n!!!     after save options and restart llview     !!!\n", 
			      -type => "comment");
    $optobj->register_option($section,"DOSWITCHCLUSTER", -label => "Auto switch between cluster", 
			     -caller => $self, -pack => 1,
			     -type => "radio", -default => $self->{"DOSWITCHCLUSTER"}->{"-"});

    $optobj->register_option($section,"Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option($section,"BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT1});

    $mainwin->build_gui();

    my($posx,$posy,$width,$height)=(10,10,$mainwin->{WIDTH}-10,$mainwin->{HEIGHT}-10);
    my $lheight=(($height-20)/$self->{MAXCLUSTER})-8;

    # now we can build elements options
    for($i=0;$i<$self->{MAXCLUSTER};$i++) {
	next if(!$self->{"CLUSTERACTIVE$i"}->{"-"});
	$cluster=$self->{"CLUSTERNAME$i"}->{"-"};
	$optobj->set_cluster($cluster);
	$section="General";
	$self->{SOURCE}->{$cluster}=$self->{SOURCE}->{"-"};
	$optobj->register_option($section,"SOURCE", -label => "data source", 
				 -caller => $self, -pack => 1, 
				 -values => ["www","exec","locdata"],
				 -labels => ["WWW: from Web-Server","llqxml: Execute local command",
					     "LocalData: tar file on local machine"],
				 -type => "radiogroup", -default => $self->{SOURCE}->{$cluster},
				 -updatereq => 1);
	
	$self->{VERBOSE}->{$cluster}=$self->{VERBOSE}->{"-"};
	$optobj->register_option($section,"VERBOSE", -label => "verbose", 
				 -caller => $self, -pack => 1,
				 -type => "radio", -default => $self->{VERBOSE}->{$cluster});
	
	$self->{DEMOVERSION}->{$cluster}=$self->{DEMOVERSION}->{"-"};
	$optobj->register_option($section,"DEMOVERSION", -label => "demo version", 
				 -caller => $self, -pack => 3,
				 -type => "radio", -default => $self->{DEMOVERSION}->{$cluster});
	
	$self->{SHOWPM}->{$cluster}=$self->{SHOWPM}->{"-"};
	$optobj->register_option($section,"SHOWPM", -label => "show +/- buttons", 
				 -caller => $self, -pack => 3,
				 -type => "radio", -default => $self->{SHOWPM}->{$cluster});
	

	$self->{SELECTNODES}->{$cluster}=$self->{SELECTNODES}->{"-"};
	$optobj->register_option($section,"SELECTNODES", -label => "Node selection regexp", -labelwidth => 30,
				 -caller => $self, -pack => 1,
				 -type => "string", -default => $self->{SELECTNODES}->{$cluster});

	$self->{SELECTUID}->{$cluster}=$self->{SELECTUID}->{"-"};
	$optobj->register_option($section,"SELECTUID", -label => "Job selection regexp (uid)", -labelwidth => 30,
				 -caller => $self, -pack => 1,
				 -type => "string", -default => $self->{SELECTUID}->{$cluster});
	
	$self->{REMOTECONTROL}->{$cluster}=$self->{REMOTECONTROL}->{"-"};
	$optobj->register_option($section,"REMOTECONTROL", -label => "RC", 
				 -caller => $self, -pack => 2,
				 -type => "radio", -default => $self->{REMOTECONTROL}->{$cluster});
	
	$section="Elements";
	
	$optobj->register_comment($section,"COMMENT1", 
				  -text => "\n!!! changes on following options have only effect !!!\n!!!".
				           "     after save options and restart llview     !!!\n", 
				  -type => "comment");

	$self->{DOSCALA}->{$cluster}=$self->{DOSCALA}->{"-"};
	$optobj->register_option($section,"DOSCALA", -label => "show usage bar", 
				 -caller => $self, -pack => 1, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOSCALA}->{$cluster});
	
	$self->{DONODES}->{$cluster}=$self->{DONODES}->{"-"};
	$optobj->register_option($section,"DONODES", -label => "show nodes", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DONODES}->{$cluster});
	
	$self->{DOJOBLIST}->{$cluster}=$self->{DOJOBLIST}->{"-"};
	$optobj->register_option($section,"DOJOBLIST", -label => "show joblist", 
				 -caller => $self, -pack => 1, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOJOBLIST}->{$cluster});
	
	$self->{DORUNNING}->{$cluster}=$self->{DORUNNING}->{"-"};
	$optobj->register_option($section,"DORUNNING", -label => "show running", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DORUNNING}->{$cluster});
	
	$self->{DOWAITING}->{$cluster}=$self->{DOWAITING}->{"-"};
	$optobj->register_option($section,"DOWAITING", -label => "show waiting", 
				 -caller => $self, -pack => 1, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOWAITING}->{$cluster});
	
	$self->{DOGRAPH}->{$cluster}=$self->{DOGRAPH}->{"-"};
	$optobj->register_option($section,"DOGRAPH", -label => "show graph", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOGRAPH}->{$cluster});

	$self->{DOHISTOGRAM}->{$cluster}=$self->{DOHISTOGRAM}->{"-"};
	$optobj->register_option($section,"DOHISTOGRAM", -label => "show histogram", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOHISTOGRAM}->{$cluster});
	
	$self->{DOSTATUS}->{$cluster}=$self->{DOSTATUS}->{"-"};
	$optobj->register_option($section,"DOSTATUS", -label => "show status", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOSTATUS}->{$cluster});
	
	$self->{DOHISTORY}->{$cluster}=$self->{DOHISTORY}->{"-"};
	$optobj->register_option($section,"DOHISTORY", -label => "show history", 
				 -caller => $self, -pack => 1, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOHISTORY}->{$cluster});
	
	$self->{DOPARTLIST}->{$cluster}=$self->{DOPARTLIST}->{"-"};
	$optobj->register_option($section,"DOPARTLIST", -label => "show partition (BGL)", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOPARTLIST}->{$cluster});
	
	$self->{DORESGRAPH}->{$cluster}=$self->{DORESGRAPH}->{"-"};
	$optobj->register_option($section,"DORESGRAPH", -label => "show reservations (BGL)", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DORESGRAPH}->{$cluster});
	
	$self->{DOUSAGEGRAPH}->{$cluster}=$self->{DOUSAGEGRAPH}->{"-"};
	$optobj->register_option($section,"DOUSAGEGRAPH", -label => "show usage history (BGL)", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOUSAGEGRAPH}->{$cluster});

	$self->{DOFORECAST}->{$cluster}=$self->{DOFORECAST}->{"-"};
	$optobj->register_option($section,"DOFORECAST", -label => "show prediction of usage", 
				 -caller => $self, -pack => 2, -labelwidth => 25,
				 -type => "radio", -default => $self->{DOFORECAST}->{$cluster});


	# generate part on overview tab 
#	print "WF: manage_elements_mc, create subcanvas with $posx,$posy,$width x $lheight for $cluster height=$height\n";
	my $subcanvas = $self->{MAINWIN}->{CANVAS}->Scrolled('Canvas', -scrollbars => '', -relief => 'sunken', -bd => 1, 
					  -height => $lheight, -width => $width,
					  -background => "grey80",-highlightbackground => "grey80");
	my $subwidget = $self->{MAINWIN}->{CANVAS}->createWindow($posx,$posy, -window =>$subcanvas, -anchor => "nw");

	# bug fix for arranging scrolled height, wrong setting after creating
	$self->{MAINWIN}->{CANVAS}->itemconfigure($subwidget,-height => $lheight);
	$self->{MAINWIN}->{CANVAS}->itemconfigure($subwidget,-width => $width);


	$self->{OVERVIEWCANVAS}->{$cluster}=$subcanvas;
	$self->{OVERVIEWCANVAS}->{$cluster}->createText(0,$lheight-20,
							-text => "Cluster:".$self->{"CLUSTERNAME$i"}->{"-"}
							." (".$self->{"CLUSTERDESC$i"}->{"-"}.")",
							-anchor => 'w',
							-font => $self->{BFONT1});
#	$self->{MAINWIN}->{CANVAS}->createRectangle($posx,$posy,$posx+$width,$posy+$lheight,
#						    -fill => "green", -outline => "black" );


	$posy+=$lheight;
	$posy+=10;

	# not switchable
	$self->{DOINFO}->{$cluster}=1;
	
	$clusternr++;
	$self->{MAIN}->{$cluster} = LLview_gui_main->new($self->{INSTPATH},$self->{INIFILE}->{$cluster},
							 $multicluster,$clusternr,$cluster,$self->{PREFIX});
	$self->{MAIN}->{$cluster}->{OPTIONOBJECT}=$optobj;
	$self->{MAIN}->{$cluster}->{MASTER_NB}=$self->{MAINWIN}->{MASTER_NB};
	push(@{$self->{CLUSTERLIST}},$cluster);

	# create parser
	$self->enable_parser($cluster);
	$self->enable_receiver($cluster);
	$self->{MAIN}->{$cluster}->register_data_object("getdata",$self->{PARSER}->{$cluster});
	$self->{COLORMANAGER}->{$cluster}=LLview_manage_colors->new();
	$self->{MAIN}->{$cluster}->register_color_object("managecolor",$self->{COLORMANAGER}->{$cluster});

	$self->enable_info($cluster)    if($self->{DOINFO}->{$cluster});
	$self->enable_status($cluster)  if($self->{DOSTATUS}->{$cluster});
	$self->enable_scala($cluster)   if($self->{DOSCALA}->{$cluster});
	$self->enable_nodes($cluster)   if($self->{DONODES}->{$cluster});
	$self->enable_joblist($cluster) if($self->{DOJOBLIST}->{$cluster});
	$self->enable_running($cluster) if($self->{DORUNNING}->{$cluster});
	$self->enable_waiting($cluster) if($self->{DOWAITING}->{$cluster});
	$self->enable_graph($cluster)   if($self->{DOGRAPH}->{$cluster});
	$self->enable_histogram($cluster)   if($self->{DOHISTOGRAM}->{$cluster});
	$self->enable_history($cluster)     if($self->{DOHISTORY}->{$cluster});
	$self->enable_partlist($cluster)    if($self->{DOPARTLIST}->{$cluster});
	$self->enable_reservation($cluster) if($self->{DORESGRAPH}->{$cluster});
	$self->enable_forecast($cluster)    if($self->{DOFORECAST}->{$cluster});
	$self->enable_usagegraph($cluster)  if($self->{DOUSAGEGRAPH}->{$cluster});

	# for highlighting
	$self->{MAIN}->{$cluster}->{FONT1}=$self->{JOBLIST}->{$cluster}->{FONT1};
	$self->{MAIN}->{$cluster}->{BFONT1}=$self->{JOBLIST}->{$cluster}->{BFONT1};
	# initialize sort order of known batch queues
	$self->init_objects($cluster);
	$self->set_global_vars($cluster);
	$self->set_datatype_text($cluster);
	$self->{MAIN}->{$cluster}->build_gui();
	
    } # list of cluster


    # raise first cluster
    $nextcluster = shift(@{$self->{CLUSTERLIST}});
    push(@{$self->{CLUSTERLIST}},$nextcluster);
    $self->{MAINWIN}->raiseNoteBook($nextcluster);


    # for highlighting
    $self->{MAINWIN}->{FONT1}=$self->{JOBLIST}->{FONT1};
    $self->{MAINWIN}->{BFONT1}=$self->{JOBLIST}->{BFONT1};
    # initialize sort order of known batch queues



}

# something to do here WF 
sub set_global_vars {
    my($self) = shift;
    my($cluster) = shift;
    my($objname);
    foreach $objname (keys(%{$self->{OBJECTS}})) {
#	print "WF: set_global_vars $objname\n" if($self->{VERBOSE}); 
	$self->{OBJECTS}->{$objname}->{INSTPATH}=$self->{INSTPATH};
	$self->{OBJECTS}->{$objname}->{VERBOSE}=$self->{VERBOSE}->{$cluster};
    }
    $self->{OPTIONOBJECT}->{SHOWPM}=$self->{SHOWPM}->{$cluster};
#    print "WF: set_global_vars: cluster=$cluster selectnodes=$self->{SELECTNODES}->{$cluster}\n";
    $self->{PARSER}->{$cluster}->{SELECTNODES}=$self->{SELECTNODES}->{$cluster};
    $self->{PARSER}->{$cluster}->{SELECTUID}=$self->{SELECTUID}->{$cluster};
    $self->{PARSER}->{$cluster}->{DEMOVERSION}=$self->{DEMOVERSION}->{$cluster};
}

sub enable_parser {
    my($self) = shift;
    my($cluster) = shift;
    $self->{PARSER}->{$cluster} = LLview_parse_xml->new();
    $self->{OBJECTS}->{"PARSER_$cluster"}=$self->{PARSER}->{$cluster};
    return(1);
}

sub enable_receiver {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAINWIN};

    $self->{RECEIVER_LOCDATA}->{$cluster} = LLview_get_locdata->new();
    $self->{RECEIVER_LOCDATA}->{$cluster}->{DATAOBJ}=$self->{PARSER};
    $self->{RECEIVER_LOCDATA}->{$cluster}->init_options($mainwin->{OPTIONOBJECT});
    $self->{OBJECTS}->{"RECEIVER_LOCDATA$cluster"}=$self->{RECEIVER_LOCDATA};

    $self->{RECEIVER_WWW}->{$cluster}     = LLview_get_www->new();
    $self->{RECEIVER_WWW}->{$cluster}->{DATAOBJ}=$self->{PARSER};
    $self->{RECEIVER_WWW}->{$cluster}->init_options($mainwin->{OPTIONOBJECT});
    $self->{OBJECTS}->{"RECEIVER_WWW$cluster"}=$self->{RECEIVER_WWW};

    $self->{RECEIVER_SSH}->{$cluster}     = LLview_get_ssh->new();
    $self->{RECEIVER_SSH}->{$cluster}->{DATAOBJ}=$self->{PARSER};
    $self->{RECEIVER_SSH}->{$cluster}->init_options($mainwin->{OPTIONOBJECT});
    $self->{OBJECTS}->{"RECEIVER_SSH$cluster"}=$self->{RECEIVER_SSH};

    $self->{RECEIVER_EXEC}->{$cluster}    = LLview_get_exec->new();
    $self->{RECEIVER_EXEC}->{$cluster}->{DATAOBJ}=$self->{PARSER};
    $self->{RECEIVER_EXEC}->{$cluster}->init_options($mainwin->{OPTIONOBJECT});
    $self->{OBJECTS}->{"RECEIVER_EXEC$cluster"}=$self->{RECEIVER_EXEC};

    return(1);
}

sub enable_info {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{INFO}->{$cluster} = LLview_gui_info->new();
    $mainwin->register_canvas_object("info",$self->{INFO}->{$cluster});
    $mainwin->register_info_object("info",$self->{INFO}->{$cluster});
    $self->{OBJECTS}->{"INFO$cluster"}=$self->{INFO}->{$cluster};
    return(1);
}

sub enable_status {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{STATUS}->{$cluster}    = LLview_gui_status->new();
    $mainwin->register_canvas_object("status",$self->{STATUS}->{$cluster});
    $self->{OBJECTS}->{"STATUS$cluster"}=$self->{STATUS}->{$cluster};
    $self->{STATUS}->{$cluster}->set_errfile($self->{ERRFILE});
    $self->{STATUS}->{$cluster}->progress(0,60,0);
    return(1);
}

sub enable_scala {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{SCALA}->{$cluster}  = LLview_gui_scala->new();
    $mainwin->register_canvas_object("scala",$self->{SCALA}->{$cluster});
    $self->{OBJECTS}->{"SCALA$cluster"}=$self->{SCALA}->{$cluster};

    $self->{SCALAOVERVIEW}->{$cluster}  = LLview_gui_scala->new();
    $mainwin->register_canvas_object_on_overviewcanvas("overviewscala",$self->{SCALAOVERVIEW}->{$cluster},
						       $self->{OVERVIEWCANVAS}->{$cluster},"$cluster");
    $self->{OBJECTS}->{"SCALAOVERVIEW$cluster"}=$self->{SCALAOVERVIEW}->{$cluster};

    return(1);
}

sub enable_nodes {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{NODES}->{$cluster}  = LLview_gui_nodes->new();
    $mainwin->register_canvas_object("nodes",$self->{NODES}->{$cluster});
    $self->{OBJECTS}->{"NODES$cluster"}=$self->{NODES}->{$cluster};
    return(1);
}

sub enable_joblist {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{JOBLIST}->{$cluster}    = LLview_gui_joblist->new();
    $self->{JOBLIST}->{$cluster}->register_data_object("getdata",$self->{PARSER}->{$cluster});
    $self->{JOBLIST}->{$cluster}->register_color_object("managecolor",$self->{COLORMANAGER}->{$cluster});

    $mainwin->register_canvas_object("joblist",$self->{JOBLIST}->{$cluster});
    $mainwin->register_subcanvas_object("joblistsb",$self->{JOBLIST}->{$cluster});
    $mainwin->register_scroll_object("joblistscroll",$self->{JOBLIST}->{$cluster});
    $mainwin->register_search_object("joblistsearch",$self->{JOBLIST}->{$cluster});
    $self->{OBJECTS}->{"JOBLIST$cluster"}=$self->{JOBLIST}->{$cluster};
    return(1);
}

sub enable_running {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{RUNNING}->{$cluster}   = LLview_gui_running->new();
    $mainwin->register_notebook_object("Running",$self->{RUNNING}->{$cluster});
    $mainwin->register_search_object("runningsearch",$self->{RUNNING}->{$cluster});
    $self->{OBJECTS}->{"RUNNING$cluster"}=$self->{RUNNING}->{$cluster};
    return(1);
}

sub enable_waiting {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{WAITING}->{$cluster}   = LLview_gui_waiting->new();
    $mainwin->register_notebook_object("Waiting",$self->{WAITING}->{$cluster});
    $mainwin->register_search_object("waitingsearch",$self->{WAITING}->{$cluster});
    $self->{OBJECTS}->{"WAITING$cluster"}=$self->{WAITING}->{$cluster};
    return(1);
}

sub enable_graph {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{GRAPH}->{$cluster}  = LLview_gui_graph->new();
    $mainwin->register_canvas_object("graph",$self->{GRAPH}->{$cluster});
    $self->{OBJECTS}->{"GRAPH$cluster"}=$self->{GRAPH}->{$cluster};
    return(1);
}

sub enable_histogram {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{HISTOGRAM}->{$cluster}  = LLview_gui_histogram->new($cluster);
    $mainwin->register_canvas_object("histogram",$self->{HISTOGRAM}->{$cluster});
    $self->{OBJECTS}->{"HISTOGRAM$cluster"}=$self->{HISTOGRAM}->{$cluster};

    $self->{HISTOGRAMOVERVIEW}->{$cluster}  = LLview_gui_histogram->new("-");
    $mainwin->register_canvas_object_on_overviewcanvas("histogramoverview",$self->{HISTOGRAMOVERVIEW}->{$cluster},
						       $self->{OVERVIEWCANVAS}->{$cluster},"$cluster");
    $self->{OBJECTS}->{"HISTOGRAMOVERVIEW$cluster"}=$self->{HISTOGRAMOVERVIEW}->{$cluster};

    return(1);
}

sub enable_history {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{SCALAHIST}->{$cluster} = LLview_gui_scalahist->new();
    $mainwin->register_notebookcanvas_object("History",$self->{SCALAHIST}->{$cluster});
    # a hack
    $self->{SCALAHIST}->{$cluster}->{MAINWIN} = $mainwin;
    $self->{OBJECTS}->{"HISTORY$cluster"}=$self->{SCALAHIST}->{$cluster};
    return(1);
}

sub disable_history {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    if($self->{SCALAHIST}->{$cluster}) {
	$self->{SCALAHIST}->{$cluster}->destroy();
	$mainwin->deregister_notebookcanvas_object("history");
	$self->{SCALAHIST}->{$cluster}=undef;
	delete($self->{OBJECTS}->{"SCALAHIST$cluster"});
    }
    return(1);
}

sub enable_partlist {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{PARTLIST}->{$cluster}    = LLview_gui_partlist->new();
    $mainwin->register_canvas_object("partlist",$self->{PARTLIST}->{$cluster});
    $self->{PARTLIST}->{$cluster}->register_color_object("managecolor",$self->{COLORMANAGER}->{$cluster});

    $mainwin->register_subcanvas_object("partlistsb",$self->{PARTLIST}->{$cluster});
    $mainwin->register_scroll_object("partlistscroll",$self->{PARTLIST}->{$cluster});
    $mainwin->register_search_object("partlistsearch",$self->{PARTLIST}->{$cluster});

    $self->{OBJECTS}->{"PARTLIST$cluster"}=$self->{PARTLIST}->{$cluster};

    return(1);
}

sub enable_reservation {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{RESGRAPH}->{$cluster}    = LLview_gui_resgraph->new($cluster);
    $mainwin->register_canvas_object("resgraph",$self->{RESGRAPH}->{$cluster});
    $self->{RESGRAPH}->{$cluster}->register_color_object("managecolor",$self->{COLORMANAGER}->{$cluster});
    $self->{OBJECTS}->{"RESGRAPH$cluster"}=$self->{RESGRAPH}->{$cluster};

    return(1);
}

sub enable_forecast {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{FORECAST}->{$cluster}    = LLview_gui_forecast->new($cluster);
    $mainwin->register_canvas_object("forecast",$self->{FORECAST}->{$cluster});
    $self->{FORECAST}->{$cluster}->register_color_object("managecolor",$self->{COLORMANAGER}->{$cluster});
    $self->{OBJECTS}->{"FORECAST$cluster"}=$self->{FORECAST}->{$cluster};
    $self->{FORECAST}->{$cluster}->{MAINWIN}=$mainwin;
    return(1);
}

sub enable_usagegraph {
    my($self) = shift;
    my($cluster) = shift;
    my $mainwin=$self->{MAIN}->{$cluster};
    $self->{USAGEGRAPH}->{$cluster}    = LLview_gui_usagegraph->new();
    $mainwin->register_canvas_object("usagegraph",$self->{USAGEGRAPH}->{$cluster});
    $self->{USAGEGRAPH}->{$cluster}->register_color_object("managecolor",$self->{COLORMANAGER}->{$cluster});
    $self->{OBJECTS}->{"USAGEGRAPH$cluster"}=$self->{USAGEGRAPH}->{$cluster};


    $self->{USAGEGRAPHOVERVIEW}->{$cluster}    = LLview_gui_usagegraph->new();
    $mainwin->register_canvas_object_on_overviewcanvas("usagegraphoverview",$self->{USAGEGRAPHOVERVIEW}->{$cluster},
					       $self->{OVERVIEWCANVAS}->{$cluster},"$cluster");
    $self->{USAGEGRAPHOVERVIEW}->{$cluster}->register_color_object("managecolor",$self->{COLORMANAGER}->{$cluster});
    $self->{OBJECTS}->{"USAGEGRAPHOVERVIEW$cluster"}=$self->{USAGEGRAPHOVERVIEW}->{$cluster};

    return(1);
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val,$subt,$cluster)=@_;
    my($diffx,$diffy,$id,$objname);
#    print "manage_elements_mc,optvalchanged: $cluster,$section,$name,$subt -> $val  ...\n";# if($self->{VERBOSE}->{"-"});
    $self->{$name}->{$cluster}=$val;
    $self->set_global_vars($cluster);
    if($name eq "SOURCE") {
	$self->set_datatype_text($cluster);
    }
}

# something to do here WF
sub set_datatype_text {
    my($self) = shift;
    my($cluster) = shift;
    $self->{MAINWIN}->set_datatype_text("FILE") if ($self->{SOURCE}->{$cluster} eq "locdata");
    $self->{MAINWIN}->set_datatype_text("WWW")  if ($self->{SOURCE}->{$cluster} eq "www");
    $self->{MAINWIN}->set_datatype_text("EXEC") if ($self->{SOURCE}->{$cluster} eq "exec");
    $self->{MAINWIN}->set_datatype_text("SSH") if ($self->{SOURCE}->{$cluster} eq "ssh");
}

sub update_steptimer {
    my $self=$$selfref;
    my($tend,$value)=@_;
    my($i,$cluster);
    for($i=0;$i<$self->{MAXCLUSTER};$i++) {
	next if(!$self->{"CLUSTERACTIVE$i"}->{"-"});
	$cluster=$self->{"CLUSTERNAME$i"}->{"-"};
	$self->{MAIN}->{$cluster}->autoplay() if($self->{MAIN}->{$cluster}->{AUTOPLAY} 
	   && ($self->{MAINWIN}->{UPDATETIMEREST}%$self->{MAINWIN}->{AUTOPLAYSTEP}==0));

	next if(!$self->{"DOSTATUS"}->{$cluster});
	$self->{STATUS}->{$cluster}->progress(0,$tend,$value);
    }
}

sub update_data {
    my $self=$$selfref;
    my($rc,$receiver,$i,$cluster,$nextcluster);

    if($self->{REMOTECONTROL}==1) {
	if(-f "$self->{INSTPATH}/RESTARTNOW") {
	    unlink("$self->{INSTPATH}/RESTARTNOW");
	    exit(0);
	}
	if(-f "$self->{INSTPATH}/STOPNOW") {
	    unlink("$self->{INSTPATH}/STOPNOW");
	    exit(100);
	}
    }
    my $headstr="MultiCluster: ";
    for($i=0;$i<$self->{MAXCLUSTER};$i++) {
	next if(!$self->{"CLUSTERACTIVE$i"}->{"-"});
	$cluster=$self->{"CLUSTERNAME$i"}->{"-"};
	my $mainwin=$self->{MAIN}->{$cluster};
	
#	print "WF in manage_elements_mc update_data for cluster $i $cluster\n";
	$receiver=$self->{RECEIVER_LOCDATA}->{$cluster} if ($self->{SOURCE}->{$cluster} eq "locdata");
	$receiver=$self->{RECEIVER_WWW}->{$cluster}     if ($self->{SOURCE}->{$cluster} eq "www");
	$receiver=$self->{RECEIVER_EXEC}->{$cluster}    if ($self->{SOURCE}->{$cluster} eq "exec");
	$receiver=$self->{RECEIVER_SSH}->{$cluster}     if ($self->{SOURCE}->{$cluster} eq "ssh");
	$rc=$receiver->getdata();
	if($rc) {
	    $rc=$self->{PARSER}->{$cluster}->parse_data($receiver->{DATA});
	    $self->{MAINWIN}->set_normal_display();
	    $self->{MAINWIN}->set_time_text($self->{PARSER}->{$cluster}->{TIMESTR});
	    $headstr.=(($i>0)?",":"");
	    $headstr.=$cluster;
	    $headstr.="[/".$self->{SELECTNODES}->{$cluster}."/]" if($self->{SELECTNODES}->{$cluster} ne ".*");
	    $headstr.="[/".$self->{SELECTUID}->{$cluster}."/]" if($self->{SELECTUID}->{$cluster} ne ".*");
  
	} else {
	    print "update_data: ERROR:$receiver->{ERRSTRING}\n";
	    $self->{PARSER}->{$cluster}->{DEFAULTINFO}=$receiver->{ERRSTRING};
	    $self->{MAINWIN}->set_error_text("<ERROR>");
	    $self->{MAINWIN}->set_error_display();
	    $self->{INFO}->{$cluster}->defaultinfo();
	}
	$self->{MAINWIN}->set_window_name($headstr);

	$mainwin->callupdatemethods();
    }

    if($self->{"DOSWITCHCLUSTER"}->{"-"}) {
	$nextcluster = shift(@{$self->{CLUSTERLIST}});
	push(@{$self->{CLUSTERLIST}},$nextcluster);
	$self->{MAINWIN}->raiseNoteBook($nextcluster);
    }
    return $rc;
}

sub init_objects {
    my($self) = shift;
    my($cluster) = shift;
    $self->{PARSER}->{$cluster}->{CLASSPRIO} = {
			    'system'  => 2,
			    'c_serial' => 3,
			    'c_inter' => 4,
			    'c_short' => 5,
			    'c_med'   => 6,
			    'c_long'  => 7,
			    'c_xlong'  => 8,
			    
			    'n_short'  => 9,
			    'n_med'  => 10,
			    'n_long'  => 11,
			    
			    'm_short'  => 12,
			    'm_med'  => 13,			    
			    'm_meds'  => 14,			    
			    'm_long'  => 15,

			    'init'     => 16,
			    'boot'     => 17,
			    'running'  => 18,

			    'n0512'     => 19,
			    'n1024'     => 20,
			    'n2048'     => 21,
			    'n4096'     => 22,
			    'n8192'     => 23,
			    'small'     => 24,
			    'nocsmall'  => 25,

			    'nocont'  => 0,
			    'norun'   => 1
			    };
    return(1);
}

sub doExit {
    exit();
}

sub doMainLoop {
    my($self) = shift;
    my($cluster,$i);

    if($self->{SEARCHSTR}->{'-'}) {
	for($i=0;$i<$self->{MAXCLUSTER};$i++) {
	    next if(!$self->{"CLUSTERACTIVE$i"}->{"-"});
	    $cluster=$self->{"CLUSTERNAME$i"}->{"-"};
	    print "LLview_manage_elements_mc: set search string to $self->{SEARCHSTR} for cluster $cluster\n";
	    $self->{MAINWIN}->{$cluster}->{SEARCHSTR}=$self->{SEARCHSTR}->{'-'};
	}
    }

    if($self->{TIMER}->{'-'}!=-1) {
	print "LLview_manage_elements_mc: set end timer to $self->{TIMER}->{'-'} seconds\n";
	$self->{MAINWIN}->{MAIN}->after($self->{TIMER}->{'-'}*1000,\&doExit);
    }



    $self->{MAINWIN}->doMainLoop;
}


1;




