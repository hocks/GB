# $Source: /cvs/cvsroot/llview/lib/LLview_gui_waiting.pm,v $
# $Author: zdv087 $
# $Revision: 1.12 $
# $Date: 2007/01/08 16:41:54 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2005, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_waiting;
use Time::Local;
use strict;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_gui_waiting: new %s\n",ref($proto)) if($debug>=3);
    $self->{POSX}    = 5;
    $self->{POSY}    = 0;
    $self->{WIDTH}   = 790;
    $self->{HEIGHT}  = 16;
    $self->{WAITING}      = "   \n"x200;
    $self->{SEARCHSTR}      = "";
    $self->{ITEMS}   = [];
    bless $self, $class;
    return $self;
}

sub set_searchstr {
    my($self) = shift;
    my($str) = @_;
    $self->{SEARCHSTR}=$str;
    return 1;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$textwidget)=@_;
    my($string);
    my $frames=$dataobj->{FRAMES};
    $self->replace($dataobj,$colorobj,$textwidget,$self->{WAITING});
    $textwidget->tagConfigure('search',-foreground => "blue");
    return();
}

sub replace {
    my($self) = shift;
    my($dataobj,$colorobj,$textwidget,$string)=@_;
    my($str);
    $textwidget->delete('1.0', 'end'); 
    $textwidget->insert('end', $string);     
    return(1);
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$textwidget)=@_;
    my($wnum,$lnum,$lastqueue,$jobstep,$queue,$shared,$unicore);
    my(@marked);
    $self->{WAITING}=""; 
    $wnum=0;$lnum=0;
    $self->{WAITING}.=sprintf("  queue %3s| %14s %8s %8s %5s [%-17s] [%2s %2s %2s] %6s %6s %6s %3s %4s %s| \n",
		      "#","Jobstep","Userid","Class","State","Queue Date",
		      "#N","#T","#C",,"#tasks", "Wall(h)","Mem(GB)","Rst","Shrd","Unicore");
    $self->{WAITING}.="          +"."-"x109;    $self->{WAITING}.="+\n";
    $lnum+=2;
    $lastqueue="";
    foreach $jobstep (sort { sort_jobs_class_date($dataobj) } (keys(%{$dataobj->{WAITINGJOBS}}))) {
	if($dataobj->{JOBSTATE}->{$jobstep}{"job_type"} eq "waiting") {
	    $queue=$dataobj->{JOBSTATE}->{$jobstep}{"job_queue"};
	    if($lastqueue ne $queue ) {
		$self->{WAITING}.="$queue";		
		$self->{WAITING}.="-"x(11-length($queue));		
		$self->{WAITING}.="+\n";
		$lastqueue=$queue;
		$lnum+=1;
	    }
	    $wnum++;
	    $shared=($dataobj->{JOBSTATE}->{$jobstep}{"job_node_usage"}=~/NOT_SHARED/)?"no":"yes";
	    $unicore=($dataobj->{JOBSTATE}->{$jobstep}{"job_comment"}=~/NOT ?Unicore/)?" ":"U";
	    $self->{WAITING}.=sprintf("        %3d| %14s %8s %8s %5s [%10s] [%2d %2d %2d] ->%4d %7.1f %6.2f %4s %s %4s %s\n",
			      $wnum,
			      $jobstep,
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_owner"},
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_queue"},
			      substr($dataobj->{JOBSTATE}->{$jobstep}{"job_statuslong"},0,5),
						 
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_queuedate"},
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_nummachines"},
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_taskspernode"},
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_conscpu"},

			      $dataobj->{JOBSTATE}->{$jobstep}{"job_totaltasks"},
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_wall"}/3600,
						 
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_consmem"}/1024,
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_restart"},
			      $dataobj->{JOBSTATE}->{$jobstep}{"job_sysprio"},
			      $shared,
			      $unicore,
			      );
	    if($self->{SEARCHSTR}) {
		push(@marked,$lnum+1) if ($dataobj->{JOBSTATE}->{$jobstep}{"job_owner"}=~/$self->{SEARCHSTR}/);
	    }
	    $lnum+=1;
	}
    }

    
    $self->replace($dataobj,$colorobj,$textwidget,$self->{WAITING});
    foreach $lnum (@marked) {
	$textwidget->tagAdd("search","$lnum.0","$lnum.0 lineend");
    }
    return(1);
}

sub date_to_sec {
    my ($date)=@_;
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $timesec\n";
    return($timesec);
}

sub sort_jobs_class_date   {    
    my($dataobj) = shift;
#    print "WF: $a,$b",$dataobj->{JOBSTATE}->{$a}{"job_type"}," ",$dataobj->{JOBSTATE}->{$b}{"job_type"},"\n";
    if($dataobj->{JOBSTATE}->{$a}{"job_type"} eq $dataobj->{JOBSTATE}->{$b}{"job_type"}) {
	if($dataobj->{JOBSTATE}->{$a}{"job_queue"} eq $dataobj->{JOBSTATE}->{$b}{"job_queue"}) {
	    if($dataobj->{JOBSTATE}->{$a}{"job_type"} eq "running") {
		&date_to_sec($dataobj->{JOBSTATE}->{$a}{"job_dispatchdate"}) <=> 
		    &date_to_sec($dataobj->{JOBSTATE}->{$b}{"job_dispatchdate"});
	    } else {
#		&date_to_sec($dataobj->{JOBSTATE}->{$a}{"job_queuedate"}) <=>  
#		    &date_to_sec($dataobj->{JOBSTATE}->{$b}{"job_queuedate"});
		$dataobj->{JOBSTATE}->{$a}{"job_sysprio"} <=>  
		    $dataobj->{JOBSTATE}->{$b}{"job_sysprio"};
	    }
	} else {
	    $dataobj->{CLASSPRIO}->{$dataobj->{JOBSTATE}->{$b}{"job_queue"}} 
	    <=> $dataobj->{CLASSPRIO}->{$dataobj->{JOBSTATE}->{$a}{"job_queue"}};
	}

    } else {
	$dataobj->{JOBSTATE}->{$a}{"job_type"} cmp $dataobj->{JOBSTATE}->{$b}{"job_type"};
    }
}


1;
