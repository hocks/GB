# $Source: /cvs/cvsroot/llview/lib/LLview_manage_colors.pm,v $
# $Author: zdv087 $
# $Revision: 1.26 $
# $Date: 2007/07/14 15:22:48 $
#
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2005, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
#   stores for different categories lists of used and unused acolors
#   method 'get' gives for a id a new or already defined color
#   method 'id2nr' gives the unique number od id/color
#                  which will be used for tags names on canvas
#

package LLview_manage_colors;
use strict;
my($debug)=0;

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my($path,$i,$cat);
    printf("\t\llview_manage_color($self): new %s %s\n",ref($proto),caller()) if($debug>=2);
    $self->{CLUSTERNAME} = shift||"-"; # needed for button callback function 

    $self->{CATEGORIES}    = ["RUN","WAIT","WAITNOCONT","RESERVATION","OWNJOBS"]; 

    $cat=0; # RUN
    $self->{SCHEME}[$cat]      = "PREDEFINED";
    $self->{BUFFERSIZE}[$cat]  = 150;
    $self->{VALUEHSTART}[$cat] = 120;
    $self->{VALUEHEND}[$cat]   = 300;
    $self->{VALUE_S}[$cat]     = 80;
    $self->{VALUE_V}[$cat]     = 80;
    $self->{VALUEGRAYSTART}[$cat] = 10;
    $self->{VALUEGRAYEND}[$cat]   = 240;
    $self->{VALUERSTART}[$cat] = 100;
    $self->{VALUEREND}[$cat]   = 255;
    $self->{VALUEGSTART}[$cat] = 100;
    $self->{VALUEGEND}[$cat]   = 255;
    $self->{VALUEBSTART}[$cat] = 100;
    $self->{VALUEBEND}[$cat]   = 255;

    $cat=1; # WAIT
    $self->{SCHEME}[$cat]    = "GRAY";
    $self->{BUFFERSIZE}[$cat]  = 800;
    $self->{VALUEHSTART}[$cat] = 120;
    $self->{VALUEHEND}[$cat]   = 300;
    $self->{VALUE_S}[$cat]     = 80;
    $self->{VALUE_V}[$cat]     = 80;
    $self->{VALUEGRAYSTART}[$cat] = 10;
    $self->{VALUEGRAYEND}[$cat]   = 240;
    $self->{VALUERSTART}[$cat] = 100;
    $self->{VALUEREND}[$cat]   = 255;
    $self->{VALUEGSTART}[$cat] = 100;
    $self->{VALUEGEND}[$cat]   = 255;
    $self->{VALUEBSTART}[$cat] = 100;
    $self->{VALUEBEND}[$cat]   = 255;

    $cat=2; # WAITNOCONT
    $self->{SCHEME}[$cat]    = "GRAY";
    $self->{BUFFERSIZE}[$cat]  = 150;
    $self->{VALUEHSTART}[$cat] = 120;
    $self->{VALUEHEND}[$cat]   = 300;
    $self->{VALUE_S}[$cat]     = 80;
    $self->{VALUE_V}[$cat]     = 80;
    $self->{VALUEGRAYSTART}[$cat] = 10;
    $self->{VALUEGRAYEND}[$cat]   = 240;
    $self->{VALUERSTART}[$cat] = 100;
    $self->{VALUEREND}[$cat]   = 255;
    $self->{VALUEGSTART}[$cat] = 100;
    $self->{VALUEGEND}[$cat]   = 255;
    $self->{VALUEBSTART}[$cat] = 100;
    $self->{VALUEBEND}[$cat]   = 255;

    $cat=3; # RESERVATION
    $self->{SCHEME}[$cat]    = "GRAY";
    $self->{BUFFERSIZE}[$cat]  = 100;
    $self->{VALUEHSTART}[$cat] = 120;
    $self->{VALUEHEND}[$cat]   = 300;
    $self->{VALUE_S}[$cat]     = 80;
    $self->{VALUE_V}[$cat]     = 80;
    $self->{VALUEGRAYSTART}[$cat] = 10;
    $self->{VALUEGRAYEND}[$cat]   = 240;
    $self->{VALUERSTART}[$cat] = 100;
    $self->{VALUEREND}[$cat]   = 255;
    $self->{VALUEGSTART}[$cat] = 100;
    $self->{VALUEGEND}[$cat]   = 255;
    $self->{VALUEBSTART}[$cat] = 100;
    $self->{VALUEBEND}[$cat]   = 255;

    $cat=4; # OWNJOBS
    $self->{SCHEME}[$cat]    = "HSV";
    $self->{BUFFERSIZE}[$cat]  = 40;
    $self->{VALUEHSTART}[$cat] = 310;
    $self->{VALUEHEND}[$cat]   = 340;
    $self->{VALUE_S}[$cat]     = 80;
    $self->{VALUE_V}[$cat]     = 80;
    $self->{VALUEGRAYSTART}[$cat] =  98;
    $self->{VALUEGRAYEND}[$cat]   =  99;
    $self->{VALUERSTART}[$cat] = 100;
    $self->{VALUEREND}[$cat]   = 255;
    $self->{VALUEGSTART}[$cat] = 100;
    $self->{VALUEGEND}[$cat]   = 255;
    $self->{VALUEBSTART}[$cat] = 100;
    $self->{VALUEBEND}[$cat]   = 255;

    $self->{SCHEMES}       = ["PREDEFINED","GRAY","HSV","RGB"];

    $i=0;
    for $cat (@{$self->{CATEGORIES}}) {
	$self->{CAT2NR}->{$cat}=$i;
	$i++;
    }

    # initalize buffers
    for($cat=0;$cat<=$#{$self->{CATEGORIES}};$cat++) {
	$self->{RANDOM}[$cat]        = 1;
 	$self->{BUFFER}[$cat]        = [];

	$self->{KNOWNIDSSIZE}[$cat]  = 0;
	$self->{KNOWNIDS}[$cat]      = {};

	$self->{USEDCOLORSSIZE}[$cat]= 0;
	$self->{USEDCOLORS}[$cat]    = {};

	$self->{COLORTONR}[$cat]     = {};
	$self->{NRTOCOLOR}[$cat]     = [];
    }


    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-50-*-*-*-*-*-*";
	
    $self->{COLORS}        = [];
    $self->{COLORS_SORTED} = [];
    

    $self->{COLORSEXAMPLEWIDTH}  = 720;
    $self->{COLORSEXAMPLEHEIGHT} = 200;

    bless $self, $class;

    # initialize list of fix colors
    $self->initcolor();

    return $self;
}

sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($name,$cat,$category);
    my $frames=$dataobj->{FRAMES};
    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{INFOOBJECT}=$infoobj;
    $self->{OPTIONOBJECT}=$optobj;

    my $section="Color";

    for($cat=0;$cat<=$#{$self->{CATEGORIES}};$cat++) {
	$category=$self->{CATEGORIES}[$cat];
	my $ssection=$cat."_".$category;
	$optobj->register_option($section,"SCHEME", -label => "color schemes", -subtype => $ssection,
				 -caller => $self, -pack => 1, 
				 -values => [@{$self->{SCHEMES}}],
				 -labels => [@{$self->{SCHEMES}}],
				 -side => "left",
				 -type => "radiogroup", -default => $self->{SCHEME}[$cat],
				 -updatereq => 0);

	$optobj->register_option($section,"RANDOM", -label => "Ramdomize", 
				 -caller => $self,-pack => 2, -subtype => $ssection,
				 -type => "radio", -min => 0, -max => 1, -default => $self->{RANDOM}[$cat]);

	$optobj->register_option($section,"VALUEGRAYSTART", -label => "Gray model:    Val start", 
				 -caller => $self,-pack => 1, -subtype => $ssection,-labelwidth => 20,
				 -type => "int", -min => 0, -max => 360, -step => 10,
				 -default => $self->{VALUEGRAYSTART}[$cat]);

	$optobj->register_option($section,"VALUEGRAYEND", -label => "end", 
				 -caller => $self,-pack => 2, -subtype => $ssection,-labelwidth => 5, 
				 -type => "int", -min => 0, -max => 360, -step => 10,
				 -default => $self->{VALUEGRAYEND}[$cat]);

	$optobj->register_option($section,"VALUEHSTART", -label => "HSV model:    H start", 
				 -caller => $self,-pack => 1, -subtype => $ssection,-labelwidth => 20,
				 -type => "int", -min => 0, -max => 360, -step => 10,
				 -default => $self->{VALUEHSTART}[$cat]);

	$optobj->register_option($section,"VALUEHEND", -label => "H end", 
				 -caller => $self,-pack => 4, -subtype => $ssection,-labelwidth => 5, 
				 -type => "int", -min => 0, -max => 360, -step => 10,
				 -default => $self->{VALUEHEND}[$cat]);

	$optobj->register_option($section,"VALUE_S", -label => "S", 
				 -caller => $self,-pack => 4, -subtype => $ssection,-labelwidth => 2,
				 -type => "int", -min => 0, -max => 100,  -step => 10,
				 -default => $self->{VALUE_S}[$cat]);

	$optobj->register_option($section,"VALUE_V", -label => "V", 
				 -caller => $self,-pack => 4, -subtype => $ssection,-labelwidth => 2,
				 -type => "int", -min => 0, -max => 100,  -step => 10,
				 -default => $self->{VALUE_V}[$cat]);


	$optobj->register_option($section,"VALUERSTART", -label => "RGB model:    R start", 
				 -caller => $self,-pack => 1, -subtype => $ssection,-labelwidth => 20,
				 -type => "int", -min => 0, -max => 255, -step => 10,
				 -default => $self->{VALUERSTART}[$cat]);

	$optobj->register_option($section,"VALUEREND", -label => "R end", 
				 -caller => $self,-pack => 6, -subtype => $ssection,-labelwidth => 5, 
				 -type => "int", -min => 0, -max => 255, -step => 10,
				 -default => $self->{VALUEREND}[$cat]);

	$optobj->register_option($section,"VALUEGSTART", -label => "G start", 
				 -caller => $self,-pack => 6, -subtype => $ssection,-labelwidth => 10,
				 -type => "int", -min => 0, -max => 255, -step => 10,
				 -default => $self->{VALUEGSTART}[$cat]);

	$optobj->register_option($section,"VALUEGEND", -label => "G end", 
				 -caller => $self,-pack => 6, -subtype => $ssection,-labelwidth => 5, 
				 -type => "int", -min => 0, -max => 255, -step => 10,
				 -default => $self->{VALUEGEND}[$cat]);

	$optobj->register_option($section,"VALUEBSTART", -label => "B start", 
				 -caller => $self,-pack => 6, -subtype => $ssection,-labelwidth => 10,
				 -type => "int", -min => 0, -max => 255, -step => 10,
				 -default => $self->{VALUEBSTART}[$cat]);

	$optobj->register_option($section,"VALUEBEND", -label => "B end", 
				 -caller => $self,-pack => 6, -subtype => $ssection,-labelwidth => 5, 
				 -type => "int", -min => 0, -max => 255, -step => 10,
				 -default => $self->{VALUEBEND}[$cat]);

	$optobj->register_option($section,"COLORSLIDE", -label => "colors", 
				 -caller => $self, -pack => 1, -labelwidth => 6,
				 -type => "canvas", -subtype => $ssection,
				 -width => $self->{COLORSEXAMPLEWIDTH}, 
				 -height => $self->{COLORSEXAMPLEHEIGHT},
				 -default => 0);

	$optobj->register_option($section,"BUFFERSIZE", -label => "color buffer size", 
				 -caller => $self,-pack => 1, -subtype => $ssection,
				 -type => "int", -min => 0, -max => 2000, 
				 -default => $self->{BUFFERSIZE}[$cat], -step => 10);


    }
    $optobj->register_comment($section,"COMMENT1", ,-pack => 2, 
			      -text => "\n!!! please RESTART after changing buffer size !!!\n", 
			      -type => "comment");
    
    $self->{BUILDREADY}=1;
    
    my $off=0;
    for($cat=0;$cat<=$#{$self->{CATEGORIES}};$cat++) {
	$self->{BUFFERSIZE_INT}[$cat] = $self->{BUFFERSIZE}[$cat];
	$self->{BUFFEROFFSET}[$cat]  = $off; $off+=$self->{BUFFERSIZE_INT}[$cat];
    }

    for($cat=0;$cat<=$#{$self->{CATEGORIES}};$cat++) {
	$self->reset_idcache($cat);
	$self->fill_buffer($cat);
    }

    return();
}

sub register_external_updater {
    my $self = shift;
    my $category=shift;
    my $obj=shift;
    if(!$self->{EXTUPDATER}->{$category}) {
	$self->{EXTUPDATER}->{$category}=$obj;
    }

}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val,$subtype)=@_;
    my($diffx,$diffy,$id);
#    print "color_cb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY}) $subtype\n";
    if($subtype) {
	$subtype=~s/^\d+_//s;
	my $cat=$self->{CAT2NR}->{$subtype};
	$self->{$name}[$cat]=$val;

	# update color samples and colors in llview canvases
	if($name eq "COLORSLIDE") { 
	    $self->fill_examplecolors($cat) if($self->{BUILDREADY});
	    if($self->{EXTUPDATER}->{$subtype}) {
		$self->{EXTUPDATER}->{$subtype}->updatecoloredobjects($subtype)  if($self->{BUILDREADY});
	    }
	}
	# parameters changing the color scheme
	if(($name eq "SCHEME") 
	   || ($name eq "RANDOM")
	   || ($name=~/^VALUE/)
	   ) { 
	    $self->check_range("VALUERSTART","VALUEREND",$cat);
	    $self->check_range("VALUEGSTART","VALUEGEND",$cat);
	    $self->check_range("VALUEBSTART","VALUEBEND",$cat);
# wrap around
#	    $self->check_range("VALUEHSTART","VALUEHEND",$cat);
	    $self->check_range("VALUEGRAYSTART","VALUEGRAYEND",$cat);
	    $self->save_state($cat)         ;
	    $self->reset_idcache($cat);
	    $self->fill_buffer($cat)        if($self->{BUILDREADY});
	    $self->restore_state($cat)      ;
	    $self->fill_examplecolors($cat) if($self->{BUILDREADY});
	}
    } else {
	$self->{$name}=$val;
    }

}

sub check_range {
    my($self) = shift;
    my($startn,$endn,$cat)=@_;
    my $category=$self->{CATEGORIES}[$cat];
    my $ssection=$cat."_".$category;

    if($self->{$startn}[$cat]>=$self->{$endn}[$cat]) {
	$self->{$startn}[$cat]=$self->{$endn}[$cat]-10;
	if($self->{$startn}[$cat]<0) {
	    $self->{$startn}[$cat]+=10;
	    $self->{$endn}[$cat]+=10;
	}
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"Color",$ssection,$startn,$self->{$startn}[$cat]);
    }
}

sub save_state {
    my($self) = shift;
    my($cat)=@_;
    my($id,$color);
    
    $self->{STATE}={}; 
    foreach $color (keys(%{$self->{USEDCOLORS}[$cat]})) {
	my $id=$self->{USEDCOLORS}[$cat]->{$color};
	my $nr=$self->{COLORTONR}[$cat]->{$color};
	$self->{STATE}->{$id}=$nr;
#	print " $cat storing state $id -> $nr (->$color)\n";
    }
#    print " keys in usedcolors: ",join(" ",keys(%{$self->{USEDCOLORS}[$cat]})),"\n";
}

sub restore_state {
    my($self) = shift;
    my($cat)=@_;
    my($id,$color);
    
#    print " keys in usedcolors: ",join(" ",keys(%{$self->{USEDCOLORS}[$cat]})),"\n";
    foreach $id (keys(%{$self->{STATE}})) {
	my $nr=$self->{STATE}->{$id};
	my $color=$self->{NRTOCOLOR}[$cat]->[$nr];
	$self->{USEDCOLORS}[$cat]->{$color}=$id;
	$self->{KNOWNIDS}[$cat]->{$id}=$color;
#	print " $cat restoring state $id -> $nr (->$color)\n";
    }
#    print " keys in usedcolors: ",join(" ",keys(%{$self->{USEDCOLORS}[$cat]})),"\n";
}

sub fill_buffer {
    my($self) = shift;
    my($cat)=@_;
    my $scheme=$self->{SCHEME}[$cat];
    print "WF: color, fill_buffer($cat) scheme=$scheme\n" if($debug>=2); 

    if($scheme eq "PREDEFINED") {
	my($color,$id,$c);
	$self->{COLORTONR}[$cat]={}; 
	$self->{NRTOCOLOR}[$cat]=[];

	my @work=(@{$self->{COLORS}});
	$#{$self->{BUFFER}[$cat]}=-1;

	$c=1;
	foreach $color (@{$self->{COLORS_SORTED}}) {
	    unshift(@{$self->{BUFFER}[$cat]},$color);
	    print "WFA[$c]:",$color," cat=$cat\n"  if($debug>=3);
	    $self->{COLORTONR}[$cat]->{$color}=$c;
	    $self->{NRTOCOLOR}[$cat]->[$c]=$color;
	    $c++;
	    last if($c>$self->{BUFFERSIZE_INT}[$cat]);
	}

	while(@work) {
	    $color=splice(@work,int(rand(scalar @work)),1);
	    if(!(exists($self->{COLORTONR}[$cat]->{$color}))) {
		print "WFB[$c]:",$color," cat=$cat\n"  if($debug>=3);
		push(@{$self->{BUFFER}[$cat]},$color);
		$self->{COLORTONR}[$cat]->{$color}=$c;
		$self->{NRTOCOLOR}[$cat]->[$c]=$color;
		$c++;
		last if($c>$self->{BUFFERSIZE_INT}[$cat]);
	    }
	}

	# fill rest with grey colors
	if($c<$self->{BUFFERSIZE_INT}[$cat]) {
	    my ($r);
	    for($r=0;$r<($self->{BUFFERSIZE_INT}[$cat]-$c);$r++) {
		$work[$r]=sprintf( "\#%02x%02x%02x", $r, $r, $r);
	    }
	    while(@work) {
		$color=splice(@work,int(rand(scalar @work)),1);
		if(!(exists($self->{COLORTONR}[$cat]->{$color}))) {
		    print "WFB[$c]:",$color," cat=$cat\n"  if($debug>=3);
		    push(@{$self->{BUFFER}[$cat]},$color);
		    $self->{COLORTONR}[$cat]->{$color}=$c;
		    $self->{NRTOCOLOR}[$cat]->[$c]=$color;
		    $c++;
		    last if($c>$self->{BUFFERSIZE_INT}[$cat]);
		}
	    }
	}
    
	return();
    }
    if($scheme eq "GRAY") {
	my (@work,$r,$color,$c,$i);
	my $numcol=$self->{BUFFERSIZE_INT}[$cat];

	$#{$self->{BUFFER}[$cat]}=-1; # reset buffer
	$self->{COLORTONR}[$cat]={}; 
	$self->{NRTOCOLOR}[$cat]=[];

	my $off=0;
	$c=1;
	while($c<$self->{BUFFERSIZE_INT}[$cat]) {
	    # generate colors
	    $i=0;
	    for($r=$self->{VALUEGRAYSTART}[$cat];$r<$self->{VALUEGRAYEND}[$cat];$r++) {
		$work[$i++]=sprintf( "\#%02x%02x%02x", $r, $r, $r+$off);
	    }
#	    print "WF: $i gray $self->{RANDOM}[$cat]",$#{$self->{BUFFER}[$cat]},"\n";

	    # put colors in buffer
	    while(@work) {
		if($self->{RANDOM}[$cat]==1) {
		    $color=splice(@work,int(rand(scalar @work)),1);
		} else {
		    $color=shift(@work);
		}
		if(!(exists($self->{COLORTONR}[$cat]->{$color}))) {
		    print "WFB[$c]:",$color," cat=$cat\n"  if($debug>=3);
		    push(@{$self->{BUFFER}[$cat]},$color);
		    $self->{COLORTONR}[$cat]->{$color}=$c;
		    $self->{NRTOCOLOR}[$cat]->[$c]=$color;
		    $c++;
		    last if($c>$self->{BUFFERSIZE_INT}[$cat]);
		}
	    }
	    $off++; 
	    last if($c>$self->{BUFFERSIZE_INT}[$cat]);
	}
    }
    if($scheme eq "HSV") {
	my (@work,$h,$s,$v,$r,$g,$b,$color,$c,$diff,$i);
	my $numcol=$self->{BUFFERSIZE_INT}[$cat];

	$#{$self->{BUFFER}[$cat]}=-1; # reset buffer
	$self->{COLORTONR}[$cat]={}; 
	$self->{NRTOCOLOR}[$cat]=[];


	my $off=0;
	$c=1;
	while($c<$self->{BUFFERSIZE_INT}[$cat]) {

	    # generate colors
	    if($self->{VALUEHEND}[$cat]>$self->{VALUEHSTART}[$cat]) {
		$diff=int $self->{VALUEHEND}[$cat]-$self->{VALUEHSTART}[$cat];
	    } else {
		$diff=int $self->{VALUEHEND}[$cat]+360-$self->{VALUEHSTART}[$cat];
	    }
#	    $diff=-$diff if($diff<0); # only a hack, panel has to take care about this
	    for($i=0;$i<$diff;$i++) {
		$h = ($self->{VALUEHSTART}[$cat]+$i)%360; 
		$s=$self->{VALUE_S}[$cat]; 
		$v=$self->{VALUE_V}[$cat]; 
		if($v+$off<100) {
		    $v+=$off;
		} else {
		    $v-=$off;
		}
		($r,$g,$b)=&hsv2rgb($h,$s,$v);
		$r = int 255.0/100.0 * $r;	$g = int 255.0/100.0 *$g;	$b = int 255.0/100.0 * $b;
		$work[$i]=sprintf( "\#%02x%02x%02x", $r, $g, $b);
	    }

	    # put colors in buffer
#	    print "WF: hsv $c diff=$diff ",$#{$self->{BUFFER}[$cat]},"\n";
	    while(@work) {
		if($self->{RANDOM}[$cat]==1) {
		    $color=splice(@work,int(rand(scalar @work)),1);
		} else {
		    $color=shift(@work);
		}
		if(!(exists($self->{COLORTONR}[$cat]->{$color}))) {
		    print "WFB[$c]:",$color," cat=$cat\n"  if($debug>=3);
		    push(@{$self->{BUFFER}[$cat]},$color);
		    $self->{COLORTONR}[$cat]->{$color}=$c;
		    $self->{NRTOCOLOR}[$cat]->[$c]=$color;
		    $c++;
		    last if($c>$self->{BUFFERSIZE_INT}[$cat]);
		}
	    }
	    $off++; 
	    last if($c>$self->{BUFFERSIZE_INT}[$cat]);
	}
    }
    if($scheme eq "RGB") {
	my (@work,$r,$g,$b,$color,$c,$i);
	my $numcol=$self->{BUFFERSIZE_INT}[$cat];

	$#{$self->{BUFFER}[$cat]}=-1; # reset buffer
	$self->{COLORTONR}[$cat]={}; 
	$self->{NRTOCOLOR}[$cat]=[];

	my $off=0;
	$c=1;
	while($c<$self->{BUFFERSIZE_INT}[$cat]) {
	    # generate colors
	    $i=0;
	    $r=$self->{VALUERSTART}[$cat];
	    $g=$self->{VALUEGSTART}[$cat];
	    $b=$self->{VALUEBSTART}[$cat];
	    COL: 
	    for($r=$self->{VALUERSTART}[$cat];$r<$self->{VALUEREND}[$cat];$r++) {
		for($g=$self->{VALUEGSTART}[$cat];$r<$self->{VALUEGEND}[$cat];$g++) {
		    for($b=$self->{VALUEBSTART}[$cat];$b<$self->{VALUEBEND}[$cat];$b++) {
			$work[$i++]=sprintf( "\#%02x%02x%02x", $r, $g, $b+$off);
#			print "WF: col $i -> $r, $g, $b $work[$i-1]\n";
			last COL if ($i>$self->{BUFFERSIZE_INT}[$cat]);
		    }
		}
	    }
	    print "WF: $i gray $self->{RANDOM}[$cat]",$#{$self->{BUFFER}[$cat]},"\n";

	    # put colors in buffer
	    while(@work) {
		if($self->{RANDOM}[$cat]==1) {
		    $color=splice(@work,int(rand(scalar @work)),1);
		} else {
		    $color=shift(@work);
		}
		if(!(exists($self->{COLORTONR}[$cat]->{$color}))) {
		    print "WFB[$c]:",$color," cat=$cat\n"  if($debug>=3);
		    push(@{$self->{BUFFER}[$cat]},$color);
		    $self->{COLORTONR}[$cat]->{$color}=$c;
		    $self->{NRTOCOLOR}[$cat]->[$c]=$color;
		    $c++;
		    last if($c>$self->{BUFFERSIZE_INT}[$cat]);
		}
	    }
	    $off++; 
	    last if($c>$self->{BUFFERSIZE_INT}[$cat]);
	}
    }


}


# reset id cache, delete all known ids
sub reset_idcache {
    my($self) = shift;
    my($cat)=@_;
    my($color,$id);
    
#    print "WF: resetidcache $self >$cat< ",caller(),"\n";
    $self->{KNOWNIDSSIZE}[$cat]  = 0;
    $self->{KNOWNIDS}[$cat]      = {};
    
    $self->{USEDCOLORSSIZE}[$cat]= 0;
    $self->{USEDCOLORS}[$cat]    = {};

#    foreach $id (keys(%{$self->{KNOWNIDS}[$cat]})) {
#	delete($self->{KNOWNIDS}[$cat]->{$id});
#    }
#    foreach $color (keys(%{$self->{USEDCOLORS}[$cat]})) {
#	delete($self->{USEDCOLORS}[$cat]->{$color});
#    }
}

#
sub get_color {
    my($self) = shift;
    my($category,$id)=@_;
    my($cat,$color);
    $cat=$self->{CAT2NR}->{$category};
    if(($category ne "RUN" ) && (!$cat)) {
	print "ERROR in get_color wrong category $category from ",caller(),"\n";
    }
    if(!$id) {
	print "ERROR in get_color no id, category $category from ",caller(),"\n";
    }
    if(exists($self->{KNOWNIDS}[$cat]->{$id})) {
	$color=$self->{KNOWNIDS}[$cat]->{$id};
    } else {
	# new color
	if($#{$self->{BUFFER}[$cat]}>0) {
	    $color=shift(@{$self->{BUFFER}[$cat]}); 
	} else {
	    printf("llview_manage_color: not enough colors in category %s(%d) buffersize=%d...\n",$category,$cat,$self->{BUFFERSIZE}[$cat]);
	    $color="red"; 
	}
	if($self->{USEDCOLORS}[$cat]->{$color}) {
	    printf( "llview_manage_color: warning color in use .. by: %10s %-15s -> %-20s #buffer=%3d\n",
		    $self->{USEDCOLORS}[$cat]->{$color},$id,$color,$#{$self->{BUFFER}[$cat]});
	}
	$self->{KNOWNIDS}[$cat]->{$id}=$color;
	$self->{USEDCOLORS}[$cat]->{$color}=$id;
	printf( "llview_manage_color: %-15s new color for %-15s -> %-20s nr=%3d #buffer=%3d (%s)\n",$category,$id,$color,
		$self->{COLORTONR}[$cat]->{$color},$#{$self->{BUFFER}[$cat]},join(",",caller())) if($debug>=3);
    }
    return($color);
}

sub colortonr {
    my($self) = shift;
    my($category,$color)=@_;
    my $cat=$self->{CAT2NR}->{$category};
    my $nr=$self->{COLORTONR}[$cat]->{$color}+$self->{BUFFEROFFSET}[$cat];
    return($nr);
}

sub nrtocolor {
    my($self) = shift;
    my($category,$nr)=@_;
    my $cat=$self->{CAT2NR}->{$category};
    $nr-=$self->{BUFFEROFFSET}[$cat];
    my $color=$self->{NRTOCOLOR}[$cat]->[$nr];
    return($color);
}

sub nrtocat {
    my($self) = shift;
    my($nr)=@_;
    my ($cat,$category);
    for($cat=0;$cat<=$#{$self->{CATEGORIES}};$cat++) {
	last if( ($nr>=$self->{BUFFEROFFSET}[$cat]) 
		 && ($nr<$self->{BUFFEROFFSET}[$cat]+$self->{BUFFERSIZE_INT}[$cat]) );
    }
    return("UNKNOWN") if($cat>$#{$self->{CATEGORIES}});  
    $category=$self->{CATEGORIES}->[$cat];
    return($category);
}

sub nrtoid {
    my($self) = shift;
    my($category,$nr)=@_;
    my $cat=$self->{CAT2NR}->{$category};
    $nr-=$self->{BUFFEROFFSET}[$cat];
    my $color=$self->{NRTOCOLOR}[$cat]->[$nr];
    my $id=$self->{USEDCOLORS}[$cat]->{$color};
    return($id);
}

sub idtonr {
    my($self) = shift;
    my($category,$id)=@_;
    my $color=$self->get_color($category,$id);
    my $nr=$self->colortonr($category,$color);
    return($nr);
}

sub getusednrs {
    my($self) = shift;
    my($category)=@_;
    my $cat=$self->{CAT2NR}->{$category};
    my(@nrs,$color);
    foreach $color (keys(%{$self->{USEDCOLORS}[$cat]})) {
	push(@nrs,$self->colortonr($category,$color));
    }
    return(@nrs);
}

sub getusednrs_all {
    my($self) = shift;
    my(@nrs,$color,$cat);

    for($cat=0;$cat<=$#{$self->{CATEGORIES}};$cat++) {
	push(@nrs,$self->getusednrs($self->{CATEGORIES}->[$cat]));
    }
#    print "WF: color, getusednrs return(@nrs)\n";
    return(@nrs);
}


sub free {
    my($self) = shift;
    my($category,$id)=@_;
    my $cat=$self->{CAT2NR}->{$category};
    my($color);
    if(exists($self->{KNOWNIDS}[$cat]->{$id})) {
	$color=$self->{KNOWNIDS}[$cat]->{$id};
	delete($self->{KNOWNIDS}[$cat]->{$id});
	delete($self->{USEDCOLORS}[$cat]->{$color});
	push(@{$self->{BUFFER}[$cat]},$color);
	printf( "llview_manage_color: $category free color for %-15s -> %-20s #buffer=%3d\n",$id,$color,$#{$self->{BUFFER}[$cat]}) if($debug>=2);
    } else {
	printf("llview_manage_color: $category freeing color for unknown id %s ...\n",$id) if($debug>=2);
    }
    return($color);
}

sub free_unused {
    my($self) = shift;
    my $category= shift;
    my $cat=$self->{CAT2NR}->{$category};
    my @ids=@_;
    my($id,$num);
    my %checkids=();
    
#    printf("llview_manage_color: free_unused: $category check IDs @ids\n");
    foreach $id (@ids) {
	if(exists($self->{KNOWNIDS}[$cat]->{$id})) {
	    $checkids{$id}=1;
	} else {
#	    printf("llview_manage_color: free_unused: new id %s ...\n",$id);
	}
    }

    $num=0;
    foreach $id (keys(%{$self->{KNOWNIDS}[$cat]})) {
	if(!exists($checkids{$id})) {
#	    print "llview_manage_colors: free_unused: $id \n";
	    $self->free($category,$id);
	    $num++;
	}
    }
#    printf("llview_manage_color: free_unused: $category check IDs @ids ready num=$num\n");
    return($num);
}


sub fill_examplecolors {
    my($self) = shift;
    my($cat)=@_;
    my $category=$self->{CATEGORIES}[$cat];
    my $ssection=$cat."_".$category;
    my $canvas=$self->{OPTIONOBJECT}->get_canvas_obj("Color","COLORSLIDE", -subtype => $ssection);
    my $width =$self->{COLORSEXAMPLEWIDTH};
    my $height=$self->{COLORSEXAMPLEHEIGHT};
    my $numcol=$self->{BUFFERSIZE_INT}[$cat];
    my($id,$c);
    my ($nx,$ny,$x,$y,$dx,$dy);
    $nx=20;$ny=$numcol/$nx; 
    $ny=int($ny)+1 if($ny != int($ny));
    $dx=$width/$nx;
    $dy=$height/$ny;
    
    # remove old rectangles
    while ($id=shift(@{$self->{ITEMS}[$cat]})) {
	$canvas->delete($id);
    }

    $c=1;
    for($y=0;$y<$ny;$y++) {
	for($x=0;$x<$nx;$x++) {
	    my $text=sprintf("%d%s",$c,
			     ($self->{USEDCOLORS}[$cat]->{$self->{NRTOCOLOR}[$cat]->[$c]})?" Used":""
			     );
	    $id=$canvas->createRectangle($x*$dx    ,$y*$dy,
					 $x*$dx+$dx,$y*$dy+$dy,
					 -fill => $self->{NRTOCOLOR}[$cat]->[$c]);
	    push(@{$self->{ITEMS}[$cat]},$id);
	    $id=$canvas->createText($x*$dx,$y*$dy,-text => $text, 
				    anchor=> "nw", -font => $self->{FONT1});
	    push(@{$self->{FIXEDITEMS}},$id);
	    $c++;
	}
    }
}


sub hsv2rgb {
    my ($h, $s, $v) = @_;
    my ($i, $f, $p, $q, $t, $r,$g,$b);
    if ($s == 0) {
	$r = $b = $g = $v;
    } else {
	$h /= 60;
	$i = int $h;
	$f = $h - $i;
	$p = $v/100.0 * (100 - $s);
	$q = $v/100.0 * (100 - $s * $f);
	$t = $v/100.0 * (100 - $s * (1 - $f));
      SWITCH: {
	  if ($i == 0) {
	      $r = $v;
	      $g = $t;
	      $b = $p;
	      last SWITCH;
	  }
	  if ($i == 1) {
	      $r = $q;
	      $g = $v;
	      $b = $p;
	      last SWITCH;
	  }
	  if ($i == 2) {
	      $r = $p;
	      $g = $v;
	      $b = $t;
	      last SWITCH;
	  }
	  if ($i == 3) {
	      $r = $p;
	      $g = $q;
	      $b = $v;
	      last SWITCH;
	  }
	  if ($i == 4) {
	      $r = $t;
	      $g = $p;
	      $b = $v;
	      last SWITCH;
	  }
	  $r = $v;
	  $g = $p;
	  $b = $q;
      } 
    }
    return ($r, $g, $b);
}

# initialize list of fix colors
sub initcolor {
    my($self) = shift;
    $self->{COLORS_SORTED} = [
			'light goldenrod',
			'aquamarine2',                
			'azure',
			'bisque', 
			'blue',
			'blue violet',
			'brown',               
			'chartreuse',                  
			'chocolate',                   
			'coral',                       
			'CornflowerBlue',              
			'cyan',                        
			'dark blue',                   
			'dark red',                    
			'DarkCyan',                    
			'DarkRed',                     
			'DarkSeaGreen',                
			'deep pink',                   
			'DeepSkyBlue',                 
			'DodgerBlue',                  
			'firebrick',                   
			'FloralWhite',                 
			'ForestGreen',                 
			'gold',                        
			'goldenrod',                   
			'green',                       
			'green yellow',                
			'honeydew',                    
			'HotPink',
			'IndianRed',   
			'khaki',
			'lavender',
			'LemonChiffon',
			'light blue',                 
			'light salmon',                 
			'light pink',                 
			'light sky blue',             
			'LightSkyBlue',               
			'linen',                      
			'magenta',                    
			'maroon',                     
			'medium purple',              
			'orange',                     
			'PaleGreen',                  
			'PeachPuff',                  
			'peru',                       
			'plum',                       
			'purple',                     
			'RosyBrown',                  
			'RoyalBlue',                  
			'salmon',                     
			];
    $self->{COLORS} = [
			     "antique white",
			     "AntiqueWhite",
			     "AntiqueWhite1",
			     "AntiqueWhite2",
			     "AntiqueWhite3",
			     "AntiqueWhite4",
			     "aquamarine",
			     "aquamarine1",
			     "aquamarine2",
			     "aquamarine3",
			     "aquamarine4",
			     "beige",
			     "bisque",
			     "bisque1",
			     "bisque2",
			     "bisque3",
			     "bisque4",
			     "blanched almond",
			     "BlanchedAlmond",
			     "blue",
			     "blue violet",
			     "blue1",
			     "blue2",
			     "blue3",
			     "blue4",
			     "BlueViolet",
			     "brown",
			     "brown1",
			     "brown2",
			     "brown3",
			     "brown4",
			     "burlywood",
			     "burlywood1",
			     "burlywood2",
			     "burlywood3",
			     "burlywood4",
			     "cadet blue",
			     "CadetBlue",
			     "CadetBlue1",
			     "CadetBlue2",
			     "CadetBlue3",
			     "CadetBlue4",
			     "chartreuse",
			     "chartreuse1",
			     "chartreuse2",
			     "chartreuse3",
			     "chartreuse4",
			     "chocolate",
			     "chocolate1",
			     "chocolate2",
			     "chocolate3",
			     "chocolate4",
			     "coral",
			     "coral1",
			     "coral2",
			     "coral3",
			     "coral4",
			     "cornflower blue",
			     "CornflowerBlue",
			     "cornsilk",
			     "cornsilk1",
			     "cornsilk2",
			     "cornsilk3",
			     "cornsilk4",
			     "cyan",
			     "cyan1",
			     "cyan2",
			     "cyan3",
			     "cyan4",
			     "dark blue",
			     "dark cyan",
			     "dark goldenrod",
			     "dark gray",
			     "dark green",
			     "dark grey",
			     "dark khaki",
			     "dark magenta",
			     "dark olive green",
			     "dark orange",
			     "dark orchid",
			     "dark red",
			     "dark salmon",
			     "dark sea green",
			     "dark slate blue",
			     "dark slate gray",
			     "dark slate grey",
			     "dark turquoise",
			     "dark violet",
			     "DarkBlue",
			     "DarkCyan",
			     "DarkGoldenrod",
			     "DarkGoldenrod1",
			     "DarkGoldenrod2",
			     "DarkGoldenrod3",
			     "DarkGoldenrod4",
			     "DarkGray",
			     "DarkGreen",
			     "DarkGrey",
			     "DarkKhaki",
			     "DarkMagenta",
			     "DarkOliveGreen",
			     "DarkOliveGreen1",
			     "DarkOliveGreen2",
			     "DarkOliveGreen3",
			     "DarkOliveGreen4",
			     "DarkOrange",
			     "DarkOrange1",
			     "DarkOrange2",
			     "DarkOrange3",
			     "DarkOrange4",
			     "DarkOrchid",
			     "DarkOrchid1",
			     "DarkOrchid2",
			     "DarkOrchid3",
			     "DarkOrchid4",
			     "DarkRed",
			     "DarkSalmon",
			     "DarkSeaGreen",
			     "DarkSeaGreen1",
			     "DarkSeaGreen2",
			     "DarkSeaGreen3",
			     "DarkSeaGreen4",
			     "DarkSlateBlue",
			     "DarkSlateGray",
			     "DarkSlateGray1",
			     "DarkSlateGray2",
			     "DarkSlateGray3",
			     "DarkSlateGray4",
			     "DarkSlateGrey",
			     "DarkTurquoise",
			     "DarkViolet",
			     "deep pink",
			     "deep sky blue",
			     "DeepPink",
			     "DeepPink1",
			     "DeepPink2",
			     "DeepPink3",
			     "DeepPink4",
			     "DeepSkyBlue",
			     "DeepSkyBlue1",
			     "DeepSkyBlue2",
			     "DeepSkyBlue3",
			     "DeepSkyBlue4",
			     "dodger blue",
			     "DodgerBlue",
			     "DodgerBlue1",
			     "DodgerBlue2",
			     "DodgerBlue3",
			     "DodgerBlue4",
			     "firebrick",
			     "firebrick1",
			     "firebrick2",
			     "firebrick3",
			     "firebrick4",
			     "floral white",
			     "FloralWhite",
			     "forest green",
			     "ForestGreen",
			     "gainsboro",
			     "ghost white",
			     "GhostWhite",
			     "gold",
			     "gold1",
			     "gold2",
			     "gold3",
			     "gold4",
			     "goldenrod",
			     "goldenrod1",
			     "goldenrod2",
			     "goldenrod3",
			     "goldenrod4",
			     "green",
			     "green yellow",
			     "green1",
			     "green2",
			     "green3",
			     "green4",
			     "GreenYellow",
			     "honeydew",
			     "honeydew1",
			     "honeydew2",
			     "honeydew3",
			     "honeydew4",
			     "hot pink",
			     "HotPink",
			     "HotPink1",
			     "HotPink2",
			     "HotPink3",
			     "HotPink4",
			     "indian red",
			     "IndianRed",
			     "IndianRed1",
			     "IndianRed2",
			     "IndianRed3",
			     "IndianRed4",
			     "khaki",
			     "khaki1",
			     "khaki2",
			     "khaki3",
			     "khaki4",
			     "lavender",
			     "lavender blush",
			     "LavenderBlush",
			     "LavenderBlush1",
			     "LavenderBlush2",
			     "LavenderBlush3",
			     "LavenderBlush4",
			     "lawn green",
			     "LawnGreen",
			     "lemon chiffon",
			     "LemonChiffon",
			     "LemonChiffon1",
			     "LemonChiffon2",
			     "LemonChiffon3",
			     "LemonChiffon4",
			     "light blue",
			     "light coral",
			     "light cyan",
			     "light goldenrod",
			     "light goldenrod yellow",
			     "light green",
			     "light pink",
			     "light salmon",
			     "light sea green",
			     "light sky blue",
			     "light slate blue",
			     "light slate gray",
			     "light slate grey",
			     "light steel blue",
			     "light yellow",
			     "LightBlue",
			     "LightBlue1",
			     "LightBlue2",
			     "LightBlue3",
			     "LightBlue4",
			     "LightCoral",
			     "LightCyan",
			     "LightCyan1",
			     "LightCyan2",
			     "LightCyan3",
			     "LightCyan4",
			     "LightGoldenrod",
			     "LightGoldenrod1",
			     "LightGoldenrod2",
			     "LightGoldenrod3",
			     "LightGoldenrod4",
			     "LightGoldenrodYellow",
			     "LightGreen",
			     "LightPink",
			     "LightPink1",
			     "LightPink2",
			     "LightPink3",
			     "LightPink4",
			     "LightSalmon",
			     "LightSalmon1",
			     "LightSalmon2",
			     "LightSalmon3",
			     "LightSalmon4",
			     "LightSeaGreen",
			     "LightSkyBlue",
			     "LightSkyBlue1",
			     "LightSkyBlue2",
			     "LightSkyBlue3",
			     "LightSkyBlue4",
			     "LightSlateBlue",
			     "LightSlateGray",
			     "LightSlateGrey",
			     "LightSteelBlue",
			     "LightSteelBlue1",
			     "LightSteelBlue2",
			     "LightSteelBlue3",
			     "LightSteelBlue4",
			     "LightYellow",
			     "LightYellow1",
			     "LightYellow2",
			     "LightYellow3",
			     "LightYellow4",
			     "lime green",
			     "LimeGreen",
			     "linen",
			     "magenta",
			     "magenta1",
			     "magenta2",
			     "magenta3",
			     "magenta4",
			     "maroon",
			     "maroon1",
			     "maroon2",
			     "maroon3",
			     "maroon4",
			     "medium aquamarine",
			     "medium blue",
			     "medium orchid",
			     "medium purple",
			     "medium sea green",
			     "medium slate blue",
			     "medium spring green",
			     "medium turquoise",
			     "medium violet red",
			     "MediumAquamarine",
			     "MediumBlue",
			     "MediumOrchid",
			     "MediumOrchid1",
			     "MediumOrchid2",
			     "MediumOrchid3",
			     "MediumOrchid4",
			     "MediumPurple",
			     "MediumPurple1",
			     "MediumPurple2",
			     "MediumPurple3",
			     "MediumPurple4",
			     "MediumSeaGreen",
			     "MediumSlateBlue",
			     "MediumSpringGreen",
			     "MediumTurquoise",
			     "MediumVioletRed",
			     "midnight blue",
			     "MidnightBlue",
			     "mint cream",
			     "MintCream",
			     "misty rose",
			     "MistyRose",
			     "MistyRose1",
			     "MistyRose2",
			     "MistyRose3",
			     "MistyRose4",
			     "moccasin",
			     "navajo white",
			     "NavajoWhite",
			     "NavajoWhite1",
			     "NavajoWhite2",
			     "NavajoWhite3",
			     "NavajoWhite4",
			     "navy",
			     "navy blue",
			     "NavyBlue",
			     "old lace",
			     "OldLace",
			     "olive drab",
			     "OliveDrab",
			     "OliveDrab1",
			     "OliveDrab2",
			     "OliveDrab3",
			     "OliveDrab4",
			     "orange",
			     "orange red",
			     "orange1",
			     "orange2",
			     "orange3",
			     "orange4",
			     "OrangeRed",
			     "OrangeRed1",
			     "OrangeRed2",
			     "OrangeRed3",
			     "OrangeRed4",
			     "orchid",
			     "orchid1",
			     "orchid2",
			     "orchid3",
			     "orchid4",
			     "pale goldenrod",
			     "pale green",
			     "pale turquoise",
			     "pale violet red",
			     "PaleGoldenrod",
			     "PaleGreen",
			     "PaleGreen1",
			     "PaleGreen2",
			     "PaleGreen3",
			     "PaleGreen4",
			     "PaleTurquoise",
			     "PaleTurquoise1",
			     "PaleTurquoise2",
			     "PaleTurquoise3",
			     "PaleTurquoise4",
			     "PaleVioletRed",
			     "PaleVioletRed1",
			     "PaleVioletRed2",
			     "PaleVioletRed3",
			     "PaleVioletRed4",
			     "papaya whip",
			     "PapayaWhip",
			     "peach puff",
			     "PeachPuff",
			     "PeachPuff1",
			     "PeachPuff2",
			     "PeachPuff3",
			     "PeachPuff4",
			     "peru",
			     "pink",
			     "pink1",
			     "pink2",
			     "pink3",
			     "pink4",
			     "plum",
			     "plum1",
			     "plum2",
			     "plum3",
			     "plum4",
			     "powder blue",
			     "PowderBlue",
			     "purple",
			     "purple1",
			     "purple2",
			     "purple3",
			     "purple4",
#			     "red",
			     "red1",
			     "red2",
			     "red3",
			     "red4",
			     "rosy brown",
			     "RosyBrown",
			     "RosyBrown1",
			     "RosyBrown2",
			     "RosyBrown3",
			     "RosyBrown4",
			     "royal blue",
			     "RoyalBlue",
			     "RoyalBlue1",
			     "RoyalBlue2",
			     "RoyalBlue3",
			     "RoyalBlue4",
			     "saddle brown",
			     "SaddleBrown",
			     "salmon",
			     "salmon1",
			     "salmon2",
			     "salmon3",
			     "salmon4",
			     "sandy brown",
			     "SandyBrown",
			     "sea green",
			     "SeaGreen",
			     "SeaGreen1",
			     "SeaGreen2",
			     "SeaGreen3",
			     "SeaGreen4",
			     "seashell",
			     "seashell1",
			     "seashell2",
			     "seashell3",
			     "seashell4",
			     "sienna",
			     "sienna1",
			     "sienna2",
			     "sienna3",
			     "sienna4",
			     "sky blue",
			     "SkyBlue",
			     "SkyBlue1",
			     "SkyBlue2",
			     "SkyBlue3",
			     "SkyBlue4",
			     "slate blue",
			     "slate gray",
			     "slate grey",
			     "SlateBlue",
			     "SlateBlue1",
			     "SlateBlue2",
			     "SlateBlue3",
			     "SlateBlue4",
			     "SlateGray",
			     "SlateGray1",
			     "SlateGray2",
			     "SlateGray3",
			     "SlateGray4",
			     "SlateGrey",
			     "spring green",
			     "SpringGreen",
			     "SpringGreen1",
			     "SpringGreen2",
			     "SpringGreen3",
			     "SpringGreen4",
			     "steel blue",
			     "SteelBlue",
			     "SteelBlue1",
			     "SteelBlue2",
			     "SteelBlue3",
			     "SteelBlue4",
			     "tan",
			     "tan1",
			     "tan2",
			     "tan3",
			     "tan4",
			     "thistle",
			     "thistle1",
			     "thistle2",
			     "thistle3",
			     "thistle4",
			     "tomato",
			     "tomato1",
			     "tomato2",
			     "tomato3",
			     "tomato4",
			     "turquoise",
			     "turquoise1",
			     "turquoise2",
			     "turquoise3",
			     "turquoise4",
			     "violet",
			     "violet red",
			     "VioletRed",
			     "VioletRed1",
			     "VioletRed2",
			     "VioletRed3",
			     "VioletRed4",
			     "wheat",
			     "wheat1",
			     "wheat2",
			     "wheat3",
			     "wheat4",
			     "white",
			     "white smoke",
			     "WhiteSmoke",
			     "yellow",
			     "yellow green",
			     "yellow1",
			     "yellow2",
			     "yellow3",
			     "yellow4",
			     "YellowGreen"
			    	       ];
}			    
1;
