# $Source: /cvs/cvsroot/llview/lib/LLview_gui_options.pm,v $
# $Author: zdv087 $
# $Revision: 1.74 $
# $Date: 2007/07/12 20:49:16 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_options;
use strict;
use Tk;
use Carp;
use Config::IniFiles;
use Tk::FileSelect;
#use Tk::FileDialog;
use Cwd 'abs_path';
my($debug)=0;
my($selfref)=-1;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $inifile=shift;
    my $instpath=shift;
    printf("\t\LLview_gui_options: new %s\n",ref($proto)) if($debug>=3);
    $self->{MULTICLUSTER}  = shift;
    $self->{VERSION}=shift; # will be set from main.pm
    $self->{PREFIX}  = shift;
    $self->{VERBOSE} = 0;
    $self->{HOME}=$ENV{HOME};
    $self->{INSTPATH} = $instpath;
    $self->{SHOWPM}  = 1;
    $self->{HAVEINFOMSG} = 0;
    $self->{TLWIN}   = undef;
    $self->{POSX}    = 90;
    $self->{POSY}    = 730;
    $self->{WIDTH}   = 700;
    $self->{HEIGHT}  = 400;
    $self->{TEXT}    = "<no information>";
    $self->{TEXTTYPE}="default";
    $self->{TEXTNAME}="";
    $self->{TOPCLUSTER}="-";
    $self->{LASTCLUSTER}="-";
    $self->{CONFIGFILENAME}="llview".$self->{PREFIX}.".rc"    if(!$self->{MULTICLUSTER});
    $self->{CONFIGFILENAME}="llview".$self->{PREFIX}."_mc.rc" if($self->{MULTICLUSTER});
    $self->{ITEMS}   = [];

    $self->{FONT0}       = "-*-Courier-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT0}      = "-*-Courier-Bold-R-Normal--*-80-*-*-*-*-*-*";

    $self->{FONT1}       = "-*-Times-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}      = "-*-Times-Bold-R-Normal--*-80-*-*-*-*-*-*";

    $self->{BUILDREADY} = 0;

    $self->{ACTIVATED} = 0;

    bless $self, $class;
    if($selfref==-1)  {
	$selfref=\$self;
    } else {
	printf("WARNING: double constructor call to LLview_gui_options ...\n")
    }

    # toplevel ini file
    ($self->{DEFAULTFILE}->{$self->{TOPCLUSTER}},
     $self->{INIFILE}->{$self->{TOPCLUSTER}},
     $self->{DEFAULTFILEOBJ}->{$self->{TOPCLUSTER}},
     $self->{INIFILEOBJ}->{$self->{TOPCLUSTER}},
     $self->{UNSAVECHANGES}->{$self->{TOPCLUSTER}})=$self->set_config_file($inifile,$self->{CONFIGFILENAME});

    return $self;
}

sub set_config_file {
    my($self) = shift;
    my($p_inifile,$configfilename)=@_;
    my($defaultfile,$inifile,$defaultfileobj,$inifileobj,$unsavedchanges);
    $unsavedchanges=0;
    $defaultfile = $self->{INSTPATH}."/".$configfilename;
    if($p_inifile!~/^\s*$/) {
	$inifile = $p_inifile;
    } else {
	if(-f "./.".$configfilename) {
#	    print "WF: >./.llview.rc<\n";
	    $inifile = abs_path(".")."/.".$configfilename;
	} else {
#	    print "WF: >$home/.llview.rc<\n";
	    $inifile = $self->{HOME}."/.".$configfilename;
	}
    }
    
#    print "WF: set_config_file inifile=$inifile $p_inifile\n";

    if(-f $defaultfile) {
	print "Option: reading default options from file $defaultfile\n" if ($self->{VERBOSE});
	$defaultfileobj = Config::IniFiles->new(-file => $defaultfile);
    } else {
	print "Option: no default config file ($defaultfile) found, using default values\n" if ($self->{VERBOSE});
	$defaultfileobj = Config::IniFiles->new();
	$defaultfileobj->SetFileName($defaultfile);
    }

    if(-f $inifile) {
	print "Option: reading options from file $inifile\n" if ($self->{VERBOSE});
	if(!($inifileobj = Config::IniFiles->new(-file => $inifile))) { 
	    printf("WARNING: Config file %s cannot be read ... skipping\n",$inifile);
	    $inifileobj = Config::IniFiles->new();
	    $inifileobj->SetFileName($inifile);
	}
	my $version_ok=1;
	$version_ok=0 if(!defined($inifileobj->val("General","VERSION") ) );
	if($version_ok) {
	    $version_ok=0 if($inifileobj->val("General","VERSION") ne $self->{VERSION});
	}
#	print "WF: versioncheck: ",$inifileobj->val("General","VERSION")," ",$self->{VERSION}," $version_ok\n";
	if(!$version_ok) {
	    my($userid,$passwd)=("","");
	    printf("WARNING: old config file %s found ... skipping, please save new config file\n",$inifile);
	    if( 
		defined($inifileobj->val("WWW","AUTUSERID")) 
			&& defined($inifileobj->val("WWW","AUTPASSWD"))
				   ) {
		$userid=$inifileobj->val("WWW","AUTUSERID");
		$passwd=$inifileobj->val("WWW","AUTPASSWD");
		printf("WARNING:   reusing WWW access information from old config file\n");
		printf("WARNING:   please SAVE Options in Option Panel\n");
		$unsavedchanges=1;
	    } 
	    $inifileobj = Config::IniFiles->new();
	    $inifileobj->SetFileName($inifile);
	    $inifileobj->newval("WWW","AUTUSERID",$userid);
	    $inifileobj->newval("WWW","AUTPASSWD",$passwd);
#	    printf("WARNING:   reusing WWW access information from old config file >%s<>%s<\n",
#	    $inifileobj->val("WWW","AUTUSERID"),$inifileobj->val("WWW","AUTPASSWD"));

	}
    } else {
	print "Option: no user config file ($inifile) found, using default values\n" if ($self->{VERBOSE});
	$inifileobj = Config::IniFiles->new();
	$inifileobj->SetFileName($inifile);
    }

    return ($defaultfile,$inifile,$defaultfileobj,$inifileobj,$unsavedchanges);
}

sub build {
    my($self) = shift;
    my($mw,$optmenu,$dataobj,$colorobj,$infoobj,$canvas)=@_;

#    print "ENTRY:",caller(),Dumper($self),"\n";

    $self->{TLWIN}=undef;
    $self->{MAINWINDOW}=$mw;
    $self->{OPTMENU}=$optmenu;
    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;


    print "LLview_gui_options: build $self->{ACTIVATED} \n"  if($debug>=3);

    if(!exists($self->{OPTION_CHANGE})) {
	$self->{OPTION_CHANGE} = $optmenu->command(-label => "Change ...", 
						   -command => \&toggle_option_panel,
						   -underline => 0); 
	if(!$self->{MULTICLUSTER}) {
	
	    $self->{OPTION_SAVE}   = $optmenu->command(-label => "Save ...", 
						       -command => sub {&save_config($self->{TOPCLUSTER});},
						       -underline => 0); 
	    $self->{OPTION_SAVEAS} = $optmenu->command(-label => "Save As ...", 
						       -command => \&save_config_as,
						       -underline => 0); 
	    $self->{OPTION_LOAD}  = $optmenu->command(-label => "Load ...", 
						      -command => \&load_config,
						      -underline => 0); 
	    $self->{OPTION_RESET}    = $optmenu->command(-label => "Reset", 
							 -command => \&reset_config,
						     -underline => 0); 
	    $self->{OPTION_DEFAULT}  = $optmenu->command(-label => "Reset to default", 
							 -command => \&default_config,
						     -underline => 0); 
	    $self->{OPTION_SAVE}->configure(-state => "disabled"); 
	    $self->{OPTION_SAVEAS}->configure(-state => "disabled"); 
	    $self->{OPTION_RESET}->configure(-state => "disabled"); 
	}
    }

    return if(Exists($self->{TLWIN}));
    
    return();
}

sub build_panel {
    my($self) = shift;
    my($objname,$objref,$section,$ssection);
    my($i,$name,$tlwin);
    my $mw=$self->{MAINWINDOW};
    my $home=$ENV{HOME};
    my(%packcount,%pframe,$frame,$pack,$cluster);
    my(@clusterlist);
 
    $tlwin=$self->{TLWIN}=$mw->Toplevel(-width => $self->{WIDTH},-height => $self->{HEIGHT});
    $tlwin->title("LLview: Option panel");

    $tlwin->bind('<Control-KeyPress-o>' => [ \&toggle_option_panel ]);
    $tlwin->bind('<Control-KeyPress-q>' => [ \&toggle_option_panel ]);
    $tlwin->bind('<Control-KeyPress-s>' => sub {&save_config($self->{TOPCLUSTER});});
    $tlwin->bind('<Control-KeyPress-l>' => [ \&load_config ]);



# WF later on de
#    &deactivate_option_panel();
#    $tlwin->raise();
    $self->{ACTIVATED} = 1;


    my $nb = $tlwin->NoteBook(qw/-ipadx 6 -ipady 6/)->pack;

    $self->{PANEL_NOTEBOOK}=$nb;
    if($self->{MULTICLUSTER}) {
	# - book for general settings about clusters
	foreach $cluster (@{$self->{CLUSTERS}},"-") {
	    $self->{PANEL_CLUSTERS}->{$cluster}=$nb->add( "$cluster", -label=> ($cluster eq "-")?"General":"$cluster", 
							  -underline=>0, -raisecmd => \&raisemc);
	    $self->{NB_CLUSTERS}->{$cluster}=$self->{PANEL_CLUSTERS}->{$cluster}->NoteBook(qw/-ipadx 6 -ipady 6/)->pack;
	}
	@clusterlist=(@{$self->{CLUSTERS}},"-");
    } else {
	@clusterlist=($self->{TOPCLUSTER});
	$self->{NB_CLUSTERS}->{$self->{TOPCLUSTER}}=$nb;
	$self->{PANEL_CLUSTERS}->{$self->{TOPCLUSTER}}=$tlwin;
    }

    foreach $cluster (@clusterlist) {
        foreach $section (@{$self->{SECTARRAY}->{$cluster}}) {
	    $self->{NB_SECTIONS}->{$cluster}->{$section}=$self->{NB_CLUSTERS}->{$cluster}
	                                               ->add( "$section", -label=>"$section", -underline=>0 );
	    $packcount{$cluster}->{$section}=0;
	}
	

	foreach $ssection (sort(keys(%{$self->{SUBSECTIONS}->{$cluster}}))) {
	    my($section,$subtype)=split("__",$ssection);
	    my $sesection=$section."__".$subtype;
	    if (!Exists($self->{NB_SECTIONS_NB}->{$cluster}->{$section})) {
		$self->{NB_SECTIONS_NB}->{$cluster}->{$section}=
		    $self->{NB_SECTIONS}->{$cluster}->{$section}->NoteBook(qw/-ipadx 6 -ipady 6/)
		    ->pack(-anchor => "nw");
	    }
	    if(!Exists($self->{NB_SECTIONS}->{$cluster}->{$sesection})) {
		$self->{NB_SECTIONS}->{$cluster}->{$sesection}=$self->{NB_SECTIONS_NB}->{$cluster}->{$section}->add(
								    "$subtype", 
								    -label=>"  ${subtype}  ", 
								    -raisecmd => [ \&raisessection,$cluster,$section],
								    -underline=>2);
		$packcount{$cluster}->{$ssection}=0;
	    }
	}
    }


    foreach $objname (@{$self->{OPTOBJECTS}}) {
	my($cluster,$section,$name,$subsection)=split("__",$objname);
	$objref=$self->{OBJECTS}->{$objname};
	print "#	build option -> $objname() ($cluster,$section,$name,$subsection)\n"  if($debug>=3);
	$section.="__".$subsection if($subsection);
	$pack=1;
	$pack=$objref->{-pack} if(exists($objref->{-pack}));

	if($pack==1) {
	    # new frame
	    $pframe{$cluster}->{$section}=$self->{NB_SECTIONS}
	                                 ->{$cluster}->{$section}->Frame( 
									-relief => "sunken", 
									-borderwidth => 1)->pack(-side => "top", 
												 -anchor =>"w");
	    $packcount{$cluster}->{$section}=0;
	} else {
	    if(($packcount{$cluster}->{$section}>=$pack) || (!Exists($pframe{$cluster}->{$section}))) {
		$pframe{$cluster}->{$section}=$self->{NB_SECTIONS}
		                         ->{$cluster}->{$section}->Frame( 
									-relief => "sunken", 
									-borderwidth => 1)->pack(-side => "top", 
												 -anchor =>"w");
		$packcount{$cluster}->{$section}=0;
	    }
	}


	$packcount{$cluster}->{$section}++;
	if($objref->{-type} ne "comment") {
	    $frame=$pframe{$cluster}->{$section}->Frame( -relief => "sunken", 
							 -borderwidth => 1)->pack(-side => "left",-anchor =>"w");
	    my $labelwidth=15;
	    $labelwidth=$objref->{-labelwidth} if(exists($objref->{-labelwidth}));
	    $self->{LABELOBJ}->{$objname}=$frame->Label(-text => "".$objref->{-label}, -anchor => "w", 
							-width=>$labelwidth)->pack(-side => "left");
	} else {
	    $frame=$pframe{$cluster}->{$section}->Frame(  -relief => "flat", -borderwidth => 0)->pack(-side => "left");
	}

	# integer field
	if($objref->{-type} eq "int") {
	    my $step=$objref->{-step};
	    my $min=$objref->{-min};
	    my $max=$objref->{-max};
	    $min=-1e20 if(!defined($min));
	    $max= 1e20 if(!defined($max));
	    my $field=$frame->Entry(-textvariable => \$self->{VALOBJ}->{$objname},
				    -validate        => 'key',
				    -validatecommand => sub {
					my ($proposed, $changes, $current, $index, $type) = @_;
					return(1) if($self->{BUILDREADY}==0); # not before building panel
#					print "WF: proposed='$proposed' $min $max\n";
					if( ($proposed =~ m/^[+-]?[\d]+$/g)  
					    && ($proposed>=$min)
					    && ($proposed<=$max))  {
					    $self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					    $self->{MARKEDLABELOBJS}->{$objname}=1;
					    return 1;
					} else {
					    return 0 ;
					}
				    },
				    -width => 6,
				    )->pack(-expand => "yes",-side => "left");
	    $field->bind( "<Key-Return>" => [\&valchanged, "$objname"] );
	    $field->bind( "<FocusOut>" => [\&valchanged, "$objname"] );
	    $field->bind( "<Key-Up>" => sub {$self->{VALOBJ}->{$objname}+=1 if($self->{VALOBJ}->{$objname}<=($max+1)); 
					     &valchanged(undef,$objname);} );
	    $field->bind( "<Key-Down>" => sub {$self->{VALOBJ}->{$objname}-=1; 
					     &valchanged(undef,$objname);} );
	    $field->bind( "<Key-Prior>" => sub {$self->{VALOBJ}->{$objname}+=$step if($self->{VALOBJ}->{$objname}<=($max+$step));
						&valchanged(undef,$objname);} );
	    $field->bind( "<Key-Next>" => sub {$self->{VALOBJ}->{$objname}-=$step; 
					     &valchanged(undef,$objname);} );
	    if($self->{SHOWPM}) {
		my $framepm=$frame->Frame()->pack(-side => "left");
		my $but1=$framepm->Button(-text => "+",
					  -width=>1,-height=>1,
					  -command => sub {
					      $self->{VALOBJ}->{$objname}+=$step; 
					      &valchanged(undef,$objname);
					  },
					  -font => $self->{FONT0}
					  )->pack(-side => "left");
		my $but2=$framepm->Button(-text => "-",
					  -command => sub {
					      $self->{VALOBJ}->{$objname}-=$self->{OBJECTS}->{$objname}->{-step}; 
					      &valchanged(undef,$objname);
					  },
					  -font => $self->{FONT0}
					  )->pack(-side => "left", -fill => "none", -padx => 0, -pady => 0);
	    }
	}
	
	# small integer field
	if($objref->{-type} eq "smallint") {
	    my $step=$objref->{-step};
	    my $field=$frame->Entry(-textvariable => \$self->{VALOBJ}->{$objname},
				    -validate        => 'key',
				    -validatecommand => sub {
					my ($proposed, $changes, $current, $index, $type) = @_;
					return(1) if($self->{BUILDREADY}==0); # not before building panel
					if($proposed =~ m/^[+-]?[\d]+$/g)  {
					    $self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					    $self->{MARKEDLABELOBJS}->{$objname}=1;
					    return 1;
					} else {
					    return 0 ;
					}
				    },
				    -width => 6,
				    )->pack(-expand => "yes",-side => "left");
	    $field->bind( "<Key-Return>" => [\&valchanged, "$objname"] );
	    $field->bind( "<FocusOut>" => [\&valchanged, "$objname"] );
	    $field->bind( "<Key-Up>" => sub {$self->{VALOBJ}->{$objname}+=1; 
					     &valchanged(undef,$objname);} );
	    $field->bind( "<Key-Down>" => sub {$self->{VALOBJ}->{$objname}-=1; 
					     &valchanged(undef,$objname);} );
	    $field->bind( "<Key-Prior>" => sub {$self->{VALOBJ}->{$objname}+=$step; 
					     &valchanged(undef,$objname);} );
	    $field->bind( "<Key-Next>" => sub {$self->{VALOBJ}->{$objname}-=$step; 
					     &valchanged(undef,$objname);} );
	}
	# scrollbar integer or real
	if(($objref->{-type} eq "intscale") || ($objref->{-type} eq "realscale"))  {
	    my $step=$objref->{-step};
	    my $field=$frame->Entry(-textvariable => \$self->{VALOBJ}->{$objname},
				    -validate        => 'key',
				    -validatecommand => sub {
					my ($proposed, $changes, $current, $index, $type) = @_;
					return(1) if($self->{BUILDREADY}==0); # not before building panel
					if($proposed =~ m/^[+-]?[\d]+$/g)  {
					    $self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					    $self->{MARKEDLABELOBJS}->{$objname}=1;
					    return 1;
					} else {
					    return 0 ;
					}
				    },
				    -width => 6,
				    )->pack(-expand => "yes",-side => "left", -padx => 3);
	    $field->bind( "<Key-Return>" => [\&valchanged, "$objname"] );
	    $field->bind( "<FocusOut>" => [\&valchanged, "$objname"] );
	    $field->bind( "<Key-Tab>" => [\&valchanged, "$objname"] );
	    $field->bind( "<Key-Up>" => sub {$self->{VALOBJ}->{$objname}+=1; &valchanged(undef,$objname);} );
	    $field->bind( "<Key-Down>" => sub {$self->{VALOBJ}->{$objname}-=1; &valchanged(undef,$objname);} );
	    $field->bind( "<Key-Prior>" => sub {$self->{VALOBJ}->{$objname}+=$step; &valchanged(undef,$objname);} );
	    $field->bind( "<Key-Next>" => sub {$self->{VALOBJ}->{$objname}-=$step; &valchanged(undef,$objname);} );
	    my $digits=0;
	    my $resolution=1;
	    $digits=$objref->{-digits} if ($objref->{-type} eq "realscale");
	    $resolution=$objref->{-resolution} if ($objref->{-type} eq "realscale");
#	    print "$objname, digits -> $digits $resolution\n";
	    $self->{SCALE}->{$objname}=$frame->Scale(  -variable => \$self->{VALOBJ}->{$objname},
						       -from => $objref->{-min},
#						       -digits => $digits,
						       -resolution => $resolution,
						       -length => 200,
						       -width => 20,
						       -to => $objref->{-max},
						       -orient => "horizontal",
#						       -command => sub {
#							   &valchanged(undef,$objname);
#						         },
						       -font => $self->{FONT0}
						        )->pack(-side => "left");
	    
	    my $framepm=$frame->Frame()->pack(-side => "left");
	    my $but2=$framepm->Button(-text => "select",
				      -command => sub {
					  &valchanged(undef,$objname);
				      }
				      )->pack(-side => "right", -fill => "none", -padx => 0, -pady => 0);
	}
	# string entry
	if($objref->{-type} eq "string") {
	    my $fieldwidth=36;
	    $fieldwidth=$objref->{-fieldwidth} if(exists($objref->{-fieldwidth}));
	    my $field=$frame->Entry(-textvariable => \$self->{VALOBJ}->{$objname},
				    -width => $fieldwidth, 
				    -validate        => 'key',
				    -validatecommand => sub {
					my ($proposed, $changes, $current, $index, $type) = @_;
					return(1) if($self->{BUILDREADY}==0); # not before building panel
					$self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					$self->{MARKEDLABELOBJS}->{$objname}=1;
					return 1;
				    },
				    )->pack(-expand => "yes",-side => "left");
	    $field->configure(-show => $objref->{-show}) if(exists($objref->{-show}));
	    $field->bind( "<Key-Return>" => [\&valchanged, "$objname"] );
	    $field->bind( "<FocusOut>" => [\&valchanged, "$objname"] );
	}
	# file select panel
	if($objref->{-type} eq "fileselect") {
	    my $field=$frame->Entry(-textvariable => \$self->{VALOBJ}->{$objname},
				    -validate        => 'key',
				    -validatecommand => sub {
					my ($proposed, $changes, $current, $index, $type) = @_;
					return(1) if($self->{BUILDREADY}==0); # not before building panel
					$self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					$self->{MARKEDLABELOBJS}->{$objname}=1;
					return 1;
				    },
				    -width => 80,
				    )->pack(-expand => "yes",-side => "left");
	    $field->bind( "<Key-Return>" => [\&valchanged, "$objname"] );
	    $field->bind( "<FocusOut>" => [\&valchanged, "$objname"] );
	    my $filesel = $frame->Button(-text => "Select ...",
					 -command => sub {
					     $self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					     &selectfile($objname);
					 })->pack(-side => "left");
	}
	# directory select panel
	if($objref->{-type} eq "dirselect") {
	    my $field=$frame->Entry(-textvariable => \$self->{VALOBJ}->{$objname},
				    -width => 36,
				    )->pack(-expand => "yes",-side => "left");
	    $field->bind( "<Key-Return>" => [\&valchanged, "$objname"] );
	    $field->bind( "<FocusOut>" => [\&valchanged, "$objname"] );
	    my $filesel = $frame->Button(-text => "Select ...",
					 -command => sub {
					     $self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					     &selectdir($objname);
					 })->pack(-side => "left");
	}
	# radio button
	if($objref->{-type} eq "radio") {
	    my $button=$frame->Checkbutton(-text => 'on/off',
					   -variable => \$self->{VALOBJ}->{$objname},
					   -onvalue => "1",
					   -offvalue => "0",
					   -width => 13,
					   -command => sub {
					     $self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					       &valchanged(undef,$objname);
					   }
					   )->pack(-side => 'left');
	}
	# radio button group
	if($objref->{-type} eq "radiogroup") {
	    my $valuesref=$objref->{-values};
	    my $labelsref=$objref->{-labels};
	    my $side="top";
	    $side=$objref->{-side} if ($objref->{-side});
	    for($i=0;$i<=$#{$valuesref};$i++) {
		my $button=$frame->Radiobutton(-text => $labelsref->[$i],
					       -variable => \$self->{VALOBJ}->{$objname},
					       -value => $valuesref->[$i],
					       -command => sub {
						   $self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
						   $self->{MARKEDLABELOBJS}->{$objname}=1;
						   &valchanged(undef,$objname);
					       }
					       )->pack(-side => $side, -anchor => "w");
	    }
	}
	if($objref->{-type} eq "optionmenu") {
	    my $valuesref=$objref->{-values};
	    my $labelsref=$objref->{-labels};
	    my $raisenb=$objref->{-raisenb};
	    my $side="top";
	    if($raisenb) {
		$self->{RAISENB}->{$objname}=$cluster."__".$raisenb;
		$self->{NB_SECTIONS_NB}->{$cluster}->{$raisenb}->raise($self->{VALOBJ}->{$objname});
		$self->{RAISENBBACK}->{$cluster."__".$raisenb}=$objname;
	    }
	    $side=$objref->{-side} if ($objref->{-side});
	    my $button=$frame->Optionmenu(-text => $labelsref->[$i],
					  -variable => \$self->{VALOBJ}->{$objname},
					  -options => [@{$valuesref}],
					  -command => sub {
					      $self->{LABELOBJ}->{$objname}->configure(-foreground => "darkred");
					      $self->{MARKEDLABELOBJS}->{$objname}=1;
					      &valchanged(undef,$objname);
					  }
					  )->pack(-side => $side, -anchor => "w");
	}
	if($objref->{-type} eq "button") {
	    my $button=$frame->Button(-text => 'do',
				      -command => sub {
					  &buttonpressed(undef,$objname);
				      }
				      )->pack(-side => 'left');
	}

	if($objref->{-type} eq "comment") {
	    my $comment=$frame->Label(-text => "".$objref->{-text}, -justify => "center", -borderwidth => 0, -relief => "flat",
				      -anchor => "w",  -foreground => "red",
				      )->pack(-side => "left");
	}

	if($objref->{-type} eq "canvas") {
	    my $width=$objref->{-width};
	    my $height=$objref->{-height};
	    my $but2=$frame->Button(-text => "update",
				    -command => sub {
					&valchanged(undef,$objname);
				    }
				    )->pack(-side => "bottom", -anchor =>"w", -fill => "none", -padx => 0, -pady => 0);
	    $self->{CANVASOBJ}->{$objname}=$frame->Scrolled('Canvas', 
							    -scrollbars => 'oe', -relief => 'sunken', -bd => 1, 
							    -width => $width, -height => $height,
							    )->pack(-side => 'top', -expand => 1, -fill => 'both');

	}
    }



    foreach $cluster (@clusterlist) {
	my($bframe)=$self->{PANEL_CLUSTERS}->{$cluster}->Frame()->pack(-side => "top", -anchor => "center");
	$self->{BUTTON_SAVE}->{$cluster}=$bframe->Button(-text => "Save",
						       -command => sub {&save_config($cluster);})->pack(-side => "left");
	$self->{BUTTON_SAVEAS}->{$cluster}=$bframe->Button(-text => "Save As",
							 -command => sub {&save_config_as($cluster);})->pack(-side => "left");
	$self->{BUTTON_LOAD}->{$cluster}=$bframe->Button(-text => "Load",
						       -command => sub {&load_config($cluster);})->pack(-side => "left");
	$self->{BUTTON_RESET}->{$cluster}=$bframe->Button(-text => "Reset",
							-command => sub {&reset_config($cluster);})->pack(-side => "left");
	$self->{BUTTON_DEFAULT}->{$cluster}=$bframe->Button(-text => "Default",
							  -command => sub {&default_config($cluster);})->pack(-side => "left");
	$self->{WIDGET_INIFILE}->{$cluster}=$bframe->Label(-textvariable => \$self->{INIFILE}->{$cluster},
										     -justify => "right")->pack();

	# config values changed from old config file
	$self->disable_save_buttons($cluster) if($self->{UNSAVECHANGES}->{$cluster}==0);
    }
    $self->{TLWIN}->Button(-text => "Close",-command => \&deactivate_option_panel)->pack(-side => "left");

    $self->{BUILDREADY} = 1;


}

sub update_optval {
    my($self) = shift;
    my $cluster=shift;
    my $section=shift;
    my $name=shift;
    my $val=shift;
    my $objname=$cluster."__".$section."__".$name;
    $self->{VALOBJ}->{$objname}=$val;
}

sub update_optval_subsection {
    my($self) = shift;
    my $cluster=shift;
    my $section=shift;
    my $subsection=shift;
    my $name=shift;
    my $val=shift;
    my $objname=$cluster."__".$section."__".$name."__".$subsection;
    $self->{VALOBJ}->{$objname}=$val;
}

sub update_optval_direct {
    my($self) = shift;
    my $cluster=shift;
    my $section=shift;
    my $name=shift;
    my $val=shift;
    my $objname=$cluster."__".$section."__".$name;
    $self->{VALOBJ}->{$objname}=$val;
    $self->valchanged($objname);
}

sub update_optval_direct_subsection {
    my($self) = shift;
    my $cluster=shift;
    my $section=shift;
    my $subsection=shift;
    my $name=shift;
    my $val=shift;
    my $objname=$cluster."__".$section."__".$name."__".$subsection;
    $self->{VALOBJ}->{$objname}=$val;
    $self->valchanged($objname);
}

sub update_scale_minmax {
    my($self) = shift;
    my $cluster=shift;
    my $section=shift;
    my $name=shift;
    my $min=shift;
    my $max=shift;
    my $objname=$cluster."__".$section."__".$name;
    if(Exists($self->{SCALE}->{$objname})) {
	$self->{SCALE}->{$objname}->configure(-from => $min, -to => $max);
    }
}

sub valchanged {
    my($widget,$objname)=@_;
    my $self=$$selfref;
    my ($key);
    my $objref=$self->{OBJECTS}->{$objname};
    my($cluster,$section,$name,$subtype)=split("__",$objname);
    $key=$section;
    $key.="__".$subtype if($subtype);

    # set color to blue if there was a modification in this field before
    $self->{LABELOBJ}->{$objname}->configure(-foreground => "blue") if($self->{MARKEDLABELOBJS}->{$objname});

    print "options: valchanged $objname ($cluster) ($key) $self->{VALOBJ}->{$objname}\n"  if($debug<=3);
    $self->enable_save_buttons($cluster) if($self->{UNSAVECHANGES}->{$cluster}==0);

    $self->{UNSAVECHANGES}->{$cluster}++;
    
    $self->{INIFILEOBJ}->{$cluster}->setval($key,$name,$self->{VALOBJ}->{$objname});
    $objref->{-caller}->optvalchanged($section,$name,$self->{VALOBJ}->{$objname},$subtype,$cluster);

    if($self->{RAISENB}->{$objname}) {
	my($rcluster,$rsection)=split(/__/,$self->{RAISENB}->{$objname});
	$self->{NB_SECTIONS_NB}->{$rcluster}->{$rsection}->raise($self->{VALOBJ}->{$objname});
    }
    
    if($objref->{-updatereq}) {
	if($self->{CALLER}) {
	    $self->{CALLER}->direct_update_no_timer();
	}
    }
}

sub buttonpressed {
    my($widget,$objname)=@_;
    my $self=$$selfref;
    my $objref=$self->{OBJECTS}->{$objname};
    my($cluster,$section,$name)=split("__",$objname);
    print "options: buttonpressed $objname\n"  if($debug>=3);
    $objref->{-caller}->optvalchanged($section,$name,$self->{VALOBJ}->{$objname});
    if($objref->{-updatereq}) {
	if($self->{CALLER}) {
	    $self->{CALLER}->direct_update_no_timer();
	}
    }
}

sub selectfile {
    my($objname)=@_;
    my $self=$$selfref;
    my $file;
    my $dir=$self->{VALOBJ}->{$objname};
    print "WF: $objname,$dir\n"  if($debug>=3);
    $dir=~s/^~/$ENV{HOME}/se;
    $dir=~s/[^\/]*$//gs;
    $dir=abs_path($dir);
    if(!$self->{FILESELECTWIDGET}->{$objname}) {
	$self->{FILESELECTWIDGET}->{$objname} = $self->{TLWIN}->FileSelect(-width => 40, -width => 60 );
    }

    $file=$self->{FILESELECTWIDGET}
      ->{$objname}->configure(-directory =>$dir);
    $file=$self->{FILESELECTWIDGET}->{$objname}->Show();
    $self->{VALOBJ}->{$objname}=$file if($file);
    &valchanged(undef,$objname);

}

sub selectdir {
    my($objname)=@_;
    my $self=$$selfref;
    my $file;
    my $dir=$self->{VALOBJ}->{$objname};
    print "WF: $objname,$dir\n"  if($debug>=0);
    $dir=~s/[^\/]*$//gs;
    $dir=~s/^~/$ENV{HOME}/s;
    $dir=abs_path($dir);
    if(!$self->{FILESELECTWIDGET}->{$objname}) {
	$self->{FILESELECTWIDGET}->{$objname} = $self->{TLWIN}->FileSelect(-verify => ['-d']);
    }

    $file=$self->{FILESELECTWIDGET}
      ->{$objname}->configure(-directory =>$dir);
    $file=$self->{FILESELECTWIDGET}->{$objname}->Show();
    $self->{VALOBJ}->{$objname}=$file if($file);
    &valchanged(undef,$objname);

}

sub activate_option_panel {
    my $self=$$selfref;
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my $canvas=$self->{CANVAS};
    
    print "LLview_gui_options: activate_option_panel,",Exists($self->{TLWIN})," \n" if($debug>=3);
    if(!Exists($self->{TLWIN})) {
	$self->build_panel();
    }
    $self->{TLWIN}->deiconify();
#    has negative effects: reset window size to short window ...
#    $self->{TLWIN}->raise();
    $self->{ACTIVATED} = 1;
   
}

sub deactivate_option_panel {
    my $self=$$selfref;
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    $self->{TLWIN}->withdraw();
    $self->{ACTIVATED} = 0;
}

sub toggle_option_panel {
    my $self=$$selfref;
    if(($self->{ACTIVATED}) && (Exists($self->{TLWIN}))) {
	&deactivate_option_panel();
    } else {
	&activate_option_panel();
    }
}

sub set_cluster {
    my $self = shift;
    $self->{LASTCLUSTER}=shift;
}

sub register_cluster {
    my $self = shift;
    my $cluster=shift;
    my $prefix=shift;
    push(@{$self->{CLUSTERS}},$cluster);
    ($self->{DEFAULTFILE}->{$cluster},
     $self->{INIFILE}->{$cluster},
     $self->{DEFAULTFILEOBJ}->{$cluster},
     $self->{INIFILEOBJ}->{$cluster},
     $self->{UNSAVECHANGES}->{$cluster})=$self->set_config_file("","llview_$prefix.rc");
}


sub register_caller {
    my $self = shift;
    $self->{CALLER}=shift;
}


# register_option(<section>,<name>,
#   -label    => "label",
#   -type     => "type",
#   -caller   => objref, ...
#   -subtype  => num, ...
#    )
sub register_option {
    my $self = shift;
    my $section=shift;
    my $name=shift;
    my %parms=(@_);
    my $cluster=$self->{LASTCLUSTER};
    my $myname=$cluster."__".$section."__".$name;
    my $key=$section;
    if($parms{"-subtype"}) {
#	print "register_option: $myname subtype -> $parms{-subtype}\n";
	$key=$section."__".$parms{"-subtype"};
	$self->{SUBSECTIONS}->{$cluster}->{$key}++;
	$myname.="__".$parms{"-subtype"};
    }
    
    $self->{SECTIONS}->{$cluster}->{$section}++;
    push(@{$self->{SECTARRAY}->{$cluster}},$section) if($self->{SECTIONS}->{$cluster}->{$section}==1);
    push(@{$self->{OPTOBJECTS}},$myname);
    $self->{OBJECTS}->{$myname}=\%parms;
    my $objref=$self->{OBJECTS}->{$myname};

#    print "WF: register_option $myname >$key< >$name< >$cluster<\n";
    if(defined($self->{INIFILEOBJ}->{$cluster}->val($key,$name))) {
	$self->{VALOBJ}->{$myname}=$self->{INIFILEOBJ}->{$cluster}->val($key,$name);
	$objref->{-caller}->optvalchanged($section,$name,$self->{VALOBJ}->{$myname},$parms{"-subtype"},$cluster);
    } elsif(defined($self->{DEFAULTFILEOBJ}->{$cluster}->val($key,$name))) {
	$self->{VALOBJ}->{$myname}=$self->{DEFAULTFILEOBJ}->{$cluster}->val($key,$name);
	$objref->{-caller}->optvalchanged($section,$name,$self->{VALOBJ}->{$myname},$parms{"-subtype"},$cluster);
    } else {
	if(defined($objref->{-default})) {
	    $self->{VALOBJ}->{$myname}=$objref->{-default};
	} else {
	    print "register_option: no default value for $myname($key,$name)\n";
	}
    }
    if(!defined($self->{INIFILEOBJ}->{$cluster}->val($key,$name))) {
	    $self->{INIFILEOBJ}->{$cluster}->newval($key,$name,$self->{VALOBJ}->{$myname});
#	    $self->{INIFILEOBJ}->setval($key,$name,$self->{VALOBJ}->{$myname});
    }
    return(1);
}

sub get_canvas_obj {
    my $self = shift;
    my $section=shift;
    my $name=shift;
    my %parms=(@_);
    my $cluster=$self->{LASTCLUSTER};
    my $myname=$cluster."__".$section."__".$name;
    if($parms{"-subtype"}) {
	$myname.="__".$parms{"-subtype"};
    }
#    print "WF: get_canvas_obj >$myname< >$name<\n";
    return($self->{CANVASOBJ}->{$myname});
}

sub register_comment {
    my $self = shift;
    my $section=shift;
    my $name=shift;
    my %parms=(@_);
    my $cluster=$self->{LASTCLUSTER};
    my $myname=$cluster."__".$section."__".$name;
    my $key=$section;
    
    $self->{SECTIONS}->{$cluster}->{$section}++;
    push(@{$self->{SECTARRAY}->{$cluster}},$section) if($self->{SECTIONS}->{$cluster}->{$section}==1);
    push(@{$self->{OPTOBJECTS}},$myname);
    $self->{OBJECTS}->{$myname}=\%parms;
    my $objref=$self->{OBJECTS}->{$myname};

    return(1);
}

sub enable_save_buttons {
    my $self = shift;
    my $cluster = shift;
#    print "WF: enable_save_buttons $cluster\n";
    return if (!Exists($self->{BUTTON_SAVE}->{$cluster}));
    $self->{BUTTON_SAVE}->{$cluster}->configure(-state => "active"); 
    $self->{BUTTON_SAVEAS}->{$cluster}->configure(-state => "active"); 
    $self->{BUTTON_RESET}->{$cluster}->configure(-state => "active"); 
    if(!$self->{MULTICLUSTER}) {
	$self->{OPTION_SAVE}->configure(-state => "active"); 
	$self->{OPTION_SAVEAS}->configure(-state => "active"); 
	$self->{OPTION_RESET}->configure(-state => "active"); 
    }
}

sub disable_save_buttons {
    my $self = shift;
    my $cluster = shift;
    return if (!Exists($self->{BUTTON_SAVE}->{$cluster}));
    $self->{BUTTON_SAVE}->{$cluster}->configure(-state => "disabled"); 
    $self->{BUTTON_SAVEAS}->{$cluster}->configure(-state => "disabled"); 
    $self->{BUTTON_RESET}->{$cluster}->configure(-state => "disabled"); 
    if(!$self->{MULTICLUSTER}) {
	$self->{OPTION_SAVE}->configure(-state => "disabled"); 
	$self->{OPTION_SAVEAS}->configure(-state => "disabled"); 
	$self->{OPTION_RESET}->configure(-state => "disabled"); 
    }
}

sub raisemc {
    my $self=$$selfref;
    my $cluster=$self->{PANEL_NOTEBOOK}->raised();
#    print "WF: Cluster $cluster is raised\n";
}

sub raisessection {
    my $self=$$selfref;
    my ($cluster,$section)=@_;
    my $subtype=$self->{NB_SECTIONS_NB}->{$cluster}->{$section}->raised();
    if($self->{RAISENBBACK}->{$cluster."__".$section}) {
	my $objname=$self->{RAISENBBACK}->{$cluster."__".$section};
#	print "WF: raisessection Cluster $cluster section $section $subtype is raised -> $objname\n";
	$self->update_optval_direct(split(/__/,$objname),$subtype);
    }
}


sub reset_label_marker {
    my $self= shift;
    my ($cluster)=@_;
    my($objname);
    foreach $objname (keys(%{$self->{MARKEDLABELOBJS}})) {
#	print "WF: reset $objname\n";
	$self->{LABELOBJ}->{$objname}->configure(-foreground => "black");
	delete($self->{MARKEDLABELOBJS}->{$objname});
    }
}

sub save_config {
    my $self=$$selfref;
    my $cluster = shift || $self->{TOPCLUSTER};
#    print "WF: $cluster\n";
    print "save_config: cluster=$cluster pwd=",abs_path(".")," fn=",$self->{INIFILEOBJ}->{$cluster}->{cf},"\n";
    if($debug>=3) {
	my ($section,$key,$val);
	foreach $section ($self->{INIFILEOBJ}->{$cluster}->Sections()) {
	    foreach $key ($self->{INIFILEOBJ}->{$cluster}->Parameters($section)) {
		printf("WF: %-20s %-20s: %s\n",$section,$key,$self->{INIFILEOBJ}->{$cluster}->val($section,$key));
	    }
	}

    }
    $self->{INIFILEOBJ}->{$cluster}->RewriteConfig();
    $self->disable_save_buttons($cluster);
    $self->{UNSAVECHANGES}->{$cluster} = 0;
    $self->reset_label_marker($cluster);
}

sub reset_to_userconfig {
    my $self=$$selfref;
    my $cluster=shift;
    $self->{INIFILEOBJ}->{$cluster}->RewriteConfig();
    $self->disable_save_buttons();
    $self->{UNSAVECHANGES}->{$cluster} = 0;
}

sub save_config_as {
    my $self=$$selfref;
    my $cluster=shift || $self->{LASTCLUSTER};
    my ($file,$dir);
    my $objname="saveas";
    $dir=$self->{INIFILE}->{$cluster};
    $dir=~s/[^\/]*$//gs;
    $dir=abs_path($dir);

    if(!$self->{FILESELECTWIDGET}->{$objname}) {
	$self->{FILESELECTWIDGET}->{$objname} = $self->{TLWIN}->FileSelect();
    }
    $file=$self->{FILESELECTWIDGET}->{$objname}->configure(-dirlabel => "Save Config File: Directory",
							   -directory =>$dir,
							   -defaultextension => "rc");
    $file=$self->{FILESELECTWIDGET}->{$objname}->Show();

    if($file) {
	$self->{INIFILE}->{$cluster}=$file;
	$self->{INIFILEOBJ}->{$cluster}->WriteConfig($file);
	$self->disable_save_buttons($cluster);
	$self->{UNSAVECHANGES}->{$cluster} = 0;
    }
}

sub load_config {
    my $self=$$selfref;
    my $cluster=shift;
    my ($file,$dir,$section,$ssection,$subtype,$parameter,$value);
    my $objname="load";
    $dir=$self->{INIFILE}->{$cluster}; $dir=~s/[^\/]*$//gs; $dir=abs_path($dir);

    if(!$self->{FILESELECTWIDGET}->{$objname}) {
	$self->{FILESELECTWIDGET}->{$objname} = $self->{MAINWINDOW}->FileSelect();
    }
    $file=$self->{FILESELECTWIDGET}->{$objname}->configure(-dirlabel => "Load Config File: Directory",
							   -directory =>$dir,
							   -defaultextension => "rc");
    $file=$self->{FILESELECTWIDGET}->{$objname}->Show();

    if($file) {
	$self->{INIFILE}->{$cluster}=$file;
	$self->{INIFILEOBJ}->{$cluster}->SetFileName($file);
	$self->{INIFILEOBJ}->{$cluster}->ReadConfig();
	$self->disable_save_buttons($cluster);
	$self->{UNSAVECHANGES}->{$cluster} = 0;
	foreach $objname (keys(%{$self->{VALOBJ}})) {
	    my($mcluster,$section,$name,$subtype)=split("__",$objname);
	    next if ($mcluster ne $cluster);
	    my $key=$section;
	    my $objref=$self->{OBJECTS}->{$objname};
	    $key.="__".$subtype if($subtype);
	    $value=$self->{INIFILEOBJ}->{$cluster}->val($key,$name);
	    if(defined($value)) {
		if($value ne $self->{VALOBJ}->{$objname}) {
		    printf("WF: reset value of %-40s -> %s (%s)\n",$objname,$value,$self->{VALOBJ}->{$objname}) if($self->{VERBOSE});
		    $self->{VALOBJ}->{$objname}=$value;
		    $objref->{-caller}->optvalchanged($section,$name,$self->{VALOBJ}->{$objname},$subtype,$cluster);
		}
	    } else {
		printf("WF: set inifile value of %-40s -> %s \n",$objname,$self->{VALOBJ}->{$objname})   if($self->{VERBOSE});
		$self->{INIFILEOBJ}->{$cluster}->newval($key,$name,$self->{VALOBJ}->{$objname});
		$self->enable_save_buttons($cluster) if($self->{UNSAVECHANGES}->{$cluster}==0);
		$self->{UNSAVECHANGES}->{$cluster}++;
	    }
	}
    }
}

sub reset_config {
    my $self=$$selfref;
    my ($file,$dir,$section,$ssection,$subtype,$parameter,$value);
    my $objname;
    my $cluster=shift;
    $self->{INIFILEOBJ}->{$cluster}->ReadConfig();
    $self->disable_save_buttons($cluster);
    $self->{UNSAVECHANGES}->{$cluster} = 0;
    foreach $objname (keys(%{$self->{VALOBJ}})) {
	my($mcluster,$section,$name,$subtype)=split("__",$objname);
	next if ($mcluster ne $cluster);
	my $key=$section;
	my $objref=$self->{OBJECTS}->{$objname};
	$key.="__".$subtype if($subtype);
	$value=$self->{INIFILEOBJ}->{$cluster}->val($key,$name);
	if(defined($value)) {
	    if($value ne $self->{VALOBJ}->{$objname}) {
		printf("WF: reset value of %-40s -> %s (%s)\n",$objname,$value,$self->{VALOBJ}->{$objname})   if($self->{VERBOSE});
		$self->{VALOBJ}->{$objname}=$value;
		$objref->{-caller}->optvalchanged($section,$name,$self->{VALOBJ}->{$objname},$subtype,$cluster);
	    }
	} else {
	    printf("WF: set inifile value of %-40s -> %s \n",$objname,$self->{VALOBJ}->{$objname})   if($self->{VERBOSE});
	    $self->{INIFILEOBJ}->{$cluster}->newval($key,$name,$self->{VALOBJ}->{$objname});
	    $self->enable_save_buttons($cluster) if($self->{UNSAVECHANGES}->{$cluster}==0);
	    $self->{UNSAVECHANGES}->{$cluster}++;
	}
    }
}

sub default_config {
    my $self=$$selfref;
    my ($file,$dir,$section,$ssection,$subtype,$parameter,$value,$value2);
    my $objname;
    my $cluster=shift;
    $self->{DEFAULTFILEOBJ}->{$cluster}->ReadConfig();
    $self->disable_save_buttons($cluster);
    $self->{UNSAVECHANGES}->{$cluster} = 0;
    foreach $objname (keys(%{$self->{VALOBJ}})) {
	my($mcluster,$section,$name,$subtype)=split("__",$objname);
	next if ($mcluster ne $cluster);
	my $key=$section;
	my $objref=$self->{OBJECTS}->{$objname};
	$key.="__".$subtype if($subtype);
	$value=$self->{DEFAULTFILEOBJ}->{$cluster}->val($key,$name);
	$value2=$self->{INIFILEOBJ}->{$cluster}->val($key,$name);
	if(defined($value)) {
	    if($value ne $self->{VALOBJ}->{$objname}) {
		printf("WF: reset value of %-40s -> %s (%s)\n",$objname,$value,$self->{VALOBJ}->{$objname})   if($self->{VERBOSE});
		$self->{VALOBJ}->{$objname}=$value;
		$objref->{-caller}->optvalchanged($section,$name,$self->{VALOBJ}->{$objname},$subtype,$cluster);
		if(defined($value2)) {
		    if($value2 ne $self->{VALOBJ}->{$objname}) {
			printf("WF: set inifile value of %-40s -> %s \n",$objname,$self->{VALOBJ}->{$objname})   if($self->{VERBOSE});
			$self->{INIFILEOBJ}->{$cluster}->setval($key,$name,$self->{VALOBJ}->{$objname});
			$self->{UNSAVECHANGES}->{$cluster}++;
		    }
		} else {
		    printf("WF: set new inifile value of %-40s -> %s \n",$objname,$self->{VALOBJ}->{$objname})   if($self->{VERBOSE});
		    $self->{INIFILEOBJ}->{$cluster}->newval($key,$name,$self->{VALOBJ}->{$objname});
		    $self->enable_save_buttons($cluster) if($self->{UNSAVECHANGES}->{$cluster}==0);
		    $self->{UNSAVECHANGES}->{$cluster}++;
		}
	    }
	}
    }
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}




1;
