# $Source: /cvs/cvsroot/llview/lib/LLview_gui_scalahist.pm,v $
# $Author: zdv087 $
# $Revision: 1.38 $
# $Date: 2007/04/17 13:13:45 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_scalahist;
use strict;
use LLview_manage_colors;
use LLview_parse_xml;
use Time::Local;
use Cwd 'abs_path';
my($debug)=0;

my($selfref)=-1;

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_gui_scalahist: new %s\n",ref($proto)) if($debug>=3);
    $self->{VERBOSE}=1;
    $self->{HAVEINFOMSG} = 0;
#    $self->{POSXSCALA} = "left";
    $self->{POSXSCALA} = "right";
    $self->{POSX}      = 0;
    $self->{POSY}      = 0;
    $self->{WIDTH}     = 900;
    $self->{WIDTHSCALA} = 30;
    $self->{WIDTHREG}  = 800-$self->{WIDTHSCALA};
    $self->{POSXREG}   = $self->{WIDTHSCALA};
    $self->{HEIGHT}    = 800;
    $self->{MAXCOLS}   = 100;
    $self->{TAGCNT}    = 0;
    $self->{NUMCOLS}   = 0;
    $self->{MINCPUS}   = 16;
    $self->{MINCPUSCOLOR}   = "grey55";
    $self->{FREECPUSCOLOR}   = "white";
    $self->{BACKGROUNDCOLOR} = "grey80";
    $self->{PART}   = 40;
    $self->{DATA}          = [];
    $self->{DATA_TIMESTEP} = [];

    $self->{SHOWDAYSTEP}=$self->{MAXCOLS}/2;
    $self->{SHOWHOURSTEP}=5;
    $self->{SHOWMINSTEP}=2;

    $self->{UPDATESTEP} = 5;
    $self->{LASTUPDATESEC}=-1;
    $self->{DOGAP} = 1;

    $self->{LASTSHOWDAY}=0;
    $self->{LASTSHOWHOUR}=0;
    $self->{LASTSHOWMIN}=0;

    $self->{CLEANALL}=0;
    $self->{PRINTPS}=0;

    $self->{HISTFILE}="";
    $self->{READHISTFILE}=0;
    $self->{READHISTFROM}=0.0;
    $self->{ITEMTEXT}="<no info>";

    $self->{ITEMS}   = [];
    $self->{NODEIDS} = [];
    $self->{FIXEDITEMS} = [];

    $self->{LASTHTAG}="-";

    $self->{MAINWIN}=undef;

    $self->{BUILDREADY}=0;
    $self->{BUILDFIXEDREADY}=0;

    $self->{FONT1}       = "-*-Courier-Medium-R-Normal--*-100-*-*-*-*-*-*";
    $self->{BFONT1}      = "-*-Courier-Bold-R-Normal--*-100-*-*-*-*-*-*";

    bless $self, $class;
    if($selfref==-1)  {
	$selfref=\$self;
    } else {
	printf("WARNING: double constructor call to LLview_gui_scalahist ...\n")
    }
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($marker);

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;
    $marker="History";

#    return;
    
    $optobj->register_option($marker,"POSX", -label => "posx", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSX}, -step => 10);

    $optobj->register_option($marker,"POSY", -label => "posy", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSY}, -step => 10);

    $optobj->register_option($marker,"HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 1200, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option($marker,"WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option($marker,"MINCPUS", -label => "Min. CPUs", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 0, -max => 256, -default => $self->{MINCPUS}, -step => 1);

    $optobj->register_option($marker,"MINCPUSCOLOR", -label => "Color of Min. CPUs", 
			     -caller => $self,-pack => 2, -min => 0, -max => 256,
			     -type => "string", -default => $self->{MINCPUSCOLOR});

    $optobj->register_option($marker,"PART", -label => "Part in %", 
			     -caller => $self,-pack => 1, -min => 0, -max => 256,
			     -type => "int", -default => $self->{PART}, -step => 10);

    $optobj->register_option($marker,"DOGAP", -label => "Generate Gap", 
			     -caller => $self,-pack => 2, -min => 0, -max => 256,
			     -type => "radio", -default => $self->{DOGAP});

    $optobj->register_option($marker,"SHOWDAYSTEP", -label => "DAY STEP", 
			     -caller => $self,-pack => 1,
			     -type => "smallint", -min => 0, -max => 256, -default => $self->{SHOWDAYSTEP}, -step => 1);
    $optobj->register_option($marker,"SHOWHOURSTEP", -label => "HOUR STEP", 
			     -caller => $self,-pack => 2,
			     -type => "smallint", -min => 0, -max => 256, -default => $self->{SHOWHOURSTEP}, -step => 1);
    $optobj->register_option($marker,"SHOWMINSTEP", -label => "MIN STEP", 
			     -caller => $self,-pack => 3,
			     -type => "smallint", -min => 0, -max => 256, -default => $self->{SHOWMINSTEP}, -step => 1);

    $optobj->register_option($marker,"Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option($marker,"BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT1});

    $optobj->register_option($marker,"CLEANALL", -label => "Reset Display", 
			     -caller => $self,-pack => 1,
			     -type => "button", -default => $self->{CLEANALL});

    $optobj->register_option($marker,"PRINTPS", -label => "Print PostScript", 
			     -caller => $self,-pack => 2,
			     -type => "button", -default => $self->{PRINTPS});

    $optobj->register_option($marker,"MAXCOLS", -label => "max cols", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 0, -max => 400, -default => $self->{MAXCOLS}, -step => 10);

    $optobj->register_option($marker,"UPDATESTEP", -label => "Update Step (min)", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 256, -default => $self->{UPDATESTEP}, -step => 1);

    $optobj->register_option($marker,"HISTFILE", -label => "History data file", 
			     -caller => $self,-pack => 1,
			     -type => "fileselect", -default => $self->{HISTFILE});

    $optobj->register_option($marker,"READHISTFILE", -label => "READHISTFILE", 
			     -caller => $self,-pack => 2,
			     -type => "button", -default => $self->{READHISTFILE});

    $optobj->register_option($marker,"READHISTFROM", -label => "from time (h)", 
			     -caller => $self,-pack => 1,
			     -type => "realscale", -min => 0, -max => 24, -digits => 2, -resolution => 0.2, 
			     -default => $self->{UPDATESTEP}, -step => 1);

    $self->{BUILDREADY}=1;
    return();
}


sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id);
    print "scala_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY})\n" if($self->{VERBOSE});
    if(($name eq "HEIGHT") || ($name eq "WIDTH")) {
	$self->{$name}=$val;
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
    }
    if( ($name eq "POSX") || ($name eq "POSY")) {
	$diffx=$diffy=0;
	$diffx=$val-$self->{$name} if ($name eq "POSX");
	$diffy=$val-$self->{$name} if ($name eq "POSY");
	$self->{$name}=$val;
	foreach $id (@{$self->{FIXEDITEMS}}) {
	    $self->{CANVAS}->move($id,$diffx,$diffy)  if ($self->{BUILDREADY});
	}
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
    }
    if ($name eq "Font") {
	$self->{FONT1}=$val;
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
    }
    if ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
    }

    if(($name eq "MINCPUS") || ($name eq "MINCPUSCOLOR")) {
	$self->{$name}=$val;
    } 

    if(($name eq "PART") || ($name eq "MAXCOLS")) {
	$self->{$name}=$val;
    } 

    if(($name eq "UPDATESTEP") || ($name eq "DOGAP") || ($name eq "HISTFILE" )|| ($name eq "READHISTFROM" ) ) {
	$self->{$name}=$val;
    } 

    if(($name eq "SHOWDAYSTEP") || ($name eq "SHOWHOURSTEP") || ($name eq "SHOWMINSTEP")) {
	$self->{$name}=$val;
    } 

    if($name eq "CLEANALL") {
	if ($self->{BUILDREADY}) {
	    $self->cleanall();
	}
    } 

    if($name eq "PRINTPS") {
	if ($self->{BUILDREADY}) {
	    my $lastdata=$self->{DATA}[$#{$self->{DATA}}];
	    my ($filename_temp,$filename);
	    if($lastdata) {
		$filename=sprintf("llview_history_%02d.%02d.%02d.ps",$lastdata->{DATE}[0],
				  $lastdata->{DATE}[1],
				  $lastdata->{DATE}[2]);
	    } else {
		$filename="llview_history.ps_temp";
	    }	
	    $filename_temp=$filename."_temp";
	    print "printing Postscript File $filename\n";
	    $self->{CANVAS}->postscript(-file => $filename_temp,
					-pageheight => 750,
					-pagewidth => 500,
					-rotate => 1);
	    open(IN,$filename_temp);
	    open(OUT,"> $filename");
	    while(<IN>) {
		s/Courier findfont 4/Courier findfont 14/gs;
		s/Courier-Bold findfont 4/Courier-Bold findfont 14/gs;
		print OUT $_;
	    }
	    close(IN);
	    close(OUT);
	    unlink($filename_temp);
	}
    }

    if($name eq "READHISTFILE") {
	if ($self->{BUILDREADY}) {
	    if($self->{MAINWIN}) {
		$self->{MAINWIN}->raisenotebookpage("History");
	    }
	    $self->readhistfile();
	}
    } 

}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name);
    my $frames=$dataobj->{FRAMES};

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    my $startx;
    if($self->{POSXSCALA}=~/left/i) {
	$startx            = 0;
	$self->{POSXREG}   = $self->{WIDTHSCALA};
    } else {
	$startx=$self->{POSX}+$self->{WIDTH}-$self->{WIDTHSCALA};
	$self->{POSXREG}   = 0;
    }
    my $starty=$self->{POSY};
    my $deltax=$self->{WIDTHSCALA};
    my $deltay=$self->{HEIGHT}/$frames;

    $id=$canvas->createRectangle($self->{POSX},$self->yinv($self->{POSY}),
				 $self->{WIDTH},$self->yinv($self->{HEIGHT}), -fill => $self->{BACKGROUNDCOLOR});
    push(@{$self->{FIXEDITEMS}},$id);

    for($i=1;$i<=$frames;$i++) {
	$id=$canvas->createRectangle($startx,$self->yinv($starty),$startx+$deltax,$self->yinv($starty+$deltay), -fill => "grey90");
	push(@{$self->{FIXEDITEMS}},$id);
	$name=sprintf("% 2d",$i);
	$id=$canvas->createText($startx+0.5*$deltax,$self->yinv($starty+0.5*$deltay),-text => $name, -font => $self->{FONT1});
	push(@{$self->{FIXEDITEMS}},$id);

	$starty+=$deltay;
    }

    $id=$self->{MSGAREA}=$canvas->Label(-borderwidth => 2, -relief => "groove", 
					-width => 140, 
					-foreground => "yellow",
					-background => "grey40",
					-height => 1, 
					-font => $self->{FONT1}, 
					-anchor => "nw",-justify => 'left',
					-textvariable => \$self->{ITEMTEXT});
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createWindow($self->{POSX},$self->{POSY}, 
			  -window => $self->{MSGAREA}, -anchor => "nw");
    push(@{$self->{FIXEDITEMS}},$id);

    $canvas->configure(-scrollregion => [ $canvas->bbox("all") ]);

    $self->{BUILDFIXEDREADY}=1;

}


sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$text);
    my($num,$jobid,$cpus,$color,$nr,$name,$n);
    my $frames=$dataobj->{FRAMES};
    my($actdata);

    $self->clean();

    return(-1) if($frames<=0);

    $text=$dataobj->{TIMESTR};
    my $date_in_sec=date_to_sec($text);
    my $tdiff=$date_in_sec-$self->{LASTUPDATESEC};
    
    # threshold for new update reached?
    return(0) if( ($tdiff>0) && ($tdiff+5<($self->{UPDATESTEP}*60)));

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},
			$self->{COLOROBJECT},$self->{CANVAS}) if(!$self->{BUILDFIXEDREADY});

    # scan fo number of CPUS
    $self->{CPUS}=0;
    $self->{NODESIZE}=0;
    for($n=1;$n<=$frames;$n++) {
 	$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$cpus=$dataobj->{NODESTATE}->[$n]->{"cpu_total"};
	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}=~/BGL/) {
	    $cpus/=2;
	}
	$self->{NODESIZE}=$cpus if($cpus>$self->{NODESIZE});
	$self->{CPUS}+=$cpus;
    }

    # generate a gap, if necessary
    if(($self->{NUMCOLS}>0) && (($tdiff<0) || ($tdiff>1.5*($self->{UPDATESTEP}*60)))) {
#	printf("WF: act->%s diff->%10d>1.5*%d sec numcols=%s\n",$text,$tdiff,$self->{UPDATESTEP}*60,$self->{NUMCOLS});
	$self->generate_gap();
    } else {
#	printf("WF: act->%s diff->%10d>1.5*%d sec\n",$text,$tdiff,$self->{UPDATESTEP}*60);
    }

    $self->{LASTUPDATESEC}=$date_in_sec;

    $actdata=$self->extract_data_from_dataobj();
    $self->generate_new_label($actdata);
    $self->generate_job_stripes($actdata);

  
    $self->{NUMCOLS}++;
    $self->{TAGCNT}++;
    $self->{TAGCNT}=0 if($self->{TAGCNT}>$self->{MAXCOLS});

    push(@{$self->{DATA}},$actdata);

    $canvas->configure(-scrollregion => [ $canvas->bbox("all") ]);
    
    return();
}


sub extract_data_from_dataobj {
    my($self)    = shift;
    my($actdata);
    my $dataobj=$self->{DATAOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my($text,$cpusum,$small_cpusum,$i,,$jobid,$cpus,$color);
    my ($month,$day,$year,$hour,$min,$sec);
    
    $text=$dataobj->{TIMESTR};
    $text=~/(\d+)\/(\d+)\/(\d+)-(\d+):(\d+):(\d+)/s;
    ($month,$day,$year,$hour,$min,$sec)=($1,$2,$3,$4,$5,$6);
    $actdata->{DATE}[0]=$year; $actdata->{DATE}[1]=$month;  $actdata->{DATE}[2]=$day;
    $actdata->{DATE}[3]=$hour; $actdata->{DATE}[4]=$min;    $actdata->{DATE}[5]=$sec;

    $cpusum=0;
    $i=0;
    $small_cpusum=0;
    foreach $jobid (sort {sort_jobs_allcpu_up($dataobj)} keys( %{$dataobj->{RUNNINGDATA}} ) ) {
# 	printf("WF: %s\n",$jobid);
#	    $cpus=$dataobj->{RUNNINGDATA}->{$jobid}{FL_ALLCPU};
	$cpus=$dataobj->{RUNNINGDATA}->{$jobid}{FL_OVERALL};
	if($cpus>=$self->{MINCPUS}) {
	    $color=$colorobj->get_color("RUN",$jobid);
	    $cpusum+=$cpus;
	    $actdata->{JOBID}[$i]=$jobid;
	    $actdata->{COLOR}[$i]=$color;
	    $actdata->{CPUS}[$i]=$cpus;
	    $actdata->{WALL}[$i]=$dataobj->{RUNNINGDATA}->{$jobid}{FL_WALLSEC};
	    $actdata->{REST}[$i]=$dataobj->{RUNNINGDATA}->{$jobid}{FL_RESTSEC};
	    $self->{JOBINFO}->{$jobid}=sprintf("%s, class=%s, started at=%s, ,end at %s, spec=%s, #cpus= %s",
						 $dataobj->{RUNNINGDATA}->{$jobid}{FL_USER},
						 $dataobj->{RUNNINGDATA}->{$jobid}{FL_CLASS},
						 $dataobj->{RUNNINGDATA}->{$jobid}{FL_DISPATCH},
						 $dataobj->{RUNNINGDATA}->{$jobid}{FL_ENDTIME},
						 $dataobj->{RUNNINGDATA}->{$jobid}{FL_SPEC},
						 $dataobj->{RUNNINGDATA}->{$jobid}{FL_ALLCPU},
					    );
	    $self->{JOBINFOCNT}->{$jobid}++;
	    $i++;
	} else {
	    $small_cpusum+=$cpus;
	}
    }
    $actdata->{JOBID}[$i]="smallcpus";
    $actdata->{COLOR}[$i]=$self->{MINCPUSCOLOR};
    $actdata->{CPUS}[$i]=$small_cpusum;
    $actdata->{WALL}[$i]=200000;
    $actdata->{REST}[$i]=100000;
#	print "WF: small_cpusum=$small_cpusum $i\n";
    $i++;
    $actdata->{JOBID}[$i]="free";
    $actdata->{COLOR}[$i]=$self->{FREECPUSCOLOR};
    $actdata->{CPUS}[$i]=$dataobj->{LLCPUS}-$dataobj->{LLOVERALLCPUS};
    $actdata->{WALL}[$i]=200000;
    $actdata->{REST}[$i]=100000;

    return($actdata);

}

sub generate_new_label {
    my($self)    = shift;
    my($actdata) = shift;
    my($id,$text);
    my $lastdata=$self->{DATA}[$#{$self->{DATA}}];
    my $starty=$self->{POSY};
    my $deltax=($self->{WIDTH}-$self->{WIDTHSCALA})/$self->{MAXCOLS};
    my $startx=$self->{POSX}+$self->{NUMCOLS}*$deltax;
    

    $id=$self->{CANVAS}->createLine($startx+$deltax,$self->yinv($starty),
				    $startx+$deltax,$self->yinv($starty-8), -tags => ["histentry"], -fill => "blue");
    push(@{$actdata->{ADDID}},$id);
    if ((!$lastdata) || (($actdata->{DATE}[2]!= $lastdata->{DATE}[2]) || ($self->{LASTSHOWDAY}>=$self->{SHOWDAYSTEP}))) {
	$text=sprintf("%02d/%02d",$actdata->{DATE}[2],$actdata->{DATE}[1]);
	$self->{LASTSHOWDAY}=0;
	$id=$self->{CANVAS}->createText(     $startx+$deltax,$self->yinv($starty-40), 
					     -tags => ["histentry"],-text => $text, -anchor => 's', -font => $self->{BFONT1});
	push(@{$actdata->{ADDID}},$id);
    } 
    if (($self->{LASTSHOWHOUR}>=$self->{SHOWHOURSTEP})) {
	$text=sprintf("%02d:%02d",$actdata->{DATE}[3],$actdata->{DATE}[4]);
	$self->{LASTSHOWHOUR}=0;
	$id=$self->{CANVAS}->createText(     $startx+$deltax,$self->yinv($starty-30), 
					     -tags => ["histentry"],-text => $text, -anchor => 's', -font => $self->{BFONT1});
	push(@{$actdata->{ADDID}},$id);
    }
    if ($self->{LASTSHOWMIN}>=$self->{SHOWMINSTEP}) {
	$text=sprintf(":%02d",$actdata->{DATE}[4]);
	$self->{LASTSHOWMIN}=0;
	$id=$self->{CANVAS}->createText(     $startx+$deltax,$self->yinv($starty-20), 
					     -tags => ["histentry"],-text => $text, -anchor => 's', -font => $self->{BFONT1});
	push(@{$actdata->{ADDID}},$id);
    } 
    $self->{LASTSHOWDAY}++;
    $self->{LASTSHOWHOUR}++;
    $self->{LASTSHOWMIN}++;

    return();
}


sub generate_job_stripes {
    my($self)    = shift;
    my($actdata) = shift;
    my $dataobj = $self->{DATAOBJECT};
    my $colorobj= $self->{COLOROBJECT};
    my $canvas  = $self->{CANVAS};
    my $frames=$dataobj->{FRAMES};
    my($i,$j,$who,$id,$color,$jobid);

    my $lastdata=$self->{DATA}[$#{$self->{DATA}}];
    my $starty=$self->{POSY};
    my $deltax=($self->{WIDTH}-$self->{WIDTHSCALA})/$self->{MAXCOLS};
    my $deltay;
    my $startx=$self->{POSX}+$self->{NUMCOLS}*$deltax;
    my $width =$self->{WIDTH};
    my $maxcpus=$self->{CPUS};

    my $ni=$#{$actdata->{JOBID}}+1;
    my $nj=($self->{NUMCOLS}>0)?$#{$lastdata->{JOBID}}+1:0;
    my $yl=0;
    my $ya=0;
    my ($ptr,$belem);
    my ($yl1,$yl2,$ya1,$ya2)=(0,0,0,0);
    $belem=0;
    $i=$j=0;
    while(($ni>0) || ($nj>0)) {
	if (($ni>0) && ($nj>0)) {
	    if ($actdata->{JOBID}[$i] eq $lastdata->{JOBID}[$j]) {
		$who="both";
	    } else {
		if(&mycmp(
			  $actdata->{CPUS}[$i],
			  $actdata->{WALL}[$i]-$actdata->{REST}[$i],
			  $actdata->{REST}[$i],
			  $actdata->{JOBID}[$i],
			  $lastdata->{CPUS}[$j],
			  $lastdata->{WALL}[$j]-$lastdata->{REST}[$j],
			  $lastdata->{REST}[$j],
			  $lastdata->{JOBID}[$j])>0) {
		    $who="act";
		} else {
		    $who="last";
		}
	    } 
	} else {
	    $who="act" if($ni>0);
	    $who="last" if($nj>0);
	}
	if ($who eq "both") {
#		print "ni=$ni, nj=$nj i=$i j=$j: $actdata->{JOBID}[$i] -> both $actdata->{CPUS}[$i]<>$lastdata->{CPUS}[$j]\n";
	    $deltay=$lastdata->{CPUS}[$j]*$self->{HEIGHT}/$maxcpus;
	    $yl1=$yl;
	    $yl2=$yl+$deltay;
	    $yl+=$deltay;
	    $j++;$nj--;
	    $deltay=$actdata->{CPUS}[$i]*$self->{HEIGHT}/$maxcpus;
	    $ya1=$ya;
	    $ya2=$ya+$deltay;
	    $ya+=$deltay;
	    $color=$actdata->{COLOR}[$i];
	    $jobid=$actdata->{JOBID}[$i];
	    $ptr=$actdata;
	    $i++;$ni--;
	}
	if ($who eq "last") {
#		print "ni=$ni, nj=$nj i=$i j=$j: $actdata->{JOBID}[$i] -> last $lastdata->{CPUS}[$i]\n";
	    $deltay=$lastdata->{CPUS}[$j]*$self->{HEIGHT}/$maxcpus;
	    $yl1=$yl;
	    $yl2=$yl+$deltay;
	    $ya1=$ya;
	    $ya2=$ya;
	    $yl+=$deltay;
	    $color=$lastdata->{COLOR}[$j];
	    $jobid=$lastdata->{JOBID}[$j];
	    $ptr=$lastdata;
	    $j++;$nj--;
	} 
	if($who eq "act") {
#		print "ni=$ni, nj=$nj i=$i j=$j: $actdata->{JOBID}[$i] -> act  $actdata->{CPUS}[$i]\n";
	    $deltay=$actdata->{CPUS}[$i]*$self->{HEIGHT}/$maxcpus;
	    $yl1=$yl;
	    $yl2=$yl;
	    $ya1=$ya;
	    $ya2=$ya+$deltay;
	    $ya+=$deltay;
	    $color=$actdata->{COLOR}[$i];
	    $jobid=$actdata->{JOBID}[$i];
	    $ptr=$actdata;
	    $i++;$ni--;
	}
	my $part=$self->{PART}*0.01;
	my $ipart=1.0-$part;
	my $tag=sprintf("%03d.%03d",$self->{TAGCNT},$belem);
	if(!($self->{BINDTAGS}[$self->{TAGCNT}][$belem])) {
#	    print "WF: bind $tag \n";
	    $canvas->bind("$tag", "<Enter>", sub { &showitem("ON",$tag); });
	    $canvas->bind("$tag", "<Leave>", sub { &showitem("OFF",$tag); });
	}
	$self->{BINDTAGS}[$self->{TAGCNT}][$belem]=$ptr;
	$belem++;
	$id=$canvas->createPolygon($startx,$self->yinv($yl1),
				   $startx,$self->yinv($yl2),
				   $startx+$part*$deltax,$self->yinv($yl2),
				   $startx+$ipart*$deltax,$self->yinv($ya2), 
				   $startx+$deltax,$self->yinv($ya2), 
				   $startx+$deltax,$self->yinv($ya1),
				   $startx+$ipart*$deltax,$self->yinv($ya1),
				   $startx+$part*$deltax,$self->yinv($yl1),
				   -fill => $color, 
				   -outline => $color, 
#				       -outline => "grey10", 
				   -tags => ["$tag", "histentry"]);
#	    printf("WF: startx=%10.2f,%10.2f %10.2f %10.2f %10.2f i=%d ni=%d j=%d nj=%d id=%d\n",
#                   	    $startx,$yl1,$yl2,$ya1,$ya2,$i,$ni,$j,$nj,$id);
	push(@{$actdata->{ID}},$id);
	$id=$canvas->createLine($startx,               $self->yinv($yl1),
				$startx+$part*$deltax, $self->yinv($yl1),
				$startx+$ipart*$deltax,$self->yinv($ya1), 
				$startx+$deltax,       $self->yinv($ya1), 
				-fill => "grey20",
				-tags => ["$tag", "histentry"]);
	push(@{$actdata->{ID}},$id);
	$id=$canvas->createLine($startx,               $self->yinv($yl2),
				$startx+$part*$deltax, $self->yinv($yl2), 
				$startx+$ipart*$deltax,$self->yinv($ya2), 
				$startx+$deltax,       $self->yinv($ya2), 
				-fill => "grey20", 
				-tags => ["$tag", "histentry"]);
	push(@{$actdata->{ID}},$id);
	
    }

}

sub generate_gap {
    my($self) = shift;
    my $starty=$self->{POSY};
    my $deltax=($self->{WIDTH}-$self->{WIDTHSCALA})/$self->{MAXCOLS};
    my $startx=$self->{POSX}+$self->{NUMCOLS}*$deltax;
    my $deltay;
    my $width =$self->{WIDTH};
    my $lastdata=$self->{DATA}[$#{$self->{DATA}}];
    my $actdata;

    # a marker
    if($lastdata) { 
	my $id=$self->{CANVAS}->createLine($startx+$deltax,$self->yinv($starty),
					   $startx+$deltax,$self->yinv($starty-10), -tags => ["histentry"],
					   -fill => "red", -width => 2);
	push(@{$lastdata->{ADDID}},$id);
    }

    if($self->{DOGAP}) {
	$actdata->{JOBID}=[];
	$self->{NUMCOLS}++;
	push(@{$self->{DATA}},$actdata);
	$self->clean();
    }


    return(1);
}

sub set_marker {
    my($self) = shift;
    my $starty=$self->{POSY};
    my $deltax=($self->{WIDTH}-$self->{WIDTHSCALA})/$self->{MAXCOLS};
    my $startx=$self->{POSX}+$self->{NUMCOLS}*$deltax;
    my $deltay;
    my $width =$self->{WIDTH};
    my $lastdata=$self->{DATA}[$#{$self->{DATA}}];
    if($lastdata) {
	my $id=$self->{CANVAS}->createLine($startx+$deltax,$self->yinv($starty),
					   $startx+$deltax,$self->yinv($starty+$self->{HEIGHT}), -tags => ["histentry"],
					   -fill => "red");
	push(@{$lastdata->{ADDID}},$id);
    }
    return(1);
}


sub showitem {
    my ($state,$tag)=@_;
    my $self=$$selfref;
    my ($jobid,$used,$cpus,$jobinfo,$actdata);
#    print "WF: showitem $tag $state \n";
    if($state eq "ON") {
	my ($x,$y)=split(/\./,$tag);
	$actdata=$self->{BINDTAGS}[$x][$y];
	$jobid=$actdata->{JOBID}[$y];
	$used=sprintf("%4.2f",($actdata->{WALL}[$y]-$actdata->{REST}[$y])/(60*60));
	if($jobid) { 
	    $jobinfo=$self->{JOBINFO}->{$jobid};
	} else {
	    $jobinfo="<no information>";
	}
	if($jobid!~/(free|smallcpus)/) {
	    $self->{ITEMTEXT}="$jobid: used=${used}h, $jobinfo";
	} else {
	    $cpus=$actdata->{CPUS}[$y];
	    $self->{ITEMTEXT}="$jobid: $cpus cpus";
	}
#	$self->{CANVAS}->itemconfigure("$tag", -outline => "red", 
#				       -width => 3); 
	$self->{LASTHTAG}=$tag;
#	print "WF: on  $self->{LASTHTAG}\n";
    } else {
	if($self->{LASTHTAG} ne "-") {
#	    print "WF: off $self->{LASTHTAG}\n";
#	    $self->{CANVAS}->itemconfigure("$self->{LASTHTAG}", 
#					   -width => 0); 
	    $self->{LASTHTAG}="-";
	}
	$self->{ITEMTEXT}="<no info>";
    }


}

sub clean {
    my($self) = shift;
    my($id,$olddata);
    my $dataobj=$self->{DATAOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    my $deltax=($self->{WIDTH}-$self->{WIDTHSCALA})/$self->{MAXCOLS};
    if($self->{NUMCOLS}>=($self->{MAXCOLS})) {
	$olddata=shift(@{$self->{DATA}});
	$self->{NUMCOLS}--;
	foreach $id (@{$olddata->{ID}}) {
	    $canvas->delete($id);
	}
	foreach $id (@{$olddata->{ADDID}}) {
	    $canvas->delete($id);
	}
	$canvas->move("histentry",-$deltax,0);
	my $jobid=$olddata->{JOBID};
	$self->{JOBINFOCNT}->{$jobid}--;
	if($self->{JOBINFOCNT}->{$jobid}<=0) {
	    delete($self->{JOBINFO}->{$jobid});
	    delete($self->{JOBINFOCNT}->{$jobid});
	}
    }
    
}

sub cleanall {
    my($self) = shift;
    my $dataobj=$self->{DATAOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    my($id,$olddata);
    foreach $id (keys(%{$self->{JOBINFOCNT}})) {
	    delete($self->{JOBINFO}->{$id});
	    delete($self->{JOBINFOCNT}->{$id});
    }
    while($self->{NUMCOLS}>0) {
#	print "WF: cleanall $self->{NUMCOLS} of $self->{MAXCOLS}\n";
	$olddata=shift(@{$self->{DATA}});
	$self->{NUMCOLS}--;
	foreach $id (@{$olddata->{ID}}) {
	    $canvas->delete($id);
	}
	foreach $id (@{$olddata->{ADDID}}) {
	    $canvas->delete($id);
	}
    }
    $self->{TAGCNT}=0;
}

sub readhistfile {
    my($self) = shift;
    my $dataobj=$self->{DATAOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    my($rc,$i,$num,$numentries);
    my($jobid,$cpus,$wall,$rest);
    my($month,$day,$year,$hour,$min,$sec);
    my($line,$timestr,$key,$val);
    my(%actjobs);
    my $sep=";";
    $self->{HISTFILE}=~s/^~/$ENV{HOME}/se;
    print "readhistfile: >$self->{HISTFILE}< >$ENV{HOME}<\n";

    $rc=open(IN,$self->{HISTFILE});
    return(0) if(!$rc);

#    $self->{CANVAS}->Busy();

    $self->cleanall();

    $line=<IN>;
    while($line) {
	if($line=~/ENTRY: (\d+),(\d+)/) {
	    my($actdata);
	    $num=$1;$numentries=$2;
	    $line=<IN>;chomp($line);
	    ($year,$month,$day,$hour,$min,$sec)=split(",",$line);
	    $timestr="$month/$day/$year $hour:$min:$sec";
	    $actdata->{DATE}[0]=$year; $actdata->{DATE}[1]=$month;  $actdata->{DATE}[2]=$day;
	    $actdata->{DATE}[3]=$hour; $actdata->{DATE}[4]=$min;    $actdata->{DATE}[5]=$sec;
#	    print "WF: $num #$numentries >$timestr<\n";
	    for($i=0;$i<$numentries;$i++) {
		$line=<IN>;
		($jobid,$cpus,$wall,$rest)=split($sep,$line);
		$actdata->{JOBID}[$i]=$jobid;
		if($jobid!~/(free|smallcpus)/) {
		    $actdata->{COLOR}[$i]=$colorobj->get_color("RUN",$jobid);
		} else {
		    $actdata->{COLOR}[$i]=$self->{MINCPUSCOLOR} if($jobid eq "smallcpus");
		    $actdata->{COLOR}[$i]=$self->{FREECPUSCOLOR} if($jobid eq "free");
		}
		$actdata->{CPUS}[$i]=$cpus;
		$actdata->{WALL}[$i]=$wall;
		$actdata->{REST}[$i]=$rest;
		$actjobs{$jobid}=1;
	    }
 	    $line=<IN>;
	    while($line=~/^JOB: (.*)\;(.*)$/) {
		$self->{JOBINFO}->{$1}=$2;
		$line=<IN>;
	    }
	    # remove old job, free color
	    while (($key,$val)=each(%actjobs)) {
		if($val==0) {
		    delete($actjobs{$key});
		    $colorobj->free($key);
		} else {
		    $actjobs{$key}=0;
		}
	    }
	    # actualize the display
	    my $date_in_sec=date_to_sec($timestr);
	    my $tdiff=$date_in_sec-$self->{LASTUPDATESEC};
	    # threshold for new update reached?
	    if ( ( ($tdiff<0) || ($tdiff+5>=($self->{UPDATESTEP}*60))) && (($hour+$min/60.0)>$self->{READHISTFROM})) {
		$self->{LASTUPDATESEC}=$date_in_sec;
		
		$self->clean();
		$self->generate_new_label($actdata);
		$self->generate_job_stripes($actdata);
		$self->{NUMCOLS}++;
		$self->{TAGCNT}++;
		$self->{TAGCNT}=0 if($self->{TAGCNT}>$self->{MAXCOLS});
		push(@{$self->{DATA}},$actdata);
#		$canvas->configure(-scrollregion => [ $canvas->bbox("all") ]);
	    }

	} else {
 	    $line=<IN>;
	}
    }
    $self->{CANVAS}->Unbusy();

}



sub sort_jobs_allcpu_up   { 
    my($dataobj) = shift;
    return(&mycmp(
		  $dataobj->{RUNNINGDATA}->{$b}{FL_OVERALL},
		  $dataobj->{RUNNINGDATA}->{$b}{FL_WALLSEC}-$dataobj->{RUNNINGDATA}->{$b}{FL_RESTSEC},
		  $dataobj->{RUNNINGDATA}->{$b}{FL_RESTSEC},
		  $b,
		  $dataobj->{RUNNINGDATA}->{$a}{FL_OVERALL},
		  $dataobj->{RUNNINGDATA}->{$a}{FL_WALLSEC}-$dataobj->{RUNNINGDATA}->{$a}{FL_RESTSEC},
		  $dataobj->{RUNNINGDATA}->{$a}{FL_RESTSEC},
		  $a
		  )  );
}


sub mycmp {
    my($a1,$a2,$a3,$a4,$b1,$b2,$b3,$b4)=@_;
    # a1 -> #cpus
    # a2 -> #runtime
    # a3 -> #rest
    # a4 -> #jobid
    return(-1) if($a4 eq "free");
    return(1) if($b4 eq "free");
    return(-1) if($a4 eq "smallcpus");
    return(1) if($b4 eq "smallcpus");

    if($a1 == $b1) {
	if($a2 == $b2) {
	    if($a3 == $b3) {
		$a4 cmp $b4;
	    } else {
		$a3 <=> $b3;
	    }
	} else {
	    $a2 <=> $b2;
	}
    } else {
	$a1 <=> $b1;
    }
    
}

sub yinv {
    my($self) = shift;
    my($yval)=@_;
    return($self->{POSY}+$self->{HEIGHT}-$yval);
}

sub date_to_sec {
    my ($date)=@_;
#    print"WF: date_to_sec $date\n";
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year $^O\n";
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $timesec\n";
    return($timesec);
}


1;
