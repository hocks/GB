# $Source: /cvs/cvsroot/llview/lib/LLview_gui_resgraph.pm,v $
# $Author: zdv087 $
# $Revision: 1.47 $
# $Date: 2007/04/17 13:13:45 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_resgraph;
use strict;
use Time::Local;
use Data::Dumper;
use Tk;

# for callback functions
my($selfref)=-1;

my($debug)=0;

my @hex = ("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
my %hextod = ("0" => 0,"1" => 1,"2" => 2,"3" => 3,"4" => 4,"5" => 5,"6" => 6,"7" => 7,
	      "8" => 8,"9" => 9,"A" => 10,"B" => 11,"C" => 12,"D" => 13,"E" => 14,"F" => 15);

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_gui_resgraph: new %s\n",ref($proto)) if($debug>=3);
    $self->{HAVEINFOMSG} = 0;
    $self->{POSX}       = 485;
    $self->{POSY}       = 730;
    $self->{WIDTHPART1} = 144;  
    $self->{WIDTH}      = 435;
    $self->{HEIGHT}     = 130;
    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}     = "-*-Helvetica-Bold-R-Normal--*-80-*-*-*-*-*-*";
    $self->{ITEMS}      = [];
    $self->{LEFTPAD}    = 40;
    $self->{RIGHTPAD}    = 0;
    $self->{BOTTOMPAD}  = 40;
    $self->{MINNODES}   = 8;
    $self->{TIMEBACK}    = 24;
    $self->{TIMEFORWARD} = 48;
    $self->{COLORMODE}   = "byuser";
    $self->{SHOWWEEKDAY} = 1;
    $self->{BUILDREADY}  = 0;
    $self->{STACKMODE}   = 0;
    $self->{SHOWID}      = 1;
    $self->{CLUSTERNAME} = shift||"-"; # needed for button callback function 

    $self->{DOALLOC}     = 0;
    $self->{ALLOCRECT}   = undef;
    $self->{ALLOCRECTX}  = 200;
    $self->{ALLOCRECTY}  = 200;
    $self->{ALLOCRECTW}  = 110;
    $self->{ALLOCRECTH}  = 110;
    $self->{ALLOCMARKERWIDTH}   = 6;
    $self->{ALLOCWHAT}   = "none"; # what is selected
    $self->{ALLOCACTIVATED} = 0;
    $self->{ALLOCWIN}    = undef;
    $self->{ALLOCWIDTH}  = 400; 
    $self->{ALLOCHEIGHT} = 300; 
    $self->{ALLOCGRIDX}  = 5; # min 
    $self->{ALLOCRECTSPEC}=$self->{ALLOCRECTW}."x".$self->{ALLOCRECTH}."+".$self->{ALLOCRECTX}."+".$self->{ALLOCRECTY};
    $self->{ALLOCSTARTDATE} = "-";
    $self->{ALLOCDURATION} = "-";
    $self->{ALLOCPARTITION} = "R01";
    $self->{ALLOCDOSSH} = 1;
    $self->{ALLOCSCRIPT} = "";
    $self->{ALLOCSSHHOST}   = "jubl.zam.kfa-juelich.de";
    $self->{ALLOCSSHUSERID} = "";
    $self->{ALLOCSPECIALUID} = "";
#    $self->{ALLOCSTARTDATEF} = % ...;
    $self->{ALLOCCOMMAND} = "-";
    $self->{ALLOCSTDOUT1} = "-";
    $self->{ALLOCSTDOUT2} = "-";
    $self->{ALLOCSTDOUT3} = "-";
    $self->{ALLOCSTDOUT4} = "-";
    $self->{ALLOCSTDOUT5} = "-";
    bless $self, $class;
    if($selfref==-1)  {
	$selfref=\$self;
    } else {
	printf("WARNING: double constructor call to LLview_gui_resgraph ...\n")
    }
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($i,$name);
    my $frames=$dataobj->{FRAMES};

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;
    $self->{OPTIONOBJECT}=$optobj;

    $optobj->register_option("Resgraph","POSX", -label => "posx", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 200, -default => $self->{POSX}, -step => 10);

    $optobj->register_option("Resgraph","POSY", -label => "posy", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 200, -default => $self->{POSY}, -step => 10);

    $optobj->register_option("Resgraph","HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 400, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option("Resgraph","WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 200, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option("Resgraph","TIMEBACK", -label => "History Time (h)", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 240, -default => $self->{TIMEBACK}, -step => 4);
    $optobj->register_option("Resgraph","TIMEFORWARD", -label => "Future Time (h)", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 240, -default => $self->{TIMEFORWARD}, -step => 4);

    $optobj->register_option("Resgraph","COLOROBJ", -label => "color mode", 
			     -caller => $self, -pack => 1, 
			     -values => ["byuser","byres"],
			     -labels => ["by user","by reservation"],
			     -type => "radiogroup", -default => $self->{COLORMODE});

    $optobj->register_option("Resgraph","SHOWWEEKDAY", -label => "Show day of week", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{SHOWWEEKDAY});

    $optobj->register_option("Resgraph","STACKMODE", -label => "Stack mode", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{STACKMODE});

    $optobj->register_option("Resgraph","SHOWID", -label => "Show ID", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{SHOWID});

    $optobj->register_option("Resgraph","DOALLOC", -label => "Interactive Alloc.", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{DOALLOC});
    $optobj->register_option("Resgraph","ALLOCDOSSH", -label => "use ssh to execute sched_bgl", 
			     -caller => $self,-pack => 1, -labelwidth => 30,
			     -type => "radio", -default => $self->{ALLOCDOSSH});

    $optobj->register_option("Resgraph","ALLOCSSHHOST", -label => "host", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{ALLOCSSHHOST});

    $optobj->register_option("Resgraph","ALLOCSSHUSERID", -label => "userid on host", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{ALLOCSSHUSERID});

    $optobj->register_option("Resgraph","Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option("Resgraph","BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT1});
   
   

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{BUILDREADY}=1;

    return();
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id);
#    print "resgraph_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY}) #$#{$self->{USAGE}}\n";

    if ($name eq "Font") {
	$self->{FONT1}=$val;
    } elsif ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
    } else {
	$self->{$name}=$val;
    }

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
 
}

sub register_color_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{COLOROBJECT}=$objref;
    return 1;
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name);
    my($LEFT_ICON,$left,$leftsubwidget,$leftframe);
    my($RIGHT_ICON,$right,$rightsubwidget,$rightframe);

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    $id=$canvas->createRectangle($self->{POSX},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH},
				 $self->{POSY}+$self->{HEIGHT},
				 -fill => "grey80", -tags => ["resgraph"]);
    push(@{$self->{FIXEDITEMS}},$id);
#    $canvas->bind("resgraph", '<ButtonRelease-1>' => [sub { my ($c) = @_;
#								  &update_left_cb($Tk::event->x,$Tk::event->y,1)}]);
#    $canvas->bind("resgraph", '<ButtonRelease-3>' => [sub { my ($c) = @_;
#								  &update_right_cb($Tk::event->x,$Tk::event->y,1)}]);
    $canvas->bind("resgraph", '<Control-ButtonRelease-1>' => [sub { my ($c) = @_;
							    &update_left_cb($Tk::event->x,$Tk::event->y,8)}]);
    $canvas->bind("resgraph", '<Control-ButtonRelease-3>' => [sub { my ($c) = @_;
							    &update_right_cb($Tk::event->x,$Tk::event->y,8)}]);

    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				 -fill => "grey60", -tags => ["resgraph"]);
    push(@{$self->{FIXEDITEMS}},$id);

    $LEFT_ICON=$self->{INSTPATH}."/lib/images/button-left-small.gif";
    $left = $self->{CANVAS}->Photo(-file => $LEFT_ICON, -format => 'gif');
    $RIGHT_ICON=$self->{INSTPATH}."/lib/images/button-right-small.gif";
    $right = $self->{CANVAS}->Photo(-file => $RIGHT_ICON, -format => 'gif');

    $leftframe=$canvas->Frame( 
			       -relief => "flat", 
			       -borderwidth => 0);
    $id=$leftframe->Button(-text => 'Update',
			   -image => $left,
			   -command => sub { &update_left_left_cb();},
			   -width => 12,
			   -height => 12,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $id=$leftframe->Button(-text => 'Update',
			   -image => $right,
			   -command => sub { &update_left_right_cb();},
			   -width => 12,
			   -height => 12,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $leftsubwidget = $canvas->createWindow($self->{POSX}+1,$self->{POSY}+$self->{HEIGHT}, -window =>$leftframe, -anchor => "sw");
    push(@{$self->{FIXEDITEMS}},$leftsubwidget);

    $rightframe=$canvas->Frame( 
			       -relief => "flat", 
			       -borderwidth => 0);
    $id=$rightframe->Button(-text => 'Update',
			   -image => $left,
			   -command => sub { &update_right_left_cb();},
			   -width => 12,
			   -height => 12,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $id=$rightframe->Button(-text => 'Update',
			   -image => $right,
			   -command => sub { &update_right_right_cb();},
			   -width => 12,
			   -height => 12,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $rightsubwidget = $canvas->createWindow($self->{POSX}+$self->{WIDTH},$self->{POSY}+$self->{HEIGHT}, -window =>$rightframe, -anchor => "se");
    push(@{$self->{FIXEDITEMS}},$rightsubwidget);

    if($self->{DOALLOC}) {
	$self->setup_alloc();
    }

}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$nonewdata)=@_;
    my($i,$cpus,$jobid,$id,$maxnodes,$maxnumber,$nodes,$nodelist,$spec,$node,$book);
    my($px,$py,@py,$dx,$dy,$n,$name,$color,$nr,$ucolor,$unr,$rcolor,$rnr,$usedh,$starth,$endh);
    my($startx,$starty,$endx,$numnodes,$nodecnt,$lstarty,$lendy,$user,$endy,$startxl,$midx);
    my($textcolor);
    my $frames=$dataobj->{FRAMES};
    return() if ($frames==0);
    return() if (($self->{TIMEBACK}+$self->{TIMEFORWARD})<=0);

    $self->{DX}  =$dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    $self->{DY}  =$dy=($self->{HEIGHT}-$self->{BOTTOMPAD})/($frames);
    $self->{MIDX}=$midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
    $dataobj->printsize("resgraphupdate: start") if($debug==5);

    $self->clean($dataobj,$colorobj,$canvas);

    $dataobj->printsize("resgraphupdate: after clean") if($debug==5);
    
    $px=$self->{POSX};
    for($n=1;$n<=$frames;$n++) {
 	$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}!~/BGL/) {
	    $py[$n]=$self->{POSY}+$self->{HEIGHT}-($n-1)*$dy;
	} else {
	    $py[$n]=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($n-1)*$dy;
	}

#	$id=$canvas->createRectangle($self->{POSX},int($py[$n]-$dy)+1,
#				     $self->{POSX}+$self->{LEFTPAD},int($py[$n]),
#				     -fill => "DarkOrange3", -outline => "black");
#	push(@{$self->{FIXEDITEMS}},$id);

	if($self->{STACKMODE}) {
	    $id=$canvas->createText($px+2,$py[$n]+0,
				    -text => sprintf("R #%2d M%d", int($n/2),1-$n%2),
				    -anchor => 'sw',
				    -font => $self->{FONT1},
				    -tags => ["NODE${n}", "resgraph"]);
	    push(@{$self->{ITEMS}},$id);
	} else {
	    $id=$canvas->createText($px+2,$py[$n]+0,
				    -text => sprintf("%s", $name),
				    -anchor => 'sw',
				    -font => $self->{FONT1},
				    -tags => ["NODE${n}", "resgraph"]);
	    push(@{$self->{ITEMS}},$id);
	}
#	printf("WF: line %f %f %f %f\n",$self->{POSX}, 
#	       $py[$n],
#	       $self->{POSX}+$self->{WIDTH},
#	       $py[$n]);

	if($n>1) { # not on first item
	    $id=$canvas->createLine(      $self->{POSX}+$self->{LEFTPAD}, $py[$n],
					  $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
					  $py[$n],
					  -width => 1,
					  -fill => (($n%2)==0)?"grey":"darkblue",
					  -tags => ["resgraph"]
					  );
	    push(@{$self->{ITEMS}},$id);
	}
    }
    $id=$canvas->createLine(      $midx, $self->{POSY},
				  $midx, $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				  -width => 2,
				  -fill => "blue", 
				  -tags => ["resgraph"]
				  );
    push(@{$self->{ITEMS}},$id);


    if($self->{STACKMODE}) {
	$self->update_reservations_stack($dataobj,$colorobj,$infoobj,$canvas,$nonewdata,\@py);
    } else {
	$self->update_reservations($dataobj,$colorobj,$infoobj,$canvas,$nonewdata,\@py);
    }

    
    foreach $jobid (keys( %{$dataobj->{RUNNINGDATA}} )) {
	$nodelist=$dataobj->{RUNNINGDATA}->{$jobid}{FL_STARTHOST};
#	print "WF: runningdata: $jobid $nodelist\n";
	$user=$dataobj->{RUNNINGDATA}->{$jobid}{FL_USER};
	$usedh=$dataobj->{RUNNINGDATA}->{$jobid}{FL_USEDH};
	$usedh=$self->{TIMEBACK} if ($usedh>$self->{TIMEBACK});
	$startx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx) - $usedh*$dx;
	$endx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
	$color=$colorobj->get_color("RUN",$jobid);
	$nr=$colorobj->colortonr("RUN",$color);
	
	my @nodes=split(/\),?\(/,$nodelist);
	$numnodes=scalar(@nodes);
	$nodecnt=0;
	$starty=$py[1];
	$endy=$py[1];
	foreach $spec (split(/\),?\(/,$nodelist)) {
	    $spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;
	    $nodecnt++;
#	    print "WF: $nodecnt/$numnodes $node\n";
	    # position of next rectangle
	    if($node=~/(R\d\d-M\d)/) {
		# it's a BGL node
		if($node=~/(R\d\d-M\d)-N(.)/) {
		    # it's a BGL nodebook
		    $node=$1;$book=$2;
		    $n=$dataobj->{NODES}->{$node}->{"node_nr"};
		    $lstarty=$py[$n]-$hextod{$book}*$dy/16;
		    $lendy=$lstarty-$dy/16;
		} else {
		    # it's a BGL midplane
		    $node=$1;$book=-1;
		    $n=$dataobj->{NODES}->{$node}->{"node_nr"};
		    $lstarty=$py[$n];
		    $lendy=$lstarty-$dy;
		}
	    } else {
		# LL node
		$n=$self->{NODES}->{$node}->{"node_nr"};
		$lstarty=$py[$n];
		$lendy=$lstarty-$dy;
	    }
	    
	    if($lstarty-$endy==0) {
		# widening rectangle in y-direction
		$endy=$lendy;
	    } else {
		if($endy-$starty!=0) {
		    # generate recent rectangle 
		    $self->gen_rect($canvas,$infoobj,$startx,$starty,$endx,$endy,"T${nr}R","T${nr}B",$color,$user);
		}
		$starty=$lstarty;
		$endy=$lendy;
	    }
	    if($nodecnt==$numnodes) {
		# generate last rectangle
		$self->gen_rect($canvas,$infoobj,$startx,$starty,$endx,$endy,"T${nr}R","T${nr}B",$color,$user);
	    }
	}
    }

    $self->create_timescale($canvas,$dataobj->{MACHSTATE}->{"system_time"},$dx,$dy);



    $dataobj->printsize("resgraphupdate: end") if($debug==5);

    if($self->{DOALLOC}) {
	$canvas->raise("alloc");
    }
    
    return();
}


sub update_reservations {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$nonewdata,$pyref)=@_;
    my($resid,$nodelist,$starth,$endh,$user,$startxl,$dx,$dy,$startx,$midx,$ucolor,$unr,$rnr);
    my($endx,$rcolor,$color,$textcolor,$numnodes,$nodecnt,$starty,$lstarty,@py,$endy,$lendy,$node,$book,$n);
    my $frames=$dataobj->{FRAMES};

    $dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    $dy=($self->{HEIGHT}-$self->{BOTTOMPAD})/($frames);
    $midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);

    foreach $resid (keys( %{$dataobj->{RESERVATION}} )) {
#	print "WF: $resid\n"
	my $prio=$dataobj->{RESERVATION}->{$resid}{'priority'};
	$nodelist=$dataobj->{RESERVATION}->{$resid}{'nodelist'};
	$starth=&timediff($dataobj->{RESERVATION}->{$resid}{'starttime'},$dataobj->{MACHSTATE}->{"system_time"})/3600;
	$endh=&timediff($dataobj->{RESERVATION}->{$resid}{'endtime'},$dataobj->{MACHSTATE}->{"system_time"})/3600;
	$user=$dataobj->{RESERVATION}->{$resid}{'user'};
#	print "WF: $user $starth $endh  ".$dataobj->{RESERVATION}->{$resid}{'starttime'}.
#	    "-".$dataobj->{RESERVATION}->{$resid}{'endtime'}." \n";
	if($starth<$self->{TIMEFORWARD}) {
	    if ($starth<0) {
		$starth=-$self->{TIMEBACK} if($starth<-$self->{TIMEBACK});
		$startxl=int($self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx) + $starth*$dx);
		$starth=0;
	    } else {
		$startxl=0;
	    }
		
	    $endh=$self->{TIMEFORWARD} if ($endh>$self->{TIMEFORWARD});
	    $startx=int($midx + $starth*$dx);
	    $endx=int($midx + $endh*$dx);
	    # get nr for user and reservation
	    $ucolor=$colorobj->get_color("WAIT",$user);
	    $unr=$colorobj->colortonr("WAIT",$ucolor);
	    $rcolor=$colorobj->get_color("WAIT",$resid);
	    $rnr=$colorobj->colortonr("WAIT",$rcolor);

	    if($self->{COLORMODE} eq "byuser") {
		$color=$ucolor;
	    } else {
		$color=$rcolor;
	    }
	    
	    if($prio>1) {
		$color="grey60";
		$textcolor="red";
	    } else {
		$textcolor="black";
	    }

	    if($user=~/^ERROR/) {
		$color="red";
	    }
	    my @nodes=split(/,/,$nodelist);
	    $numnodes=scalar(@nodes);
	    $nodecnt=0;
	    $starty=$pyref->[1];
	    $endy=$pyref->[1];
	    foreach $node (split(/,/,$nodelist)) {
		$nodecnt++;
		# position of next rectangle
		if($node=~/(R\d\d-M\d)/) {
		    # it's a BGL node
		    if($node=~/(R\d\d-M\d)-N(.)/) {
			# it's a BGL nodebook
			$node=$1;$book=$2;
			$n=$dataobj->{NODES}->{$node}->{"node_nr"};
#		    print "WF: $jobid $node $book $n\n";
			$lstarty=$pyref->[$n]-$hextod{$book}*$dy/16;
			$lendy=$lstarty-$dy/16;
		    } else {
			# it's a BGL midplane
			$node=$1;$book=-1;
			$n=$dataobj->{NODES}->{$node}->{"node_nr"};
			$lstarty=$pyref->[$n];
			$lendy=$lstarty-$dy;
		    }
		} else {
		    # LL node
		    $n=$self->{NODES}->{$node}->{"node_nr"};
		    $lstarty=$pyref->[$n];
		    $lendy=$lstarty-$dy;
		}
		
		if($lstarty-$endy==0) {
		    # widening rectangle in y-direction
		    $endy=$lendy;
		} else {
		    if($endy-$starty!=0) {
			# generate recent rectangle 
			$self->gen_rect($canvas,$infoobj,$startx,$starty,$endx,$endy,"R${rnr}R","R${rnr}B",$color,$user,$textcolor,$resid);
			$self->gen_rect($canvas,$infoobj,$startxl,$starty,$midx,$endy,"R${rnr}R","R${rnr}B","grey40","","") if($startxl!=0);
		    }
		    $starty=$lstarty;
		    $endy=$lendy;
		}
		if($nodecnt==$numnodes) {
		    # generate last rectangle
		    $self->gen_rect($canvas,$infoobj,$startx,$starty,$endx,$endy,"R${rnr}R","R${rnr}B",$color,$user,$textcolor,$resid);
		    $self->gen_rect($canvas,$infoobj,$startxl,$starty,$midx,$endy,"R${rnr}R","R${rnr}B","grey80","","") if($startxl!=0);
		}
		
	    }
	}
    }


}

sub update_reservations_stack {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$nonewdata,$pyref)=@_;
    my($resid,$nodelist,$starts,$ends,$user,$startxl,$dx,$dy,$startx,$midx,$ucolor,$unr,$rnr);
    my($endx,$rcolor,$color,$textcolor,$numnodes,$nodecnt,$starty,$lstarty,@py,$endy,$lendy,$node,$book,$n,$nummidplanes);
    my(%timestamps,@timestamps,%starts,%ends,%useds,%nummidplanes,$timestamp,$ntimestamp,$usedn,$t,$py);
    my $frames=$dataobj->{FRAMES};
    my $sectoh=1.0/(60*60);
    my $htosec=(60*60);
    # get information about all reservations
    foreach $resid (keys( %{$dataobj->{RESERVATION}} )) {
	my $prio=$dataobj->{RESERVATION}->{$resid}{'priority'};
	$nodelist=$dataobj->{RESERVATION}->{$resid}{'nodelist'};
	$starts=int(&timediff($dataobj->{RESERVATION}->{$resid}{'starttime'},$dataobj->{MACHSTATE}->{"system_time"}));
	$ends=int(&timediff($dataobj->{RESERVATION}->{$resid}{'endtime'},$dataobj->{MACHSTATE}->{"system_time"}));
# 	print "WF: $resid $starts*$sectoh\n";
	if(($starts*$sectoh)<$self->{TIMEFORWARD}) {
	    if ($starts<0) {
		$starts=int(-$self->{TIMEBACK}*$htosec) if( ($starts*$sectoh)<-$self->{TIMEBACK});
		$starts=0;
	    } else {
		$startxl=0;
	    }
	    $ends=int($self->{TIMEFORWARD}*$htosec) if ( ($ends*$sectoh)>$self->{TIMEFORWARD});
	    $timestamps{$starts}=0;
	    $timestamps{$ends}=0;
	    $starts{$resid}=$starts;
	    $ends{$resid}=$ends;
	    $useds{$resid}=$ends-$starts;

	    # determine number of midplanes
	    foreach $node (split(/,/,$nodelist)) {
		# position of next rectangle
		if($node=~/(R\d\d-M\d)/) {
		    # it's a BGL node
		    if($node=~/(R\d\d-M\d)-N(.)/) {
			# it's a BGL nodebook
			$nummidplanes{$resid}+=1/16;
		    } else {
			# it's a BGL midplane
			$nummidplanes{$resid}+=1;
		    }
		} else {
		    # LL node, no BGL node
		    $nummidplanes{$resid}+=2;
		}
	    }
	}
    }
    @timestamps=(sort {$a <=> $b} keys(%timestamps));
#    print "@timestamps frame=$frames\n";
    $dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    $dy=($self->{HEIGHT}-$self->{BOTTOMPAD})/($frames)*1;
    $midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};

    foreach $resid (sort { 
	if($useds{$b} == $useds{$a}) {$nummidplanes{$b} <=> $nummidplanes{$a}} 
	else {$useds{$b} <=> $useds{$a}}  
#	if($nummidplanes{$b} == $nummidplanes{$a}) {$useds{$b} <=> $useds{$a}} 
#	else {$nummidplanes{$b} <=> $nummidplanes{$a}}  
    } keys( %starts )) {
	my $prio=$dataobj->{RESERVATION}->{$resid}{'priority'};
	$nodelist=$dataobj->{RESERVATION}->{$resid}{'nodelist'};
	$starts=$starts{$resid};
	$ends=$ends{$resid};
	$nummidplanes=$nummidplanes{$resid};
	$user=$dataobj->{RESERVATION}->{$resid}{'user'};
#	print "WF: num=$nummidplanes $user $starts $ends, dx=",($ends-$starts),", $nodelist\n";
	
	# get nr for user and reservation
	$ucolor=$colorobj->get_color("WAIT",$user);
	$unr=$colorobj->colortonr("WAIT",$ucolor);
	$rcolor=$colorobj->get_color("WAIT",$resid);
	$rnr=$colorobj->colortonr("WAIT",$rcolor);
	if($self->{COLORMODE} eq "byuser") { $color=$ucolor;	} 
	else {	    $color=$rcolor;	}
	
	if($prio>1) {
	    $color="grey60";
	    $textcolor="red";
	} else {
	    $textcolor="black";
	}
	if($user=~/^ERROR/) {
	    $color="red";
	}

	my($x1,$x2,$y1,$y2)=(-1,-1,-1,-1);
	for($t=0;$t<$#timestamps;$t++) {
	    $timestamp=$timestamps[$t];
	    $ntimestamp=$timestamps[$t+1];
	    next if (! ( ($starts<=$timestamp) && ($ntimestamp<=$ends) ) );
	    $startx=int($midx + $timestamp*$sectoh*$dx);
	    $endx=int($midx + $ntimestamp*$sectoh*$dx);
	    $usedn=$timestamps{$timestamp};
	    $starty=$py-($usedn+$nummidplanes)*$dy;
	    $endy=$py-$usedn*$dy;
	    $timestamps{$timestamp}+=$nummidplanes;
	    # generate recent rectangle 
	    if(($y1==$starty) && ($y2==$endy)) {
		$x2=$endx;
	    } else {
		if($x1!=-1) {
		    $self->gen_rect($canvas,$infoobj,$x1,$y2,$x2,$y1,"R${rnr}R","R${rnr}B",$color,$user,$textcolor,$resid);
		}
		($x1,$x2,$y1,$y2)=($startx,$endx,$starty,$endy);
	    }
	}
	if($x1!=-1) {
	    $self->gen_rect($canvas,$infoobj,$x1,$y2,$x2,$y1,"R${rnr}R","R${rnr}B",$color,$user,$textcolor,$resid);
	}

    }
}


sub gen_rect {
    my($self) = shift;
    my($canvas,$infoobj,$startx,$starty,$endx,$endy,$rid1,$rid2,$color,$user,$textcolor,$resid)=@_;
    my($id,$dx,$dy);
    $textcolor="black" if(!$textcolor);
    $user.="\n($resid)" if($self->{SHOWID} && ($resid)); 
#    printf("WF: rectangle: %10s  from %6.2f,%6.2f to %6.2f,%6.2f rids=%s,%s col=%s\n",
#	   $user,$startx,$starty,$endx,$endy,$rid1,$rid2,$color);
    $startx=int($startx)+1; 	    $endx=int($endx)+1;
    $starty=int($starty)+1; 	    $endy=int($endy)+1;
    $dx=$endx-$startx;              $dy=$starty-$endy;
    
    $id=$canvas->createRectangle($startx,$endy,$endx-1,$starty-1, -fill => $color, 
				 -outline => "black", 
				 -tags => [$rid1, "resgraph"]);
    push(@{$self->{ITEMS}},$id);
    $infoobj->register_bind($rid1,$self);
    $infoobj->register_bind($rid2,$self);
#    print "dx=$dx dy=$dy text=>>$user<\n";
    if(($dx>40) && ($dy>10) && ($user ne "")) {
	$id=$canvas->createText(($startx+$endx)/2,($starty+$endy)/2+0,
				-text => $user,
				-anchor => 'c',
				-fill => $textcolor,
				-font => $self->{FONT1},
				-tags => [$rid2, "resgraph"]);
	push(@{$self->{ITEMS}},$id);
    } elsif (($dx>10) && ($dy>100) && ($user ne "")) {
	$user=~s/(.)/$1\n/gs;
	$id=$canvas->createText(($startx+$endx)/2,($starty+$endy)/2+0,
				-text => $user,
				-anchor => 'c',
				-fill => $textcolor,
				-font => $self->{FONT1},
				-tags => [$rid2, "resgraph"]);
	push(@{$self->{ITEMS}},$id);
	
    }
}

sub create_timescale {
    my($self) = shift;
    my($canvas,$now,$dx,$dy)=@_;
    my($id,$px,$py,$h,$step,$diffh);
    my($now2l,$now0,$daysb,$d);
    $px=$self->{POSX}+$self->{LEFTPAD}+$self->{TIMEBACK}*$dx;
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};

    # adjust step width
    $step=1;
    if($dx<20) {
	for($step=2;$step<($self->{TIMEBACK}+$self->{TIMEFORWARD});$step+=2) {
	    last if ($step*$dx>20);
	}
    }

    # print hour marker
    for($h=-$self->{TIMEBACK};$h<$self->{TIMEFORWARD};$h++) {
	if($h%$step==0) {
	    $id=$canvas->createLine( $px+$h*$dx, $py+1,
				     $px+$h*$dx, $py+5,
				     -width => 1,
				     -fill => "grey10", 
				     -tags => ["resgraph"]
				     );
	    push(@{$self->{ITEMS}},$id);
	    $id=$canvas->createText( $px+$h*$dx, $py+9,
				     -text => ($h<=0)?"${h}h":"+${h}h",
				     -anchor => 'c',
				     -font => $self->{FONT1}, 
				     -tags => ["resgraph"]);
	    push(@{$self->{ITEMS}},$id);
	} else {
	    $id=$canvas->createLine( $px+$h*$dx, $py+1,
				     $px+$h*$dx, $py+2,
				     -width => 1,
				     -fill => "grey10", 
				     -tags => ["resgraph"]
				     );
	    push(@{$self->{ITEMS}},$id);
	}
    }
    # time/date at 0-marker
    $now2l=$now;$now2l=~s/-/\n/g;
    $id=$canvas->createText( $px, $py+22,
			     -text => $now2l,
			     -anchor => 'c',
			     -font => $self->{FONT1}, 
			     -tags => ["resgraph"]);
    push(@{$self->{ITEMS}},$id);

    $now0=$now;$now0=~s/\d\d:\d\d:\d\d/00:00:00/gs;
    $diffh=&timediff($now,$now0)/3600;
    $daysb=0;  $daysb++ while($diffh+24*$daysb<$self->{TIMEBACK}); $daysb--;
    for($d=-($diffh+24*$daysb);$d<$self->{TIMEFORWARD};$d+=24) {
#	$id=$canvas->createLine( $px+$d*$dx, $py,
#				 $px+$d*$dx, $self->{POSY},
#				 -width => 2,
#				 -fill => "grey40",
#				 , -tags => ["resgraph"]
#				 );
	$id=$canvas->createLine( $px+$d*$dx, $py+00,
				 $px+$d*$dx, $py+40,
				 -width => 2,
				 -fill => "grey40",
				 , -tags => ["resgraph"]
				 );
	push(@{$self->{ITEMS}},$id);

	if($self->{SHOWWEEKDAY}) {
#	    if($px+$d*$dx+2+25<$self->{POSX}+$self->{WIDTH}) {
#		$id=$canvas->createRectangle($px+$d*$dx+2, $py-2,
#					     $px+$d*$dx+2+25, $py-3-10, -outline => "black",
#					     -fill => "DarkGoldenrod", -tags => ["resgraph"]);
#		push(@{$self->{ITEMS}},$id);
#		my $wdaystr=&sec_to_day(&date_to_sec($now)+$d*3600);
#		$id=$canvas->createText( $px+$d*$dx+2, $py-7,
#					 -text => " $wdaystr ->",
#					 -anchor => 'w',
#					 -font => $self->{FONT1}, -tags => ["resgraph"]);
#		push(@{$self->{ITEMS}},$id);
#	    }
	    if($px+$d*$dx+2+25<$self->{POSX}+$self->{WIDTH}) {
		$id=$canvas->createRectangle($px+$d*$dx+2, $py-2+30,
					     $px+$d*$dx+2+25, $py-3-10+30, -outline => "black",
					     -fill => "DarkGoldenrod", -tags => ["resgraph"]);
		push(@{$self->{ITEMS}},$id);
		# +2*3600 fix problem with summer time shift
		my $wdaystr=&sec_to_day(&date_to_sec($now)+$d*3600+2*3600);
		$id=$canvas->createText( $px+$d*$dx+2, $py-7+30,
					 -text => " $wdaystr ->",
					 -anchor => 'w',
					 -font => $self->{FONT1}, -tags => ["resgraph"]);
		push(@{$self->{ITEMS}},$id);
	    }
	}
    }
}

sub generateinfo {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$name)=@_;
    my($runtime);
    my $infostr="no info for reservation $name\n";
    if($name=~/R(\d+)[RB]/) {
	my $nr=$1;
	my $resid=$colorobj->nrtoid($nr);
#	print "WF: generateinfo resgraph $nr,$resid\n";
	$infostr=sprintf("Info for reservation %4d\n",$resid);
	$infostr.=sprintf("-------------------------------\n");
	if(exists($dataobj->{RESERVATION}->{$resid})) {
	    my $o=$dataobj->{RESERVATION}->{$resid};
	    my $duration=&timediff($o->{"endtime"},$o->{"starttime"});
	    $infostr.=sprintf("  User:        %s\n", $o->{"user"});
	    $infostr.=sprintf("  Priority:    %s\n", $o->{"priority"});
	    $infostr.=sprintf("  Nodelist:    %s\n", $o->{"nodelist"});
	    $infostr.=sprintf("  start time:  %s\n", $o->{"starttime"});
	    $infostr.=sprintf("  end   time:  %s\n", $o->{"endtime"});
	    $infostr.=sprintf("  duration:    %5.2fh  (%4.2f days)\n",
			      $duration/3600,$duration/3600/24);
	    $runtime=&timediff($o->{"starttime"},$dataobj->{MACHSTATE}->{"system_time"});
	    if($runtime<0) {
		$infostr.=sprintf("  running:     %5.2fh  (%4.2f days)\n",
				  -$runtime/3600,-$runtime/3600/24);
		$infostr.=sprintf("  rest time:   %5.2fh  (%4.2f days)\n",
				  ($duration+$runtime)/3600,($duration+$runtime)/3600/24);
	    } else {
		$infostr.=sprintf("  starting in: %5.2fh  (%4.2f days)\n",
				  $runtime/3600,$runtime/3600/24);
	    }
	    if($o->{"user"}=~/^ERROR/) {
		$infostr.=sprintf("  Color:       red\n");
	    } else {
		$infostr.=sprintf("  Color:       %s\n",$self->{COLOROBJECT}->get_color("RUN",$o->{"user"}));
	    }

	}
    }
    return($infostr);
}

sub scale {
    my($n)=@_;
#    return($n);
#    printf("log: %2d -> %f\n",$n,log($n)/log(10));
    return(log($n+1)/log(10));
}


sub sec_to_day {
    my ($lsec)=@_;
    my($wdaystr);
    my ($sec,$min,$hours,$mday,$mon,$year,$wday,$rest)=localtime($lsec);
    $wdaystr=("Su","Mo","Tu","We","Th","Fr","Sa")[$wday];
#    my $llsec=$lsec/3600;
#    print "WF: sec_to_day $lsec $llsec -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> wday=$wday wdaystr=$wdaystr\n";
    return($wdaystr);
}

sub date_to_sec {
    my ($date)=@_;
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year $^O\n";
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
    return($timesec);
}

sub sec_to_date {
    my ($lsec)=@_;
    my($date);
    my ($sec,$min,$hours,$mday,$mon,$year,$rest)=localtime($lsec);
    $year=sprintf("%02d",$year % 100);
    $mon++;
    $date=sprintf("%02d/%02d/%02d-%02d:%02d:%02d",$mon,$mday,$year,$hours,$min,$sec);
#    print "WF: sec_to_date $lsec -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $date\n";
    return($date);
}

sub timediff {
    my ($date1,$date2)=@_;
#    print"WF: timediff $date1 $date2\n";
    my $timesec1=&date_to_sec($date1);
    my $timesec2=&date_to_sec($date2);
    return($timesec1-$timesec2);
}


sub update_left_cb {
    my($x,$y,$amount)=@_;
    my $self=$$selfref;
    my $dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    my $midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
#    print "WF: update_left_cb: $x,$y\n";
    if($x<$midx) {
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Resgraph","TIMEBACK",$self->{TIMEBACK}+$amount);
    } else {
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Resgraph","TIMEFORWARD",$self->{TIMEFORWARD}-$amount);
    }
    $self->resize_alloc() if($self->{DOALLOC});

}

sub update_right_cb {
    my($x,$y,$amount)=@_;
    my $self=$$selfref;
    my $dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    my $midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
#    print "WF: update_right_cb: $x,$y\n";
    if($x<$midx) {
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Resgraph","TIMEBACK",$self->{TIMEBACK}-$amount);
    } else {
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Resgraph","TIMEFORWARD",$self->{TIMEFORWARD}+$amount);
    }
    $self->resize_alloc() if($self->{DOALLOC});
}

sub update_left_left_cb {
    my $self=$$selfref;
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Resgraph","TIMEBACK",$self->{TIMEBACK}+2);
    $self->resize_alloc() if($self->{DOALLOC});
}
sub update_left_right_cb {
    my $self=$$selfref;
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Resgraph","TIMEBACK",$self->{TIMEBACK}-2);
    $self->resize_alloc() if($self->{DOALLOC});
}

sub update_right_left_cb {
    my $self=$$selfref;
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Resgraph","TIMEFORWARD",$self->{TIMEFORWARD}-2);
    $self->resize_alloc() if($self->{DOALLOC});
}
sub update_right_right_cb {
    my $self=$$selfref;
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Resgraph","TIMEFORWARD",$self->{TIMEFORWARD}+2);
    $self->resize_alloc() if($self->{DOALLOC});
}

sub selectalloc {
    my $self=$$selfref;
    my ($what)=@_;
#    print "WF: selectalloc: $what\n";
    # reset marker
    $self->{CANVAS}->itemconfigure('allocMarker',-fill => "darkred");
    # set new marker
    $self->{CANVAS}->itemconfigure($what,-fill => "red");
    $self->{ALLOCWHAT}=$what;
}

sub motionalloc {
    my $self=$$selfref;
    my $dataobj=$self->{DATAOBJECT};
    my ($what,$c)=@_;
    my $e = $c->XEvent;
    my($x, $y, $err) = ($e->x, $e->y, 0);
    my $newX = int($c->canvasx($x));
    my $newY = int($c->canvasy($y));

    if ($what eq "allocC") {
	my $diffx=$newX-($self->{ALLOCRECTX}+$self->{ALLOCRECTW}/2);
	my $diffy=$newY-($self->{ALLOCRECTY}+$self->{ALLOCRECTH}/2);
#	print "WF: motionalloc: $what $x,$y $newX $newY -> $diffx $diffy\n";
#	$self->{CANVAS}->move('alloc',$diffx,$diffy);
	$self->{ALLOCRECTX}+=$diffx;
	$self->{ALLOCRECTY}+=$diffy;
    } 
    if ($what eq "allocUL") {
#	print "WF: motionalloc: $what $x,$y $self->{ALLOCRECTX} $self->{ALLOCRECTY} -> $newX $newY\n";
	my $diffx=$newX-($self->{ALLOCRECTX});
	my $diffy=$newY-($self->{ALLOCRECTY});
	$self->{ALLOCRECTX}+=$diffx;
	$self->{ALLOCRECTY}+=$diffy;
	$self->{ALLOCRECTW}-=$diffx;
	$self->{ALLOCRECTH}-=$diffy;
    } 
    if ($what eq "allocLR") {
#	print "WF: motionalloc: $what $x,$y $self->{ALLOCRECTX} $self->{ALLOCRECTY} -> $newX $newY\n";
	my $diffx=$newX-($self->{ALLOCRECTX}+$self->{ALLOCRECTW});
	my $diffy=$newY-($self->{ALLOCRECTY}+$self->{ALLOCRECTH});
	$self->{ALLOCRECTW}+=$diffx;
	$self->{ALLOCRECTH}+=$diffy;
    } 
    

    # calculate new reservation characteristics, adjust to grid
    my $nowinsec=&date_to_sec($dataobj->{MACHSTATE}->{"system_time"});
    my $allocstart0=(($self->{ALLOCRECTX}-$self->{MIDX})/$self->{DX}) * 3600 + $nowinsec;
    my $gridx=$self->{ALLOCGRIDX}*60;
    my $allocstartinsec=int(($allocstart0+$gridx/2)/$gridx)*$gridx;
    $self->{ALLOCSTARTDATE}=&sec_to_date($allocstartinsec);

    my $allocwidthinsec=$self->{ALLOCRECTW}/$self->{DX}*3600;
    my $newwidthinsec=int(($allocwidthinsec+$gridx/2)/$gridx)*$gridx;
    $self->{ALLOCRECTW}=int($newwidthinsec/3600*$self->{DX});
    $self->{ALLOCENDDATE}  =&sec_to_date($allocstartinsec+$newwidthinsec);

    my $allocposy=$self->{ALLOCRECTY}-$self->{POSY};
    $self->{ALLOCRECTY}=int(int(($allocposy+$self->{DY}/2)/$self->{DY})*$self->{DY}+$self->{POSY});
    my $allocheight=$self->{ALLOCRECTH};
    $self->{ALLOCRECTH}=int(int(($allocheight+$self->{DY}/2)/$self->{DY})*$self->{DY});
    

    $self->resize_alloc();
}


sub setup_alloc {
    my($self) = shift;
    my $canvas=$self->{CANVAS};
    my ($id,$allocbuttonwidget);
    $self->{ALLOCRECT}->{ALLOC}=$id=$canvas->createRectangle($self->{ALLOCRECTX},$self->{ALLOCRECTY},
							     $self->{ALLOCRECTX}+$self->{ALLOCRECTW},
							     $self->{ALLOCRECTY}+$self->{ALLOCRECTH},
							     -fill => "grey30", 
							     -tags => ["allocALL","resgraph","alloc"]);
    push(@{$self->{FIXEDITEMS}},$id);
    
    $self->{ALLOCRECT}->{ALLOCUL}=$id=$canvas->createRectangle($self->{ALLOCRECTX},$self->{ALLOCRECTY},
							       $self->{ALLOCRECTX}+$self->{ALLOCMARKERWIDTH},
							       $self->{ALLOCRECTY}+$self->{ALLOCMARKERWIDTH},
							       -fill => "darkred", 
							       -tags => ["allocUL","resgraph","alloc","allocMarker"]);
    push(@{$self->{FIXEDITEMS}},$id);
    
    $self->{ALLOCRECT}->{ALLOCLR}=$id=$canvas->createRectangle($self->{ALLOCRECTX}+$self->{ALLOCRECTW}
							       -$self->{ALLOCMARKERWIDTH},
							       $self->{ALLOCRECTY}+$self->{ALLOCRECTH}
							       -$self->{ALLOCMARKERWIDTH},
							       $self->{ALLOCRECTX}+$self->{ALLOCRECTW},
							       $self->{ALLOCRECTY}+$self->{ALLOCRECTH},
							       -fill => "darkred", 
							       -tags => ["allocLR","resgraph","alloc","allocMarker"]);
    push(@{$self->{FIXEDITEMS}},$id);
    
    $self->{ALLOCRECT}->{ALLOCC}=$id=$canvas->createRectangle($self->{ALLOCRECTX}+$self->{ALLOCRECTW}/2
							      -$self->{ALLOCMARKERWIDTH}/2,
							      $self->{ALLOCRECTY}+$self->{ALLOCRECTH}/2
							      -$self->{ALLOCMARKERWIDTH}/2,
							      $self->{ALLOCRECTX}+$self->{ALLOCRECTW}/2
							      +$self->{ALLOCMARKERWIDTH}/2,
							      $self->{ALLOCRECTY}+$self->{ALLOCRECTH}/2
							      +$self->{ALLOCMARKERWIDTH}/2,
							      -fill => "darkred", 
							      -tags => ["allocC","resgraph","alloc","allocMarker"]);
    push(@{$self->{FIXEDITEMS}},$id);
    
    $canvas->bind("allocUL", '<1>' => [sub { &selectalloc("allocUL")}]);
    $canvas->bind("allocLR", '<1>' => [sub { &selectalloc("allocLR")}]);
    $canvas->bind("allocC", '<1>' => [sub { &selectalloc("allocC")}]);
    
    $canvas->bind("allocC", '<B1-Motion>' => [sub { my ($c) = @_;
						    &motionalloc("allocC",$c)}]);
    $canvas->bind("allocUL", '<B1-Motion>' => [sub { my ($c) = @_;
						     &motionalloc("allocUL",$c)}]);
    $canvas->bind("allocLR", '<B1-Motion>' => [sub { my ($c) = @_;
						     &motionalloc("allocLR",$c)}]);

    $id=$canvas->Button(-text => 'Alloc',
			-command => sub { &toggle_alloc_panel_cb();},
#			-width => 12,
#			-height => 12,
			-font => $self->{BFONT1},
			, -background => "darkred"
			, -foreground => "white"
			)->pack(-side => 'left');
    $allocbuttonwidget = $canvas->createWindow($self->{POSX}+$self->{WIDTH}-50,$self->{POSY}+25, -window =>$id, -anchor => "sw");
    push(@{$self->{FIXEDITEMS}},$allocbuttonwidget);

    
}

sub resize_alloc {
    my($self) = shift;
    my $canvas=$self->{CANVAS};
    my $dataobj=$self->{DATAOBJECT};
    my $frames=$dataobj->{FRAMES};
    

    
    # recalculate from date
    my $nowinsec=&date_to_sec($dataobj->{MACHSTATE}->{"system_time"});
    $self->{ALLOCRECTX}=int(int(&date_to_sec($self->{ALLOCSTARTDATE})-$nowinsec)/3600*$self->{DX}+$self->{MIDX});

    $self->{ALLOCRECTSPEC}=$self->{ALLOCRECTW}."x".$self->{ALLOCRECTH}."+".$self->{ALLOCRECTX}."+".$self->{ALLOCRECTY};

    ($self->{ALLOCSTARTDATEF}->{MONTH},$self->{ALLOCSTARTDATEF}->{MDAY},$self->{ALLOCSTARTDATEF}->{YEAR},
     $self->{ALLOCSTARTDATEF}->{HOUR},$self->{ALLOCSTARTDATEF}->{MIN},$self->{ALLOCSTARTDATEF}->{SEC})
	=split(/[ :\/\-]/,$self->{ALLOCSTARTDATE});
    ($self->{ALLOCENDDATEF}->{MONTH},$self->{ALLOCENDDATEF}->{MDAY},$self->{ALLOCENDDATEF}->{YEAR},
     $self->{ALLOCENDDATEF}->{HOUR},$self->{ALLOCENDDATEF}->{MIN},$self->{ALLOCENDDATEF}->{SEC})
	=split(/[ :\/\-]/,$self->{ALLOCENDDATE});

    $self->{ALLOCRECTW}=int((&date_to_sec($self->{ALLOCENDDATE})-&date_to_sec($self->{ALLOCSTARTDATE}))/3600*$self->{DX});

    # reset values if necessary
#    $self->{ALLOCRECTW}=3*$self->{ALLOCMARKERWIDTH} if($self->{ALLOCRECTW}<3*$self->{ALLOCMARKERWIDTH});
    $self->{ALLOCRECTH}=3*$self->{ALLOCMARKERWIDTH} if($self->{ALLOCRECTH}<3*$self->{ALLOCMARKERWIDTH});

    # select Partition
    if(int($self->{ALLOCRECTH}) eq int($self->{DY})) {
	my $n=$frames-int(($self->{ALLOCRECTY}-$self->{POSY}+$self->{DY}/2)/$self->{DY});
#	print "WF: $self->{ALLOCRECTY}-$self->{POSY} $self->{DY}",(($self->{ALLOCRECTY}-$self->{POSY})/$self->{DY})," ($n)\n";
 	$self->{ALLOCPARTITION}=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$self->{ALLOCPARTITION}=~s/-M//gs;
    }
    if(int($self->{ALLOCRECTH}) eq int(2*$self->{DY})) {
	my $n=$frames-int(($self->{ALLOCRECTY}-$self->{POSY})/$self->{DY})-1;
 	$self->{ALLOCPARTITION}=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$self->{ALLOCPARTITION}=~s/-M\d//gs;
    }
    if(int($self->{ALLOCRECTH}) eq int(4*$self->{DY})) {
	my $n=$frames-int(($self->{ALLOCRECTY}-$self->{POSY})/$self->{DY})-1;
 	$self->{ALLOCPARTITION}=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$self->{ALLOCPARTITION}=~s/\d-M\d//gs;
	$self->{ALLOCPARTITION}=~s/R/Row/gs;
    }
    if(int($self->{ALLOCRECTH}) eq int(8*$self->{DY})) {
	my $n=$frames-int(($self->{ALLOCRECTY}-$self->{POSY})/$self->{DY})-1;
	$self->{ALLOCPARTITION}="Cube01" if($n<=8);
	$self->{ALLOCPARTITION}="Cube23" if($n>8);
    }
    if(int($self->{ALLOCRECTH}) eq int($frames*$self->{DY})) {
	$self->{ALLOCPARTITION}="ALL";
    }
    if(int($self->{ALLOCRECTH}) eq int(($frames-2)*$self->{DY})) {
	my $n=$frames-int(($self->{ALLOCRECTY}-$self->{POSY})/$self->{DY})-1;
 	$self->{ALLOCPARTITION}=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$self->{ALLOCPARTITION}=~s/-M\d//gs;
	$self->{ALLOCPARTITION}=~s/R\d/Col/gs;
    }
    # set command
    $self->{ALLOCCOMMAND}="ssh ".$self->{ALLOCSSHUSERID}."\@".$self->{ALLOCSSHHOST}." " if($self->{ALLOCDOSSH});
    $self->{ALLOCCOMMAND}="" if(!$self->{ALLOCDOSSH});
    $self->{ALLOCCOMMAND}.=sprintf("%s 20%02d.%02d.%02d_%02d:%02d 20%02d.%02d.%02d_%02d:%02d %s 1 %s %s",
				   "/usr/local/bin/sched_bgl -a",
				   $self->{ALLOCSTARTDATEF}->{YEAR},
				   $self->{ALLOCSTARTDATEF}->{MONTH},
				   $self->{ALLOCSTARTDATEF}->{MDAY},
				   $self->{ALLOCSTARTDATEF}->{HOUR},
				   $self->{ALLOCSTARTDATEF}->{MIN},

				   $self->{ALLOCENDDATEF}->{YEAR},
				   $self->{ALLOCENDDATEF}->{MONTH},
				   $self->{ALLOCENDDATEF}->{MDAY},
				   $self->{ALLOCENDDATEF}->{HOUR},
				   $self->{ALLOCENDDATEF}->{MIN},
				   $self->{ALLOCPARTITION},
				   $self->{ALLOCSPECIALUID},
				   ($self->{ALLOCSCRIPT})?"-x ".$self->{ALLOCSCRIPT}:" "
				   );

    my $diff=&timediff($self->{ALLOCENDDATE},$self->{ALLOCSTARTDATE});
    $self->{ALLOCDURATION}=sprintf("%3d:%02d",int($diff/3600),int(($diff/3600-int($diff/3600))*60+0.5));


    $canvas->coords("allocALL",
		    $self->{ALLOCRECTX},$self->{ALLOCRECTY},
		    $self->{ALLOCRECTX}+$self->{ALLOCRECTW},
		    $self->{ALLOCRECTY}+$self->{ALLOCRECTH});
   
    $canvas->coords("allocUL",
		    $self->{ALLOCRECTX},$self->{ALLOCRECTY},
		    $self->{ALLOCRECTX}+$self->{ALLOCMARKERWIDTH},
		    $self->{ALLOCRECTY}+$self->{ALLOCMARKERWIDTH});
	
    $canvas->coords("allocLR",
		    $self->{ALLOCRECTX}+$self->{ALLOCRECTW}-$self->{ALLOCMARKERWIDTH},
		    $self->{ALLOCRECTY}+$self->{ALLOCRECTH}-$self->{ALLOCMARKERWIDTH},
		    $self->{ALLOCRECTX}+$self->{ALLOCRECTW},
		    $self->{ALLOCRECTY}+$self->{ALLOCRECTH});
    
    $canvas->coords("allocC",
		    $self->{ALLOCRECTX}+$self->{ALLOCRECTW}/2-$self->{ALLOCMARKERWIDTH}/2,
		    $self->{ALLOCRECTY}+$self->{ALLOCRECTH}/2-$self->{ALLOCMARKERWIDTH}/2,
		    $self->{ALLOCRECTX}+$self->{ALLOCRECTW}/2+$self->{ALLOCMARKERWIDTH}/2,
		    $self->{ALLOCRECTY}+$self->{ALLOCRECTH}/2+$self->{ALLOCMARKERWIDTH}/2);
}

sub build_alloc_panel {
    my($self) = shift;
    my($allocwin,$field,$sep,$i);
    $allocwin=$self->{TLWIN}=$self->{CANVAS}->Toplevel(-width => $self->{ALLOCWIDTH},-height => $self->{ALLOCHEIGHT});
    $allocwin->title("LLview: Allocation panel");
    $allocwin->bind('<Control-KeyPress-a>' => [ \&toggle_alloc_panel_cb ]);
    $allocwin->bind('<Control-KeyPress-q>' => [ \&toggle_alloc_panel_cb ]);

    my $frame1=$allocwin->Frame( -relief => "sunken", 
				 -background => "darkgreen",
				 -borderwidth => 1)->pack(-side => "top", 
							  -anchor =>"w");
    $frame1->Label(-text    => "Current settings:", 
		   -anchor => "w", -width=>20,
		   )->pack(-side => "left");
    $frame1->Label(-text    => "from", 
		   -anchor => "w", -width=>4,
		   )->pack(-side => "left");
    $frame1->Label(-textvariable => \$self->{ALLOCSTARTDATE}, 
		   -anchor => "w", -width=>18,
		   -background => "grey80",
		   -foreground => "darkgreen"
		   )->pack(-side => "left");
    $frame1->Label(-text    => "to", 
		   -anchor => "w", -width=>2,
		   )->pack(-side => "left");
    $frame1->Label(-textvariable => \$self->{ALLOCENDDATE}, 
		   -anchor => "w", -width=>18,
		   -background => "grey80",
		   -foreground => "darkgreen"
		   )->pack(-side => "left");
    $frame1->Label(-text    => "duration", 
		   -anchor => "w", -width=>8,
		   )->pack(-side => "left");
    $frame1->Label(-textvariable => \$self->{ALLOCDURATION}, 
		   -anchor => "w", -width=>5,
		   -background => "grey80",
		   -foreground => "darkgreen"
		   )->pack(-side => "left");
    $frame1->Label(-text    => "hours", 
		   -anchor => "w", -width=>5,
		   )->pack(-side => "left");
#    $frame1->Label(-textvariable => \$self->{ALLOCRECTSPEC}, -anchor => "w", -width=>16)->pack(-side => "left");

    my $frame2=$allocwin->Frame( -relief => "sunken", 
				 -borderwidth => 1)->pack(-side => "top", 
							  -anchor =>"w");
    my %separray=("MONTH"=>"/", "MDAY"=>"/", "YEAR"=>" ","HOUR"=>":","MIN"=>":","SEC"=>" ");

    $frame2->Label(-text    => "from", 
		   -anchor => "w", -width=>4,
		   )->pack(-side => "left");
    foreach $i ("MONTH","MDAY","YEAR","HOUR","MIN","SEC") {
	$sep=$separray{$i};
	$field=$frame2->Entry(-textvariable => \$self->{ALLOCSTARTDATEF}->{$i},
		      -width => 2,-background => "white", -foreground => "blue"
			      )->pack(-side => "left");
	$field->bind( "<Key-Return>" => sub {\&from_date_cb();});
	$field->bind( "<Key-Tab>"    => sub {\&from_date_cb();});
	$field->bind( "<Key-Up>"     => sub {$self->{ALLOCSTARTDATEF}->{$i}=sprintf("%02d",$self->{ALLOCSTARTDATEF}->{$i}+1);
					     \&from_date_cb();} );
	$field->bind( "<Key-Down>"   => sub {$self->{ALLOCSTARTDATEF}->{$i}=sprintf("%02d",$self->{ALLOCSTARTDATEF}->{$i}-1);
					     \&from_date_cb();} );
	$field->bind( "<Key-Prior>"  => sub {$self->{ALLOCSTARTDATEF}->{$i}=sprintf("%02d",$self->{ALLOCSTARTDATEF}->{$i}+5);
					     \&from_date_cb();} );
	$field->bind( "<Key-Next>"   => sub {$self->{ALLOCSTARTDATEF}->{$i}=sprintf("%02d",$self->{ALLOCSTARTDATEF}->{$i}-5);
					     \&from_date_cb();} );
	$frame2->Label(-text => $sep, -anchor => "w", -width=>1)->pack(-side => "left");
    }
    $frame2->Label(-text    => "to", 
		   -anchor => "w", -width=>2,
		   )->pack(-side => "left");
    foreach $i ("MONTH","MDAY","YEAR","HOUR","MIN","SEC") {
	$sep=$separray{$i};
	$field=$frame2->Entry(-textvariable => \$self->{ALLOCENDDATEF}->{$i},
		      -width => 2,-background => "white", -foreground => "blue"
			      )->pack(-side => "left");
	$field->bind( "<Key-Return>" => sub {\&to_date_cb();});
	$field->bind( "<Key-Tab>"    => sub {\&to_date_cb();});
	$field->bind( "<Key-Up>"     => sub {$self->{ALLOCENDDATEF}->{$i}=sprintf("%02d",$self->{ALLOCENDDATEF}->{$i}+1);
					     \&to_date_cb();} );
	$field->bind( "<Key-Down>"   => sub {$self->{ALLOCENDDATEF}->{$i}=sprintf("%02d",$self->{ALLOCENDDATEF}->{$i}-1);
					     \&to_date_cb();} );
	$field->bind( "<Key-Prior>"  => sub {$self->{ALLOCENDDATEF}->{$i}=sprintf("%02d",$self->{ALLOCENDDATEF}->{$i}+5);
					     \&to_date_cb();} );
	$field->bind( "<Key-Next>"   => sub {$self->{ALLOCENDDATEF}->{$i}=sprintf("%02d",$self->{ALLOCENDDATEF}->{$i}-5);
					     \&to_date_cb();} );
	$frame2->Label(-text => $sep, -anchor => "w", -width=>1)->pack(-side => "left");
    }

    my $frame3=$allocwin->Frame( -relief => "sunken", 
				 -borderwidth => 1)->pack(-side => "top", 
							  -anchor =>"w");
    $frame3->Label(-text => "Partition", -anchor => "w", -width=>9)->pack(-side => "left");
    $field=$frame3->Entry(-textvariable => \$self->{ALLOCPARTITION},
			  -width => 20,-background => "white", -foreground => "blue"
			  )->pack(-side => "left");
    $field->bind( "<Key-Return>" => sub {\&to_date_cb();});
    $field->bind( "<Key-Tab>"    => sub {\&to_date_cb();});
    $frame3->Label(-text => "for Userid", -anchor => "w", -width=>9)->pack(-side => "left");
    $field=$frame3->Entry(-textvariable => \$self->{ALLOCSPECIALUID},
			  -width => 10,-background => "white", -foreground => "blue"
			  )->pack(-side => "left");
    $field->bind( "<Key-Return>" => sub {\&to_date_cb();});
    $field->bind( "<Key-Tab>"    => sub {\&to_date_cb();});
        
    my $frame4=$allocwin->Frame( -relief => "sunken", 
				 -borderwidth => 1)->pack(-side => "top", 
							  -anchor =>"w");
    $frame4->Button(-text => 'Allocate',
		    -command => sub { &do_allocate();},
		    -font => $self->{BFONT1},
		    , -background => "grey85"
		    )->pack(-side => 'left');
    
    my $frame4a=$allocwin->Frame( -relief => "sunken", 
				 -borderwidth => 1)->pack(-side => "top", 
							  -anchor =>"w");
    $frame4a->Label(-text => "Script", -anchor => "w", -width=>9)->pack(-side => "left");
    $field=$frame4a->Entry(-textvariable => \$self->{ALLOCSCRIPT},
			  -width => 110,-background => "white", -foreground => "blue"
			  )->pack(-side => "left");
    $field->bind( "<Key-Return>" => sub {\&to_date_cb();});
    $field->bind( "<Key-Tab>"    => sub {\&to_date_cb();});


    my $frame5=$allocwin->Frame( -relief => "sunken", 
				 -borderwidth => 1)->pack(-side => "top", 
							  -anchor =>"w");
    $frame5->Label(-text => "Command", -anchor => "w", -width=>9)->pack(-side => "left");
    $field=$frame5->Entry(-textvariable => \$self->{ALLOCCOMMAND},
			  -width => 110,-background => "white", -foreground => "blue"
			  )->pack(-side => "left");

    my $frame6=$allocwin->Frame( -relief => "sunken", 
				 -borderwidth => 1)->pack(-side => "top", 
							  -anchor =>"w");
    $frame6->Label(-text => "Result", -anchor => "n", -width=>9)->pack(-side => "left");
    for($i=1;$i<10;$i++) {
	$self->{"ALLOCSTDOUT$i"}="-";
	$field=$frame6->Entry(-textvariable => \$self->{"ALLOCSTDOUT$i"},
			      -width => 110,-background => "grey90", -foreground => "darkgreen",
			      -relief => "flat", -border => 0
			      )->pack(-side => "top");
    }

    $self->{ALLOCWIN}=$allocwin;
    $self->{ALLOCACTIVATED} = 1;

}

sub from_date_cb {
    my $self=$$selfref;
    $self->{ALLOCSTARTDATE}=$self->{ALLOCSTARTDATEF}->{MONTH}."/"
	.$self->{ALLOCSTARTDATEF}->{MDAY}."/".$self->{ALLOCSTARTDATEF}->{YEAR}." ".
	$self->{ALLOCSTARTDATEF}->{HOUR}.":".$self->{ALLOCSTARTDATEF}->{MIN}.":".$self->{ALLOCSTARTDATEF}->{SEC};
    $self->resize_alloc();
}

sub to_date_cb {
    my $self=$$selfref;
    $self->{ALLOCENDDATE}=$self->{ALLOCENDDATEF}->{MONTH}."/"
	.$self->{ALLOCENDDATEF}->{MDAY}."/".$self->{ALLOCENDDATEF}->{YEAR}." ".
	$self->{ALLOCENDDATEF}->{HOUR}.":".$self->{ALLOCENDDATEF}->{MIN}.":".$self->{ALLOCENDDATEF}->{SEC};
    $self->resize_alloc();
}

sub toggle_alloc_panel_cb {
    my $self=$$selfref;
    if(($self->{ALLOCACTIVATED}) && (Exists($self->{ALLOCWIN}))) {
	&deactivate_alloc_panel();
    } else {
	&activate_alloc_panel();
    }
}

sub do_allocate {
    my $self=$$selfref;
    my ($i,$line);
    my $cmd=$self->{ALLOCCOMMAND};
    my @stdoutf=`$cmd`;
    $i=0;
    foreach $line (@stdoutf) {
	print "$line";
	$line=~s/\s*\n//gs;
	next if $line=~/^\s*$/;
	$i++;
	$self->{"ALLOCSTDOUT$i"}=$line;
    }
}

sub activate_alloc_panel {
    my $self=$$selfref;
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $infoobject=$self->{INFOOBJECT};
    my $canvas=$self->{CANVAS};
    
    print "LLview_gui_resgraph: activate_alloc_panel,",Exists($self->{ALLOCWIN})," \n" if($debug>=3);
    if(!Exists($self->{ALLOCWIN})) {
	$self->build_alloc_panel();
    }
    $self->{ALLOCWIN}->deiconify();
    $self->{ALLOCACTIVATED} = 1;
   
}

sub deactivate_alloc_panel {
    my $self=$$selfref;
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    $self->{ALLOCWIN}->withdraw();
    $self->{ALLOCACTIVATED} = 0;
}


1;

