# $Source: /cvs/cvsroot/llview/lib/LLview_gui_nodes.pm,v $
# $Author: zdv087 $
# $Revision: 1.78 $
# $Date: 2007/07/17 09:31:25 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_nodes;
use strict;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my($i);
    printf("\t\LLview_gui_nodes: new %s\n",ref($proto)) if($debug>=3);
    $self->{INSTPATH}= ".";
    $self->{POSX}       = 5;
    $self->{POSY}       = 25;
    $self->{WIDTH}      = 460;
    $self->{HEIGHT}     = 700;
    $self->{VERBOSE}    = 0;
    $self->{ACTROWX}    = 0;
    $self->{ACTROWY}    = 0;
    $self->{ACTROWDY}   = 0;
    $self->{ACTROWLASTELEMX}=-1;
    $self->{ACTROWLASTELEMY}=-1;
    $self->{ACTROWLASTELEMBX}=-1;
    $self->{ACTROWLASTELEMBY}=-1;
    $self->{NBOXX}  = [];
    $self->{NBOXY}  = [];
    $self->{LASTLLCPUS}= -1;
    $self->{LNAMES} = {}; 
    
    # Panel node box
    $self->{BOXCPUS}    = [2,4,8,16,32,64,"BGL"]; 
    # PE<=2
    $i=0;
    $self->{PRBOXDX}[$i]    = 12;
    $self->{PRBOXDY}[$i]    = 8;
    $self->{PRBOXPX}[$i]    = 0;
    $self->{PRBOXPY}[$i]    = 25;
    $self->{IMGSHOW}[$i]    = 0;
    $self->{IMGPOSX}[$i]    = 0;
    $self->{IMGPOSY}[$i]    = 30;
    $self->{IMGSIZEX}[$i]   = 32;
    $self->{SCALEDX}[$i]    = 34;
    $self->{SCALEDY}[$i]    = 5;
    $self->{SCALEPX}[$i]    = 14;
    $self->{SCALEPY}[$i]    = 14;
    $self->{SCALESHOW}[$i]  = 1;
    $self->{STATEPX}[$i]    = 0;
    $self->{STATEPY}[$i]    = 14;
    $self->{STATEDX}[$i]    = 14;
    $self->{STATEDY}[$i]    = 14;
    $self->{NAMEPX}[$i]     =  0;
    $self->{NAMEPY}[$i]     =  0;
    $self->{NAMEDX}[$i]     = 60;
    $self->{NAMEDY}[$i]     = 10;
    $self->{NAMEDOFRAME}[$i] = 0;
    $self->{NAMEMODE}[$i]   = 1; # 0 no display, 1 display, 2 display only if node not in running state 
    $self->{NAMEBGCOL}[$i]   = "DarkOrange3";
    $self->{IMAGE}[$i]      =  "lib/images/p655n.ppm";
    $self->{NUMBOXPERROW}[$i] = 2;

    # PE<=4
    $i=1;
    $self->{PRBOXDX}[$i]    = 12;
    $self->{PRBOXDY}[$i]    = 8;
    $self->{PRBOXPX}[$i]    = 0;
    $self->{PRBOXPY}[$i]    = 25;
    $self->{IMGSHOW}[$i]    = 0;
    $self->{IMGPOSX}[$i]    = 0;
    $self->{IMGPOSY}[$i]    = 30;
    $self->{IMGSIZEX}[$i]   = 32;
    $self->{SCALEDX}[$i]    = 34;
    $self->{SCALEDY}[$i]    = 5;
    $self->{SCALEPX}[$i]    = 14;
    $self->{SCALEPY}[$i]    = 14;
    $self->{SCALESHOW}[$i]  = 1;
    $self->{STATEPX}[$i]    = 0;
    $self->{STATEPY}[$i]    = 14;
    $self->{STATEDX}[$i]    = 14;
    $self->{STATEDY}[$i]    = 14;
    $self->{NAMEPX}[$i]     =  0;
    $self->{NAMEPY}[$i]     =  0;
    $self->{NAMEDX}[$i]     = 60;
    $self->{NAMEDY}[$i]     = 10;
    $self->{NAMEDOFRAME}[$i] = 0;
    $self->{NAMEMODE}[$i]   = 1; # 0 no display, 1 display, 2 display only if node not in running state 
    $self->{NAMEBGCOL}[$i]   = "DarkOrange3";
    $self->{IMAGE}[$i]      =  "lib/images/p655n.ppm";
    $self->{NUMBOXPERROW}[$i] = 4;

    # PE<=8
    $i=2;
    $self->{PRBOXDX}[$i]    = 12;
    $self->{PRBOXDY}[$i]    = 8;
    $self->{PRBOXPX}[$i]    = 0;
    $self->{PRBOXPY}[$i]    = 25;
    $self->{IMGSHOW}[$i]    = 0;
    $self->{IMGPOSX}[$i]    = 0;
    $self->{IMGPOSY}[$i]    = 0;
    $self->{IMGSIZEX}[$i]   = 32;
    $self->{SCALEDX}[$i]    = 34;
    $self->{SCALEDY}[$i]    = 5;
    $self->{SCALEPX}[$i]    = 14;
    $self->{SCALEPY}[$i]    = 14;
    $self->{SCALESHOW}[$i]  = 1;
    $self->{STATEPX}[$i]    = 0;
    $self->{STATEPY}[$i]    = 14;
    $self->{STATEDX}[$i]    = 14;
    $self->{STATEDY}[$i]    = 14;
    $self->{NAMEPX}[$i]     = 0;
    $self->{NAMEPY}[$i]     = 0;
    $self->{NAMEDX}[$i]     = 60;
    $self->{NAMEDY}[$i]     = 12;
    $self->{NAMEMODE}[$i]   = 1; # 0 no display, 1 display, 2 display only if node not in running state 
    $self->{NAMEDOFRAME}[$i] = 0;
    $self->{NAMEBGCOL}[$i]   = "DarkOrange3";
    $self->{IMAGE}[$i]      =  "lib/images/p655n.ppm";
    $self->{NUMBOXPERROW}[$i] = 4;

    # PE<=16
    $i=3;
    $self->{PRBOXDX}[$i]    = 8;
    $self->{PRBOXDY}[$i]    = 8;
    $self->{PRBOXPX}[$i]    = 40;
    $self->{PRBOXPY}[$i]    = 29;
    $self->{IMGSHOW}[$i]    = 1;
    $self->{IMGPOSX}[$i]    = 0;
    $self->{IMGPOSY}[$i]    = 26;
    $self->{IMGSIZEX}[$i]   = 32;
    $self->{SCALEDX}[$i]    = 55;
    $self->{SCALEDY}[$i]    = 5;
    $self->{SCALEPX}[$i]    = 17;
    $self->{SCALEPY}[$i]    = 14;
    $self->{SCALESHOW}[$i]  = 1;
    $self->{STATEPX}[$i]    = 2;
    $self->{STATEPY}[$i]    = 14;
    $self->{STATEDX}[$i]    = 14;
    $self->{STATEDY}[$i]    = 14;
    $self->{NAMEPX}[$i]     = 0;
    $self->{NAMEPY}[$i]     = 0;
    $self->{NAMEDX}[$i]     = 60;
    $self->{NAMEDY}[$i]     = 12;
    $self->{NAMEMODE}[$i]   = 1; # 0 no display, 1 display, 2 display only if node not in running state 
    $self->{NAMEDOFRAME}[$i] = 0;
    $self->{NAMEBGCOL}[$i]   = "DarkOrange3";
    $self->{IMAGE}[$i]      = "lib/images/p690-angle_n.ppm";
    $self->{NUMBOXPERROW}[$i] = 4;

    # PE<=32
    $i=4;
    $self->{PRBOXDX}[$i]    = 8;
    $self->{PRBOXDY}[$i]    = 8;
    $self->{PRBOXPX}[$i]    = 40;
    $self->{PRBOXPY}[$i]    = 29;
    $self->{IMGSHOW}[$i]    = 1;
    $self->{IMGPOSX}[$i]    = 0;
    $self->{IMGPOSY}[$i]    = 26;
    $self->{IMGSIZEX}[$i]   = 32;
    $self->{SCALEDX}[$i]    = 55;
    $self->{SCALEDY}[$i]    = 5;
    $self->{SCALEPX}[$i]    = 17;
    $self->{SCALEPY}[$i]    = 14;
    $self->{SCALESHOW}[$i]  = 1;
    $self->{STATEPX}[$i]    = 2;
    $self->{STATEPY}[$i]    = 14;
    $self->{STATEDX}[$i]    = 14;
    $self->{STATEDY}[$i]    = 14;
    $self->{NAMEPX}[$i]     = 0;
    $self->{NAMEPY}[$i]     = 0;
    $self->{NAMEDX}[$i]     = 25;
    $self->{NAMEDY}[$i]     = 12;
    $self->{NAMEMODE}[$i]   = 1; # 0 no display, 1 display, 2 display only if node not in running state 
    $self->{NAMEDOFRAME}[$i] = 0;
    $self->{NAMEBGCOL}[$i]   = "DarkOrange3";
    $self->{IMAGE}[$i]      = "lib/images/p690-angle_n.ppm";
    $self->{NUMBOXPERROW}[$i] = 4;

    # PE<=64
    $i=5;
    $self->{PRBOXDX}[$i]    = 8;
    $self->{PRBOXDY}[$i]    = 8;
    $self->{PRBOXPX}[$i]    = 40;
    $self->{PRBOXPY}[$i]    = 29;
    $self->{IMGSHOW}[$i]    = 1;
    $self->{IMGPOSX}[$i]    = 0;
    $self->{IMGPOSY}[$i]    = 26;
    $self->{IMGSIZEX}[$i]   = 32;
    $self->{SCALEDX}[$i]    = 55;
    $self->{SCALEDY}[$i]    = 5;
    $self->{SCALEPX}[$i]    = 17;
    $self->{SCALEPY}[$i]    = 14;
    $self->{SCALESHOW}[$i]  = 1;
    $self->{STATEPX}[$i]    = 2;
    $self->{STATEPY}[$i]    = 14;
    $self->{STATEDX}[$i]    = 14;
    $self->{STATEDY}[$i]    = 14;
    $self->{NAMEPX}[$i]     = 0;
    $self->{NAMEPY}[$i]     = 0;
    $self->{NAMEDX}[$i]     = 60;
    $self->{NAMEDY}[$i]     = 12;
    $self->{NAMEMODE}[$i]   = 1; # 0 no display, 1 display, 2 display only if node not in running state 
    $self->{NAMEDOFRAME}[$i] = 0;
    $self->{NAMEBGCOL}[$i]   = "DarkOrange3";
    $self->{IMAGE}[$i]      = "lib/images/p690-angle_n.ppm";
    $self->{NUMBOXPERROW}[$i] = 4;

    # BGL midplane
    $i=6;
    $self->{PRBOXDX}[$i]    = 8;
    $self->{PRBOXDY}[$i]    = 8;
    $self->{PRBOXPX}[$i]    = 40;
    $self->{PRBOXPY}[$i]    = 29;
    $self->{IMGSHOW}[$i]    = 1;
    $self->{IMGPOSX}[$i]    = 0;
    $self->{IMGPOSY}[$i]    = 26;
    $self->{IMGSIZEX}[$i]   = 32;
    $self->{SCALEDX}[$i]    = 55;
    $self->{SCALEDY}[$i]    = 5;
    $self->{SCALEPX}[$i]    = 17;
    $self->{SCALEPY}[$i]    = 14;
    $self->{SCALESHOW}[$i]  = 0;
    $self->{STATEPX}[$i]    = 2;
    $self->{STATEPY}[$i]    = 14;
    $self->{STATEDX}[$i]    = 14;
    $self->{STATEDY}[$i]    = 14;
    $self->{NAMEPX}[$i]     = 0;
    $self->{NAMEPY}[$i]     = 0;
    $self->{NAMEDX}[$i]     = 80;
    $self->{NAMEDY}[$i]     = 12;
    $self->{RACKPERPIC}[$i] = 2;
    $self->{LINEBREAK}[$i]  = 2;
    $self->{ADDOFFX}[$i]    = 0;
    $self->{ADDOFFY}[$i]    = 0;
    $self->{TEXTTYPE}[$i]   = 1;
    $self->{BOXGAP}[$i]   = 0;
    $self->{NAMEMODE}[$i]   = 1; # 0 no display, 1 display, 2 display only if node not in running state 
    $self->{NAMEDOFRAME}[$i] = 1;
    $self->{NAMEBGCOL}[$i]   = "DarkOrange3";
    $self->{IMAGE}[$i]      = "lib/images/bgls.ppm";
    $self->{NUMBOXPERROW}[$i] = 4;

    $self->{DOUSERLAYOUT}     = 0;
    $self->{USERLAYOUT}     = ".*";
    $self->{USERLAYOUTSCANNAMES}=0;
    $self->{USERLAYOUTRACKSPERROW}=8;
    $self->{USERLAYOUTXGAP}=10;
    $self->{USERLAYOUTYGAP}=10;

    $self->{DOINOUT}     = 1;
    $self->{INOUTMARKPX} = 10;
    $self->{INOUTMARKPY} = 730;
    $self->{MARGINBOXW}= 2;
    $self->{MARGINBOXE}= 2;
    $self->{MARGINBOXN}= 3;
    $self->{MARGINBOXS}= 3;
    $self->{LAYOUTDEBUG}=0;
    $self->{BOXCOLOR}="grey85";

    $self->{DOLOGO}     = 0;
    $self->{LOGOPX}     = 10;
    $self->{LOGOPY}     = 730;
    $self->{LOGOIMAGE}  = "lib/images/Jubl-Logo-big3.gif";

    $self->{DOLOGON}     = 0;
    $self->{LOGONPX}     = 350;
    $self->{LOGONPY}     = 645;
    $self->{LOGONCOLOR}  = "darkblue";
    $self->{LOGONTEXT}   = "-";


    $self->{CPU_PER_INI}=0.5;
    $self->{MEM_PER_INI}=0.8;
    $self->{MEMREQ_PER_INI}=0.8;
    $self->{MEMUSED_PER_INI}=0.1;

    $self->{BUILDREADY}=0;
    $self->{BUILDFIXEDREADY}=0;

    $self->{FRAMES}  =  1;


    $self->{PRBOXPOSX}  = [];
    $self->{PRBOXPOSY}  = [];
    $self->{PRBOX}      = [];
    $self->{ITEMS}      = [];
    $self->{STATUSTXT}  = [];

    $self->{FONT1}      = "-*-Helvetica-Bold-R-Normal--*-80-*-*-*-*-*-*";
    $self->{FONT2}       = "-*-Helvetica-Medium-R-Normal--*-90-*-*-*-*-*-*";
    $self->{FONT3}       = "-*-Times-Medium-R-Normal--*-120-*-*-*-*-*-*";
    $self->{FONT4}       = "-*-Helvetica-Bold-R-Normal--*-280-*-*-*-*-*-*";

    $self->{STATUSCOLOR} = {
	'Ru' => 'darkgreen',
	'Do' => 'red',
	'Bu' => 'darkred',
	'Id' => 'blue',
	'No' => 'black',
	'of' => 'red',
	'Ab' => 'red',
	'pa' => 'red',
	'er' => 'red'
	};

    $self->{CPUCOLORS} = {
	'=' => 'grey40',                  
	'-' => 'white',
	' ' => 'grey85',                     
	'!' => 'grey25',                  
	'%' => 'grey45',                  
	};
    
    bless $self, $class;
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($n,$id,$i);
    my($marker,$cpus);
    my $frames=$dataobj->{FRAMES};

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;

    $optobj->register_option("Nodes","POSX", -label => "X position", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option("Nodes","POSY", -label => "Y position", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSY}, -step => 10);

    $optobj->register_option("Nodes","HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 1280, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option("Nodes","WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option("Nodes","MARGINBOXW", -label => "Box Margin West", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 0, -max => 200, -default => $self->{MARGINBOXW}, -step => 1);
    $optobj->register_option("Nodes","MARGINBOXE", -label => "Box Margin East", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 200, -default => $self->{MARGINBOXE}, -step => 1);
    $optobj->register_option("Nodes","MARGINBOXN", -label => "Box Margin North", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 0, -max => 200, -default => $self->{MARGINBOXN}, -step => 1);
    $optobj->register_option("Nodes","MARGINBOXS", -label => "Box Margin South", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 200, -default => $self->{MARGINBOXS}, -step => 1);

    $optobj->register_option("Nodes","LAYOUTDEBUG", -label => "Debug Layout", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{LAYOUTDEBUG});
    $optobj->register_option("Nodes","BOXCOLOR", -label => "BOX Color", 
			     -caller => $self, -pack => 1,
			     -type => "string", -default => $self->{BOXCOLOR});

    $optobj->register_option("Nodes","DOUSERLAYOUT", -label => "use User Layout", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{DOUSERLAYOUT});
    $optobj->register_option("Nodes","USERLAYOUT", -label => "Layout", 
			     -caller => $self,-pack => 1, -fieldwidth => 100,
			     -type => "string", -default => $self->{USERLAYOUT});
    $optobj->register_option("Nodes","USERLAYOUTSCANNAMES", -label => "named racksx", 
			     -caller => $self,-pack => 1, -fieldwidth => 100,
			     -type => "radio", -default => $self->{USERLAYOUTSCANNAMES});
    $optobj->register_option("Nodes","USERLAYOUTRACKSPERROW", -label => "Racks per Row", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 0, -max => 200, -default => $self->{USERLAYOUTRACKSPERROW}, -step => 1);

    $optobj->register_option("Nodes","USERLAYOUTXGAP", -label => "Rack gap X", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 0, -max => 200, -default => $self->{USERLAYOUTXGAP}, -step => 1);
    $optobj->register_option("Nodes","USERLAYOUTYGAP", -label => "Rack gap Y", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 200, -default => $self->{USERLAYOUTYGAP}, -step => 1);


    for($i=0;$i<=$#{$self->{BOXCPUS}};$i++) {
	if($self->{BOXCPUS}[$i] ne "BGL") {
	    $cpus=sprintf("%02d",$self->{BOXCPUS}[$i]);
	} else {
	    $cpus="BGL";
	}
	$marker="NodeBox";
	$optobj->register_option($marker,"PRBOXPX", -label => "Proc. rel. pos. X", 
				 -caller => $self,-pack => 1, -subtype => "$cpus",
				 -type => "int", -min => -10, -max => 200, -default => $self->{PRBOXPX}[$i], -step => 2);
	$optobj->register_option($marker,"PRBOXPY", -label => "Proc. rel. pos. Y", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => 0, -max => 200, -default => $self->{PRBOXPY}[$i], -step => 2);
	$optobj->register_option($marker,"PRBOXDX", -label => "Proc. Box Width", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => 2, -max => 64, -default => $self->{PRBOXDX}[$i], -step => 1);
	$optobj->register_option($marker,"PRBOXDY", -label => "Proc. Box Height", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => 2, -max => 64, -default => $self->{PRBOXDY}[$i], -step => 1);
	

	$optobj->register_option($marker,"IMGSIZEX", -label => "Image Width", 
				 -caller => $self,-pack => 1, -subtype => "$cpus",
				 -type => "int", -min => 8, -max => 128, -default => $self->{IMGSIZEX}[$i], -step => 2);
	$optobj->register_option($marker,"IMGPOSX", -label => "Image rel. pos. X", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => -10, -max => 20, -default => $self->{IMGPOSX}[$i], -step => 2);
	
	$optobj->register_option($marker,"IMGPOSY", -label => "Image rel. pos. Y", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => 0, -max => 200, -default => $self->{IMGPOSY}[$i], -step => 2);
	$optobj->register_option($marker,"IMGSHOW", -label => "Show Image", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "radio", -default => $self->{IMGSHOW}[$i]);

	$optobj->register_option($marker,"IMAGE", -label => "Image name", 
				 -caller => $self,-pack => 1, -subtype => "$cpus",
				 -type => "string", -default => $self->{IMAGE}[$i]);
	
	$optobj->register_option($marker,"SCALEDX", -label => "Bars Width", 
				 -caller => $self,-pack => 1, -subtype => "$cpus",
				 -type => "int", -min => 2, -max => 64, -default => $self->{SCALEDX}[$i], -step => 1);
	$optobj->register_option($marker,"SCALEDY", -label => "Bars Height", 
				 -caller => $self,-pack => 5, -subtype => "$cpus",
				 -type => "int", -min => 2, -max => 64, -default => $self->{SCALEDY}[$i], -step => 1);
	$optobj->register_option($marker,"SCALEPX", -label => "Bars rel. pos. X", 
				 -caller => $self,-pack => 5, -subtype => "$cpus",
				 -type => "int", -min => -10, -max => 200, -default => $self->{SCALEPX}[$i], -step => 2);
	$optobj->register_option($marker,"SCALEPY", -label => "Bars rel. pos. Y", 
				 -caller => $self,-pack => 5, -subtype => "$cpus",
				 -type => "int", -min => 0, -max => 200, -default => $self->{SCALEPY}[$i], -step => 2);
	$optobj->register_option($marker,"SCALESHOW", -label => "Show", 
				 -caller => $self,-pack => 5, -subtype => "$cpus", -labelwidth=>5,
				 -type => "radio", -min => -10, -max => 200, -default => $self->{SCALESHOW}[$i], -step => 2);

	$optobj->register_option($marker,"STATEPX", -label => "State rel. pos. X", 
				 -caller => $self,-pack => 1, -subtype => "$cpus",
				 -type => "int", -min => -10, -max => 200, -default => $self->{STATEPX}[$i], -step => 2);
	$optobj->register_option($marker,"STATEPY", -label => "State rel. pos. Y", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => 0, -max => 200, -default => $self->{STATEPY}[$i], -step => 2);
	$optobj->register_option($marker,"STATEDX", -label => "State width", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => 0, -max => 200, -default => $self->{STATEDY}[$i], -step => 2);
	$optobj->register_option($marker,"STATEDY", -label => "State height", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => 0, -max => 200, -default => $self->{STATEDY}[$i], -step => 2);

	
	$optobj->register_option($marker,"NAMEPX", -label => "Name rel. pos. X", 
				 -caller => $self,-pack => 1, -subtype => "$cpus",
				 -type => "int", -min => -10, -max => 20, -default => $self->{NAMEPX}[$i], -step => 2);
	$optobj->register_option($marker,"NAMEPY", -label => "Name rel. pos. Y", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => -10, -max => 200, -default => $self->{NAMEPY}[$i], -step => 2);
	$optobj->register_option($marker,"NAMEDX", -label => "Name width", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => -10, -max => 200, -default => $self->{NAMEDX}[$i], -step => 2);
	$optobj->register_option($marker,"NAMEDY", -label => "Name height", 
				 -caller => $self,-pack => 4, -subtype => "$cpus",
				 -type => "int", -min => -10, -max => 200, -default => $self->{NAMEDY}[$i], -step => 2);
	$optobj->register_option($marker,"NAMEDOFRAME", -label => "Frame (Name)", 
				 -caller => $self,-pack => 1, -subtype => "$cpus",
				 -type => "radio", -min => 0, -max => 1, -default => $self->{NAMEDOFRAME}[$i], -step => 2);
	$optobj->register_option($marker,"NAMEMODE", -label => "Name Display mode", 
				 -caller => $self,-pack => 3, -subtype => "$cpus",
				 -type => "int", -min => 0, -max => 2, -default => $self->{NAMEMODE}[$i], -step => 2);
	$optobj->register_option($marker,"NAMEBGCOL", -label => "Frame color (Name)", 
				 -caller => $self,-pack => 3, -subtype => "$cpus",
				 -type => "string", -default => $self->{NAMEBGCOL}[$i]);

	$optobj->register_option($marker,"NUMBOXPERROW", -label => "#box/row", 
				 -caller => $self,-pack => 2, -subtype => "$cpus",
				 -type => "int", -min => 1, -max => 64, -default => $self->{NUMBOXPERROW}[$i], -step => 1);



	if($cpus eq "BGL") {
	    $optobj->register_option($marker,"RACKPERPIC", -label => "racks per picture", 
				     -caller => $self,-pack => 2, -subtype => "$cpus",
				     -type => "int", -min => 1, -max => 8, -default => $self->{RACKPERPIC}[$i], -step => 1);
	    $optobj->register_option($marker,"LINEBREAK", -label => "linebreak after", 
				     -caller => $self,-pack => 2, -subtype => "$cpus",
				     -type => "int", -min => 1, -max => 8, -default => $self->{LINEBREAK}[$i], -step => 1);
	    $optobj->register_option($marker,"ADDOFFX", -label => "add. offset x", 
				     -caller => $self,-pack => 2, -subtype => "$cpus",
				     -type => "int", -min => 0, -max => 800, -default => $self->{ADDOFFX}[$i], -step => 2);
	    $optobj->register_option($marker,"ADDOFFY", -label => "add. offset y", 
				     -caller => $self,-pack => 2, -subtype => "$cpus",
				     -type => "int", -min => 0, -max => 800, -default => $self->{ADDOFFY}[$i], -step => 2);
	    $optobj->register_option($marker,"TEXTTYPE", -label => "type of texture (0 none, 1,2)", 
				     -caller => $self,-pack => 2, -subtype => "$cpus",
				     -type => "int", -min => 0, -max => 2, -default => $self->{TEXTTYPE}[$i], -step => 1);
	    $optobj->register_option($marker,"BOXGAP", -label => "add. gap between boxes", 
				     -caller => $self,-pack => 2, -subtype => "$cpus",
				     -type => "int", -min => 0, -max => 2, -default => $self->{BOXGAP}[$i], -step => 1);
    
	}

    }

    $optobj->register_option("Nodes","FONT1", -label => "Font (State)", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option("Nodes","FONT2", -label => "Font (Action)", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT2});
    $optobj->register_option("Nodes","FONT3", -label => "Font (NodeName)", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT3});
    $optobj->register_option("Nodes","FONT4", -label => "Font (SiteName)", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT4});


    $optobj->register_option("Nodes","DOINOUT", -label => "show InOUT", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -min => 0, -max => 1, -default => $self->{DOINOUT}, -step => 2);
    $optobj->register_option("Nodes","INOUTMARKPX", -label => "InOut pos. X", 
			     -caller => $self,-pack => 3,
			     -type => "int", -min => -10, -max => 200, -default => $self->{INOUTMARKPX}, -step => 10);
    $optobj->register_option("Nodes","INOUTMARKPY", -label => "InOut pos. Y", 
			     -caller => $self,-pack => 3,
			     -type => "int", -min => -10, -max => 200, -default => $self->{INOUTMARKPY}, -step => 10);

    $optobj->register_option("Nodes","DOLOGO", -label => "show Logo", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -min => 0, -max => 1, -default => $self->{DOLOGO}, -step => 2);
    $optobj->register_option("Nodes","LOGOPX", -label => "Logo pos. X", 
			     -caller => $self,-pack => 3,
			     -type => "int", -min => -10, -max => 2000, -default => $self->{LOGOPX}, -step => 10);
    $optobj->register_option("Nodes","LOGOPY", -label => "Logo pos. Y", 
			     -caller => $self,-pack => 3,
			     -type => "int", -min => -10, -max => 1200, -default => $self->{LOGOPY}, -step => 10);

    $optobj->register_option("Nodes","LOGOIMAGE", -label => "Image name", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{LOGOIMAGE});
    
    $optobj->register_option("Nodes","DOLOGON", -label => "show Site Name", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -min => 0, -max => 1, -default => $self->{DOLOGON}, -step => 2);
    $optobj->register_option("Nodes","LOGONPX", -label => "Name pos. X", 
			     -caller => $self,-pack => 4,
			     -type => "int", -min => -10, -max => 2000, -default => $self->{LOGONPX}, -step => 10);
    $optobj->register_option("Nodes","LOGONPY", -label => "Name pos. Y", 
			     -caller => $self,-pack => 4,
			     -type => "int", -min => -10, -max => 1200, -default => $self->{LOGONPY}, -step => 10);

    $optobj->register_option("Nodes","LOGONCOLOR", -label => "Color", 
			     -caller => $self,-pack => 4,
			     -type => "string", -default => $self->{LOGONCOLOR});

    $optobj->register_option("Nodes","LOGONTEXT", -label => "Site Name", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{LOGONTEXT});

    $infoobj->register_bind("LASTIN",$self);
    $infoobj->register_bind("LASTOUT",$self);
    $infoobj->register_bind("FIRSTWAIT",$self);

    # dummy rectangle
    $id=$canvas->createRectangle($self->{POSX},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH},$self->{POSY}+$self->{HEIGHT},
				 -fill => "grey65", -outline => "black" );
    push(@{$self->{FIXEDITEMS}},$id);


    $self->{BUILDREADY}=1;

    $canvas->configure(-scrollregion => [ $canvas->bbox("all") ]);


    return();
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val,$subnum)=@_;
    my($diffx,$diffy,$id);
    my $br=$self->{BUILDREADY};
#    print "nodes_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY}) \n" if($self->{VERBOSE});
    if($subnum) {
	if($section=~/NodeBox/) {
	    my $i=0;
	    $i++ while(($i<=$#{$self->{BOXCPUS}}) && ($self->{BOXCPUS}[$i]!=$subnum)); 
	    $self->{$name}[$i]=$val;
	}
    } elsif($section=~/Nodes/) {
	$self->{$name}=$val;
    } elsif($name=~/^([^\d]+)(\d+)$/) {
	$self->{$1}[$2]=$val;
    } else {
	$self->{$name}=$val;
    }
    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if($br);
    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1) if($br);
 
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name,$lname);
    my($x,$y,$rx,$ry,$dx,$dy);
    my($n,$nstate,$ncol,$p,$j);
    my(@pfn,@bigimg,@img,@imgysize);
    my $frames=$dataobj->{FRAMES};
    my ($cpus,$bbx,$bby,$bc);
    my ($scale_offx,$scale_offy,$scale_length,$scale_height);
    my ($numx,$numy,$rackperpic,$show_img,$bglnode,$imgmovex,$imgmovey);
    my ($mw,$me,$mn,$ms)=($self->{MARGINBOXW},$self->{MARGINBOXE},$self->{MARGINBOXN},$self->{MARGINBOXS});
    my ($bbx_wo_img,$bby_wo_img,$xsave,$ysave,$bcount,$gap,$maxcpus);
    $self->{FRAMES}=$frames;

    $self->{ACTROWX}    = 0;
    $self->{ACTROWY}    = 0;
    $self->{ACTROWDY}   = 0;
    $self->{ACTROWLASTELEMX}=-1;
    $self->{ACTROWLASTELEMY}=-1;
    $self->{ACTROWLASTELEMBX}=-1;
    $self->{ACTROWLASTELEMBY}=-1;
    $self->{NBOXX}  = [];
    $self->{NBOXY}  = [];

#    printf("WF buildfixed nodes: #FRAMES=%d\n",$self->{FRAMES});
    for($n=1;$n<=$frames;$n++) {
#	print "WF register_bind: NODE${n}\n";
	$self->{INFOOBJECT}->register_bind("NODE${n}",$self);
    }

    # define Images
    for($i=0;$i<=$#{$self->{BOXCPUS}};$i++) {
	if($self->{IMGSHOW}[$i]) {
	    $pfn[$i]=$self->{INSTPATH}."/".$self->{IMAGE}[$i];
	    $bigimg[$i]=$canvas->Photo(-file => $pfn[$i]);
	    $img[$i]=$canvas->Photo();
	    $imgysize[$i]=$bigimg[$i]->height/$bigimg[$i]->width*$self->{IMGSIZEX}[$i];
#	    printf("wf: copy %s:  %fx%f -> %fx%f subsample=%f\n",$pfn[$i],
#		   $bigimg[$i]->width, $bigimg[$i]->height,
#		   $self->{IMGSIZEX}[$i], $imgysize[$i],
#		   $bigimg[$i]->width/$self->{IMGSIZEX}[$i]);
	    $img[$i]->copy($bigimg[$i],  
			   -from => 0, 0, $bigimg[$i]->width, $bigimg[$i]->height, 
 			   -to => 0, 0, $self->{IMGSIZEX}[$i], $imgysize[$i], 
	 		   -subsample => $bigimg[$i]->width/$self->{IMGSIZEX}[$i], -shrink);
# 232
	}
    }

    # clean last fixed entries
    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    # calculate bounding box for each node type
    for($bc=0;$bc<=$#{$self->{BOXCPUS}};$bc++) {
	my($wx,$wy)=(0,0);
	$bbx=$bby=0;
	$wx=$self->{PRBOXPX}[$bc]+$self->{NUMBOXPERROW}[$bc]*$self->{PRBOXDX}[$bc];
	# assume max cpus for design
	$maxcpus=($self->{BOXCPUS}[$bc] ne "BGL")?$self->{BOXCPUS}[$bc]:16;
	$wy=$self->{PRBOXPY}[$bc]+$maxcpus/$self->{NUMBOXPERROW}[$bc]*$self->{PRBOXDY}[$bc];
#	$wy=$self->{PRBOXPY}[$bc]+$cpus/$self->{NUMBOXPERROW}[$bc]*$self->{PRBOXDY}[$bc];
	$bbx=$wx if($wx>$bbx);$bby=$wy if($wy>$bby);

	$wx=$self->{NAMEPX}[$bc]+$self->{NAMEDX}[$bc];
	$wy=$self->{NAMEPY}[$bc]+$self->{NAMEDY}[$bc];
	$bbx=$wx if($wx>$bbx);$bby=$wy if($wy>$bby);

	# assume that state has height of name 
	$wx=$self->{STATEPX}[$bc]+$self->{NAMEDX}[$bc];
	$wy=$self->{STATEPY}[$bc]+$self->{NAMEDY}[$bc];
	$bbx=$wx if($wx>$bbx);$bby=$wy if($wy>$bby);

	if($self->{SCALESHOW}[$bc]) {
	    $wx=$self->{SCALEPX}[$bc]+$self->{SCALEDX}[$bc];
	    $wy=$self->{SCALEPY}[$bc]+2*$self->{SCALEDY}[$bc];
	    $bbx=$wx if($wx>$bbx);$bby=$wy if($wy>$bby);
	}
	$self->{BBXWOIMG}[$bc]=$bbx;
	$self->{BBYWOIMG}[$bc]=$bby;
	if(($self->{IMGSHOW}[$bc])) {
	    $wx=$self->{IMGPOSX}[$bc]+$img[$bc]->width;
	    $wy=$self->{IMGPOSY}[$bc]+$img[$bc]->height;
	    $bbx=$wx if($wx>$bbx);$bby=$wy if($wy>$bby);
	}
	$self->{BBX}[$bc]=$bbx;
	$self->{BBY}[$bc]=$bby;
#	printf("WF: BBX %03d[%d] -> %d,%d %s bc=%d [%d,%d]\n",$bc,$cpus,$bbx,$bby,$name,$bc,	
#	       $self->{BBXWOIMG}[$bc],$self->{BBYWOIMG}[$bc]);
    }

    # map design to all nodes
    for($n=1;$n<=$frames;$n++) {
	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}!~/BGL/) {
	    $cpus=$dataobj->{NODESTATE}->[$n]->{"cpu_total"};
	} else {
	    $cpus=16;
	}
	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}!~/BGL/) {
	    $bc=0;
	    for($i=$#{$self->{BOXCPUS}};$i>=0;$i--) {
		if($cpus<=$self->{BOXCPUS}[$i]) { 
		    $bc=$i; 
		}
	    }
	} else {
	    $bc=$#{$self->{BOXCPUS}};
	}
	$self->{BC}[$n]=$bc;

	$lname=$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$name=~s/\..*$//gs;
	$self->{LNAMES}->{$name}=$lname if ($name ne $lname);
#	print "WF: BCCALC node $n $cpus->$bc >$lname< node_nr=",$self->{DATAOBJECT}->{NODES}->{$lname}->{"node_nr"}," \n";
    }

    # draw racks, and define positions of all nodes
#    print "WF: start scanuser_layout\n";
    $self->scanuser_layout() if($self->{DOUSERLAYOUT});

    # do the work 
    for($n=1;$n<=$frames;$n++) {
	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}!~/BGL/) {
	    $cpus=$dataobj->{NODESTATE}->[$n]->{"cpu_total"};
	} else {
	    $cpus=16;
	}

	$lname=$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$name=~s/\..*$//gs;

	# which design (number of PEs)
	$bc=$self->{BC}[$n];
	$bbx=$self->{BBX}[$bc];
	$bby=$self->{BBY}[$bc];
	$bbx_wo_img=$self->{BBXWOIMG}[$bc];
	$bby_wo_img=$self->{BBYWOIMG}[$bc];

	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}!~/BGL/) {
	    $bglnode=0;
	    $rackperpic=1;
	    $show_img=1;
	} else {
	    $bglnode=1;
	    $rackperpic=$self->{RACKPERPIC}[$bc];
	    if($n%(2*$rackperpic)==1) {$show_img=1;}
	    else                      {$show_img=0;}
	}

	if(!$bglnode) {
	    ($x,$y)=$self->getnewpos($n,$bbx,$bby) if(!$self->{DOUSERLAYOUT});
	    ($x,$y)=$self->getnewpos_user($n,$bbx,$bby) if($self->{DOUSERLAYOUT});
	    $imgmovex=$imgmovey=0;
	} else {
	    if($show_img) {
		($xsave,$ysave)=$self->getnewpos($n,$bbx,$bby);
		$bcount=0;
	    }
	    $bcount++;
	    $x=$xsave+$self->{ADDOFFX}[$bc];
	    $y=$ysave+$self->{ADDOFFY}[$bc];

	    if(($bcount%2)==1) {
		$y+=$bby_wo_img+$mn+$ms;
	    }
	    $x+=int(($bcount-1)/2)*($bbx_wo_img+$mw+$me);
	    $imgmovex=$xsave-$x;
	    $imgmovey=$ysave-$y;
	    $self->setpos($n,$x,$y);

#	    print "WF: $n $name bc=$bcount $xsave,$ysave $x,$y\n";
	}

#	print "WF nodename=$name ($x,$y)\n";


#	if($n%($self->{LINEBREAK}[$bc])==0) {
#	    $self->linebreak();
#	}

	# debug marker
	if($self->{LAYOUTDEBUG}) {
	    $id=$canvas->createRectangle($x,$y,
					 $x+$bbx,$y+$bby, 
					 -fill => $self->{BOXCOLOR}, -outline => "green" );
	    push(@{$self->{FIXEDITEMS}},$id);
	}

# 	$name=sprintf("j%02d",$n);

	if ( ($self->{IMGSHOW}[$bc]) && ($show_img) ) {
	    $id=$canvas->createImage($x+$self->{IMGPOSX}[$bc]+$imgmovex,$y+$self->{IMGPOSY}[$bc]+$imgmovey, 
				     -image => $img[$bc],
				     -anchor=> "nw", -tags => ["NODE${n}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	}
	
	# Name of node
	if($self->{NAMEDOFRAME}[$bc]) {
	    $id=$canvas->createRectangle($x+$self->{NAMEPX}[$bc],$y+$self->{NAMEPY}[$bc],
					 $x+$self->{NAMEPX}[$bc]+$self->{NAMEDX}[$bc],$y+$self->{NAMEPY}[$bc]+$self->{NAMEDY}[$bc], 
					 -fill => $self->{NAMEBGCOL}[$bc], -outline => "black", -tags => ["NODE${n}"] );
	    push(@{$self->{FIXEDITEMS}},$id);
	}
	if($self->{NAMEMODE}[$self->{BC}[$n]]==1) {
	    $id=$self->{NAMETXT}->[$n]=$canvas->createText($x+$self->{NAMEPX}[$bc]+4,$y+$self->{NAMEPY}[$bc],-text => $name, 
				    anchor=> "nw", -font => $self->{FONT3}, -tags => ["NODE${n}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	}
	# Status of node
	$id=$canvas->createRectangle($x+$self->{STATEPX}[$bc],$y+$self->{STATEPY}[$bc],
				     $x+$self->{STATEPX}[$bc]+$self->{STATEDX}[$bc],$y+$self->{STATEPY}[$bc]+$self->{STATEDY}[$bc], 
				     -fill => "white", -outline => "black", -tags => ["NODE${n}"] );
	push(@{$self->{FIXEDITEMS}},$id);
	$id=$self->{STATUSTXT}->[$n]=$canvas->createText($x+$self->{STATEPX}[$bc]+6,$y+$self->{STATEPY}[$bc],
							 anchor=> "n", -text => "??", -font => $self->{FONT1},
							 -tags => ["NODE${n}"]);
	push(@{$self->{FIXEDITEMS}},$id);
	
	# sliders for cpu usage, mem usage
	if($self->{SCALESHOW}[$bc]) {
	    $scale_offx=$self->{SCALEPX}[$bc];
	    $scale_offy=$self->{SCALEPY}[$bc];
	    $scale_length=$self->{SCALEDX}[$bc];
	    $scale_height=$self->{SCALEDY}[$bc];
	    
	    $id=$canvas->createRectangle($x+$scale_offx,$y+$scale_offy,
					 $x+$scale_offx+$scale_length,$y+$scale_offy+$scale_height,
					 , -tags => ["NODE${n}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	    $id=$canvas->createRectangle($x+$scale_offx,$y+$scale_offy+$scale_height,
					 $x+$scale_offx+$scale_length,$y+$scale_offy+2*$scale_height,
					 , -tags => ["NODE${n}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	    $id=$self->{STATUS_CPU}->[$n]    =$canvas->createRectangle($x+$scale_offx,$y+$scale_offy+$scale_height,
								       $x+$scale_offx+$scale_length*$self->{CPU_PER_INI},
								       $y+$scale_offy+2*$scale_height, 
								       -fill => "darkgreen", -tags => ["NODE${n}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	    $id=$self->{STATUS_MEMUSED}->[$n]=$canvas->createRectangle($x+$scale_offx,$y+$scale_offy,
								       $x+$scale_offx+$scale_length*$self->{MEMUSED_PER_INI},
								       $y+$scale_offy+$scale_height, 
								       -fill => "darkblue", -tags => ["NODE${n}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	    $id=$self->{STATUS_MEMREQ}->[$n] =$canvas->createRectangle($x+$scale_offx+$scale_length*$self->{MEMUSED_PER_INI},
								       $y+$scale_offy,
								       $x+$scale_offx+$scale_length*$self->{MEMREQ_PER_INI},
								       $y+$scale_offy+$scale_height, 
								       -fill => "lightskyblue", -tags => ["NODE${n}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	}

	
	# processors of each node
	($rx,$ry)=$self->nr2pos($n);
	$rx+=$self->{PRBOXPX}[$bc];$ry+=$self->{PRBOXPY}[$bc];
	$dx=$self->{PRBOXDX}[$bc];
	$dy=$self->{PRBOXDY}[$bc];
	$p=0;
	$numx=$self->{NUMBOXPERROW}[$bc];
#	$numx=4;
	$numy=int($cpus/$numx+0.9);
	$gap=0 if(!$bglnode);
	$gap=$self->{BOXGAP}[$bc] if($bglnode);
	for($i=0;$i<$numx;$i++) {
	    for($j=0;$j<$numy;$j++) {
		my ($x,$y);
		if($bglnode) {$x=$j;$y=$i;}
		else         {$x=$i;$y=$j;}
		$self->{PRBOXPOSX}->[$n][$p]=$rx+$x*$dx;
		$self->{PRBOXPOSY}->[$n][$p]=$ry+$y*$dy;
		$id=$self->{PRBOX}->[$n][$p]= $canvas->createRectangle($rx+$x*$dx, $ry+$y*$dy, 
								       $rx+($x+1)*$dx-$gap, $ry+($y+1)*$dy-$gap);
		push(@{$self->{FIXEDITEMS}},$id);
		if($bglnode) {
		    $self->create_texture1($rx+$x*$dx, $ry+$y*$dy,$rx+($x+1)*$dx-$gap, $ry+($y+1)*$dy-$gap) 
			if ($self->{TEXTTYPE}[$bc]==1);
		    $self->create_texture2($rx+$x*$dx, $ry+$y*$dy,$rx+($x+1)*$dx-$gap, $ry+($y+1)*$dy-$gap) 
			if ($self->{TEXTTYPE}[$bc]==2);
		}
		$p++;
		last if($p>=$cpus);
	    }
	    last if($p>=$cpus);
	}
    } # frames
    

    if($self->{DOINOUT}) {
	$rx=$self->{INOUTMARKPX};
	$ry=$self->{INOUTMARKPY};
	$id=$canvas->createRectangle($rx, $ry, 
				     $rx+20, $ry+20,-fill => "green",-tags => ["LASTIN"]);
	push(@{$self->{FIXEDITEMS}},$id);
	$id=$canvas->createText($rx+10, $ry+10,-text => "IN", -font => $self->{FONT2},-tags => ["LASTIN"]);
	push(@{$self->{FIXEDITEMS}},$id);
	
	$ry+=25;
	$id=$canvas->createRectangle($rx, $ry, 
				     $rx+20, $ry+20,-fill => "blue",-tags => ["LASTOUT"]);
	push(@{$self->{FIXEDITEMS}},$id);
	$id=$canvas->createText($rx+10, $ry+10,-text => "OUT", -font => $self->{FONT2},-tags => ["LASTOUT"]);
	push(@{$self->{FIXEDITEMS}},$id);
	
	$ry+=25;
	$id=$canvas->createRectangle($rx, $ry, 
				     $rx+20, $ry+20,-fill => "red",-tags => ["FIRSTWAIT"]);
	push(@{$self->{FIXEDITEMS}},$id);
	$id=$canvas->createText($rx+10, $ry+10,-text => "WAIT", -font => $self->{FONT2},-tags => ["FIRSTWAIT"]);
	push(@{$self->{FIXEDITEMS}},$id);
	
	push(@{$self->{FIXEDITEMS}},$id);
    }

    if($self->{DOLOGO}) {
	my $pfn=$self->{INSTPATH}."/".$self->{LOGOIMAGE};
	my $img=$canvas->Photo(-file => $pfn);
	$id=$canvas->createImage($self->{LOGOPX}, $self->{LOGOPY},
				 -image => $img,
				 -anchor=> "nw");
	push(@{$self->{FIXEDITEMS}},$id);
#	print "WF: set image $pfn to pos $self->{LOGOPX}, $self->{LOGOPY}\n";
    }

    if($self->{DOLOGON}) {
	$id=$canvas->createText($self->{LOGONPX},$self->{LOGONPY}, 
				-text => $self->{LOGONTEXT},
				-fill => $self->{LOGONCOLOR},
				-font => $self->{FONT4});

	push(@{$self->{FIXEDITEMS}},$id);
    }

    $canvas->configure(-scrollregion => [ $canvas->bbox("all") ]);

    $self->{BUILDFIXEDREADY}=1;

}

sub generateinfo {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$name)=@_;
    my $infostr="no info for name $name\n";
    if($name=~/NODE(\d+)/) {
	my $nodenr=$1;
	my $o=$dataobj->{NODESTATE}->[$nodenr];
	$infostr=sprintf("Info for node %8s [%s]\n",$o->{"node_name"},$o->{"node_state"});
	$infostr.=sprintf("-------------------------------\n");
	$infostr.=sprintf("  Usage:   [%2d PE of %2d PE used] %d jobs\n", $o->{"cpu_run"},$o->{"node_cpus"},$o->{"num_jobs"});
 	$infostr.=sprintf("  Memory:  [%3.2f GB of %3.2f GB used, %3.2f GB requ.]\n",
			 $o->{"mem_used"}/1024,$o->{"mem_total"}/1024,
			 $o->{"consmem_used"}/1024);
	$infostr.=sprintf("  Jobs:    %s\n", 
			  format_bracket_list($o->{"job_list"},$infoobj->{WIDTH}-18,"\n           ") );
	$infostr.=sprintf("  Classes: %s\n", 
			  format_bracket_list($o->{"node_avail_classes"},$infoobj->{WIDTH}-18,"\n           ") );
    }
    if($name=~/LASTIN/) {
	my $nodenr=$1;
        $dataobj->{ANALYSE}->analyse_data();
	$infostr=$dataobj->{ANALYSE}->{LASTIN};
    }
    if($name=~/LASTOUT/) {
	my $nodenr=$1;
        $dataobj->{ANALYSE}->analyse_data();
	$infostr=$dataobj->{ANALYSE}->{LASTOUT};
    }
    if($name=~/FIRSTWAIT/) {
	my $nodenr=$1;
        $dataobj->{ANALYSE}->analyse_data();
	$infostr=$dataobj->{ANALYSE}->{FIRSTWAIT};
    }
    return($infostr);
}


sub format_bracket_list {
    my($in,$width,$delim)=@_;
    my $out="";
    my $len=0;
    while($in=~s/^([^\)]+\))//) {
	$out.=$1;
	$len+=length($1);
	if($len>$width) {
	    $out.=$delim;
	    $len=0;
	}
    }
    return($out);
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;


    my($id,$text,$cpusum,$jobidcnt,$lastjobid,$cpus,$bc);
    my($num,$jobid,$color,$nr,$n,$p,$jobnr,$letter,$bglnode,$name);

    my $frames=$dataobj->{FRAMES};
    return(0) if($frames<=0);
    my $startx=$self->{POSX};
    my $starty=$self->{POSY};
    my $deltax=$self->{WIDTH}/$frames;
    my $width =$self->{WIDTH};

    $self->clean($dataobj,$colorobj,$canvas);

    # first build of fixed display parts
    if(!$self->{BUILDFIXEDREADY}) {
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},
			    $self->{COLOROBJECT},$self->{CANVAS}); 
    } elsif($self->{LASTLLCPUS}!=$self->{DATAOBJECT}->{LLCPUS}) {
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},
			    $self->{COLOROBJECT},$self->{CANVAS});
	$self->{LASTLLCPUS}=$self->{DATAOBJECT}->{LLCPUS};
    }

    for($n=1;$n<=$frames;$n++) {
	$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$name=~s/\..*$//gs;
	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}!~/BGL/) {
	    $cpus=$dataobj->{NODESTATE}->[$n]->{"cpu_total"};
	    $bglnode=0;
	} else {
	    $cpus=16;
	    $bglnode=1;
	}
	for($p=0;$p<$cpus;$p++) {
	    $jobid=$dataobj->{PROCSTATE}->[$n][$p];
	    if($jobid!~/^[-= \?\&\!%]$/) {
		$color=$colorobj->get_color("RUN",$jobid);
		if($dataobj->{RUNNINGDATA}->{$jobid}{FL_CONSCPU}>1) {
		    $self->set_omp_mark($dataobj,$colorobj,$canvas, $n,$p,"start",$self->{BC}[$n]) if(!$bglnode);
		    $jobidcnt=1;
		}
		$lastjobid=$jobid;
		$jobnr=$colorobj->idtonr("RUN",$jobid);
		$canvas->itemconfigure($self->{PRBOX}->[$n][$p], -fill => $color, -tags => ["T${jobnr}R"]);
	    } else {
		if($jobid eq '&') {
		    $jobid=$lastjobid;
		    $color=$colorobj->get_color("RUN",$jobid);
		    $jobidcnt++;
		    if($jobidcnt<$dataobj->{RUNNINGDATA}->{$jobid}{FL_CONSCPU}) {
			$self->set_omp_mark($dataobj,$colorobj,$canvas, $n,$p,"line",$self->{BC}[$n]) if(!$bglnode);
		    } else {
			$self->set_omp_mark($dataobj,$colorobj,$canvas, $n,$p,"end",$self->{BC}[$n]) if(!$bglnode);
		    }
		    $jobnr=$colorobj->idtonr("RUN",$jobid);
		    $canvas->itemconfigure($self->{PRBOX}->[$n][$p], -fill => $color, -tags => ["T${jobnr}R"]);
		} else {
		    $letter=$jobid;
		    if(defined($self->{CPUCOLORS}->{$letter})) {
			$color=$self->{CPUCOLORS}->{$letter};
		    } else {
			$color="grey";
			#print "($n,$p,$jobid) -> >$letter<\n";
		    }
		    $jobnr=$jobid;
		    if($letter eq "-") {
			$canvas->itemconfigure($self->{PRBOX}->[$n][$p], -fill => $color, -tags => ["free"]);
		    } else {
			$canvas->itemconfigure($self->{PRBOX}->[$n][$p], -fill => $color, -tags => []);
		    }
		    if($letter eq '%') {
			# error marker
			$self->set_error_mark($dataobj,$colorobj,$canvas, $n,$p,"line",$self->{BC}[$n]);
		    }

		}
	    }
	}
	my $col="green";
	$col=$self->{STATUSCOLOR}->{$dataobj->{NODESTATE}->[$n]->{"state"}} 
	     if(exists($self->{STATUSCOLOR}->{$dataobj->{NODESTATE}->[$n]->{"state"}}));
	$canvas->itemconfigure($self->{STATUSTXT}->[$n], -text => lc($dataobj->{NODESTATE}->[$n]->{"state"}), 
			       -fill => $col);

	$bc=$self->{BC}[$n];
	if($self->{NAMEMODE}[$bc]==2) {
	    my($x,$y)=$self->nr2pos($n);
	    if($dataobj->{NODESTATE}->[$n]->{"state"} ne "Ru") {
		$id=$canvas->createRectangle($x+$self->{NAMEPX}[$bc],$y+$self->{NAMEPY}[$bc],
					     $x+$self->{NAMEPX}[$bc]+$self->{NAMEDX}[$bc],$y+$self->{NAMEPY}[$bc]+$self->{NAMEDY}[$bc], 
					     -fill => $self->{NAMEBGCOL}[$bc], -outline => "black", -tags => ["NODE${n}"] );
		push(@{$self->{FIXEDITEMS}},$id);
		$id=$self->{NAMETXT}->[$n]=$canvas->createText($x+$self->{NAMEPX}[$bc]+4,$y+$self->{NAMEPY}[$bc],-text => $name,
							       -fill => "red", anchor=> "nw", -font => $self->{FONT3}, -tags => ["NODE${n}"]);
		push(@{$self->{FIXEDITEMS}},$id);
	    }
	}

#	printf("WF: [%2d] %s %f %f %f\n",$n,
#	       $dataobj->{NODESTATE}->[$n]->{"node_name"},
#	       $dataobj->{NODESTATE}->[$n]->{"cpuusage"},
#	       $dataobj->{NODESTATE}->[$n]->{"memreq"},
#	       $dataobj->{NODESTATE}->[$n]->{"memused"}
#	       );
	$self->adjust_scale_cpu_mem($dataobj,$colorobj,$canvas,
				    $n,$dataobj->{NODESTATE}->[$n]->{"cpuusage"}/100.0,
				    $dataobj->{NODESTATE}->[$n]->{"memreq"}/100.0,
				    $dataobj->{NODESTATE}->[$n]->{"memused"}/100.0);
    }

    return();
}

sub adjust_scale_cpu_mem {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas, $n,$cpu_per,$memreq_per,$memused_per)=@_;
    my($x,$y)=$self->nr2pos($n);
    my $bc=$self->{BC}[$n];
    my $scale_offx=$self->{SCALEPX}[$bc];
    my $scale_offy=$self->{SCALEPY}[$bc];
    my $scale_length=$self->{SCALEDX}[$bc];
    my $scale_height=$self->{SCALEDY}[$bc];

    if($self->{SCALESHOW}[$bc]) {
	$canvas->coords($self->{STATUS_CPU}->[$n],$x+$scale_offx,$y+$scale_offy+$scale_height,
			$x+$scale_offx+$scale_length*$cpu_per,$y+$scale_offy+2*$scale_height);
	$canvas->coords($self->{STATUS_MEMUSED}->[$n],$x+$scale_offx,$y+$scale_offy,
			$x+$scale_offx+$scale_length*$memused_per,$y+$scale_offy+$scale_height);
	$canvas->coords($self->{STATUS_MEMREQ}->[$n],$x+$scale_offx+$scale_length*$memused_per,$y+$scale_offy,
			$x+$scale_offx+$scale_length*$memreq_per,$y+$scale_offy+$scale_height);
    }

}


sub create_texture1 {
    my($self) = shift;
    my($x1,$y1,$x2,$y2)=@_;
    my($x,$y,$dx,$dy,$px,$py);
    my($id);
    my $canvas=$self->{CANVAS};
    $dx=($x2-$x1)/9;
    $dy=($y2-$y1)/7;
    for($y=0;$y<2;$y++) {
	for($x=1;$x<=8;$x++) {
	    $px=$x1+($x*$dx);
	    $py=$y1+(4*$y*$dy);
	    $id=$canvas->createLine(      $px,   $py+1*$dy,
					  $px,   $py+2*$dy,
					  -width => 1,
					  -fill => "black"
					  );
	    push(@{$self->{FIXEDITEMS}},$id);
	}
    }
}

sub create_texture2 {
    my($self) = shift;
    my($x1,$y1,$x2,$y2)=@_;
    my($x,$y,$dx,$dy,$px,$py);
    my($id);
    my $canvas=$self->{CANVAS};
    $dx=($x2-$x1)/9;
    $dy=($y2-$y1)/5;
    for($y=1;$y<=4;$y++) {
	for($x=1;$x<=8;$x++) {
	    $px=int($x1+($x*$dx)+0.5);
	    $py=int($y1+($y*$dy)+0.5);
	    $id=$canvas->createLine(      $px,   $py,
					  $px+2, $py,
					  -width => 1,
					  -fill => "black"
					  );
	    push(@{$self->{FIXEDITEMS}},$id);
	}
    }
}


sub set_error_mark {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas, $n,$p,$type,$bc)=@_;
    my ($id,$x,$y);
    my ($color);

#    print "WF: set_error_mark\n";
    $id=$canvas->createLine(      $self->{PRBOXPOSX}->[$n][$p]+2,  
				  $self->{PRBOXPOSY}->[$n][$p]+2,
				  $self->{PRBOXPOSX}->[$n][$p]+$self->{PRBOXDX}[$bc]-$self->{BOXGAP}[$bc]-2,  
				  $self->{PRBOXPOSY}->[$n][$p]+$self->{PRBOXDY}[$bc]-$self->{BOXGAP}[$bc]-2,
				  -width => 2,
				  -fill => "red"
				  );
    push(@{$self->{ITEMS}},$id);
    $id=$canvas->createLine(      $self->{PRBOXPOSX}->[$n][$p]+2,  
				  $self->{PRBOXPOSY}->[$n][$p]+$self->{PRBOXDY}[$bc]-$self->{BOXGAP}[$bc]-2,
				  $self->{PRBOXPOSX}->[$n][$p]+$self->{PRBOXDX}[$bc]-$self->{BOXGAP}[$bc]-2,  
				  $self->{PRBOXPOSY}->[$n][$p]+2,
				  -width => 2,
				  -fill => "red"
				  );
    push(@{$self->{ITEMS}},$id);

}

sub set_omp_mark {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas, $n,$p,$type,$bc)=@_;
    my ($id,$x,$y);
    my ($color);
   
    $color='darkblue';
    $x=int($self->{PRBOXPOSX}->[$n][$p]+0.5*$self->{PRBOXDX}[$bc]);
    $y=int($self->{PRBOXPOSY}->[$n][$p]+0.5*$self->{PRBOXDY}[$bc]);

#    $x=int($self->{PRBOXPOSX}->[$n][$p]);
#    $y=int($self->{PRBOXPOSY}->[$n][$p]);

#    print "WF: $n,$p,$type -> $x,$y $self->{PRBOXDX}\n";
    if(1) {
	# version with vertical lines
	if($type eq "start") {
	    $id=$canvas->createLine(      $x,   $y-4,
					  $x,   $y+2,
					  -arrow => 'first',
					  -width => 1,
					  -arrowshape => [4,5,2],
					  -tags => ["omp"],
					  -fill => $color
					  );
	} elsif ($type eq "end") {
	    $id=$canvas->createLine(      $x,   $y+4,
					  $x,   $y-2,
					  -arrow => 'first',
					  -width => 1,
					  -arrowshape => [4,5,2],
					  -tags => ["omp"],
					  -fill => $color
					  );
	} else {
	    $id=$canvas->createLine(      $x,   $y+3,
					  $x,   $y-2,
					  -arrow => 'none',
					  -width => 1,
					  -arrowshape => [4,5,2],
					  -tags => ["omp"],
					  -fill => $color
					  );
	}
    } else {
	# version with horizontal lines
	if($type eq "start") {
	    $id=$canvas->createLine(      $x-4,   $y,
					  $x+3,   $y,
				      -arrow => 'first',
					  -width => 1,
					  -arrowshape => [4,5,2],
					  -tags => ["omp"],
					  -fill => $color
					  );
	} elsif ($type eq "end") {
	    $id=$canvas->createLine(      $x+4,   $y,
					  $x-2,   $y,
					  -arrow => 'first',
					  -width => 1,
					  -arrowshape => [4,5,2],
					  -tags => ["omp"],
					  -fill => $color
					  );
	} else {
	    $id=$canvas->createLine(      $x+3,   $y,
					  $x-2,   $y,
					  -arrow => 'none',
					  -width => 1,
					  -arrowshape => [4,5,2],
					  -tags => ["omp"],
					  -fill => $color
					  );
	}
    }

    push(@{$self->{ITEMS}},$id);
}

sub linebreak {
    my($self) = shift;
    $self->{ACTROWX}=0;
    $self->{ACTROWY}+=$self->{ACTROWDY};
    $self->{ACTROWDY}=0;
}

sub move {
    my($self) = shift;
    my($addx,$addy)=@_;
    $self->{ACTROWX}+=$addx;
    $self->{ACTROWY}+=$addy;
}

sub getnewpos {
    my($self) = shift;
    my($nr,$bbx,$bby)=@_;
    my $xsize=$self->{WIDTH};
    my $ysize=$self->{HEIGHT};
    my ($mw,$me,$mn,$ms)=($self->{MARGINBOXW},$self->{MARGINBOXE},$self->{MARGINBOXN},$self->{MARGINBOXS});


    if(($self->{ACTROWX}+$bbx+$mw+$me)>$xsize) {
	if ($self->{ACTROWLASTELEMX}!=-1) {
	    # some space below last element
	    if(($bby+$mn+$ms)<=$self->{ACTROWLASTELEMBY}) {
		$self->{ACTROWX}=$self->{ACTROWLASTELEMX};
		$self->{ACTROWY}=$self->{ACTROWLASTELEMY};
		$self->{ACTROWDY}=$self->{ACTROWLASTELEMBY};
		$self->{ACTROWLASTELEMX}=$self->{ACTROWLASTELEMY}=$self->{ACTROWLASTELEMBY}=-1;
	    }
	}
    }

    if(($self->{ACTROWX}+$bbx+$mw+$me)>$xsize) {
	# linebreak
	$self->{ACTROWX}=0;
	$self->{ACTROWY}+=$self->{ACTROWDY};
	$self->{ACTROWDY}=0;
    }

    # some space below last elements
    if(($bby+$mn+$ms)<$self->{ACTROWDY}) {
	if ($self->{ACTROWLASTELEMX}==-1) {
	    $self->{ACTROWLASTELEMX}=$self->{ACTROWX};
	    $self->{ACTROWLASTELEMY}=$self->{ACTROWY}+($bby+$mn+$ms);
	    $self->{ACTROWLASTELEMBY}=$self->{ACTROWDY}-($bby+$mn+$ms);
	}
    }

    $self->setpos($nr,$self->{POSX}+$self->{ACTROWX}+$mw,$self->{POSY}+$self->{ACTROWY}+$mn);
    $self->{ACTROWX}+=$bbx+$mw+$me;


    $self->{ACTROWDY}=($bby+$mn+$ms) if(($bby+$mn+$ms)>$self->{ACTROWDY});


#    printf("WF: getnewpos: %3d -> px=%3d,py=%3d bbx=%3d,bby=%3d a=%d,%d,%d\n",
#	   $nr,$self->{NBOXX}[$nr],$self->{NBOXY}[$nr],$bbx,$bby,
#	   $self->{ACTROWLASTELEMX},$self->{ACTROWLASTELEMY},$self->{ACTROWLASTELEMBY});
    return($self->{NBOXX}[$nr],$self->{NBOXY}[$nr]);
}

sub nr2pos {
    my($self) = shift;
    my($nr)=@_;
    return($self->{NBOXX}[$nr],$self->{NBOXY}[$nr]);
}

# set position of node box
sub setpos {
    my($self) = shift;
    my($nr,$x,$y)=@_;
    ($self->{NBOXX}[$nr],$self->{NBOXY}[$nr])=($x,$y);
}

sub scanuser_layout {
    my($self) = shift;
    my($str,$module,@modules,$pair,%opts,@names,$cnt,$dx,$dy,$startx,$starty,$name,$id);
    my($bbx,$bby,$bc);
    my ($mw,$me,$mn,$ms)=($self->{MARGINBOXW},$self->{MARGINBOXE},$self->{MARGINBOXN},$self->{MARGINBOXS});
    my($actposx,$actposy,$modcnt)=(0,0,0);
    my(%namelists,$rackname,$nodename,$n);

    # scan for mapping between nodes and racks
    if($self->{USERLAYOUTSCANNAMES}) {
	for($n=1;$n<=$self->{FRAMES};$n++) {
	    $nodename=$self->{DATAOBJECT}->{NODESTATE}->[$n]->{"node_name"};
	    $rackname=$self->{DATAOBJECT}->{NODESTATE}->[$n]->{"node_rack"};
	    push(@{$namelists{$rackname}},$nodename);
	}
    }
    
    @modules=split(/\)\(/,$self->{USERLAYOUT});
    foreach $module (@modules) {
	$module=~/^\(?([^:]+):(.*),\[(.*)\]\)?$/;
	my($type,$namerange,$opts)=($1,$2,$3);
	foreach $pair (split('\s*,\s*',$opts)) {
	    if($pair=~/(.*)\=(.*)/) {
		$opts{$1}=$2;
	    }
	}
	if($type eq "rack") {
	    $self->{MODULES}->[$modcnt]->{TYPE}=$type;
	    $self->{MODULES}->[$modcnt]->{POSX}=$actposx;
	    $self->{MODULES}->[$modcnt]->{POSY}=$actposy;
	    $self->{MODULES}->[$modcnt]->{WIDTH} =$opts{"width"};
	    $self->{MODULES}->[$modcnt]->{HEIGHT}=$opts{"height"};
	    if(($modcnt+1)%$self->{USERLAYOUTRACKSPERROW}>0) { 
		$actposx+=$self->{MODULES}->[$modcnt]->{WIDTH}+$self->{USERLAYOUTXGAP};
	    } else {
		$actposx=0;$actposy+=$self->{MODULES}->[$modcnt]->{HEIGHT}+$self->{USERLAYOUTYGAP};
	    }
	    @names=("dummy");
	    if($self->{USERLAYOUTSCANNAMES}) {
		@names=sort(@{$namelists{$opts{name}}}) if ($namelists{$opts{name}});
	    } else {
		@names=$self->expand_namerange($namerange);
	    }
	    $cnt=scalar @names;

#	    printf("WF: RACK #%2d: +%3d+%3d %3dx%3d (%s)\n",$modcnt,
#		   $self->{MODULES}->[$modcnt]->{POSX},$self->{MODULES}->[$modcnt]->{POSY},
#		   $self->{MODULES}->[$modcnt]->{WIDTH},$self->{MODULES}->[$modcnt]->{HEIGHT},"@names");

	    if($opts{stack}!~/(up|down)/) {
		# distribute nodes over rack size
		$dy=$self->{MODULES}->[$modcnt]->{HEIGHT}/$cnt;
		if($opts{order} eq "down") {
		    $starty=$self->{MODULES}->[$modcnt]->{POSY};
		} else {
		    $starty=$self->{MODULES}->[$modcnt]->{POSY}+$self->{MODULES}->[$modcnt]->{HEIGHT}-$dy;
		    $dy=-$dy;
		}
		foreach $name (@names) {
		    $self->{NODES}->{$name}->{X}=$self->{MODULES}->[$modcnt]->{POSX}+$mw;
		    $self->{NODES}->{$name}->{Y}=$starty+$self->{MARGINBOXN};
#		    printf("WF:    Node: %4s +%3d+%3d\n",$name, 
#			   $self->{NODES}->{$name}->{X}, $self->{NODES}->{$name}->{Y});
		    $starty+=$dy;
		}
	    } else {
		# stack nodes in rack
		if($opts{stack} eq "up") {
		    $starty=$self->{MODULES}->[$modcnt]->{POSY}+$mn;
		} else {
		    $starty=$self->{MODULES}->[$modcnt]->{POSY}+$self->{MODULES}->[$modcnt]->{HEIGHT}-$ms;
		}
		my $lastdx=200;
		foreach $name (@names) {
		    my $lname=$name;
		    $lname=$self->{LNAMES}->{$name} if(exists($self->{LNAMES}->{$name}));
		    $n=$self->{DATAOBJECT}->{NODES}->{$lname}->{"node_nr"};
		    $bc=$self->{BC}[$n];
		    $bbx=$self->{BBX}[$bc];
		    $bby=$self->{BBY}[$bc];
		    # try to put two nodes in one row 
		    if($bbx+$lastdx<=$self->{MODULES}->[$modcnt]->{WIDTH}) {
			$self->{NODES}->{$name}->{X}=$self->{MODULES}->[$modcnt]->{POSX}+$mw+$lastdx;
			$self->{NODES}->{$name}->{Y}=$starty;
			$lastdx+=$bbx+$mw;
		    } else {
			$starty-=($bby+$mn) if($opts{stack} eq "down");
			$self->{NODES}->{$name}->{X}=$self->{MODULES}->[$modcnt]->{POSX}+$mw;
			$self->{NODES}->{$name}->{Y}=$starty;
			$starty+=($bby+$mn) if($opts{stack} eq "up");
			$lastdx=$bbx;
		    }
#		    printf("WF:    Node: (%s) +%3d+%3d n=%d bc=%d bbx=%d bby=%d lastdx=%d\n",$name, 
#			   $self->{NODES}->{$name}->{X}, $self->{NODES}->{$name}->{Y},$n,$bc,$bbx,$bby,$lastdx);
		}
	    }

	} elsif($type eq "row") {
	    $self->{MODULES}->[$modcnt]->{TYPE}=$type;
	    $self->{MODULES}->[$modcnt]->{POSX}=$actposx;
	    $self->{MODULES}->[$modcnt]->{POSY}=$actposy;
	    $self->{MODULES}->[$modcnt]->{WIDTH} =$opts{"width"};
	    $self->{MODULES}->[$modcnt]->{HEIGHT}=$opts{"height"};
	    $actposy+=$self->{MODULES}->[$modcnt]->{HEIGHT}+$mn;
	    @names=$self->expand_namerange($namerange);

#	    print "WF: names=@names\n";
	    if($opts{stack}!~/(left|right)/) {
		$cnt=scalar @names;
		$dx=$self->{MODULES}->[$modcnt]->{WIDTH}/$cnt;
		if($opts{order} eq "left") {
		    $startx=$self->{MODULES}->[$modcnt]->{POSX};
		} else {
		    $startx=$self->{MODULES}->[$modcnt]->{POSX}+$self->{MODULES}->[$modcnt]->{WIDTH}-$dx;
		    $dx=-$dx;
		}
		foreach $name (@names) {
		    $self->{NODES}->{$name}->{X}=$startx+$self->{MARGINBOXW};
		    $self->{NODES}->{$name}->{Y}=$self->{MODULES}->[$modcnt]->{POSY}+$self->{MARGINBOXN};
		    $startx+=$dx;
		}
	    } else {
		# stack nodes in row
		if($opts{stack} eq "left") {
		    $startx=$self->{MODULES}->[$modcnt]->{POSX};
		} else {
		    $startx=$self->{MODULES}->[$modcnt]->{POSX}+$self->{MODULES}->[$modcnt]->{WIDTH};
		}
		foreach $name (@names) {
		    my $lname=$name;
		    $lname=$self->{LNAMES}->{$name} if(exists($self->{LNAMES}->{$name}));
		    $n=$self->{DATAOBJECT}->{NODES}->{$lname}->{"node_nr"};
		    $bc=$self->{BC}[$n];
		    $bbx=$self->{BBX}[$bc];
		    $bby=$self->{BBY}[$bc];
		    $startx-=($bbx+$mw) if($opts{stack} eq "right");
		    $self->{NODES}->{$name}->{X}=$startx;
		    $self->{NODES}->{$name}->{Y}=$self->{MODULES}->[$modcnt]->{POSY}+$mn;
		    $startx+=($bbx+$mw) if($opts{stack} eq "left");
#		    printf("WF:    Node: (%s)(%s) +%3d+%3d n=%d bc=%d bbx=%d bby=%d\n",$name,$lname, 
#			   $self->{NODES}->{$name}->{X}, $self->{NODES}->{$name}->{Y},$n,$bc,$bbx,$bby);
		}
	    }
#	    printf("WF: ROW #%2d: +%3d+%3d %3dx%3d (%s)\n",$modcnt,
#		   $self->{MODULES}->[$modcnt]->{POSX},$self->{MODULES}->[$modcnt]->{POSY},
#		   $self->{MODULES}->[$modcnt]->{WIDTH},$self->{MODULES}->[$modcnt]->{HEIGHT},"@names");
	} else {
	    print "module: -> ($type)($namerange)($opts) >$module< UNKNOWN TYPE!!!\n";
	}
	if($opts{frame} eq "yes") {
	    $id=$self->{CANVAS}->createRectangle($self->{POSX}+$self->{MODULES}->[$modcnt]->{POSX},
						 $self->{POSY}+$self->{MODULES}->[$modcnt]->{POSY},
						 $self->{POSX}+$self->{MODULES}->[$modcnt]->{POSX}+$self->{MODULES}->[$modcnt]->{WIDTH},
						 $self->{POSY}+$self->{MODULES}->[$modcnt]->{POSY}+$self->{MODULES}->[$modcnt]->{HEIGHT},
						 -fill => $opts{fill}, -outline => $opts{border} );
	    push(@{$self->{FIXEDITEMS}},$id);
	}
	if($opts{name}) {
	    $id=$self->{CANVAS}->createText($self->{POSX}+$self->{MODULES}->[$modcnt]->{POSX}+20,
				     $self->{POSY}+$self->{MODULES}->[$modcnt]->{POSY}
				     +$self->{MODULES}->[$modcnt]->{HEIGHT}+1,
				     -text => $opts{name}, 
				     -anchor=> "nw", -font => $self->{FONT3});
	    push(@{$self->{FIXEDITEMS}},$id);
	}
	if($opts{image}) {
	    my $image=$opts{image};
	    if(!$self->{RACKIMAGES}->{$image}) {
		# define image
		my $pfn=$self->{INSTPATH}."/".$image;
		my $bigimg=$self->{CANVAS}->Photo(-file => $pfn);
		$self->{RACKIMAGES}->{$image}=$self->{CANVAS}->Photo();
		my $imgysize=$bigimg->height/$bigimg->width*$self->{MODULES}->[$modcnt]->{WIDTH};
#	    printf("wf: copy %s:  %fx%f -> %fx%f subsample=%f\n",$pfn[$i],
#		   $bigimg[$i]->width, $bigimg[$i]->height,
#		   $self->{IMGSIZEX}[$i], $imgysize[$i],
#		   $bigimg[$i]->width/$self->{IMGSIZEX}[$i]);
		$self->{RACKIMAGES}->{$image}->copy($bigimg,  
						    -from => 0, 0, $bigimg->width, $bigimg->height, 
						    -to => 0, 0, $self->{MODULES}->[$modcnt]->{WIDTH}, $imgysize, 
						    -subsample => $bigimg->width/$self->{MODULES}->[$modcnt]->{WIDTH}, -shrink);
		
	    }
	    $id=$self->{CANVAS}->createImage($self->{POSX}+$self->{MODULES}->[$modcnt]->{POSX},
					     $self->{POSY}+$self->{MODULES}->[$modcnt]->{POSY},
					     -image => $self->{RACKIMAGES}->{$image},
					     -anchor=> "nw", -tags => ["NODE${n}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	}
	$modcnt++;
    }

}

sub getnewpos_user {    
    my($self) = shift;
    my($nr,$bbx,$bby)=@_;
    my($name); 
    
    $name=$self->{DATAOBJECT}->{NODESTATE}->[$nr]->{"node_name"};
    $name=~s/\..*$//gs;

    if($self->{NODES}->{$name}) {
	$self->setpos($nr,$self->{POSX}+$self->{NODES}->{$name}->{X},
		      $self->{POSY}+$self->{NODES}->{$name}->{Y});
    }
#    print "WF: getnewpos_user: $nr -> ($name) $self->{NODES}->{$name}->{X}x$self->{NODES}->{$name}->{Y}\n";
	
	return($self->{NBOXX}[$nr],$self->{NBOXY}[$nr]);
}

sub expand_namerange {
    my($self) = shift;
    my($namerange) = shift;
    my(@names,$spec,$i,$len);

    foreach $spec (split(',',$namerange)) {
	if($spec=~/([^\d]*)(\d+)([^\d]*)\.\.([^\d]*)(\d+)([^\d]*)/) {
#	    print "WF: $1,$2,$3,$4,$5,$6\n";
	    if (($1 eq $4) && ($3 eq $6) && ($2<$5) ) {
		$len=length($2);
		for($i=$2;$i<=$5;$i++) {
		    push(@names,sprintf("%s%0${len}d%s",$1,$i,$3));
		}
	    }
	} else {
	    push(@names,$spec);
	}
    }
    return(@names);
}

1;
