# $Source: /cvs/cvsroot/llview/lib/LLview_get_ssh.pm,v $
# $Author: zdv087 $
# $Revision: 1.6 $
# $Date: 2007/04/17 13:13:45 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
package LLview_get_ssh;
use strict;
my($debug)=0;

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_get_ssh: new %s\n",ref($proto)) if($debug>=3);
    $self->{OPTSECTION} ="data_WWW";
    $self->{HOSTNAME}    = "jump.fz-juelich.de";
    $self->{USERID}      = "zdv087";
    $self->{CMD}      = "/home1/zam/zdv087/demo/lstat/llapi/llqxml";
    $self->{DATA}          = "";
    bless $self, $class;
    return $self;
}

sub init_options {
    my($self) = shift;
    my($optobj) = shift;
    my $section=$self->{OPTSECTION};
}

sub getdata {
    my($self) = shift;

    my $cmd="ssh ".$self->{USERID}."\@".$self->{HOSTNAME}." ".$self->{CMD};
    print "executing: $cmd\n";
    $self->{DATA}=`$cmd`;
    print "executing: $cmd rc=$?\n";
   
    open(OUT,"> WF.xml");
    print OUT $self->{DATA};
    close(OUT);

    return(1);
}

1;
