# $Source: /cvs/cvsroot/llview/lib/LLview_gui_histogram.pm,v $
# $Author: zdv087 $
# $Revision: 1.21 $
# $Date: 2007/07/12 20:49:16 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_histogram;
use strict;
use Time::Local;
use warnings;
my($debug)=0;
my($instancecnt)=-1;
my(@selfref)=(-1);


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my ($i);
    printf("\tLLview_gui_histogram: new %s\n",ref($proto)) if($debug>=3);
    $self->{HAVEINFOMSG} = 0;
    $self->{POSX}       = 485;
    $self->{POSY}       = 730;
    $self->{WIDTHPART1} = 144;  
    $self->{WIDTH}      = 435;
    $self->{HEIGHT}     = 130;
    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}     = "-*-Helvetica-Bold-R-Normal--*-100-*-*-*-*-*-*";
    $self->{FONT2}      = "-*-Courier-Medium-R-Normal--*-80-*-*-*-*-*-*";

    $self->{CLUSTERNAME}  = shift||"-"; # needed for button callback function 

    $self->{ITEMS}      = [];
    $self->{LEFTPAD}    = 30;
    $self->{RIGHTPAD}   = 00;
    $self->{BOTTOMPAD}  = 25;
    $self->{TOPPAD}  = 5;
    $self->{AUTOUPDATECNT}  = 0;
    $self->{AUTOUPDATEMAX}  = 20;
    $self->{TABNAME} = "Histogram";

    $self->{SELECTEDDIAGRAM} = "Diagram 1";
    $self->{MAXDISPLAYED} = 5;

    $self->{SUBNAMES}=["Diagram 1","Diagram 2","Diagram 3","Diagram 4","Diagram 5","Diagram 6","Diagram 7","Diagram 8"];
    
    for($i=0;$i<=$#{$self->{SUBNAMES}};$i++) {
	$self->{SUBNAMESTONR}->{$self->{SUBNAMES}[$i]}=$i;
	$self->{JOBSELECTION}[$i]  = "WAIT";
	$self->{LEGENDOFFSETX}[$i] = 100;
	$self->{LEGENDOFFSETY}[$i] = 2;
	$self->{XDATA}[$i]        = "QUEUETIME";
	$self->{YDATA}[$i]        = "COUNT";
	$self->{XFORMAT}[$i]      = "day";
	$self->{YFORMAT}[$i]      = "%3d";
	$self->{TITLE}[$i]        = "Job Waiting Time";
	$self->{XTITLE}[$i]       = "time (days)";
	$self->{YTITLE}[$i]       = "count";
	$self->{FILLCOLOR}[$i]    = "darkblue";
	$self->{FILLCOLORRUN}[$i] = "darkgreen";
	$self->{XLOG}[$i]         = "LINEAR";
	$self->{YLOG}[$i]         = "LINEAR";
	$self->{STEPWIDTH}[$i]    = 1;
	$self->{MAXSTEPS}[$i]     = 200;
    }

    $self->{VERBOSE}   = 0;
    
    $self->{BUILDREADY}=0;
    bless $self, $class;
    $instancecnt++;
    $self->{INSTANCENR} = $instancecnt;
    $selfref[$instancecnt]=\$self;
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj,$tabname)=@_;
    my($i,$name,$section);
    my $frames=$dataobj->{FRAMES};
    my(@subnames);

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;
    $self->{OPTIONOBJECT}=$optobj;
    
    $self->{TABNAME}=$section="Histogram" if (!$tabname);
    $self->{TABNAME}=$section="Hist_$tabname" if ($tabname);

    for($i=0;$i<=$#{$self->{SUBNAMES}};$i++) {
	my $sublabel=$self->{SUBNAMES}[$i];

	$optobj->register_option($section,"TITLE", -label => "diagram title", 
				 -caller => $self,-pack => 1, -subtype => $sublabel,
				 -type => "string", -default => $self->{TITLE}[$i]);

	$optobj->register_option($section,"JOBSELECTION", -label => "Jobselection", 
				 -caller => $self, -pack => 1,  -subtype => $sublabel,
				 -values => ["RUN","WAIT","ALL","ALLSEP"],
				 -type => "optionmenu", -default => $self->{JOBSELECTION}[$i]);

	$optobj->register_option($section,"LEGENDOFFSETX", -label => "Legend offset X", 
				 -caller => $self,-pack => 3, -min => 0.0, -max => 1000,  -subtype => $sublabel,
				 -type => "int", -default => $self->{LEGENDOFFSETX}[$i]);
	$optobj->register_option($section,"LEGENDOFFSETY", -label => "Legend offset Y", 
				 -caller => $self,-pack => 3, -min => 0.0, -max => 1000,  -subtype => $sublabel,
				 -type => "int", -default => $self->{LEGENDOFFSETY}[$i]);

	
	$optobj->register_option($section,"XDATA", -label => "X-Axis data", 
				 -caller => $self, -pack => 1,  -subtype => $sublabel,
			     -values => ["CPU","CPUWALL","WALL","QUEUETIME","DISPATCHTIME","QUEUE"],
				 -type => "optionmenu", -default => $self->{XDATA}[$i]);
	
	$optobj->register_option($section,"YDATA", -label => "Y-Axis data", 
				 -caller => $self, -pack => 1,  -subtype => $sublabel,
				 -values => ["COUNT","CPU","CPUWALL","WALL"],
				 -type => "optionmenu", -default => $self->{YDATA}[$i]);
	
	$optobj->register_option($section,"STEPWIDTH", -label => "Stepwidth (xdata)", 
				 -caller => $self,-pack => 1, -min => 0.01, -max => 1000,  -subtype => $sublabel,
				 -type => "int", -default => $self->{STEPWIDTH}[$i]);
	
	$optobj->register_option($section,"XLOG", -label => "Log x data", 
				 -caller => $self, -pack => 1,  -subtype => $sublabel,
				 -values => ["LINEAR","LOG10","LOG2"],
				 -type => "optionmenu", -default => $self->{XLOG}[$i]);

	$optobj->register_option($section,"YLOG", -label => "Log y data", 
				 -caller => $self, -pack => 1,  -subtype => $sublabel,
				 -values => ["LINEAR","LOG10","LOG2"],
				 -type => "optionmenu", -default => $self->{YLOG}[$i]);
	
	$optobj->register_option($section,"XFORMAT", -label => "Format X", 
				 -caller => $self,-pack => 1, -subtype => $sublabel,
				 -fieldwidth => 12,
				 -type => "string", -default => $self->{XFORMAT}[$i]);

	$optobj->register_option($section,"YFORMAT", -label => "Format Y", 
				 -caller => $self,-pack => 2, -subtype => $sublabel,
				 -fieldwidth => 12,
				 -type => "string", -default => $self->{YFORMAT}[$i]);

	$optobj->register_option($section,"FILLCOLOR", -label => "Fill Color", 
				 -caller => $self,-pack => 1, -subtype => $sublabel,
				 -fieldwidth => 12,
				 -type => "string", -default => $self->{FILLCOLOR}[$i]);

	$optobj->register_option($section,"FILLCOLORRUN", -label => "Fill Color (Run)", 
				 -caller => $self,-pack => 2, -subtype => $sublabel,
				 -fieldwidth => 12,
				 -type => "string", -default => $self->{FILLCOLORRUN}[$i]);

    }


    $optobj->register_comment($section,"COMMENT1", 
			      -text => "\n Global Option for all diagrams\n", 
			      -type => "comment");

    $optobj->register_option($section,"SELECTEDDIAGRAM", -label => "Display Diagram", 
			     -caller => $self, -pack => 1,
			     -values => $self->{SUBNAMES},
#			     -raisenb => "$section",
#			     -raisenb => "Histogram",
			     -type => "optionmenu", -default => $self->{SELECTEDDIAGRAM});
    
    $optobj->register_option($section,"MAXDISPLAYED", -label => "# diagram to display", 
			     -caller => $self, -min => 0, -max => ($#{$self->{SUBNAMES}}+1), -pack => 1, 
			     -type => "int", -default => $self->{MAXDISPLAYED}, -step => 10);

    $optobj->register_option($section,"AUTOUPDATEMAX", -label => "autoplay delay (s)", 
			     -caller => $self, -min => 0, -max => 600, -pack => 2, 
			     -type => "int", -default => $self->{AUTOUPDATEMAX}, -step => 10);

    $optobj->register_option($section,"POSX", -label => "posx", 
			     -caller => $self,-pack => 1, 
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);
    
    $optobj->register_option($section,"POSY", -label => "posy", 
			     -caller => $self,-pack => 2, 
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSY}, -step => 10);
    
    $optobj->register_option($section,"HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2, 
			     -type => "int", -min => 50, -max => 1200, -default => $self->{HEIGHT}, -step => 10);
	
    $optobj->register_option($section,"WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2, 
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);
	
    $optobj->register_option($section,"Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option($section,"BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT1});
   
   
#    for($i=0;$i<($self->{WIDTH}-$self->{LEFTPAD}-$self->{RIGHTPAD});$i++) {
#	push(@{$self->{USAGE}},50);
#    }

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{BUILDREADY}=1;

    return();
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val,$subnum)=@_;
    my($diffx,$diffy,$id);
#    print "histogram_sb,optvalchanged: $section,$name -> $val ($subnum)\n";
    if(($name eq "HEIGHT") || ($name eq "WIDTH")) {
	$self->{$name}=$val;
	shift(@{$self->{USAGE}}) while($#{$self->{USAGE}}>($self->{WIDTH}-$self->{LEFTPAD}-$self->{RIGHTPAD}));
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
    }
    if( ($name eq "POSX") || ($name eq "POSY")) {
	$diffx=$diffy=0;
	$diffx=$val-$self->{$name} if ($name eq "POSX");
	$diffy=$val-$self->{$name} if ($name eq "POSY");
	$self->{$name}=$val;
	foreach $id (@{$self->{FIXEDITEMS}}) {
	    $self->{CANVAS}->move($id,$diffx,$diffy)  if ($self->{BUILDREADY});
	}
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
    }
    if ($name eq "Font") {
	$self->{FONT1}=$val;
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
    }
    if ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
    }
    

    if($subnum) {
	if ($name=~/(JOBSELECTION|XDATA|YDATA|STEPWIDTH|MAXSTEPS|XLOG|YLOG|TITLE|FORMAT|COLOR|LEGENDOFFSET)/) {
	    my $i=$self->{SUBNAMESTONR}->{$subnum};
	    $self->{$name}[$i]=$val;
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},
				$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},
			  $self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
	}
    } else {
	if ($name=~/(SELECTEDDIAGRAM|MAXDISPLAYED)/) {
	    $self->{$name}=$val;
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},
				$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},
			  $self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
	}
    }
    

 
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub stepdiagramcnt {
    my($self) = shift;
    my($dnr);
    $self->{AUTOUPDATECNT}++;
    return(1) if($self->{AUTOUPDATECNT}<$self->{AUTOUPDATEMAX});
    $self->{AUTOUPDATECNT}=0;
    $dnr=$self->{SUBNAMESTONR}->{$self->{SELECTEDDIAGRAM}};
    $dnr++; $dnr=0 if($dnr>=$self->{MAXDISPLAYED});
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},$self->{TABNAME},"SELECTEDDIAGRAM",$self->{SUBNAMES}->[$dnr]);
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name,$frame,$subwidget,$dy,$dnr);

    print "WF: update_fixed ($self->{SELECTEDDIAGRAM})\n" if($debug>2);

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    $id=$canvas->createRectangle($self->{POSX},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH},
				 $self->{POSY}+$self->{HEIGHT},
				 -fill => "grey90");
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				 -fill => "grey60");
    push(@{$self->{FIXEDITEMS}},$id);


    $dy=$self->{HEIGHT}/($#{$self->{SUBNAMES}}+1);
    for($i=0;$i<$self->{MAXDISPLAYED};$i++) {
	$self->{BUTTON}->[$i]=$id=$canvas->createRectangle($self->{POSX}-12,$self->{POSY}+$i*$dy+1,
							   $self->{POSX}-2,$self->{POSY}+($i+1)*$dy-1,
							   -fill => "grey80",-tags => ["DIABUTTON${i}"]);
	push(@{$self->{FIXEDITEMS}},$id);
	$id=$canvas->createText($self->{POSX}-6,$self->{POSY}+($i+0.5)*$dy,
				-anchor => "center", # text will be centered over that point
				-text => $i+1,
				-font => $self->{FONT2},
				-tags => ["DIABUTTON${i}"]);
	push(@{$self->{FIXEDITEMS}},$id);
	$canvas->bind("DIABUTTON${i}", '<ButtonPress-1>' => [ \&change_selected_diagram, "$i",$self->{INSTANCENR} ] );
    }
    $dnr=$self->{SUBNAMESTONR}->{$self->{SELECTEDDIAGRAM}};
    $canvas->itemconfigure($self->{BUTTON}->[$dnr],-fill => "yellow");
}

sub change_selected_diagram {
    my ($canvas,$nr, $instancenr)=@_;
    my($i);
    my $self=${$selfref[$instancenr]};
    print "WF: change_selected_diagram: nr=$nr instancenr=$instancenr $self->{CLUSTERNAME}\n" if($debug>=2);
    for($i=0;$i<$#{$self->{SUBNAMES}};$i++) {
	$canvas->itemconfigure($self->{BUTTON}->[$i],-fill => "grey80");
    }
    $canvas->itemconfigure($self->{BUTTON}->[$nr],-fill => "yellow");
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},$self->{TABNAME},"SELECTEDDIAGRAM",$self->{SUBNAMES}->[$nr]);

}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$nonewdata)=@_;
    my($minxval,$maxxval,$minyval,$maxyval,$stepwidth,$ydataref,$ydatarunref,$xavg,$yavg,$xlabelsref);
    my($dnr);

    $nonewdata=0 if(!defined($nonewdata));
    $self->clean($dataobj,$colorobj,$canvas);

    $dnr=$self->{SUBNAMESTONR}->{$self->{SELECTEDDIAGRAM}};
    print "WF: update DIAGRAMNR=$dnr ($self->{SELECTEDDIAGRAM})\n" if($debug>2);

    ($minxval,$maxxval,$minyval,$maxyval,$stepwidth,$ydataref,$ydatarunref,$xavg,$yavg,$xlabelsref)=
	$self->scandata($self->{JOBSELECTION}[$dnr],$self->{XDATA}[$dnr],$self->{YDATA}[$dnr],
			$self->{STEPWIDTH}[$dnr],$self->{MAXSTEPS}[$dnr],$self->{XLOG}[$dnr],$self->{YLOG}[$dnr]);
    print"WF: found values in x-range $minxval,$maxxval and y-range $minyval,$maxyval, stepwidth=$stepwidth\n" if($debug>=2);
    $self->plotlegend($canvas,
		      $self->{POSX},$self->{POSY},
		      $self->{LEFTPAD},$self->{BOTTOMPAD},$self->{TOPPAD},
		      $self->{WIDTH}-$self->{RIGHTPAD}-$self->{LEFTPAD},
		      $self->{HEIGHT}-$self->{BOTTOMPAD}-$self->{TOPPAD},
		      $self->{XLOG}[$dnr],$self->{YLOG}[$dnr],$self->{XFORMAT}[$dnr],$self->{YFORMAT}[$dnr],
		      $self->{XDATA}[$dnr],$self->{YDATA}[$dnr],
		      $minxval,$maxxval,$minyval,$maxyval,$stepwidth,$xavg,$yavg,$xlabelsref);
    $self->plotdata($canvas,
		    $self->{POSX}+$self->{LEFTPAD},$self->{POSY}+$self->{TOPPAD},
		    $self->{WIDTH}-$self->{RIGHTPAD}-$self->{LEFTPAD}, $self->{HEIGHT}-$self->{BOTTOMPAD}-$self->{TOPPAD},
		    $self->{XLOG}[$dnr],$self->{YLOG}[$dnr],
		    $self->{FILLCOLOR}[$dnr],$self->{FILLCOLORRUN}[$dnr],$self->{JOBSELECTION}[$dnr],
		    $minxval,$maxxval,$minyval,$maxyval,$stepwidth,$ydataref,$ydatarunref);

    my ($myxtitle,$myytitle)=$self->determine_axistitles($self->{XDATA}[$dnr],$self->{YDATA}[$dnr],
							 $self->{XFORMAT}[$dnr],$self->{YFORMAT}[$dnr]);
    $self->plottitles($canvas,
		      $self->{POSX},$self->{POSY},$self->{LEFTPAD},$self->{BOTTOMPAD},
		      $self->{WIDTH}-$self->{RIGHTPAD}-$self->{LEFTPAD}, $self->{HEIGHT}-$self->{BOTTOMPAD},
		      $self->{JOBSELECTION}[$dnr], 
		      $self->{XDATA}[$dnr],$self->{YDATA}[$dnr],
		      $self->{XFORMAT}[$dnr],$self->{YFORMAT}[$dnr],
		      $self->{FILLCOLOR}[$dnr],$self->{FILLCOLORRUN}[$dnr],
		      $self->{LEGENDOFFSETX}[$dnr],$self->{LEGENDOFFSETY}[$dnr],
		      ($dnr+1).": ".$self->{TITLE}[$dnr],$myxtitle,$myytitle,$xavg,$yavg);

    return();
}

sub scandata {
    my($self) = shift;
    my($jobselection,$xdatamode,$ydatamode,$stepwidth,$maxsteps,$xlog,$ylog)=@_;
    my(@scanjobids,$cpus,@xdata,@ydata,@ydatarun,%ydata,%ydatarun,$jobid,$wallh);
    my($xval,$minxval,$maxxval,$diff,$val,$minyval,$maxyval,$i,$wavg,$number,$sumy,$sumx,$vals);
    my(@xlabels,%queues,$queuecnt);
    my $dataobj=$self->{DATAOBJECT};

    %queues=();
    print"WF: starting scandata $jobselection,$xdatamode,$ydatamode\n" if($debug>=2);

    # @xdata: values found, sorted by size
    # @ydata: values found, sorted by xdata order
    # %xdata: position in vectors

    @scanjobids=(keys( %{$dataobj->{RUNNINGJOBS}})) if($jobselection eq "RUN");
    @scanjobids=(keys( %{$dataobj->{WAITINGJOBS}})) if($jobselection eq "WAIT");
    @scanjobids=(keys( %{$dataobj->{JOBSTATE}})) if($jobselection eq "ALL");
    @scanjobids=(keys( %{$dataobj->{JOBSTATE}})) if($jobselection eq "ALLSEP");
    
    if($xdatamode eq "QUEUE") {
	@scanjobids=(sort {$dataobj->{JOBSTATE}->{$a}{"job_queue"} cmp $dataobj->{JOBSTATE}->{$b}{"job_queue"} } @scanjobids);
    }

    $minxval= 1e20;    $maxxval=-1e20; $queuecnt=0;
    $number=$wavg=$sumx=$sumy=0;
    foreach $jobid (@scanjobids) {
	next if(!$jobid);
	next if($dataobj->{JOBSTATE}->{$jobid}{"job_statuslong"} eq "HOLD");
	next if($dataobj->{JOBSTATE}->{$jobid}{"job_statuslong"} eq "REMOVED");
	$cpus=($dataobj->{JOBSTATE}->{$jobid}{"job_nummachines"}
	       *$dataobj->{JOBSTATE}->{$jobid}{"job_taskspernode"}
	       *$dataobj->{JOBSTATE}->{$jobid}{"job_conscpu"});  
	$wallh=$dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600;

#	print "WF scanjobids $jobid $cpus \n" if($debug>=2);
	if($xdatamode eq "QUEUETIME") {
	    next if($dataobj->{JOBSTATE}->{$jobid}{"job_queuedate"} eq "-");
	    $xval=&timediff(($dataobj->{JOBSTATE}->{$jobid}{"job_dispatchdate"} eq "-")? # already started?
			       $dataobj->{MACHSTATE}->{"system_time"}:
			       $dataobj->{JOBSTATE}->{$jobid}{"job_dispatchdate"},
			     $dataobj->{JOBSTATE}->{$jobid}{"job_queuedate"})/3600;
	} elsif($xdatamode eq "DISPATCHTIME") {
	    next if($dataobj->{JOBSTATE}->{$jobid}{"job_dispatchdate"} eq "-");
	    $xval=&timediff($dataobj->{MACHSTATE}->{"system_time"},
			    $dataobj->{JOBSTATE}->{$jobid}{"job_dispatchdate"})/3600;
	} elsif($xdatamode eq "CPU") {
	    printf("WF: $jobid cpus=$cpus %d %d %d\n",$dataobj->{JOBSTATE}->{$jobid}{"job_nummachines"},
		   $dataobj->{JOBSTATE}->{$jobid}{"job_taskspernode"},
		   $dataobj->{JOBSTATE}->{$jobid}{"job_conscpu"}) if($debug>=2);
	    $xval=$cpus;
	} elsif($xdatamode eq "WALL") {
	    $xval=$cpus;
	} elsif($xdatamode eq "CPUWALL") {
	    $xval=$cpus;
	} elsif($xdatamode eq "QUEUE") {
	    if(!exists($queues{$dataobj->{JOBSTATE}->{$jobid}{"job_queue"}})) {
		$queues{$dataobj->{JOBSTATE}->{$jobid}{"job_queue"}}=$queuecnt;
		$xlabels[$queuecnt]=$dataobj->{JOBSTATE}->{$jobid}{"job_queue"};
		$queuecnt++;
	    }
	    $xval=$queues{$dataobj->{JOBSTATE}->{$jobid}{"job_queue"}};
	    print "WF: QUEUE $xval=$xval ($dataobj->{JOBSTATE}->{$jobid}{'job_queue'})\n" if($debug>=2);
	}
#	print "WF: CPUSHOUR ydatamode=$ydatamode\n";
	if($ydatamode eq "COUNT") {
	    $val=1;
	} elsif($ydatamode eq "CPU") {
	    $val=$cpus;
	} elsif($ydatamode eq "WALL") {
	    $val=$wallh;
	} elsif($ydatamode eq "CPUWALL") {
	    $val=$cpus*$wallh;
	}
	$ydata{$xval}+=$val;
	$ydatarun{$xval}+=$val if($dataobj->{JOBSTATE}->{$jobid}{"job_type"} eq "running");
	$wavg+=$xval*$val;
	$sumx+=$xval;	$sumy+=$val;
	$number++;

	$minxval=$xval if($xval<$minxval);
	$maxxval=$xval if($xval>$maxxval);
    }
    $sumx=1 if($sumx==0);    $sumy=1 if($sumy==0); $number=1 if($number==0);
    
    print "WF: number=$number sumx=$sumx sumy=$sumy xavg=",$wavg/$sumy," yavg=",$sumy/$number,"\n" if($debug>=2);


    $stepwidth=1 if($xdatamode=~/^QUEUE$/);
    
    if($xlog eq "LINEAR") {
	$diff=$maxxval-$minxval;
	if($diff/$maxsteps>$stepwidth) {
	    print"WF: enlarge stepwidth from $stepwidth to ",$diff/$maxsteps,"\n" if($debug>=2);
	    $stepwidth=$diff/$maxsteps;
	}

	foreach $xval (keys(%ydata)) {
	    $val=int($xval/$stepwidth);
	    $ydata[$val]+=$ydata{$xval};
#           print "WF: mapdata $xval -> $val += $ydata{$xval}\n" if($debug>=2);
	}
	foreach $xval (keys(%ydatarun)) {
	    $val=int($xval/$stepwidth);
	    $ydatarun[$val]+=$ydatarun{$xval};
#           print "WF: mapdata $xval -> $val += $ydata{$xval} run\n" if($debug>=2);
	}
    } else {
	foreach $xval (keys(%ydata)) {
	    $vals=&scale($xval,$xlog);
	    if(int($vals) ne $vals) {		$val=int($vals)+1;	    } else {		$val=$vals;	    }
	    $ydata[$val]+=$ydata{$xval};
            print "WF: mapdata $xval -> $vals -> $val += $ydata{$xval}\n" if($debug>=2);
	}
	foreach $xval (keys(%ydatarun)) {
	    $vals=&scale($xval,$xlog);
	    if(int($vals) ne $vals) {		$val=int($vals)+1;	    } else {		$val=$vals;	    }
	    $ydatarun[$val]+=$ydatarun{$xval};
#           print "WF: mapdata $xval -> $val += $ydata{$xval} run\n" if($debug>=2);
	}
    }

    $minyval=1e20;    $maxyval=-1e20;
    for($i=0;$i<=$#ydata;$i++)  {
	$ydata[$i]=0 if(!$ydata[$i]);
	$ydatarun[$i]=0 if(!$ydatarun[$i]);
	$minyval=$ydata[$i] if($ydata[$i]<$minyval);
	$maxyval=$ydata[$i] if($ydata[$i]>$maxyval);
    }
    print"WF: ending scandata $jobselection,$xdatamode,$ydatamode $minyval,$maxyval\n" if($debug>=2);
    return($minxval,$maxxval,$minyval,$maxyval,$stepwidth,\@ydata,\@ydatarun,$wavg/$sumy,$sumy/$number,\@xlabels);
}


sub plotdata {
    my($self) = shift;
    my($canvas,$xpos,$ypos,$width,$height,$xlog,$ylog,$fillcolor,$fillcolorrun,$jobselection,
       $minxval,$maxxval,$minyval,$maxyval,$stepwidth,$ydataref,$ydatarunref)=@_;
    my($i,$dx,$dy,$id);
    my $numval=$#{$ydataref};
    
    # calculate grid size
    return if($maxyval<=0);
    $dx=$width/($numval+1);
    $dy=$height/&scale($maxyval,$ylog);

    # draw bars
    for($i=0;$i<=$numval;$i++) {
	print"WF: plotdata $i $ydataref->[$i] ",&scale($ydataref->[$i],$ylog)," [",&scale($ydataref->[$i],$ylog),
	"] ($ylog,dy=$dy)\n" if($debug>=2);
	if(&scale($ydataref->[$i],$ylog)*$dy>=1) { # at least one pixel
	    if($jobselection eq "ALLSEP") {
		$id=$canvas->createRectangle($xpos+$i*$dx,$ypos+$height,
					     $xpos+($i+1)*$dx,$ypos+$height-&scale($ydatarunref->[$i],$ylog)*$dy,
					     -fill => $fillcolorrun);
		push(@{$self->{ITEMS}},$id);
		$id=$canvas->createRectangle($xpos+$i*$dx,$ypos+$height-&scale($ydatarunref->[$i],$ylog)*$dy,
					     $xpos+($i+1)*$dx,$ypos+$height-&scale($ydataref->[$i],$ylog)*$dy,
					     -fill => $fillcolor);
		push(@{$self->{ITEMS}},$id);
	    } else {
		$id=$canvas->createRectangle($xpos+$i*$dx,$ypos+$height,
					     $xpos+($i+1)*$dx,$ypos+$height-&scale($ydataref->[$i],$ylog)*$dy,
					     -fill => $fillcolor);
		push(@{$self->{ITEMS}},$id);
	    }
	}
    }
}

sub plotlegend {
    my($self) = shift;
    my($canvas,$xpos,$ypos,$leftpad,$bottompad,$toppad,$width,$height,$xlog,$ylog,$xformat,$yformat,$xdata,$ydata,
       $minxval,$maxxval,$minyval,$maxyval,$stepwidth,$xavg,$yavg,$xlabelsref)=@_;
    my($x,$xs,$y,$ys,$dx,$dy,$id,$pos,$text,$textwidth,$textheight,$lasttextpos,$lastlinepos);
    my($ystepwidth,$maxnumber,@markerpoints);

    return if($maxyval<=0);
    return if($stepwidth<=0);

    my $numval=int(&scale($maxxval,$xlog)/$stepwidth);
    
    # calculate grid size
    $dx=$width/($numval+1);

    # x-data
    print "WF: numval=",$numval,"\n" if($debug>=2);
    print "WF: font size:",$canvas->fontMeasure($self->{FONT1}, "SHORT"), "\n" if($debug>=2);

    # x avg.
    $pos=$xpos+$leftpad+$dx*($xavg/$stepwidth);
    $id=$canvas->createLine($pos,$ypos+$height+10, 
			    $pos,$ypos,
			    -fill => "blue",
			    -width=> 1 );
    push(@{$self->{ITEMS}},$id);

    $lasttextpos=-100;
    foreach $x ($self->determine_markerpoints_x($maxxval,$stepwidth,$xlog)) {
#    for($x=0;$x<=$maxxval;$x+=$stepwidth) {
	$xs=&scale($x,$xlog);
	$pos=$xpos+$leftpad+$dx*($xs/$stepwidth)+0.5*$dx;
	printf("WF: marker at xs=%10.4f dx=%8.2f x=%10.4f pos=%10.4f lasttextpos=%10.4f\n",
	       $xs,$dx,$x,$pos,$lasttextpos) if($debug>=2);
	if($xdata!~/^QUEUE$/) {
	    $text=$self->textformat($xformat,$x+$stepwidth) if($xlog eq "LINEAR");
	    $text=$self->textformat($xformat,$x) if($xlog ne "LINEAR");
	} else {
	    my $textwidth=8;
	    if($xformat=~/\%(\d+)s/) {
		$textwidth=$1;
	    }
	    $text=substr($xlabelsref->[$x],0,$textwidth);
	}
	$textwidth=$canvas->fontMeasure($self->{FONT1}, $text);
	if($pos-0.5*$textwidth>($lasttextpos+2)) {
	    $id=$canvas->createLine($pos,$ypos+$toppad+$height, 
				    $pos,$ypos+$toppad+$height+2, 
				    -width=> 1 );
	    push(@{$self->{ITEMS}},$id);
	    $id=$canvas->createText($pos,$ypos+$toppad+$height+2, 
				    -anchor => "n", # text will be centered over that point
				    -text => $text,
				    -font => $self->{FONT1});
	    push(@{$self->{ITEMS}},$id);
	    $lasttextpos=$pos+0.5*$textwidth;
	}
    }


    
    # y data
    $textheight=$canvas->fontMetrics($self->{FONT1},-linespace);
    print "WF: textheight=$textheight, $maxyval,$ylog\n" if($debug>=2);

    $dy=$height/&scale($maxyval,$ylog);
    $maxnumber=int($height/$textheight)+1;
    $lasttextpos=$lastlinepos=-100;
    foreach $y ($self->determine_markerpoints($maxyval,$maxnumber,$ylog)) {
	$ys=&scale($y,$ylog);
	$pos=$ys*$dy;
	printf("WF: marker at ys=%10.4f dy=%8.2f y=%10.4f pos=%10.4f lastlinepos=%10.4f height=$height\n",
	       $ys,$dy,$y,$pos,$lastlinepos,$height) if($debug>=2);
	if (($pos>$lastlinepos) && ($pos<=$height)) {
	    $id=$canvas->createLine($xpos+$leftpad-2,$ypos+$toppad+$height-$pos, 
				    $xpos+$leftpad+$width,  $ypos+$toppad+$height-$pos, 	
				    -fill => "grey50",
				    -width=> 1 );
	    push(@{$self->{ITEMS}},$id);
	    $lastlinepos=$pos;
	    if ( ($pos-0.5*$textheight>($lasttextpos-1)) || ($y==$maxyval)) {
		$text=$self->textformat($yformat,$y);
#		$text=sprintf($yformat,$y);
#		$pos=$height-$textheight if($pos>$height);
		$id=$canvas->createText($xpos+0.9*$leftpad,$ypos+$toppad+$height-$pos, 
					-anchor => "e", # text will be centered over that point
					-text => $text,
					-font => $self->{FONT1});
		push(@{$self->{ITEMS}},$id);
		$lasttextpos=$pos+0.5*$textheight;
	    }
	}
    }

    # x avg.
    $pos=$dy*&scale($yavg,$ylog);
    $id=$canvas->createLine($xpos+$leftpad-2,$ypos+$toppad+$height-$pos, 
			    $xpos+$leftpad+$width,  $ypos+$toppad+$height-$pos, 	
			    -fill => "blue",
			    -width=> 1 );
    push(@{$self->{ITEMS}},$id);
    
}

sub determine_markerpoints {
    my($self) = shift;
    my($maxval,$maxnumber,$ylog)=@_;
    my(@markerpoints,$i,$j,$di);
    if($ylog eq "LINEAR") {
#	push(@markerpoints,0);
	$di=$maxval/$maxnumber;
	if($maxval<=10) {
	    $di=1;
	} elsif($maxval<100) {
	    push(@markerpoints,1);
	    push(@markerpoints,5);
	    $di=10;
	} elsif($maxval<5000) {
	    push(@markerpoints,100);
	    push(@markerpoints,250);
	    $di=500;
	} elsif($maxval<10000) {
	    push(@markerpoints,100);
	    push(@markerpoints,500);
	    $di=1000;
	} elsif($maxval<50000) {
	    push(@markerpoints,1000);
	    push(@markerpoints,2500);
	    $di=5000;
	} elsif($maxval<100000) {
	    push(@markerpoints,1000);
	    push(@markerpoints,5000);
	    $di=10000;
	}
	for($i=$di;$i<$maxval;$i+=$di) {
	    push(@markerpoints,$i);
	}
    } elsif($ylog eq "LOG10") {
	for($i=1;$i<$maxval;$i*=10) {
	    push(@markerpoints,$i);
	    push(@markerpoints,$i*5);
	}
    } elsif($ylog eq "LOG2") {
	for($i=1;$i<$maxval;$i*=2) {
	    push(@markerpoints,$i);
	}
    }    
    push(@markerpoints,$maxval);
    print "WF: determine_markerpoints $maxval,$maxnumber,$ylog [@markerpoints]\n" if($debug>=2);
    return(@markerpoints);
}

sub determine_markerpoints_x {
    my($self) = shift;
    my($maxval,$stepwidth,$xlog)=@_;
    my(@markerpoints,$i,$j,$di);
    if($xlog eq "LINEAR") {
	for($i=0;$i<=$maxval;$i+=$stepwidth) {
	    push(@markerpoints,$i);
	}
    } elsif($xlog eq "LOG10") {
	for($i=1;$i<=$maxval;$i*=10) {
	    push(@markerpoints,$i);
	}
    } elsif($xlog eq "LOG2") {
	for($i=1;$i<=$maxval;$i*=2) {
	    push(@markerpoints,$i);
	}
    }    
    print "WF: determine_markerpoints_x $maxval,$stepwidth,$xlog [@markerpoints]\n" if($debug>=2);
    return(@markerpoints);
}

sub textformat {
    my($self) = shift;
    my($format,$data)=@_;
    my($text);
    if($format eq "dayhour") {
	my($days,$hours);
	$days=int(($data)/24.0);
	$hours=($data)-$days*24.0;
	if($days==0) {
	    $text=sprintf("%02dh",$hours);
	} elsif($hours<1.0) {
	    $text=sprintf("%dd",$days);
	} else {
	    $text=sprintf("%dd:%02dh",$days,$hours);
	}
    } elsif($format eq "day") {
	$text=sprintf("%3.2f",($data)/24.0);
    } elsif($format eq "tcpuh") {
	$text=sprintf("%3.1f",($data)/1000.0);
    } else {
	$text=sprintf($format,$data);
    }
    return($text);
}

sub plottitles {
    my($self) = shift;
    my($canvas,$xpos,$ypos,$leftpad,$bottompad,$width,$height,$jobselection,$xdata,$ydata,$xformat,$yformat,$fillcolor,$fillcolorrun,
       $offsetx,$offsety,
       $title,$xtitle,$ytitle,$xavg,$yavg)=@_;
    my($id,$text); 

    $id=$canvas->createText($xpos+2,$ypos+$height+$bottompad/2-2, 
			    -anchor => "nw", # text will be centered over that point
			    -text => $title,
			    -font => $self->{BFONT1});
    push(@{$self->{ITEMS}},$id);

    if($xdata!~/^QUEUE$/) {
	$text=$self->textformat($xformat,$xavg);
	$id=$canvas->createText($xpos+$width*0.4+$leftpad,$ypos+$height+$bottompad/2, 
				-anchor => "n", # text will be centered over that point
				-text => "wght. avg(x)=".$text,
				-font => $self->{FONT1});
	push(@{$self->{ITEMS}},$id);
    }

    $text=$self->textformat($yformat,$yavg);
    $id=$canvas->createText($xpos+$width*0.7+$leftpad,$ypos+$height+$bottompad/2, 
			    -anchor => "n", # text will be centered over that point
			    -text => "avg(y)=".$text,
			    -font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);


    $id=$canvas->createText($xpos+$width+$leftpad*0.9,$ypos+$height+$bottompad/2, 
			    -anchor => "ne", # text will be centered over that point
			    -text => $xtitle,
			    -font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);

    $ytitle=~s/(.)/$1\n/gs;
    $id=$canvas->createText($xpos+$leftpad*0.05,$ypos+0.8*$height, 
			    -anchor => "w", # text will be centered over that point
			    -text => $ytitle,
			    -font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);
    
    
    if($jobselection eq "ALLSEP") {
	# Legend for running waiting jobs
	my($px,$py,$dx,$dy)=($xpos+$leftpad+$offsetx,$ypos+$offsety,115,15);
	$id=$canvas->createRectangle($px,$py,$px+$dx,$py+$dy, -fill => "grey90");
	push(@{$self->{ITEMS}},$id);

	$id=$canvas->createRectangle($px+3,$py+3,$px+13,$py+11, -fill => $fillcolorrun);
	push(@{$self->{ITEMS}},$id);

	$id=$canvas->createText($px+15,$py+2, -anchor => "nw",-text => "running",-fill => "grey30",-font => $self->{FONT1});
	push(@{$self->{ITEMS}},$id);

	$id=$canvas->createRectangle($px+53,$py+3,$px+63,$py+11, -fill => $fillcolor);
	push(@{$self->{ITEMS}},$id);

	$id=$canvas->createText($px+65,$py+2, -anchor => "nw",-text => "waiting jobs",-fill => "grey30",-font => $self->{FONT1});
	push(@{$self->{ITEMS}},$id);

    }



}

sub determine_axistitles {
    my($self) = shift;
    my($xdata,$ydata,$xformat,$yformat)=@_;
    my($xtitle,$ytitle);
    
    $xtitle=$ytitle="unknown";
    $ytitle="count" if($ydata eq "COUNT");
    $ytitle="cpuh"  if($ydata eq "CPUWALL");
    $ytitle="#cpu"  if($ydata eq "CPU");
    $ytitle="hours" if($ydata eq "WALL");

    $ytitle="Tcpuh"  if($yformat eq "tcpuh");


    $xtitle="queue" if($xdata eq "QUEUE");
    $xtitle="time (hours)" if($xdata eq "QUEUETIME");
    $xtitle="time (hours)" if($xdata eq "DISPATCHTIME");
    $xtitle="#CPU" if($xdata eq "CPU");

    $xtitle="time (days)" if($xformat eq "day");
    $xtitle="time (days:hours)" if($xformat eq "dayhour");

    return($xtitle,$ytitle)
} 

sub scale {
    my($n,$log)=@_;
    return(log(($n>0)?$n:1)/log(10)) if($log eq "LOG10");
    return(log(($n>0)?$n:1)/log(2))  if($log eq "LOG2");
    return($n)                if($log eq "LINEAR");
}

sub unscale {
    my($nl,$log)=@_;
    return(exp($nl*log(10))) if($log eq "LOG10");
    return(exp($nl*log(2)))  if($log eq "LOG2");
    return($nl)                if($log eq "LINEAR");
}


sub date_to_sec {
    my ($date)=@_;
#    print"WF: date_to_sec $date\n";
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year \n";
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $timesec\n";
    return($timesec);
}

sub timediff {
    my ($date1,$date2)=@_;
#    print"WF: timediff >$date1< >$date2<\n";
    return(-1) if((!$date1) || (!$date2));
    my $timesec1=&date_to_sec($date1);
    my $timesec2=&date_to_sec($date2);
#    if((($timesec1-$timesec2)/3600)>100) {
#	printf("timediff: %20s - %20s -> %d\n",$date1,$date2,$timesec1-$timesec2);
#    }
    return($timesec1-$timesec2);
}

1;

