# $Source: /cvs/cvsroot/llview/lib/LLview_gui_info.pm,v $
# $Author: zdv087 $
# $Revision: 1.27 $
# $Date: 2007/06/19 14:04:37 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_info;
use strict;
my($debug)=0;
my($instancecnt)=-1;
my(@selfref)=(-1);


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_gui_info: new %s\n",ref($proto)) if($debug>=3);
    $self->{HAVEINFOMSG} = 0;
    $self->{VERBOSE} = 0;
    $self->{POSX}    = 35;
    $self->{POSY}    = 730;
    $self->{WIDTH}   = 70;
    $self->{HEIGHT}  = 12;
    $self->{TWOCOLUMN}=0;
    $self->{TEXT}    = "<no information>";
    $self->{FGCOL}   = "yellow";
    $self->{BGCOL}   = "grey40";
    $self->{TEXTTYPE}="default";
    $self->{TEXTNAME}="";
    $self->{ITEMS}      = [];
    $self->{FIXEDITEMS} = [];

    $self->{FONT0}       = "-*-Courier-Medium-R-Normal--*-100-*-*-*-*-*-*";
    $self->{BFONT0}      = "-*-Courier-Bold-R-Normal--*-100-*-*-*-*-*-*";

    $self->{BUILDREADY}=0;

    bless $self, $class;
    $instancecnt++;
    $self->{INSTANCENR} = $instancecnt;
    $selfref[$instancecnt]=\$self;
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($i,$name);
    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;

    my $frames=$dataobj->{FRAMES};


    $optobj->register_option("Info","POSX", -label => "posx", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option("Info","POSY", -label => "posy", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSY}, -step => 10);

    $optobj->register_option("Info","HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 1200, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option("Info","WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option("Info","TWOCOLUMN", -label => "Two column", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{TWOCOLUMN});

    $optobj->register_option("Info","FGCOL", -label => "Foreground color", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FGCOL});

    $optobj->register_option("Info","BGCOL", -label => "Background color", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BGCOL});

    $optobj->register_option("Info","Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT0});
    $optobj->register_option("Info","BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT0});

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{BUILDREADY}=1;

    return(1);
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id);
#    print "info_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY})\n"  if($self->{VERBOSE});
    if(($name eq "HEIGHT") || ($name eq "WIDTH")) {
	$self->{$name}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    if( ($name eq "POSX") || ($name eq "POSY")) {
	$diffx=$diffy=0;
	$diffx=$val-$self->{$name} if ($name eq "POSX");
	$diffy=$val-$self->{$name} if ($name eq "POSY");
	$self->{$name}=$val;
	foreach $id (@{$self->{FIXEDITEMS}}) {
	    $self->{CANVAS}->move($id,$diffx,$diffy)  if ($self->{BUILDREADY});
	}
	if ($self->{BUILDREADY}) {
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    if (($name eq "FGCOL") || ($name eq "BGCOL") || ($name eq "TWOCOLUMN")) {
	$self->{$name}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    if ($name eq "Font") {
	$self->{FONT0}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    if ($name eq "BoldFont") {
	$self->{BFONT0}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
 
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name);

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    $id=$self->{MSGAREA}=$canvas->Label(-borderwidth => 2, 
					-width => $self->{WIDTH}, 
					-height => $self->{HEIGHT}, 
					-font => $self->{FONT0}, 
					-relief => "sunken",
					-anchor => "nw",-justify => 'left',
					-background => $self->{BGCOL},
					-foreground => $self->{FGCOL},
				    -textvariable => \$self->{TEXT});
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createWindow($self->{POSX},$self->{POSY}, 
			  -window => $self->{MSGAREA}, -anchor => "nw");
    push(@{$self->{FIXEDITEMS}},$id);

}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    
    if($self->{TEXTTYPE} eq "default") {
	$self->defaultinfo();
    } elsif($self->{TEXTTYPE} eq "jobid") {
	$self->jobinfo($self->{TEXTNAME});
    } elsif($self->{TEXTTYPE} eq "freeinfo") {
	$self->freeinfo(); 
    } elsif($self->{TEXTTYPE} eq "callback") {
	&infocallback("ON",$self->{TEXTNAME},0,0,$self->{INSTANCENR});
    }
    
    return();
}

sub jobinfo {
    my($self) = shift;
    my($category,$jobstep)=@_;
    my($prefixpattern);
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    $self->{TEXTTYPE}="jobstep";
    $self->{TEXTNAME}="$jobstep";

    if($dataobject->{RUNNINGJOBS}->{$jobstep}) {
	$self->{TEXT}=$self->getjobinfo($jobstep,$dataobject);
    } else {
	$self->{TEXT}="unknown jobstep: $jobstep in $category\n";

	if($self->{BINDINGCAT}->{$category}) {
	    $self->{TEXT}=$self->{BINDINGCAT}->{$category}->generateinfo($dataobject,$colorobject,$self,$canvas,
									 $jobstep,0,0,$category);
	} else {
	    foreach $prefixpattern (keys(%{$self->{BINDINGPREFIX}})) {
		if($jobstep=~/^$prefixpattern/) {
		    $self->{TEXT}=$self->{BINDINGPREFIX}->{$prefixpattern}->generateinfo($dataobject,$colorobject,$self,$canvas,
											 $jobstep,0,0);
		    last;
		}
	    }
	}
    }

    $self->format_column();

    printf("LLview_gui_info: jobinfo(%s)=%s\n",$jobstep,$self->{TEXT})  if($debug==4);
   
    return();
}

sub getjobinfo {
    my($self) = shift;
    my($jobstep,$dataobject)=@_;
    my($infostr);
    my $o=$dataobject->{RUNNINGDATA};
    my $width2=($self->{WIDTH})/($self->{TWOCOLUMN}?2:1);
    
    $infostr=sprintf("Info for Jobstep %8s [%s] (%s)\n",$o->{$jobstep}->{FL_JOBID},substr($o->{$jobstep}->{FL_JOBNAME},0,30),$jobstep);
    $infostr.=sprintf("--------------------------------------------------------------\n");
    $infostr.=sprintf("  User:    %s\n", $o->{$jobstep}->{FL_USER});
    $infostr.=sprintf("  CPUs:    %d (%s)\n", $o->{$jobstep}->{FL_ALLCPU},$o->{$jobstep}->{FL_SPEC});
    $infostr.=sprintf("  Time:    %sh of %s, ending at %s \n", 
		      $o->{$jobstep}->{FL_USEDH}, $o->{$jobstep}->{FL_WALL},$o->{$jobstep}->{FL_ENDTIME});
    $infostr.=sprintf("  Class:   %s\n", $o->{$jobstep}->{FL_CLASS});
    $infostr.=sprintf("  Restart: %s    %s\n", $o->{$jobstep}->{FL_RESTART}, 
		      ($o->{$jobstep}->{FL_UNICORE} eq "U")?"submitted by Unicore":"");
    $infostr.=sprintf("  Exec:      ...%s \n", substr($o->{$jobstep}->{FL_TASKEXEC},-30));
    $infostr.=sprintf("  Nodelist: %s\n", 
		      format_bracket_list($o->{$jobstep}->{FL_STARTHOST},$width2-10,"\n           ") );
    $infostr.=sprintf("  Color:     %s (%d)\n",$self->{COLOROBJECT}->get_color("RUN",$jobstep),
                                               $self->{COLOROBJECT}->idtonr("RUN",$jobstep));
  
    return($infostr);
}


sub format_bracket_list {
    my($in,$width,$delim)=@_;
    my $out="";
    my $len=0;
    while($in=~s/^([^\)]+\))//) {
	$out.=$1;
	$len+=length($1);
	if($len>$width) {
	    $out.=$delim;
	    $len=0;
	}
    }
    return($out);
}

sub defaultinfo {
    my($self) = shift;
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    $self->{TEXTTYPE}="default";
    $self->{TEXT}=$dataobject->{DEFAULTINFO}; 
    $self->format_column();
    return();
}

sub freeinfo {
    my($self) = shift;
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    $self->{TEXTTYPE}="freeinfo";
    $self->{TEXT}=$dataobject->{FREEINFO};
    $self->format_column();
    return();
}

sub register_bind {
    my($self) = shift;
    my($name,$obj)=@_;
    if(!$self->{BINDING}->{$name}) {
	$self->{BINDING}->{$name}=$obj;
#	printf("infoobj->register_bind(%s,%s)\n",$name,ref($obj));
	$self->{CANVAS}->bind("$name", "<Enter>", sub { &infocallback("ON",$name,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR}); });
	$self->{CANVAS}->bind("$name", "<Leave>", sub { &infocallback("OFF",$name,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR}); });
    }
    
    return(1);
}

sub register_bind_motion {
    my($self) = shift;
    my($name,$obj)=@_;
    if(!$self->{BINDING}->{$name}) {
	$self->{BINDING}->{$name}=$obj;
#	printf("infoobj->register_bind(%s,%s)\n",$name,ref($obj));
	$self->{CANVAS}->bind("$name", "<Motion>", sub { &infocallback("ON",$name,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR}); });
    }
    
    return(1);
}

sub register_bind_enter {
    my($self) = shift;
    my($name,$obj)=@_;
    if(!$self->{BINDING}->{$name}) {
	$self->{BINDING}->{$name}=$obj;
#	printf("infoobj->register_bind(%s,%s)\n",$name,ref($obj));
	$self->{CANVAS}->bind("$name", "<Enter>", sub { &infocallback("ON",$name,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR}); });
    }
    
    return(1);
}

sub register_bind_leave {
    my($self) = shift;
    my($name,$obj)=@_;
    if(!$self->{BINDING}->{$name}) {
	$self->{BINDING}->{$name}=$obj;
#	printf("infoobj->register_bind(%s,%s)\n",$name,ref($obj));
	$self->{CANVAS}->bind("$name", "<Leave>", sub { &infocallback("ON",$name,$Tk::event->x,$Tk::event->y,$self->{INSTANCENR}); });
    }
    
    return(1);
}

sub register_prefix {
    my($self) = shift;
    my($name,$obj)=@_;
    if(!$self->{BINDINGPREFIX}->{$name}) {
	$self->{BINDINGPREFIX}->{$name}=$obj;
    }
    
    return(1);
}

sub register_category {
    my($self) = shift;
    my($name,$obj)=@_;
    if(!$self->{BINDINGCAT}->{$name}) {
	$self->{BINDINGCAT}->{$name}=$obj;
    }
    
    return(1);
}


sub setinfo {
    my $self=shift;
    my ($infostr)=@_;
    $self->{TEXT}=$infostr;
    $self->format_column();
}

sub infocallback {
    my ($state,$name,$x,$y, $instancenr)=@_;
    my $self=${$selfref[$instancenr]};
    my $dataobject=$self->{DATAOBJECT};
    my $colorobject=$self->{COLOROBJECT};
    my $canvas=$self->{CANVAS};
    print "infocallback: >$state<>$name<\n"  if($debug==4);
    if($state eq "ON") {
	$self->{TEXTTYPE}="callback";
	$self->{TEXTNAME}="$name";
	$self->{TEXT}=$self->{BINDING}->{$name}->generateinfo($dataobject,$colorobject,$self,$canvas,$name,$x,$y);
	$self->format_column();
    } else {
	$self->{TEXTTYPE}="default";
	$self->defaultinfo();
    }
    
}

sub format_column {
    my($self) = shift;
    my ($newtext,$i);
    return if (!$self->{TWOCOLUMN});
    my $width2=($self->{WIDTH}-1)/2;
    my @lines=split(/\n/,$self->{TEXT});
    my $numlines=$#lines+1;
    my $numlines2=$numlines/2;
    $newtext="";
    for($i=0;$i<$numlines2;$i++) {
	$newtext.=sprintf("%-${width2}s|%-${width2}s\n",
			  substr($lines[$i],0,$width2),
			  substr($lines[$i+$numlines2],0,$width2));
    }
    $self->{TEXT}=$newtext;
}

1;
