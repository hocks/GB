# $Source: /cvs/cvsroot/llview/lib/LLview_gui_partlist.pm,v $
# $Author: zdv087 $
# $Revision: 1.11 $
# $Date: 2007/04/17 13:13:45 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_partlist;
use LLview_gui_list;
use strict;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_gui_partlist_sb: new %s\n",ref($proto)) if($debug>=3);
    $self->{LISTOBJ} = LLview_gui_list->new();
    $self->{LISTOBJ}->register_parent($self);
    $self->{FONT1}   = $self->{LISTOBJ}->{FONT1};
    $self->{BFONT1}  = $self->{LISTOBJ}->{BFONT1};
    $self->{VERBOSE} = 0;
    $self->{DATAOBJECT}      = "";
    $self->{COLOROBJECT}     = "";
    $self->{SEARCHSTR}       = "";
    bless $self, $class;
    return $self;
}

sub register_data_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{DATAOBJECT}=$objref;
    return 1;
}

sub register_color_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{COLOROBJECT}=$objref;
    return 1;
}

sub set_searchstr {
    my($self) = shift;
    my($str) = @_;
    $self->{SEARCHSTR}=$str;
    $self->{LISTOBJ}->set_searchstr($self->{SEARCHSTR});
    return 1;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($i,$name);
    my $marker="PartList";

#	 part_name="R000_N0"
#	 part_nodelist="R00-M0-N0"
#	 part_owner=""
#	 part_mode="C"
#	 part_istorus="000"
#	 part_status="F"

    $self->{LISTOBJ}->register_hash($dataobj->{PARTITION});
    $self->{LISTOBJ}->register_column(1,"part_name",  "Name",   "%-18s","alpha", 120);
    $self->{LISTOBJ}->register_column(2,"part_owner", "Owner",  "%-18s","alpha", 120);
    $self->{LISTOBJ}->register_column(3,"part_mode",  "Mode",   "%4s", "alpha", 40);
    $self->{LISTOBJ}->register_column(4,"part_status","Status", "%4s", "alpha", 40);
        
    $self->{LISTOBJ}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj,$marker);

    $self->{SUBCANVAS}=$self->{LISTOBJ}->{SUBCANVAS};
    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;

    $self->{BUILDREADY}      = 1;    
    return(1);
}

sub scroll_to {
    my($self) = shift;
    my($jobid) = shift;
    $self->{LISTOBJ}->scroll_to($jobid);
}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($jobid,$nr,$num,$color,$mark,$text,$id);
    $self->{LISTOBJ}->update($dataobj,$colorobj,$infoobj,$canvas);

    return();
}


1;
