# $Source: /cvs/cvsroot/llview/lib/LLview_get_grid.pm,v $
# $Author: zdv087 $
# $Revision: 1.4 $
# $Date: 2007/04/27 11:06:51 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_get_grid;
use strict;
use LWP::Simple;
use LWP::UserAgent;
use Time::HiRes qw ( time );
use Compress::Zlib;
#use SOAP::Lite +trace => [qw(headers debug)];
use SOAP::Lite ;
use Data::Dumper;
use LLview_xml_tools;

my($debug)=3;

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_get_grid: new %s\n",ref($proto)) if($debug>=3);
    $self->{VERBOSE}  =0;

    $self->{CLUSTERNAME} = shift||"-"; # needed for button callback function 

    $self->{RUSFACTORY}    = "http://unigrids.org/2006/04/services/rusf";
    $self->{FACTORYPROXY}  = "http://zam025s02:7777/services/RUSFactoryService";
    $self->{RUSSERVICE}    = "http://unigrids.org/2006/04/services/rus";
    $self->{SERVICEPROXY}      = "http://zam025s02:7777/services/RUSService";

    $self->{SERVICE}      = undef;
    $self->{FACTORYSERVICE} = undef;
    $self->{HEADERACTION} = undef;
    $self->{HEADERWSA}    = undef;

    $self->{FILENAMEMASK} = "llqxml_%08d.xml";
    $self->{FILENAME}     = "llqxml_00000001.xml";

    $self->{URFORMAT} = 1;  

    $self->{OPTSECTION} ="GRID";
    $self->{STOREFILE}=0;
    $self->{STOREDIR} = "../data_grid";

    $self->{AUTACCESS} = 1;
    $self->{AUTUSERID} = "";
    $self->{AUTPASSWD} = "";

    $self->{STORETAR} =0;
    $self->{STORETARFILE} = "../data_grid/data_test1.tar";

    $self->{TARCMD} = "tar";
    $self->{DATA}          = "";
    $self->{ERRSTRING}     = "ok";

    $self->{XMLTOOLOBJ} = LLview_xml_tools->new();

    bless $self, $class;
    return $self;
}

sub init_options {
    my($self) = shift;
    my($optobj) = shift;
    $self->{OPTIONOBJECT}=$optobj;

    my $section=$self->{OPTSECTION};
    $optobj->register_option($section,"RUSFACTORY", -label => "rus factory", 
			     -caller => $self,-pack => 1, -labelwidth=>30, 
			     -type => "string", -default => $self->{RUSFACTORY});

    $optobj->register_option($section,"FACTORYPROXY", -label => "factory proxy", 
			     -caller => $self,-pack => 1, -labelwidth=>30, 
			     -type => "string", -default => $self->{FACTORYPROXY});

    $optobj->register_option($section,"RUSSERVICE", -label => "rus service", 
			     -caller => $self,-pack => 1, -labelwidth=>30, 
			     -type => "string", -default => $self->{RUSSERVICE});

    $optobj->register_option($section,"SERVICEPROXY", -label => "service proxy", 
			     -caller => $self,-pack => 1, -labelwidth=>30, 
			     -type => "string", -default => $self->{SERVICEPROXY});

    $optobj->register_option($section,"URFORMAT", -label => "XML Usage Record format", 
			     -caller => $self,-pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{URFORMAT});

#    $optobj->register_option($section,"FILENAMEMASK", -label => "Filename Mask", 
#			     -caller => $self,-pack => 1,
#			     -type => "string", -default => $self->{FILENAMEMASK});

#    $optobj->register_option($section,"STOREFILE", -label => "Store in Files", 
#			     -caller => $self,-pack => 1,
#			     -type => "radio", -default => $self->{STOREFILE});
#
#    $optobj->register_option($section,"STOREDIR", -label => "Directory", 
#			     -caller => $self,-pack => 1,
#			     -type => "string", -default => $self->{STOREDIR});
#
#    $optobj->register_option($section,"STORETAR", -label => "Store in Tar-File", 
#			     -caller => $self,-pack => 1,
#			     -type => "radio", -default => $self->{STORETAR});
#
#    $optobj->register_option($section,"STORETARFILE", -label => "File (tar)", 
#			     -caller => $self,-pack => 1,
#			     -type => "string", -default => $self->{STORETARFILE});
#
#    $optobj->register_option($section,"CNT", -label => "actual number", 
#			     -caller => $self,-pack => 1,
#			     -type => "int", -min => 0, -max => 200000, -default => $self->{CNT}, -step => 100);
#    $optobj->register_option($section,"FILENAME", -label => "actual filename", 
#			     -caller => $self,-pack => 1,
#			     -type => "string", -default => $self->{FILENAME});

}


sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id,$objname);
    print "locdata,optvalchanged: $section,$name -> $val\n" if($debug>=3);
    $self->{$name}=$val;
 
}

sub getdata {
    my($self) = shift;
    my($nr,$tstart,$tdiff,$tstart2,$tdiff2);
    my $ua;
    my $response;
    if(!$self->{SERVICE}) {
	
	# factory
	$tstart=time;
	$self->{FACTORYSERVICE} = SOAP::Lite -> uri($self->{RUSFACTORY})
	    -> proxy($self->{FACTORYPROXY});
	my $result = $self->{FACTORYSERVICE} -> CreateRUSR(["ttt"]) -> result();
	$self->{DISAMBIGUATOR}=$result->{'ReferenceParameters'}->{'ResourceDisambiguator'};
	$tdiff=time-$tstart;
	printf("llview: get service from factory %s in %6.2f s\n",$self->{RUSFACTORY},$tdiff) if ($debug>=3);

	# rus service
	$self->{SERVICE} = SOAP::Lite -> uri($self->{RUSSERVICE})-> proxy($self->{SERVICEPROXY});

	
	$self->{HEADERACTION}=SOAP::Header->name('add:Action' 
					    => "http://unigrids.org/2006/04/services/rus/RUS/ExtractUsageRecordsRequest")    
	    ->attr({'xmlns:add' => "http://www.w3.org/2005/08/addressing"});

	
	$self->{HEADERWSA}=SOAP::Header->name('add:To' 
					      => "http://zam025s02:7777/services/RUSService?res=$self->{DISAMBIGUATOR}")
	    ->attr({'xmlns:add' => "http://www.w3.org/2005/08/addressing",
		    'xmlns:env' => "http://schemas.xmlsoap.org/soap/envelope/", 
		    'xmlns:xsi' => "http://www.w3.org/2001/XMLSchema-instance",
		    'xmlns:xsd' => "http://www.w3.org/2001/XMLSchema", 
		    'xmlns:soap' => "http://schemas.xmlsoap.org/soap/envelope/", 
		    'xmlns:sg' => "http://docs.oasis-open.org/wsrf/sg-2"});
    }

    $tstart=time;
    $self->{DATA} = $self->{SERVICE} -> ExtractUsageRecords($self->{HEADERACTION},$self->{HEADERWSA},1) -> result();
    $tdiff=time-$tstart;

    $tstart2=time;
    $self->{DATA}=$self->{XMLTOOLOBJ}->urf2llv($self->{DATA}) if($self->{URFORMAT});
    $tdiff2=time-$tstart2;

    $self->{DATA}=~/system_time=\"(\d+)\/(\d+)\/(\d+)-(\d+):(\d+):(\d+)\"/s;
    my ($month,$day,$year,$hour,$min,$sec)=($1,$2,$3,$4,$5,$6);
    printf("llview: got data for (%02d/%02d/%02d %02d:%02d:%02d) in %10.4f sec (%10.4f conv) from %s\n",
	   $month,$day,$year,$hour,$min,$sec,$tdiff,$tdiff2,$self->{RUSSERVICE}) if($self->{VERBOSE});

    if($self->{STOREFILE}) {
	my $dir=$self->{STOREDIR};
	my $nrfile="$dir/NR.dat";

	if(-f $nrfile) {
	    open(IN,$nrfile);
	    $nr=<IN>;
	    chomp($nr);
	    close(IN);
	} else {
	    $nr=0;
	}
	$nr++;
	$self->{CNT}=$nr;
	$self->{FILENAME}=sprintf($self->{FILENAMEMASK},$self->{CNT});
	open(OUT,"> $dir/$self->{FILENAME}");
	print OUT $self->{DATA};
	close(OUT);
	open(OUT,"> $nrfile");
	print OUT $nr;
	close(OUT);
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},$self->{OPTSECTION},"CNT",$self->{CNT});
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},$self->{OPTSECTION},"FILENAME",$self->{FILENAME});

    } # storefile

    if($self->{STORETAR}) {
	my $tarfile=$self->{STORETARFILE};
	my ($tarcmd,$gz,$cmd);
	my $dir=$tarfile;
	$dir=~s/[^\/]*$//gs;

	$nr=0;
	if(-f $tarfile) {
	    my($fn);
	    open(IN,"tar tf $tarfile|");
	    while($fn=<IN>) {
		if($fn=~/_(\d+)./) {
		    $nr=$1*1 if ($1>$nr);
		}
	    }
	    close(IN);
	    $tarcmd="tar uf "; 
	} else {
	    $nr=0;
	    $tarcmd="tar cf "; 
	}
	$nr++;
	$self->{CNT}=$nr;
	$self->{FILENAME}=sprintf($self->{FILENAMEMASK}.".gz",$self->{CNT});
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"http","CNT",$self->{CNT});
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"http","FILENAME",$self->{FILENAME});
	$gz = gzopen("$dir/$self->{FILENAME}","wb") ;
	$gz->gzwrite($self->{DATA});
	$gz->gzclose();
	$cmd="(cd $dir;$tarcmd $tarfile $self->{FILENAME})";
	print $cmd,"\n";
	system($cmd);
	unlink("$dir/$self->{FILENAME}");

    } # storetar

    return(1);
}

1;


