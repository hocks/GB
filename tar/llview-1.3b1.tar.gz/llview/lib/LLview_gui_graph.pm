# $Source: /cvs/cvsroot/llview/lib/LLview_gui_graph.pm,v $
# $Author: zdv087 $
# $Revision: 1.16 $
# $Date: 2007/04/17 13:13:45 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_graph;
use strict;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_gui_graph: new %s\n",ref($proto)) if($debug>=3);
    $self->{HAVEINFOMSG} = 0;
    $self->{POSX}       = 485;
    $self->{POSY}       = 730;
    $self->{WIDTHPART1} = 144;  
    $self->{WIDTH}      = 435;
    $self->{HEIGHT}     = 130;
    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}     = "-*-Helvetica-Bold-R-Normal--*-80-*-*-*-*-*-*";
    $self->{ITEMS}      = [];
    $self->{LEFTPAD}    = 10;
    $self->{RIGHTPAD}    = 10;
    $self->{BOTTOMPAD}  = 20;
    $self->{MINNODES}   = 8;
    $self->{USAGE}      = [];
    $self->{SMALLLIMIT} = 32;
    $self->{NODESIZE}   = 64;
    $self->{BUILDREADY}=0;
    bless $self, $class;
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($i,$name);
    my $frames=$dataobj->{FRAMES};

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;

    $optobj->register_option("Graph","POSX", -label => "posx", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option("Graph","POSY", -label => "posy", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSY}, -step => 10);

    $optobj->register_option("Graph","HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 1200, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option("Graph","WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option("Graph","SMALLLIMIT", -label => "Limit small jobs", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 1, -max => 512, -default => $self->{SMALLLIMIT}, -step => 10);

    $optobj->register_option("Graph","NODESiZW", -label => "Node Size", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 1, -max => 512, -default => $self->{NODESIZE}, -step => 10);

    $optobj->register_option("Graph","Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option("Graph","BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT1});
   
   
#    for($i=0;$i<($self->{WIDTH}-$self->{LEFTPAD}-$self->{RIGHTPAD});$i++) {
#	push(@{$self->{USAGE}},50);
#    }

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{BUILDREADY}=1;

    return();
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id);
#    print "graph_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY}) #$#{$self->{USAGE}}\n";
    if(($name eq "HEIGHT") || ($name eq "WIDTH") || ($name eq "SMALLLIMIT") ) {
	$self->{$name}=$val;
	shift(@{$self->{USAGE}}) while($#{$self->{USAGE}}>($self->{WIDTH}-$self->{LEFTPAD}-$self->{RIGHTPAD}));
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
    }
    if( ($name eq "POSX") || ($name eq "POSY")) {
	$diffx=$diffy=0;
	$diffx=$val-$self->{$name} if ($name eq "POSX");
	$diffy=$val-$self->{$name} if ($name eq "POSY");
	$self->{$name}=$val;
	foreach $id (@{$self->{FIXEDITEMS}}) {
	    $self->{CANVAS}->move($id,$diffx,$diffy)  if ($self->{BUILDREADY});
	}
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
    }
    if ($name eq "Font") {
	$self->{FONT1}=$val;
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
    }
    if ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
	$self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
	$self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
    }
 
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name);

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				 -fill => "grey60");
    push(@{$self->{FIXEDITEMS}},$id);

}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$nonewdata)=@_;
    my(@waitingc,@runningc,@waitingn,@runningn);
    my($i,$cpus,$jobid,$id,$maxnodes,$maxnumber,$nodes);
    my($px,$py,$dx,$dy);
    my($upx,$upy,$udx,$udy);

    $nonewdata=0 if(!defined($nonewdata));
    $dataobj->printsize("graphupdate: start") if($debug==5);

    $self->clean($dataobj,$colorobj,$canvas);

    $dataobj->printsize("graphupdate: after clean") if($debug==5);

    $maxnumber=0;
    foreach $jobid (keys( %{$dataobj->{RUNNINGJOBS}} )) {
	$cpus=$dataobj->{RUNNINGDATA}->{$jobid}{FL_ALLCPU};

	if($cpus<$self->{SMALLLIMIT}) {
	    $runningc[$cpus]++;$maxnumber=$runningc[$cpus] if($runningc[$cpus]>$maxnumber);
	    $runningn[1]++;$maxnumber=$runningn[1] if($runningn[1]>$maxnumber);
	} else {
	    $nodes=int(($cpus+1)/$self->{NODESIZE});
	    $runningn[$nodes]++;$maxnumber=$runningn[$nodes] if($runningn[$nodes]>$maxnumber);
	}
    }

    $dataobj->printsize("graphupdate: point 2") if($debug==5);

    foreach $jobid (keys( %{$dataobj->{WAITINGJOBS}} )) {
	$cpus=($dataobj->{JOBSTATE}->{$jobid}{"job_nummachines"}
	       *$dataobj->{JOBSTATE}->{$jobid}{"job_taskspernode"}
	       *$dataobj->{JOBSTATE}->{$jobid}{"job_conscpu"});  
	if($cpus<=$self->{SMALLLIMIT}) {
	    $waitingc[$cpus]++;$maxnumber=$waitingc[$cpus] if($waitingc[$cpus]>$maxnumber);
	    $waitingn[1]++;$maxnumber=$waitingn[1] if($waitingn[1]>$maxnumber);
	} else { 
#	    $nodes=int(($cpus+1)/32);
	    $nodes=$dataobj->{JOBSTATE}->{$jobid}{"job_nummachines"};
	    $waitingn[$nodes]++;$maxnumber=$waitingn[$nodes] if($waitingn[$nodes]>$maxnumber);
	}
    }

    $dataobj->printsize("graphupdate: point 1") if($debug==5);

    $maxnodes=$#runningn;
    $maxnodes=$#waitingn if($#waitingn>$#runningn);
    $maxnodes=$self->{MINNODES} if($maxnodes<$self->{MINNODES});
    return if(($maxnodes==0) || ($maxnumber==0));
    $maxnumber+=10;

    $px=$self->{POSX}+$self->{LEFTPAD};
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    $dx=($self->{WIDTHPART1}-10)/($self->{NODESIZE});
    $dy=($self->{HEIGHT}-$self->{BOTTOMPAD})/&scale($maxnumber);


    $dataobj->printsize("graphupdate: point 0") if($debug==5);

    # y lines
    foreach $i (1,2,5,10,20,30,50,70,100,150,200,300,400,500) {
	if($i<=$maxnumber) {
	    $id=$canvas->createLine($self->{POSX}+$self->{LEFTPAD},$py-&scale($i)*$dy,
				    $self->{POSX}+$self->{WIDTHPART1},$py-&scale($i)*$dy,-fill => "grey40");
	    push(@{$self->{ITEMS}},$id);
	    $id=$canvas->createLine($self->{POSX}+$self->{WIDTHPART1}+10,$py-&scale($i)*$dy,
				    $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				    $py-&scale($i)*$dy,-fill => "grey40");
	    push(@{$self->{ITEMS}},$id);
	    $id=$canvas->createText($self->{POSX}+8,$py-&scale($i)*$dy,
				    -text => sprintf("%d", $i),
				    -anchor => "e",
				    -font => $self->{FONT1});
	    push(@{$self->{ITEMS}},$id);
	}
    }

    $dataobj->printsize("graphupdate: before usage") if($debug==5);
    if(!$nonewdata) {
	if($dataobj->{LLCPUS}>0) {
	    push(@{$self->{USAGE}},$dataobj->{LLUSEDCPUS}/($dataobj->{LLCPUS})*100);
	    shift(@{$self->{USAGE}}) if($#{$self->{USAGE}}>($self->{WIDTH}-$self->{LEFTPAD}-$self->{RIGHTPAD}));
	}
    }
    $dataobj->printsize("graphupdate: after  usage") if($debug==5);
    
    $upx=$self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD}-$#{$self->{USAGE}};
    $udx=1;
    $upy=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    $udy=($self->{HEIGHT}-$self->{BOTTOMPAD})/100.0;
	
    for($i=$#{$self->{USAGE}};$i>0;$i--) {
	$id=$canvas->createLine(
				$upx+($i-1)*$udx,
				$upy-$self->{USAGE}->[$i-1] * $udy,
				$upx+$i*$udx,
				$upy-$self->{USAGE}->[$i] * $udy,
				-fill => ($i%2==1)?"darkred":"red",
				-width=> 3 );
	push(@{$self->{ITEMS}},$id);
    }

    foreach $i (0,10,20,30,40,50,60,70,80,90,100) {
	    $id=$canvas->createText($self->{POSX}+$self->{WIDTH}+2,$upy-$i*$udy,
				    -text => sprintf("%d", $i),
				    -font => $self->{FONT1});
	    push(@{$self->{ITEMS}},$id);
    }


    for($i=1;$i<=$self->{SMALLLIMIT};$i++) {
	if( grep(/$i/,(1,2,4,8,16,24,32,64,128,256,512))) {
	    $id=$canvas->createText($px+($i-0.5)*$dx,$py,
				    -text => sprintf("%d", $i),
				    -anchor => 'n',
				    -font => $self->{FONT1});
	    push(@{$self->{ITEMS}},$id);
	}
	if($runningc[$i]) {
#	    printf("-> running %03d procs: %2d -> %f\n",$i,$runningc[$i],&scale($runningc[$i]));
	    $id=$canvas->createRectangle($px+($i-1)*$dx,$py,
					 $px+($i-0.5)*$dx,$py-&scale($runningc[$i])*$dy,
					 -fill => "darkgreen");
	    push(@{$self->{ITEMS}},$id);
	}

	if($waitingc[$i]) {
#	    printf("-> waiting %03d procs: %2d -> %f\n",$i,$waitingc[$i],&scale($waitingc[$i]));
	    $id=$canvas->createRectangle($px+($i-0.5)*$dx,$py,
					 $px+($i-0.0)*$dx,$py-&scale($waitingc[$i])*$dy,
					 -fill => "darkblue");
	    push(@{$self->{ITEMS}},$id);
	}
    }
    $id=$canvas->createLine($px+0.5*$dx,            $py+$self->{BOTTOMPAD}-8,
			    $px+(32/2.3)*$dx,$py+$self->{BOTTOMPAD}-8,-fill => "grey30",-arrow => "first");
    push(@{$self->{ITEMS}},$id);
    $id=$canvas->createLine($px+(32/1.7)*$dx,$py+$self->{BOTTOMPAD}-8,
			    $px+(32+0.5)*$dx,    $py+$self->{BOTTOMPAD}-8,-fill => "grey30",-arrow => "last");
    push(@{$self->{ITEMS}},$id);
    $id=$canvas->createText($px+(32/2)*$dx,$py+$self->{BOTTOMPAD}-8,
			    -text => "cpus",-fill => "grey30",-font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);

    
    $dataobj->printsize("graphupdate: point a") if($debug==5);

    $px=$self->{POSX}+$self->{WIDTHPART1}+$self->{LEFTPAD};
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    $dx=($self->{WIDTH}-$self->{RIGHTPAD}-$self->{WIDTHPART1})/($maxnodes+1);
    $dy=($self->{HEIGHT}-$self->{BOTTOMPAD})/&scale($maxnumber);

    for($i=1;$i<=$maxnodes;$i++) {
	$id=$canvas->createText($px+($i-0.5)*$dx,$py,
				-text => sprintf("%d", $i),
				-anchor => 'n',
				-font => $self->{BFONT1});
	push(@{$self->{ITEMS}},$id);
	if($runningn[$i]) {
#	    printf("-> running %03d nodes: %2d -> %f\n",$i,$runningn[$i],&scale($runningn[$i]));
	    $id=$canvas->createRectangle($px+($i-1)*$dx,$py,
					 $px+($i-0.5)*$dx,$py-&scale($runningn[$i])*$dy,
					 -fill => "darkgreen");
	    push(@{$self->{ITEMS}},$id);
	}

	if($waitingn[$i]) {
#	    printf("-> waiting %03d nodes: %2d -> %f\n",$i,$waitingn[$i],&scale($waitingn[$i]));
	    $id=$canvas->createRectangle($px+($i-0.5)*$dx,$py,
					 $px+($i-0.0)*$dx,$py-&scale($waitingn[$i])*$dy,
					 -fill => "darkblue");
	    push(@{$self->{ITEMS}},$id);
	}
    }

    $dataobj->printsize("graphupdate: point b") if($debug==5);

    $id=$canvas->createLine($px+0.5*$dx,            $py+$self->{BOTTOMPAD}-8,
			    $px+($maxnodes/2.3)*$dx,$py+$self->{BOTTOMPAD}-8,-fill => "grey30",-arrow => "first");
    push(@{$self->{ITEMS}},$id);
    $id=$canvas->createLine($px+($maxnodes/1.7)*$dx,$py+$self->{BOTTOMPAD}-8,
			    $px+($maxnodes+0.5)*$dx,    $py+$self->{BOTTOMPAD}-8,-fill => "grey30",-arrow => "last");
    push(@{$self->{ITEMS}},$id);
    $id=$canvas->createText($px+($maxnodes/2)*$dx,$py+$self->{BOTTOMPAD}-8,
			    -text => "nodes",-fill => "grey30",-font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);

    # Legend
    $px=$self->{POSX}+10;
    $dx=($self->{WIDTH}-10)/300;
    $id=$canvas->createRectangle($px+10*$dx,$py+$self->{BOTTOMPAD}+5,
				 $px+40*$dx,$py+$self->{BOTTOMPAD},
				 -fill => "darkgreen");
    push(@{$self->{ITEMS}},$id);
    $id=$canvas->createText($px+42*$dx,$py+$self->{BOTTOMPAD}-2, -anchor => "nw",
			    -text => "running jobs",-fill => "grey30",-font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);

    $id=$canvas->createRectangle($px+110*$dx,$py+$self->{BOTTOMPAD}+5,
				 $px+140*$dx,$py+$self->{BOTTOMPAD},
				 -fill => "darkblue");
    push(@{$self->{ITEMS}},$id);

    $dataobj->printsize("graphupdate: point c") if($debug==5);


    $id=$canvas->createText($px+142*$dx,$py+$self->{BOTTOMPAD}-2, -anchor => "nw",
			    -text => "waiting jobs",-fill => "grey30",-font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);

    $id=$canvas->createRectangle($px+210*$dx,$py+$self->{BOTTOMPAD}+4,
				 $px+240*$dx,$py+$self->{BOTTOMPAD}+1,
				 -fill => "darkred", -outline => "darkred");
    push(@{$self->{ITEMS}},$id);
    $id=$canvas->createText($px+242*$dx,$py+$self->{BOTTOMPAD}-2, -anchor => "nw",
			    -text => "% usage",-fill => "grey30",-font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);

    $dataobj->printsize("graphupdate: end") if($debug==5);
    
    return();
}

sub scale {
    my($n)=@_;
#    return($n);
#    printf("log: %2d -> %f\n",$n,log($n)/log(10));
    return(log($n+1)/log(10));
}

1;

