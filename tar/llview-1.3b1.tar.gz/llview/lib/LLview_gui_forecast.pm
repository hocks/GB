# $Source: /cvs/cvsroot/llview/lib/LLview_gui_forecast.pm,v $
# $Author: zdv087 $
# $Revision: 1.93 $
# $Date: 2007/06/19 20:16:12 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
#
# on BGL: nodes will be counted (1 node are 2 CPUs, -> 1 CO, 2 VN processes) 
#
#

package LLview_gui_forecast;
use strict;
use Time::Local;
use Time::HiRes qw ( time );
use Data::Dumper;
use Tk;
use LLview_gui_jobstackhull;
use LLview_gui_jobstackhullv;

# for callback functions
my($selfref)=-1;

my($debug)=0;
my($ISNOTOPEN)=0;
my($ISOPEN)=1;

my @hex = ("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
my %hextod = ("0" => 0,"1" => 1,"2" => 2,"3" => 3,"4" => 4,"5" => 5,"6" => 6,"7" => 7,
	      "8" => 8,"9" => 9,"A" => 10,"B" => 11,"C" => 12,"D" => 13,"E" => 14,"F" => 15);

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_gui_forecast: new %s\n",ref($proto)) if($debug>=3);
    $self->{HAVEINFOMSG} = 0;
    $self->{POSX}       = 485;
    $self->{POSY}       = 730;
    $self->{WIDTHPART1} = 144;  
    $self->{WIDTH}      = 435;
    $self->{HEIGHT}     = 130;
    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}     = "-*-Helvetica-Bold-R-Normal--*-80-*-*-*-*-*-*";
    $self->{ITEMS}      = [];
    $self->{LEFTPAD}    = 30;
    $self->{RIGHTPAD}    = 0;
    $self->{BOTTOMPAD}     = 40;
    $self->{BOTTOMPADTOP}  = 15;
    $self->{MINNODES}   = 8;
    $self->{TIMEBACK}    = 24;
    $self->{TIMEFORWARD} = 48;
    $self->{COLORMODE}   = "byuser";
    $self->{SHOWWEEKDAY} = 1;
    $self->{SPLITSTACK}  = 1;
    $self->{SPLITSTACKREGSMALLNODES}  = "R00-M[01]";
#    $self->{SPLITSTACKREGLARGENODES}  = "R(01|10|11|20|21|30|31)-M[01]";
    $self->{NOCONTSELECT} = 1;
    $self->{NOCONTREG}           = "(nocont|nocsmall)";
    $self->{NOCONTCOMMENTREG}    = "NOCONT";
    $self->{BUILDREADY}   = 0;
    $self->{FREELIST}     = undef;
    $self->{SHOWID}       = 1;
    $self->{CLUSTERNAME}  = shift||"-"; # needed for button callback function 
    $self->{VERBOSE}      = 1;
    $self->{PROTO}        = 0; # 1 = generate proto
    $self->{MAINTENANCE_START}=[];
    $self->{MAINTENANCE_END}=[];
    $self->{WAITARRANGEVERT}=1;
    $self->{CHECKMAXSTARTER}=0;
    $self->{NUMJOBS}=0; 
    $self->{MAXNUMJOBS}=1000; 
    $self->{SHOWMARKERPERMANENT}=0; 
    $self->{DOSCREENSHOT}=0; 
    $self->{DOSCREENLOOP}=0; 
    $self->{SCREENSHOTCOUNTER}=0; 
    $self->{USESCREENSHOTCOUNTER}=0; 
    $self->{SCREENSHOTTIMEPOS}=0; 
    $self->{SEARCHSTR}       = "";
    
    bless $self, $class;
    if($selfref==-1)  {
	$selfref=\$self;
    } else {
	printf("WARNING: double constructor call to LLview_gui_forecast ...\n")
    }
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($i,$name);
    my $frames=$dataobj->{FRAMES};

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;
    $self->{OPTIONOBJECT}=$optobj;

    $optobj->register_option("Forecast","POSX", -label => "posx", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option("Forecast","POSY", -label => "posy", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSY}, -step => 10);

    $optobj->register_option("Forecast","HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 1200, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option("Forecast","WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option("Forecast","TIMEBACK", -label => "History Time (h)", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1240, -default => $self->{TIMEBACK}, -step => 4);
    $optobj->register_option("Forecast","TIMEFORWARD", -label => "Future Time (h)", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1240, -default => $self->{TIMEFORWARD}, -step => 4);

    $optobj->register_option("Forecast","COLOROBJ", -label => "color mode", 
			     -caller => $self, -pack => 1, 
			     -values => ["byuser","byres"],
			     -labels => ["by user","by reservation"],
			     -type => "radiogroup", -default => $self->{COLORMODE});

    $optobj->register_option("Forecast","SHOWWEEKDAY", -label => "Show day of week", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{SHOWWEEKDAY});

    $optobj->register_option("Forecast","WAITARRANGEVERT", -label => "Vertically Arrangement", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{WAITARRANGEVERT});

#    $optobj->register_option("Forecast","SHOWID", -label => "Show ID", 
#			     -caller => $self,-pack => 1,
#			     -type => "radio", -default => $self->{SHOWID});
#    $optobj->register_option("Forecast","SPLITSTACK", -label => "Split Stack", 
#			     -caller => $self,-pack => 1,
#			     -type => "radio", -default => $self->{SPLITSTACK});

    $optobj->register_option("Forecast","SPLITSTACKREGSMALLNODES", -label => "Reg.Exp Small nodes", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{SPLITSTACKREGSMALLNODES});

    $optobj->register_option("Forecast","NOCONTSELECT", -label => "select nocont jobs", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{NOCONTSELECT});
    $optobj->register_option("Forecast","NOCONTREG", -label => "Reg.Exp. NOCONT Jobs (class)", 
			     -caller => $self,-pack => 1, -labelwidth => 25,
			     -type => "string", -default => $self->{NOCONTREG});
    $optobj->register_option("Forecast","NOCONTCOMMENTREG", -label => "Reg.Exp. NOCONT Jobs (comment)", 
			     -caller => $self,-pack => 1, -labelwidth => 25,
			     -type => "string", -default => $self->{NOCONTCOMMENTREG});

    $optobj->register_option("Forecast","PROTO", -label => "DEBUG: write protocol", 
			     -caller => $self,-pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{PROTO});


    $optobj->register_option("Forecast","Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option("Forecast","BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT1});


    $optobj->register_option("Forecast","MAXNUMJOBS", -label => "max. number of jobs", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 1, -max => 1000, 
			     -default => $self->{MAXNUMJOBS}, -step => 5);

    $optobj->register_option("Forecast","DOSCREENSHOT", -label => "Screenshot after update", 
			     -caller => $self,-pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOSCREENSHOT});

    $optobj->register_option("Forecast","DOSCREENLOOP", -label => "loop over maxnum", 
			     -caller => $self,-pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOSCREENLOOP});

    $optobj->register_option("Forecast","USESCREENSHOTCOUNTER", -label => "use counter for fn", 
			     -caller => $self,-pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{USESCREENSHOTCOUNTER});

    $optobj->register_option("Forecast","SHOWMARKERPERMANENT", -label => "permanent marker line", 
			     -caller => $self,-pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{SHOWMARKERPERMANENT});


    if($self->{WAITARRANGEVERT}) {
	$self->{TOPHULLOBJ}=LLview_gui_jobstackhullv->new() if(!$self->{TOPHULLOBJ});
	$self->{TOPHULLOBJSMALL}=LLview_gui_jobstackhullv->new() if(!$self->{TOPHULLOBJSMALL});
    } else {
	$self->{TOPHULLOBJ}=LLview_gui_jobstackhull->new() if(!$self->{TOPHULLOBJ});
	$self->{TOPHULLOBJSMALL}=LLview_gui_jobstackhull->new() if(!$self->{TOPHULLOBJSMALL});
    }
    $self->{BOTTOMHULLOBJ}=LLview_gui_jobstackhull->new() if(!$self->{BOTTOMHULLOBJ});
    $self->{BOTTOMHULLOBJSMALL}=LLview_gui_jobstackhull->new() if(!$self->{BOTTOMHULLOBJSMALL});
  
   
    $self->{TOPHULLOBJ}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj);
    $self->{BOTTOMHULLOBJ}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj);
    $self->{TOPHULLOBJSMALL}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj);
    $self->{BOTTOMHULLOBJSMALL}->build($dataobj,$colorobj,$infoobj,$canvas,$optobj);

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{MAINWIN}->register_steptimer_function("forecastupdate",\&update_screenshot);

    $self->{BUILDREADY}=1;

    return();
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id);
#    print "forecast_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY}) #$#{$self->{USAGE}}\n";

    if ($name eq "Font") {
	$self->{FONT1}=$val;
    } elsif ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
    } elsif ($name eq "WAITARRANGEVERT") {
	$self->{WAITARRANGEVERT}=$val;
	if($self->{WAITARRANGEVERT}) {
	    $self->{TOPHULLOBJ}=LLview_gui_jobstackhullv->new();
	    $self->{TOPHULLOBJSMALL}=LLview_gui_jobstackhullv->new();
	} else {
	    $self->{TOPHULLOBJ}=LLview_gui_jobstackhull->new();
	    $self->{TOPHULLOBJSMALL}=LLview_gui_jobstackhull->new();
	}
	$self->{TOPHULLOBJ}->build($self->{DATAOBJECT},$self->{COLOROBJECT},
				   $self->{INFOOBJECT},$self->{CANVAS},$self->{OPTIONOBJECT});
	$self->{TOPHULLOBJSMALL}->build($self->{DATAOBJECT},$self->{COLOROBJECT},
					$self->{INFOOBJECT},$self->{CANVAS},$self->{OPTIONOBJECT});
    } else {
	$self->{$name}=$val;
    }



    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
 
}

sub set_searchstr {
    my($self) = shift;
    my($str) = @_;
    $self->{SEARCHSTR}=$str;
    return 1;
}

sub register_color_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{COLOROBJECT}=$objref;
    return 1;
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }

    while ($id=shift(@{$self->{FREELIST}})) {    }
    $self->{NODESTARTERS}=[];
    $self->{NODEACTSTARTERS}=[];
    $self->{NODEACTSTARTERSTOPDOG}=[];
    $self->{FREECPUS}=[];
    $self->{FREECPUSTOPDOG}=[];
    $self->{TIMELINE_TS}=[];
    $self->{TIMELINE_FREE}=[];
    $self->{TIMELINE_STARTERS}=[];
    $self->{TIMELINE_JEND}=[];
    $self->{MAINTENANCE_START}=[];
    $self->{MAINTENANCE_END}=[];
    $self->{ACTSTARTERCLASSUSER}={};
    $self->{ACTSTARTERCLASSUSERTOP}={};
    $self->{MAXSTARTERCLASS}={};
    $self->{MAXSTARTERCLASSUSER}={};
    $self->{CLASS2NR}={};
    $self->{NR2CLASS}=[];
    $self->{WAITINGSTEPNAMES}={};
    $self->{WAITINGJOBSTATE}={};
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name);
    my($LEFT_ICON,$left,$leftsubwidget,$leftframe);
    my($RIGHT_ICON,$right,$rightsubwidget,$rightframe);

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    $id=$canvas->createRectangle($self->{POSX},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH},
				 $self->{POSY}+$self->{HEIGHT},
				 -fill => "grey80", -tags => ["forecast"]);
    push(@{$self->{FIXEDITEMS}},$id);
#    $canvas->bind("forecast", '<ButtonRelease-1>' => [sub { my ($c) = @_;
#								  &update_left_cb($Tk::event->x,$Tk::event->y,1)}]);
#    $canvas->bind("forecast", '<ButtonRelease-3>' => [sub { my ($c) = @_;
#								  &update_right_cb($Tk::event->x,$Tk::event->y,1)}]);
    $canvas->bind("forecast", '<Control-ButtonRelease-1>' => [sub { my ($c) = @_;
							    &update_left_cb($Tk::event->x,$Tk::event->y,8)}]);
    $canvas->bind("forecast", '<Control-ButtonRelease-3>' => [sub { my ($c) = @_;
							    &update_right_cb($Tk::event->x,$Tk::event->y,8)}]);

    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				 -fill => "LightSkyBlue2", -tags => ["forecast"]);
    push(@{$self->{FIXEDITEMS}},$id);

    $LEFT_ICON=$self->{INSTPATH}."/lib/images/button-left-small.gif";
    $left = $self->{CANVAS}->Photo(-file => $LEFT_ICON, -format => 'gif');
    $RIGHT_ICON=$self->{INSTPATH}."/lib/images/button-right-small.gif";
    $right = $self->{CANVAS}->Photo(-file => $RIGHT_ICON, -format => 'gif');

    $leftframe=$canvas->Frame( 
			       -relief => "flat", 
			       -borderwidth => 0);
    $id=$leftframe->Button(-text => 'Update',
			   -image => $left,
			   -command => sub { &update_left_left_cb();},
			   -width => 10,
			   -height => 10,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $id=$leftframe->Button(-text => 'Update',
			   -image => $right,
			   -command => sub { &update_left_right_cb();},
			   -width => 10,
			   -height => 10,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $leftsubwidget = $canvas->createWindow($self->{POSX}+$self->{LEFTPAD}+1,$self->{POSY}+19, 
					   -window =>$leftframe, -anchor => "sw");
    push(@{$self->{FIXEDITEMS}},$leftsubwidget);

    $rightframe=$canvas->Frame( 
			       -relief => "flat", 
			       -borderwidth => 0);
    $id=$rightframe->Button(-text => 'Update',
			   -image => $left,
			   -command => sub { &update_right_left_cb();},
			   -width => 10,
			   -height => 10,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $id=$rightframe->Button(-text => 'Update',
			   -image => $right,
			   -command => sub { &update_right_right_cb();},
			   -width => 10,
			   -height => 10,
			   -font => $self->{BFONT1},
			   , -background => "grey85"
			   )->pack(-side => 'left');
    $rightsubwidget = $canvas->createWindow($self->{POSX}+$self->{WIDTH},$self->{POSY}+19, 
					    -window =>$rightframe, -anchor => "se");
    push(@{$self->{FIXEDITEMS}},$rightsubwidget);


    # for marker line
    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}+$self->{BOTTOMPADTOP},
				 -fill => "grey80");
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}+$self->{BOTTOMPADTOP},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT},
				 -fill => "grey50", -tags => ["forecastmarkerarea"]);
    push(@{$self->{FIXEDITEMS}},$id);
    $self->{INFOOBJECT}->register_bind_motion("forecastmarkerarea",$self);
    $self->{INFOOBJECT}->register_bind_enter("forecastmarkerarea",$self);
    $self->{INFOOBJECT}->register_bind_leave("forecastmarkerarea",$self);
    $self->{INFOOBJECT}->register_category("RESERVATION",$self);
    $self->{INFOOBJECT}->register_category("WAIT",$self);
    $self->{INFOOBJECT}->register_category("WAITNOCONT",$self);
    $self->{INFOOBJECT}->register_category("OWNJOBS",$self);

    $self->{COLOROBJECT}->register_external_updater("WAIT",$self);
    $self->{COLOROBJECT}->register_external_updater("WAITNOCONT",$self);
    $self->{COLOROBJECT}->register_external_updater("RESERVATION",$self);
    $self->{COLOROBJECT}->register_external_updater("OWNJOBS",$self);

}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$nonewdata)=@_;
    my($i,$cpus,$jobid,$id,$maxnodes,$maxnumber,$nodes,$nodelist,$spec,$node,$book);
    my($px,$py,@py,$dx,$dy,$n,$name,$color,$nr,$ucolor,$unr,$rcolor,$rnr,$usedh,$usedhcut,$starth,$endh);
    my($endx,$numnodes,$nodecnt,$lstarty,$lendy,$user,$endy,$midx);
    my($textcolor,$wall,$cpu,$pair);
    my($tstart,$tdiff);
    my($numnodessmall,$numnodeslarge);
    my $frames=$dataobj->{FRAMES};
    $self->{NUMJOBS}=0; 

    return() if ($frames==0);
    return() if (($self->{TIMEBACK}+$self->{TIMEFORWARD})<=0);
    
    $self->PROTO_clear();
    
    $self->{DX}  =$dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    $self->{DY}  =$dy=($self->{HEIGHT}-$self->{BOTTOMPAD})/($frames);
    $self->{MIDX}=$midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
    $self->{MIDXX}=($self->{TIMEBACK}*$dx);
    $dataobj->printsize("forecastupdate: start") if($debug==5);

    $self->clean($dataobj,$colorobj,$canvas);
    $dataobj->printsize("forecastupdate: after clean") if($debug==5);
   
    $self->{CPUS}=0;
    $self->{NODESIZE}=0;
    $self->{SMALLCPUS}=0;
    $numnodessmall=$numnodeslarge=0;
    for($n=1;$n<=$frames;$n++) {
 	$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	$cpus=$dataobj->{NODESTATE}->[$n]->{"cpu_total"};
	if($dataobj->{NODESTATE}->[$n]->{"node_arch"}=~/BGL/) {
	    $cpus/=2;
	}
	$self->{NODESIZE}=$cpus if($cpus>$self->{NODESIZE});
	$self->{CPUS}+=$cpus;
	$self->{FREECPUS}->[$n]=$cpus;
	if($name=~/$self->{SPLITSTACKREGSMALLNODES}/) {
	    $numnodessmall++; 
	    $self->{SMALLCPUS}+=$cpus;
	} else {
	    $numnodeslarge++;
	}
    }
    $px=$self->{POSX};
#    printf("WF: splitstack: numnodessmall,numnodeslarge: %d,%d\n",$numnodessmall,$numnodeslarge);

    # initialize hull objects
    if($self->{SPLITSTACK}) {
	my $fraction=$numnodessmall/($numnodessmall+$numnodeslarge);
	my $height=$self->{HEIGHT}-$self->{BOTTOMPAD};

	$self->{TOPHULLOBJ}->setsize($self->{POSX}+$self->{LEFTPAD}, int($self->{POSY}+$fraction*$height),
				     $self->{WIDTH}-$self->{LEFTPAD}, $height*(1.0-$fraction));
	$self->{TOPHULLOBJ}->setdirection("top");
	$self->{TOPHULLOBJ}->settag("forecast");
	$self->{TOPHULLOBJ}->init("TOPHULLOBJ");  # clean and default hull
	$self->{TOPHULLOBJ}->setautogrey(60,90,14);
	$self->{TOPHULLOBJSMALL}->setsize($self->{POSX}+$self->{LEFTPAD}, int($self->{POSY}),
					  $self->{WIDTH}-$self->{LEFTPAD}, $height*$fraction);
	$self->{TOPHULLOBJSMALL}->setdirection("top");
	$self->{TOPHULLOBJSMALL}->settag("forecast");
	$self->{TOPHULLOBJSMALL}->init("TOPHULLOBJSMALL");  # clean and default hull
	$self->{TOPHULLOBJSMALL}->setautogrey(60,90,14);
	$self->{TOPHULLOBJ}->{FONT1}=$self->{TOPHULLOBJSMALL}->{FONT1}=$self->{FONT1};
	$self->{TOPHULLOBJ}->{BFONT1}=$self->{TOPHULLOBJSMALL}->{BFONT1}=$self->{BFONT1};
	
	$self->{BOTTOMHULLOBJ}->setsize($self->{POSX}+$self->{LEFTPAD}, $self->{POSY}+$fraction*$height,
					$self->{WIDTH}-$self->{LEFTPAD}, $height*(1.0-$fraction));
	$self->{BOTTOMHULLOBJ}->setdirection("bottom");
	$self->{BOTTOMHULLOBJ}->settag("forecast"); 
	$self->{BOTTOMHULLOBJ}->init("BOTTOMHULLOBJ"); # clean and default hull
	$self->{BOTTOMHULLOBJ}->setautogrey(30,60,17);
	$self->{BOTTOMHULLOBJSMALL}->setsize($self->{POSX}+$self->{LEFTPAD}, $self->{POSY},
					$self->{WIDTH}-$self->{LEFTPAD}, $height*$fraction);
	$self->{BOTTOMHULLOBJSMALL}->setdirection("bottom");
	$self->{BOTTOMHULLOBJSMALL}->settag("forecast"); 
	$self->{BOTTOMHULLOBJSMALL}->init("BOTTOMHULLOBJSMALL"); # clean and default hull
	$self->{BOTTOMHULLOBJSMALL}->setautogrey(30,60,17);

	$self->{BOTTOMHULLOBJ}->{FONT1}=$self->{BOTTOMHULLOBJSMALL}->{FONT1}=$self->{FONT1};
	$self->{BOTTOMHULLOBJ}->{BFONT1}=$self->{BOTTOMHULLOBJSMALL}->{BFONT1}=$self->{BFONT1};
	
	$id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY},
				     $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				     $self->{POSY}+$fraction*$height,
				     -fill => "LightSkyBlue3", -tags => ["forecast"]);
	push(@{$self->{FIXEDITEMS}},$id);

    } else {
	$self->{TOPHULLOBJ}->setsize($self->{POSX}+$self->{LEFTPAD}, $self->{POSY},
				     $self->{WIDTH}-$self->{LEFTPAD}, $self->{HEIGHT}-$self->{BOTTOMPAD});
	$self->{BOTTOMHULLOBJ}->setsize($self->{POSX}+$self->{LEFTPAD}, $self->{POSY},
					$self->{WIDTH}-$self->{LEFTPAD}, $self->{HEIGHT}-$self->{BOTTOMPAD});
	$self->{TOPHULLOBJ}->setdirection("top");    $self->{BOTTOMHULLOBJ}->setdirection("bottom");
	$self->{TOPHULLOBJ}->settag("forecast");     $self->{BOTTOMHULLOBJ}->settag("forecast"); 
	$self->{TOPHULLOBJ}->init("TOPHULLOBJ");       # clean and default hull          
	$self->{BOTTOMHULLOBJ}->init("BOTTOMHULLOBJ"); # clean and default hull
	$self->{TOPHULLOBJ}->setautogrey(60,90,14);
	$self->{BOTTOMHULLOBJ}->setautogrey(30,60,17);
	$self->{TOPHULLOBJ}->{FONT1}=$self->{BOTTOMHULLOBJ}->{FONT1}=$self->{FONT1};
	$self->{TOPHULLOBJ}->{BFONT1}=$self->{BOTTOMHULLOBJ}->{BFONT1}=$self->{BFONT1};
    }

    for($n=1;$n<=$frames;$n++) {
 	$name=$dataobj->{NODESTATE}->[$n]->{"node_name"};
	if( $dataobj->{NODESTATE}->[$n]->{"node_arch"}=~/BGL/) {
	    $name=~/R(\d)(\d)-M(\d)/;
	    my ($x,$y,$z)=($1,$2,$3);
	    $self->{SHAPE3D}->[$x][$y][$z]=$n;
	    $self->{SHAPE3DXMAX}=$x if($self->{SHAPE3DXMAX}<$x);
	    $self->{SHAPE3DYMAX}=$y if($self->{SHAPE3DYMAX}<$y);
	    $self->{SHAPE3DZMAX}=$z if($self->{SHAPE3DZMAX}<$z);
	}
	# store class infos for forecast of waiting jobs
	my $classes=$dataobj->{NODESTATE}->[$n]->{"node_avail_classes"};
	my @classes=split(/\),?\(/,$classes);
	foreach $pair (@classes) {
	    my($class,$num)=($pair=~/\(?(.*),(.*)\)?/gs);
	    $self->{NODESTARTERS}->[$n]->{$class}+=$num;
	    $self->{NODEACTSTARTERS}->[$n]->{$class}+=$num;
	    $self->{NODESTARTERS}->[0]->{$class}+=$num;
	}
		
	$py[$n]=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($n-1)*$dy;
	
	if(($dx>5) || ($n%5==0)) {
	    $id=$canvas->createText($px+15,$py[$n]+0,
				-text => sprintf("%02d", $n),
				    -anchor => 'sw',
				    -font => $self->{FONT1},
				    -tags => ["NODE${n}", "forecast"]);
	    push(@{$self->{ITEMS}},$id);
	}
#	$id=$canvas->createRectangle($self->{POSX},int($py[$n]-$dy)+1,
#				     $self->{POSX}+$self->{LEFTPAD},int($py[$n]),
#				     -fill => "DarkOrange3", -outline => "black");
#	push(@{$self->{FIXEDITEMS}},$id);
#	printf("WF: line %f %f %f %f\n",$self->{POSX}, 
#	       $py[$n],
#	       $self->{POSX}+$self->{WIDTH},
#	       $py[$n]);

	if($n>1) { # not on first item
	    $id=$canvas->createLine(      $self->{POSX}+$self->{LEFTPAD}, $py[$n],
					  $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
					  $py[$n],
					  -width => 1,
					  -fill => (($n%2)==0)?"grey":"darkblue",
					  -tags => ["forecast"]
					  );
	    push(@{$self->{ITEMS}},$id);
	}
    }

    { # legend
	my $ytxt="#of nodes";
	$ytxt=~s/(.)/$1\n/gs;
	$id=$canvas->createText($px+5,($py[1]+$py[$frames])/2+40,
#				-text => "#\nn\no\nd\ne\ns",
				-text => $ytxt,
				-anchor => 'sw',
				-font => $self->{BFONT1},
				-tags => ["forecast","forecastmarkerarea"]);
	push(@{$self->{ITEMS}},$id);
	$id=$canvas->createText($px+$self->{LEFTPAD}+1,$self->{POSY}+$self->{HEIGHT},
				-text => "Job Scheduling Prediction ",
				-anchor => 'sw',
				-font => $self->{BFONT1},
				-tags => ["forecast","forecastmarkerarea"]);
	push(@{$self->{ITEMS}},$id);
	$id=$canvas->createText($px+$self->{WIDTH},$self->{POSY}+$self->{HEIGHT},
				-text => "Job Type: color -> running, blue -> waiting, gray -> nocont ",
				-anchor => 'se',
				-font => $self->{FONT1},
				-tags => ["forecast","forecastmarkerarea"]);
	push(@{$self->{ITEMS}},$id);
    }

    { # mark not usable cpus
	my $maxn=$frames;
	my $actn=$self->{CPUS}/$self->{NODESIZE};

	$id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},                  
				     $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($maxn)*$dy,
				     $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD}-1,
				     $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($actn)*$dy,
				     -fill => "grey80", -outline => "grey80");
	push(@{$self->{ITEMS}},$id);
	$id=$canvas->createLine(      $self->{POSX},                                  
				      $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($actn)*$dy,
				      $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD}, 
				      $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}-($actn)*$dy,
				      -width => 1,
				      -fill => "LightSkyBlue4"
				      );
	push(@{$self->{ITEMS}},$id);

    }

    # init max/act starter per class/user
    if(defined($dataobj->{CLASSES}->{"ConfiguredClasses"})) {
	my($spec,$class,$maxclass,$maxuser);
	$self->{CHECKMAXSTARTER}=1;
#	print "WF: ConfiguredClasses found\n";
	foreach $spec (split(/\s+/,$dataobj->{CLASSES}->{"ConfiguredClasses"})) {
	    $spec=~/(.*)\((.*),(.*)\)/gs;
	    ($class,$maxclass,$maxuser)=($1,$2,$3);
#	    print "WF: classes -> $spec -> $class,$maxclass,$maxuser\n";
	    $self->{MAXSTARTERCLASS}->{$class}=$maxclass;
	    $self->{MAXSTARTERCLASSUSER}->{$class}=$maxuser;
	    $self->{ACTSTARTERCLASS}->{$class}=0;
	    $self->{ACTSTARTERCLASSTOP}->{$class}=0;
	}
    }

    # build list of classes
    my $classnr=0;
    foreach my $class (sort(keys(%{$self->{NODESTARTERS}->[0]}))) {
	$self->{CLASS2NR}->{$class}=$classnr;
	$self->{NR2CLASS}->[$classnr]=$class;
	$classnr++;
    }

    $self->create_timescale($canvas,$dataobj->{MACHSTATE}->{"system_time"},$dx,$dy);

    $tstart=time;
    $self->update_running_jobs_stack();
    $tdiff=time-$tstart;
    printf("llview: forecast update running jobs in %10.4f sec\n",$tdiff) if($self->{VERBOSE});

    $tstart=time;
    $self->update_reservations_stack();
    $tdiff=time-$tstart;
    printf("llview: forecast update reservations in %10.4f sec\n",$tdiff) if($self->{VERBOSE});

    $tstart=time;
    $self->update_waiting_jobs_stack();
    $tdiff=time-$tstart;
    printf("llview: forecast update waiting jobs in %10.4f sec\n",$tdiff) if($self->{VERBOSE});

    $id=$canvas->createLine(      $midx, $self->{POSY},
				  $midx, $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				  -width => 2,
				  -fill => "blue", 
				  -tags => ["forecast"]
				  );
    push(@{$self->{ITEMS}},$id);


    $dataobj->printsize("forecastupdate: end") if($debug==5);

    # reset marker line
    my($oldx,$oldy);
    if($self->{MARKERLINE}){
	($oldx,$oldy)=$self->{CANVAS}->coords('FOREMARKERLINE');
    } else {
	($oldx,$oldy)=($self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx),0);
    }
    $self->generateinfo($dataobj,$colorobj,$infoobj,$canvas,"forecastmarkerarea",$oldx,$oldy,"");


    if($self->{DOSCREENSHOT}) {
	my $fn;
	if($self->{USESCREENSHOTCOUNTER}) {
	    $self->{SCREENSHOTCOUNTER}++;
	    $fn=sprintf("screenshots/forecast%03d.png",$self->{SCREENSHOTCOUNTER});
	} else {
	    ($oldx,$oldy)=($self->{POSX} 
			   + $self->{LEFTPAD}  
			   + ($self->{TIMEBACK}*$dx) 
			   + ($self->{SCREENSHOTTIMEPOS}*$dx),0);
	    my $infostr=$self->generateinfo($dataobj,$colorobj,$infoobj,$canvas,"forecastmarkerarea",$oldx,$oldy,"");
	    $self->{INFOOBJECT}->setinfo($infostr);

	    $fn=sprintf("screenshots/forecast%03d.png",$self->{MAXNUMJOBS});
	}
	printf(STDERR "Screenshot of X-window id=%10s fn=%-20s time %6.2fh %s\n" ,
	       $self->{MAINWIN}->{MAIN}->id(),$fn,$self->{SCREENSHOTTIMEPOS},$self->{MARKERLINE});
	system("import -window ".$self->{MAINWIN}->{MAIN}->id()." -frame $fn");
    }

   
    return();
}

sub update_screenshot {
    my $self=$$selfref;
    if($self->{DOSCREENLOOP}) {
	$self->{MAXNUMJOBS}++;
	printf(STDERR "Screenshot maxnum=$self->{MAXNUMJOBS}\n");
#	sleep(1);
	printf(STDERR "Screenshot maxnum=$self->{MAXNUMJOBS}, sleep ready\n");
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","MAXNUMJOBS",$self->{MAXNUMJOBS});
    }
}

# Information for job prediction:
# -------------------------------
# 
# Node based:
# $self->{NODESTARTERS}->[$n]->{$class}:    number of starters of this class on this node (static)
# $self->{NODESTARTERS}->[0]->{$class}:     number of starters of this class on all node (static)
# needed for scheduling:
# $self->{NODEACTSTARTERS}->[$n]->{$class}: number of starters of this class on this node (current)
# $self->{FREECPUS}->[$n]:                  number of free cpus on node
#
# information at starting time of first topdog
# $self->{NODEACTSTARTERSTOPDOG}->[$n]->{$class}: number of starters of this class on this node 
# $self->{FREECPUSTOPDOG}->[$n]:                  number of free cpus on node          
#
# $self->{WAITINGJOBSTATE}->{$jobid}: yes|removed|completed|ready|topdog      already scheduled
#
# for dependency check
# $self->{WAITINGSTEPNAMES}->{$sjobid}->{$stepname}=$jobid   sjobid jobid without stepnumber
#
# $self->{CLASS2NR}->{$class}=$i;
# $self->{NR2CLASS}->[$i]=$class;
#
# $self->{CHECKMAXSTARTER}                          Flag, if max starters info is available
# $self->{MAXSTARTERCLASS}->{$class}                max. starter per class
# $self->{ACTSTARTERCLASS}->{$class}                act. starter per class
# $self->{ACTSTARTERCLASSTOP}->{$class              act. starter per class (at time point of topdog)
# $self->{MAXSTARTERCLASSUSER}->{$class}            max. starter per user in this class
# $self->{ACTSTARTERCLASSUSER}->{$class}->{$user}   act. starter per user in this class
# $self->{ACRSTARTERCLASSUSERTOP}->{$class}->{$user}   act. starter per user in this class (at time point of topdog)
#
# Timeline:
# $self->{TIMELINE_TS}->[$i]                 timemarker
# $self->{TIMELINE_FREE}->[$i]               number of used cpus
# $self->{TIMELINE_STARTERS}->[$i]->[$clsnr] number of starters for this class at this time
# $self->{TIMELINE_JEND}->[$i]               pointer to job ends at this timestamp
#
# Node base, dynamic:
# $self->{TIMELINE_CLASSFREE}->[$i]->[$classnr]=$starters
#
#
# $self->{MAINTENANCE_START}                 vector of maintenance times
# $self->{MAINTENANCE_END}
#
#


sub update_running_jobs_stack {
    my($self) = shift;
    my($cpu,$cpus,$jobid,$usedhcut,$nodelist,$user,$usedh,$startx,$wall,$dx,$endx,$color,$nr,$jclass);
    my($starty,$py,$dy,$endy,$cpuh,$cpuhcut,$j,$helpref,$helpreft,$category);
    my $dataobj=$self->{DATAOBJECT};
    my $canvas=$self->{CANVAS};
    my $infoobj=$self->{INFOOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my $cpustart=0;
    my $cpustartsmall=0;
    my $cpumax=$self->{CPUS};
    my @current_starters;
    my $actdate=$dataobj->{MACHSTATE}->{"system_time"};
    my($sjobid,$stepname);
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    $dx=$self->{DX};
    $dy=$self->{DY};

    $self->{SCREENSHOTTIMEPOS}=0;

    open(PROTO,">> schedule.log") if($self->{PROTO});

    $self->PROTO_print_node_state($ISOPEN);
    $self->PROTO_print_timeline(0,$ISOPEN);

    foreach my $class (keys(%{$self->{CLASS2NR}})) {
	$current_starters[$self->{CLASS2NR}->{$class}]=$self->{NODESTARTERS}->[0]->{$class};
    }

    $j=0;
    foreach $jobid (sort
		    { &sort_for_forecast($dataobj) }
		    (keys( %{$dataobj->{RUNNINGDATA}} ))) {
	$j++;
	$self->{NUMJOBS}++;
	last if($self->{NUMJOBS}>$self->{MAXNUMJOBS});
	$user=$dataobj->{RUNNINGDATA}->{$jobid}{FL_USER};
	$wall=$dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600;
	$usedhcut=$usedh=$dataobj->{RUNNINGDATA}->{$jobid}{FL_USEDH};
	$usedhcut=$self->{TIMEBACK} if ($usedhcut>$self->{TIMEBACK});
	$cpuhcut=$cpuh=$wall-$usedh;
	$cpuhcut=$self->{TIMEFORWARD} if ($cpuhcut>$self->{TIMEFORWARD});
	$jclass=$dataobj->{JOBSTATE}->{$jobid}{"job_queue"};

	# check for partitions in init state on BGL
	$cpuh=0.1 if($cpuh<0.0);


	if($dataobj->{JOBSTATE}->{$jobid}{"job_stepname"}) {
	    $dataobj->{JOBSTATE}->{$jobid}{"job_stepname"}=~/([^\:]+):([^\:]+)/s;
	    ($sjobid,$stepname)=($1,$2);
	    $sjobid=~s/\.\d+$//gs;
	    $self->{WAITINGSTEPNAMES}->{$sjobid}->{$stepname}=$jobid;
	}

	# BGL job?
	if(exists($dataobj->{RUNNINGDATA}->{$jobid}{FL_BGLNODES})) {
	    $cpus=$dataobj->{RUNNINGDATA}->{$jobid}{FL_BGLNODES};
	} else {
	    $cpus=$dataobj->{RUNNINGDATA}->{$jobid}{FL_OVERALL};
	}
	# store starters state at this time
 	unshift(@{$self->{TIMELINE_TS}},$cpuh);
	unshift(@{$self->{TIMELINE_FREE}},$cpumax);
	{
	    my @help=(@current_starters);
	    unshift(@{$self->{TIMELINE_STARTERS}},\@help);
	}
	unshift(@{$self->{TIMELINE_JEND}},$jobid);
	my $destdate=&sec_to_date(&date_to_sec($actdate)+$cpuh*3600);

	# adjust starter per class
	if($self->{CHECKMAXSTARTER}) {
	    $self->{ACTSTARTERCLASS}->{$jclass}++;
	    $self->{ACTSTARTERCLASSTOP}->{$jclass}++;
	    if($self->{MAXSTARTERCLASSUSER}->{$jclass}!=-1) {
		$self->{ACTSTARTERCLASSUSER}->{$jclass}->{$user}++;
		$self->{ACTSTARTERCLASSUSERTOP}->{$jclass}->{$user}++;
	    }
	}

	printf(PROTO "running: %2d insert job %-25s, endtime=%5.2f cpus=%4d user=%8s class=%10s wall=%10.4f usedh=%10.4f %s\n",$j,
	       $jobid,$cpuh,$cpus,$user,$jclass,$wall,$usedh,$destdate) if($self->{PROTO});	
	# scan nodelist and store data for prediction in current_starters
	{
	    my($nodelist,$spec,$node,$num,$nodenr,$class);
	    $nodelist=$dataobj->{JOBSTATE}->{$jobid}{"job_nodelist"};
	    foreach $spec (split(/\),?\(/,$nodelist)) {
		$spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;
		# partition on bgl is in start state
		my $pnum=$self->get_partition_size($node);
		$num=$pnum if($pnum>0);
		$node=$self->specnodename_to_nodename($node);
		printf(PROTO "       : insert job %-20s, endtime=%5.2f class=%s %d on $node\n",
		       $jobid,$cpuh,$jclass,$num) if($self->{PROTO});	
	
		$nodenr=$dataobj->{NODES}->{$node}->{"node_nr"};
		$current_starters[$self->{CLASS2NR}->{$jclass}]-=$num;
		# for simulation of schedule of waiting jobs;
		$self->{NODEACTSTARTERS}->[$nodenr]->{$jclass}-=$num;
		$self->{FREECPUS}->[$nodenr]-=$num;
		# adjust starters of other classes on the job nodes
		foreach $class (keys(%{$self->{NODESTARTERS}->[$nodenr]})) {
		    my $diff=$self->{NODEACTSTARTERS}->[$nodenr]->{$class}-$self->{FREECPUS}->[$nodenr];
		    if($diff>0) {
			$current_starters[$self->{CLASS2NR}->{$class}]-=$diff;
			$self->{NODEACTSTARTERS}->[$nodenr]->{$class}-=$diff;
		    }
		}
	    }
	}
#	$self->PROTO_print_timeline(0,$ISOPEN);


	$startx=$self->{MIDXX} - $usedhcut*$dx;
	$endx=$self->{MIDXX}+$cpuhcut*$dx;


	$category="RUN";
	if($self->{SEARCHSTR}) {
	    $category="OWNJOBS" if ($user=~/$self->{SEARCHSTR}/);
	}

	$color=$colorobj->get_color($category,$jobid);
	$nr=$colorobj->colortonr($category,$color);

	$cpumax-=$cpus;
	my $overlap=0;
	if($self->{SPLITSTACK}) {
	    if ($dataobj->{JOBSTATE}->{$jobid}{"job_nodelist"}=~/$self->{SPLITSTACKREGSMALLNODES}/) {
		$helpref=$self->{BOTTOMHULLOBJSMALL}; 
		$helpreft=$self->{TOPHULLOBJSMALL};
		$starty=$cpustartsmall*$dy/$self->{NODESIZE};
		if($cpus>$self->{SMALLCPUS}) {
		    # seems to be a overlapping job, e.g.whole machine
		    $overlap=1; 
		    $cpustartsmall+=$self->{SMALLCPUS};
		    $cpustart+=$cpus-$self->{SMALLCPUS};
		} else {
		    $cpustartsmall+=$cpus;
		}
	    } else {
		$helpref=$self->{BOTTOMHULLOBJ};
		$helpreft=$self->{TOPHULLOBJ};
		$starty=$cpustart*$dy/$self->{NODESIZE};
		$cpustart+=$cpus;
	    }
	} else {
	    $starty=$cpustart*$dy/$self->{NODESIZE};
	    $cpustart+=$cpus;
	}

	if(!$overlap) {
	    $helpref->put(0,$startx,
			  $cpus*$dy/$self->{NODESIZE},
			  "DUMMYF","DUMMYT","grey60","","",1,"blue");
	    $helpref->put($startx,$endx,
			  $cpus*$dy/$self->{NODESIZE},
			  "T${nr}R","T${nr}B",$color,"$user","$user");
	    if($self->{WAITARRANGEVERT}) {
		# inform tophull object about starting vertical hull
		$helpreft->insert_segment_abs($endx,$helpreft->get_height()-$starty-$cpus*$dy/$self->{NODESIZE},
					      $cpus*$dy/$self->{NODESIZE});
	    }
	} else {
	    $self->{BOTTOMHULLOBJSMALL}->put(0,$startx,
			  $self->{SMALLCPUS}*$dy/$self->{NODESIZE},
			  "DUMMYF","DUMMYT","grey60","","",1,"blue");
	    $self->{BOTTOMHULLOBJSMALL}->put($startx,$endx,
			  $self->{SMALLCPUS}*$dy/$self->{NODESIZE},
			  "T${nr}R","T${nr}B",$color,"$user","$user");

	    $self->{BOTTOMHULLOBJ}->put(0,$startx,
			  ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE},
			  "DUMMYF","DUMMYT","grey60","","",1,"blue");
	    $self->{BOTTOMHULLOBJ}->put($startx,$endx,
			  ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE},
			  "T${nr}R","T${nr}B",$color,"$user","$user");

	    if($self->{WAITARRANGEVERT}) {
		# inform tophull object about starting vertical hull
		$starty=$cpustartsmall*$dy/$self->{NODESIZE};
		$self->{TOPHULLOBJSMALL}->insert_segment_abs($endx,
							     $helpreft->get_height()-$starty
							     *$dy/$self->{NODESIZE},
							     ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE});
		$starty=$cpustart*$dy/$self->{NODESIZE};
		$self->{TOPHULLOBJ}->insert_segment_abs($endx,
							$helpreft->get_height()-$starty*$dy/$self->{NODESIZE},
							($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE});
	    }
	}

    }
    # first marker
    unshift(@{$self->{TIMELINE_TS}},0);
    unshift(@{$self->{TIMELINE_FREE}},$cpumax);
    {
	my @help=(@current_starters);
	unshift(@{$self->{TIMELINE_STARTERS}},\@help);
    }
    unshift(@{$self->{TIMELINE_JEND}},undef);

    $self->PROTO_print_node_state($ISOPEN);
    $self->PROTO_print_timeline(0,$ISOPEN);

    close(PROTO);

    return();
}


# on BG/L remove nodebook part
sub specnodename_to_nodename {
    my($self) = shift;
    my($node) = @_;
    if($node=~/(R\d\d-M\d)/) {
	# it's a BGL node
	if($node=~/(R\d\d-M\d)-N(.)/) {
	    # it's a BGL nodebook
	    $node=$1;
	} else {
	    # it's a BGL midplane
	    $node=$1;
	}
    } else {
	# LL node
    }
    return($node);
}

# on BG/L remove nodebook part
sub get_partition_size {
    my($self) = shift;
    my($node) = @_;
    my($size);
    if($node=~/(R\d\d-M\d)/) {
	# it's a BGL node
	if($node=~/(R\d\d-M\d)-N(.)/) {
	    # it's a BGL nodebook
	    $size=32;
	} else {
	    # it's a BGL midplane
	    $size=512;
	}
    } else {
	# LL node
	$size=-1;
    }
    return($size);
}

sub update_waiting_jobs_stack {
    my($self) = shift;
    my($cpu,$cpus,$jobid,$usedhcut,$nodelist,$user,$usedh,$startx,$wall,$dx,$endx,$color,$nr,$unr);
    my($starty,$py,$dy,$endy,$cpuh,$jcolor,$jnr,$class,$nodenr,$ucolor,$comment,$textcolor);
    my($starttime,$endtime,$starttimetopdog,$endtimetopdog,$startts,$endts,$ts,$classnr,$j,$rc);
    my($interactwithtopdog);
    my $dataobj=$self->{DATAOBJECT};
    my $canvas=$self->{CANVAS};
    my $infoobj=$self->{INFOOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my @nodes_freecpus;
    my $cpustart=0;
    my $cpumax=$self->{CPUS};
    my $frames=$dataobj->{FRAMES};
    my $reason;
    $self->PROTO_print_node_state($ISNOTOPEN);
    $self->PROTO_print_timeline(0,$ISNOTOPEN);

    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    $dx=$self->{DX};
    $dy=$self->{DY};
    $self->{MIDX}=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);


    return if($self->{NUMJOBS}>$self->{MAXNUMJOBS});

    my @waitingjobs=();
    foreach $jobid (sort
		     { &sort_waiting_for_forecast($dataobj) }
		    (keys( %{$dataobj->{WAITINGJOBS}} ))) {
	next if($dataobj->{JOBSTATE}->{$jobid}{"job_statuslong"} eq "HOLD");
	if($dataobj->{JOBSTATE}->{$jobid}{"job_stepname"}) {
	    my $sjobid=$jobid;
	    $sjobid=~s/\.\d+$//gs;
	    $self->{WAITINGSTEPNAMES}->{$sjobid}->{$dataobj->{JOBSTATE}->{$jobid}{"job_stepname"}}=$jobid;
	}
	if($dataobj->{JOBSTATE}->{$jobid}{"job_statuslong"} eq "REMOVED") {
	    $self->{WAITINGJOBSTATE}->{$jobid}="removed";
#	    print "WF: dependency $jobid $self->{WAITINGJOBSTATE}->{$jobid}\n";
	    next; 
	}
	if($dataobj->{JOBSTATE}->{$jobid}{"job_statuslong"} eq "COMPLETED") {
	    $self->{WAITINGJOBSTATE}->{$jobid}="completed";
#	    print "WF: dependency $jobid $self->{WAITINGJOBSTATE}->{$jobid}\n";
	    next; 
	}
	push(@waitingjobs,$jobid);
    }

    # Step 1: search the Top Dog(s)
    $j=0;
    my $num_topdogs=1;

    # copy state of machine
    for($nodenr=1;$nodenr<=$frames;$nodenr++) {
	$self->{FREECPUSTOPDOG}->[$nodenr]=$self->{FREECPUS}->[$nodenr];
	foreach $class (keys(%{$self->{CLASS2NR}})) {
	    $self->{NODEACTSTARTERSTOPDOG}->[$nodenr]->{$class}=$self->{NODEACTSTARTERS}->[$nodenr]->{$class};
	}
    }
    open(PROTO,">> schedule.log") if($self->{PROTO});
    printf(PROTO "%s\n","-"x80);	
    printf(PROTO " STARTING SEARCH OF    >>> TOP DOGS <<<\n");
    printf(PROTO "%s\n","-"x80);	

    foreach $jobid (@waitingjobs) {
	$user=$dataobj->{JOBSTATE}->{$jobid}{"job_owner"};
	$wall=$dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600;
	$cpus=$dataobj->{JOBSTATE}->{$jobid}{"job_totaltasks"}*$dataobj->{JOBSTATE}->{$jobid}{"job_conscpu"};
	$class=$dataobj->{JOBSTATE}->{$jobid}{"job_queue"};
	$classnr=$self->{CLASS2NR}->{$class};

	# check if job can be started, a job can only be a top dog if maxstarters allows this

	printf(PROTO " -> job $j $jobid maxstarters %d user %d in class %s\n",
	       $self->{MAXSTARTERCLASS}->{$class},$self->{MAXSTARTERCLASSUSER}->{$class},$class)  if($self->{PROTO});
	next if($self->{MAXSTARTERCLASS}->{$class}==0);
	next if($self->{MAXSTARTERCLASSUSER}->{$class}==0);

	$j++;

#	printf(PROTO " -> job $j $jobid\n") if($self->{PROTO});

	# search position for topdog
	for ($startts=0;$startts<=$#{$self->{TIMELINE_TS}};$startts++) {
            # remove job ending at $ts 
	    $self->move_forward_in_timeline($startts,$self->{FREECPUSTOPDOG},
					    $self->{NODEACTSTARTERSTOPDOG},
					    $self->{ACTSTARTERCLASSTOP},
					    $self->{ACTSTARTERCLASSUSERTOP},
					    $ISOPEN); 
	    my $free_for_this_class=$self->{TIMELINE_STARTERS}->[$startts]->[$classnr];
#	    print " check $startts: $cpus<=$free_for_this_class\n";
	    # time point could be a candidate for scheduling top dog
	    printf(PROTO " -> examine  job %15s %-8s %5.2f %6d %16s: ",$jobid,$user,$wall,$cpus,$class) if($self->{PROTO});
	    if($cpus<=$free_for_this_class) {
		if($rc=$self->check_job_placement($jobid,$self->{FREECPUSTOPDOG},$self->{NODEACTSTARTERSTOPDOG},
      					    $self->{ACTSTARTERCLASSTOP},$self->{ACTSTARTERCLASSUSERTOP},$startts)>0) {
		    print PROTO "WF: this job is now TOPDOG $j\n";
		    $self->do_job_placement($startts,$jobid,$self->{FREECPUSTOPDOG},$self->{NODEACTSTARTERSTOPDOG},
					    $self->{ACTSTARTERCLASSTOP},$self->{ACTSTARTERCLASSUSERTOP},0);
		    $dataobj->{JOBSTATE}->{$jobid}{"job_last_not_schedule_reason"}=$reason;
		    last;
		}
	    } else {
		$rc=-11;
	    }
	    if($rc<=0) {
		$reason=$self->rctostring($rc,$class,$ts,$classnr,$cpus);
		$dataobj->{JOBSTATE}->{$jobid}{"job_last_not_schedule_reason"}=$reason;
	    }
	    printf(PROTO " reason=$rc:$reason\n")  if($self->{PROTO});
	}


	$starttimetopdog=$self->{TIMELINE_TS}->[$startts];
	$endtimetopdog=$self->{TIMELINE_TS}->[$startts]+$wall;

	if($self->{PROTO}) {  
	    open(PROTO,">> schedule.log");
	    printf(PROTO "schedule top dog job %10s in class %10s for user %s color=%s:\n",$jobid,$class,$user,$color);	
	    printf(PROTO "                 spec:      %4d cpus, %5.2f h wall\n",$cpus,$wall);
	    printf(PROTO "                 starttime: %5.2f (#%d) %s\n",$starttimetopdog,$startts,
		   &sec_to_date(&date_to_sec($dataobj->{MACHSTATE}->{"system_time"})+$starttimetopdog*3600));
	    printf(PROTO "                   endtime: %5.2f \n",$endtimetopdog);
	    printf(PROTO "                   num_topdogs:%2d\n",$j);
	    close(PROTO);
	}
	$self->{WAITINGJOBSTATE}->{$jobid}="topdog";
	$self->PROTO_print_node_state_(0,$self->{NODEACTSTARTERSTOPDOG},$self->{FREECPUSTOPDOG});
	last if($j>=$num_topdogs);
    }

    close(PROTO) if($self->{PROTO});

    # remove state of jobids for job dependencies
    foreach $jobid (keys(%{$self->{WAITINGJOBSTATE}})) {
	delete($self->{WAITINGJOBSTATE}->{$jobid}) if ($self->{WAITINGJOBSTATE}->{$jobid} eq "ready");
    }

    # Step 2: walk though time line and scan at every point for a waiting job which can scheduled
    open(PROTO,">> schedule.log") if($self->{PROTO});

    printf(PROTO "%s\n","-"x80);	
    printf(PROTO " STARTING SCHEDULING     >>> WAITING JOBS <<<\n");
    printf(PROTO "%s\n","-"x80);	

    $j=0;
    for($ts=0;$ts<=$#{$self->{TIMELINE_TS}};$ts++) {
	print PROTO "\n","="x80,"\n" if($self->{PROTO});
	printf( PROTO "STARTING search for time step %2d time=%10.5f\n",$ts,$self->{TIMELINE_TS}->[$ts]) if($self->{PROTO});
	print PROTO "="x80,"\n" if($self->{PROTO});

#	$self->PROTO_print_node_state($ISOPEN);
#	$self->PROTO_print_timeline($ts,$ISOPEN);
	$self->move_forward_in_timeline($ts,
					$self->{FREECPUS},
					$self->{NODEACTSTARTERS},
					$self->{ACTSTARTERCLASS},
					$self->{ACTSTARTERCLASSUSER},

					$ISOPEN); # remove job ending at $ts 
	$self->PROTO_print_node_state($ISOPEN);
	$self->PROTO_print_timeline($ts,$ISOPEN);

	# check if more than one job will be ended at this point in time line
 	# -> remove first all ending jobs before starting a new one
	if($ts<=$#{$self->{TIMELINE_TS}}) {
	    if($self->{TIMELINE_TS}->[$ts] == $self->{TIMELINE_TS}->[$ts+1]) {
		printf(PROTO " -> skip this timestep -> schedule next job at next point in timeline (bc. same time)\n") 
		    if($self->{PROTO});
		next;
	    }
	}

	foreach $jobid (@waitingjobs) {
	    # skip already scheduled waiting jobs
	    $reason="unknown";
	    $user=$dataobj->{JOBSTATE}->{$jobid}{"job_owner"};
	    $wall=$dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600;
	    $cpus=$dataobj->{JOBSTATE}->{$jobid}{"job_totaltasks"}*$dataobj->{JOBSTATE}->{$jobid}{"job_conscpu"};
	    $class=$dataobj->{JOBSTATE}->{$jobid}{"job_queue"};
	    $comment=$dataobj->{JOBSTATE}->{$jobid}{"job_comment"};
	    $classnr=$self->{CLASS2NR}->{$class};

#	    next if($cpus<=32); # !!!! DEBUG
	    printf(PROTO " -> examine  job %15s %-8s %5.2f %6d %16s (%s): ",$jobid,$user,$wall,$cpus,$class,
		   $self->{WAITINGJOBSTATE}->{$jobid}) if($self->{PROTO});
	    if(($self->{WAITINGJOBSTATE}->{$jobid} eq "yes") || ($self->{WAITINGJOBSTATE}->{$jobid} eq "ready")) {
		printf(PROTO "[done]\n")  if($self->{PROTO});
		next;  	   
	    } 
	    
	    # check if enough free in this class 
	    if($cpus<=$self->{TIMELINE_STARTERS}->[($ts<$#{$self->{TIMELINE_TS}})?$ts+1:$ts]->[$classnr]) {
		# jobs could fit in
		if( ($rc=$self->check_job_placement($jobid,$self->{FREECPUS},$self->{NODEACTSTARTERS},
					      $self->{ACTSTARTERCLASS},$self->{ACTSTARTERCLASSUSER},$ts))>0) {
		    printf(PROTO "[fit]\n") if($self->{PROTO});
		    # jobs fit in
		    $starttime=$self->{TIMELINE_TS}->[$ts];
		    $endtime=$starttime+$wall;
		    # check interaction with top dog
		    $interactwithtopdog=0;
		    if( ($self->{WAITINGJOBSTATE}->{$jobid} ne "topdog") 
		        && ($starttime<$starttimetopdog) 
			&& ($endtime>$starttimetopdog)) {
			$rc=$self->check_job_placement($jobid,$self->{FREECPUSTOPDOG},
									$self->{NODEACTSTARTERSTOPDOG},
									$self->{ACTSTARTERCLASSTOP},
									$self->{ACTSTARTERCLASSUSERTOP},
									$ts);
			$interactwithtopdog=($rc<=0);
		    }

		    if(!$interactwithtopdog) {
			if($self->{PROTO}) {  
			    printf(PROTO "\nschedule found candidate: job %10s in class %10s (%d) for user %s: (ts=$ts, j=$j)\n",
				   $jobid,$class,$self->{CLASS2NR}->{$class},$user);	
			    printf(PROTO "                 spec:      %4d cpus, %5.2f h wall\n",$cpus,$wall);
			    printf(PROTO "                 starttime: %5.2f (#%d)\n",$starttime,$ts);
			    printf(PROTO "                   endtime: %5.2f (#%d)\n",$endtime,$endts);
			}
#		         $self->PROTO_print_node_state($ISOPEN);
#		         $self->PROTO_print_timeline($ts,$ISOPEN);
			$self->do_job_placement($ts,$jobid,$self->{FREECPUS},$self->{NODEACTSTARTERS},
						$self->{ACTSTARTERCLASS},$self->{ACTSTARTERCLASSUSER},1);
			$self->PROTO_print_node_state($ISOPEN);
			$self->PROTO_print_timeline($ts,$ISOPEN);
			
			# scheduled job change also the situation at starttime of top dog
			if (($starttime<$starttimetopdog) && ($endtime>$starttimetopdog)) {
			    $self->do_job_placement($ts,$jobid,$self->{FREECPUSTOPDOG},$self->{NODEACTSTARTERSTOPDOG},
						    $self->{ACTSTARTERCLASSTOP},$self->{ACTSTARTERCLASSUSERTOP},0);
			}

			$endtime=$self->{TIMEFORWARD} if ($endtime>$self->{TIMEFORWARD});
			if($starttime<$self->{TIMEFORWARD}) {
			    # place rectangle on canvas
			    $startx=$self->{MIDXX} + $starttime*$dx;
			    $endx=$self->{MIDXX} + $endtime*$dx;

			    my $helpref=$self->{TOPHULLOBJ};
			    my $overlap=0;
			    if($self->{SPLITSTACK}) {
				if($dataobj->{JOBSTATE}->{$jobid}{"job_prednodelist"}=~/$self->{SPLITSTACKREGSMALLNODES}/) {
				    $helpref=$self->{TOPHULLOBJSMALL};
				    if($cpus>$self->{SMALLCPUS}) {
					# seems to be a overlapping job, e.g.whole machine
					$helpref=$self->{TOPHULLOBJ};
					$overlap=1; 
				    }
				}
			    }

			    my $nocont=0;
			    $nocont=1 if(($class=~/$self->{NOCONTREG}/) && ($self->{NOCONTSELECT}));
			    $nocont=1 if(($comment=~/$self->{NOCONTCOMMENTREG}/) && ($self->{NOCONTSELECT}));

			    my $category=(!$nocont)?"WAIT":"WAITNOCONT";
			    if($self->{SEARCHSTR}) {
				$category="OWNJOBS" if ($user=~/$self->{SEARCHSTR}/);
			    }


			    # get nr for user and job
			    $color=$colorobj->get_color($category,$jobid);
			    $unr=$colorobj->colortonr($category,,$color);
			    $textcolor="black";
			    $textcolor="red" if($self->{WAITINGJOBSTATE}->{$jobid} eq "topdog");

			    if($overlap) {
				# seems to be a overlapping job, e.g.whole machine
				# plot it also on small job region
				$helpref=$self->{TOPHULLOBJ};
				$helpref->put($self->{MIDXX}+$starttime*$dx,$self->{MIDXX}+$endtime*$dx,
					      ($cpus-$self->{SMALLCPUS})*$dy/$self->{NODESIZE},
					      "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
				$helpref=$self->{TOPHULLOBJSMALL};
				$helpref->put($self->{MIDXX}+$starttime*$dx,$self->{MIDXX}+$endtime*$dx,
					      $self->{SMALLCPUS}*$dy/$self->{NODESIZE},
					      "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
			    } else {
				$helpref->put($self->{MIDXX}+$starttime*$dx,$self->{MIDXX}+$endtime*$dx,
					      $cpus*$dy/$self->{NODESIZE},
					      "T${unr}R","T${unr}B",$color,"$j","$j:$user",1,"black",$textcolor);
			    }
			}
			$self->{WAITINGJOBSTATE}->{$jobid}="yes";
			$j++;
			$self->{SCREENSHOTTIMEPOS}=$self->{TIMELINE_TS}->[$ts+1];
			$self->{NUMJOBS}++;
			return if($self->{NUMJOBS}>$self->{MAXNUMJOBS});
			
		    } else {
			$rc=-10;
		    }
		}
	    } else {
		$rc=-11;
	    }
	    if($rc<=0) {
		$reason=$self->rctostring($rc,$class,$ts,$classnr,$cpus);
		$dataobj->{JOBSTATE}->{$jobid}{"job_last_not_schedule_reason"}=$reason;
	    }
	    printf(PROTO "[$rc:$reason]\n")  if($self->{PROTO});
	}
 	last if ($j>=2000); # debug
    }
    close(PROTO);

       
    return();
}


sub rctostring {
    my($self) = shift;
    my($rc,$class,$ts,$classnr,$cpus)=@_;
    return("could not place on nodes") if ($rc==0);
    return("maxstarter in class reached (".$self->{MAXSTARTERCLASS}->{$class}.")") if ($rc==-1);
    return("maxstarter for user in class reached (".$self->{MAXSTARTERCLASSUSER}->{$class}.")") if ($rc==-2);
    return("interfere with maintenance") if ($rc==-3);
    return("shape allocation") if ($rc==-4);
    return("dependency not fulfilled") if ($rc==-5);
    return("interact with topdog") if ($rc==-10);
    return("not enough free nodes in class ".$self->{TIMELINE_STARTERS}->[$ts]->[$classnr]."<$cpus") if ($rc==-11);
}

# state of nodes is described in vectors $freecpusref,$nodestartersref
#                                         eg: $self->{FREECPUS},$self->{NODEACTSTARTERS}
sub move_forward_in_timeline {
    my($self) = shift;
    my($ts,$freecpusref,$nodestartersref,$actstarterref,$actstarteruserref,$isopen)=@_;
    my($nodelist,$spec,$node,$num,$nodenr,$class,$jclass,$user);
    my $dataobj=$self->{DATAOBJECT};
    my $jobid=$self->{TIMELINE_JEND}->[$ts];

    return if(!$jobid);

    open(PROTO,">> schedule.log") if (($self->{PROTO}) && ($isopen eq $ISNOTOPEN));


    # mark this job as ready; for job dependencies
    if($dataobj->{JOBSTATE}->{$jobid}{"job_stepname"}) {
	$self->{WAITINGJOBSTATE}->{$jobid}="ready";
	print PROTO "\n--> set WAITINGJOBSTATE of $jobid to ready (stepname=",$dataobj->{JOBSTATE}->{$jobid}{"job_stepname"},")\n" if($self->{PROTO});
    }
    
    if($dataobj->{JOBSTATE}->{$jobid}{"job_prednodelist"}) {
	$nodelist=$dataobj->{JOBSTATE}->{$jobid}{"job_prednodelist"};
    } else {
	$nodelist=$dataobj->{JOBSTATE}->{$jobid}{"job_nodelist"};
    }
    $jclass=$dataobj->{JOBSTATE}->{$jobid}{"job_queue"};
    $user=$dataobj->{JOBSTATE}->{$jobid}{"job_owner"};

    print PROTO "\n--> next step in timeline: ts=$ts, remove job $jobid $jclass, $nodelist\n"  if($self->{PROTO});

#    $self->PROTO_print_node_state($ISOPEN);

    if($self->{CHECKMAXSTARTER}) {
	$actstarterref->{$jclass}--;
	if($self->{MAXSTARTERCLASSUSER}->{$jclass}!=-1) {
	    $actstarteruserref->{$jclass}->{$user}--;
	}
    }

    foreach $spec (split(/\),?\(/,$nodelist)) {
	$spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;

	my $pnum=$self->get_partition_size($node);
	$num=$pnum if($pnum>0);
	$node=$self->specnodename_to_nodename($node);
	$nodenr=$dataobj->{NODES}->{$node}->{"node_nr"};
	$freecpusref->[$nodenr]+=$num;
	# adjust starters of other classes on the job nodes
	foreach $class (keys(%{$nodestartersref->[$nodenr]})) {
	    my $diff=$freecpusref->[$nodenr]-$nodestartersref->[$nodenr]->{$class};
	    $diff=$num if($diff>$num); # add only cpus which freed by this job
	    print PROTO "   on node $nodenr diff is $diff for class $class\n" if($self->{PROTO});
	    if($diff>0) {
		$nodestartersref->[$nodenr]->{$class}+=$diff;
		if($nodestartersref->[$nodenr]->{$class}>$self->{NODESTARTERS}->[$nodenr]->{$class}) {
		    $nodestartersref->[$nodenr]->{$class}=$self->{NODESTARTERS}->[$nodenr]->{$class};
		}
	    }
	}
    }
#    $self->PROTO_print_node_state($ISOPEN);
    close(PROTO) if (($self->{PROTO}) && ($isopen eq $ISNOTOPEN));
}


# state of nodes is described in vectors $freecpusref,$nodestartersref
#                                         eg: $self->{FREECPUS},$self->{NODEACTSTARTERS}
sub check_job_placement {
    my($self) = shift;
    my($jobid,$freecpusref,$nodestartersref,$actstarterref,$actstarteruserref,$startts)=@_;
    my($nummachines,$taskspernode,$jclass,$nodenr,$i,$user,$rc,$nodenumbers);
    my $dataobj=$self->{DATAOBJECT};
#    print PROTO "check_job_placement($jobid,$freecpusref,$nodestartersref,$startts)" if($self->{PROTO});

    my $starth=$self->{TIMELINE_TS}->[$startts];
    my $wall=$dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600;
    my $endh=$starth+$wall;

    my $bgl=0;  $bgl=1 if ($dataobj->{JOBSTATE}->{$jobid}{job_bgl_shaperequ});


    $nummachines=$dataobj->{JOBSTATE}->{$jobid}{"job_nummachines"};
    $taskspernode=$dataobj->{JOBSTATE}->{$jobid}{"job_taskspernode"}*$dataobj->{JOBSTATE}->{$jobid}{"job_conscpu"};
    $jclass=$dataobj->{JOBSTATE}->{$jobid}{"job_queue"};
    $user=$dataobj->{JOBSTATE}->{$jobid}{"job_owner"};
    
    # check against max start per class/user
    if($self->{CHECKMAXSTARTER}) {
	if($actstarterref->{$jclass}>=$self->{MAXSTARTERCLASS}->{$jclass}) {
	    print PROTO "maxstart ",$actstarterref->{$jclass},">=",$self->{MAXSTARTERCLASS}->{$jclass}," " 
		if($self->{PROTO});
	    return(-1);
	}
	if($self->{MAXSTARTERCLASSUSER}->{$jclass}!=-1) {
	    if($actstarteruserref->{$jclass}->{$user}>=$self->{MAXSTARTERCLASSUSER}->{$jclass}) {
		print PROTO "maxstartuser ",$actstarteruserref->{$jclass}->{$user},">=",
		$self->{MAXSTARTERCLASSUSER}->{$jclass}," " if($self->{PROTO});
		return(-2);
	    }
	}
    }    

    # dependency check
    if($dataobj->{JOBSTATE}->{$jobid}{"job_dependency"}) {
	if($dataobj->{JOBSTATE}->{$jobid}{"job_dependency"}=~/\s*([^\s]+)\s*\>\= 0\s*/) {
	    my $depstepname=$1;
	    my $sjobid=$jobid; $sjobid=~s/\.\d+$//gs;
	    my $depjobid=$self->{WAITINGSTEPNAMES}->{$sjobid}->{$depstepname};
	    my $depjobstate=$self->{WAITINGJOBSTATE}->{$depjobid};
	    print "WF dependency $jobid ",$dataobj->{JOBSTATE}->{$jobid}{"job_dependency"}," -> ($depstepname) -> ($depjobid) ->($depjobstate)\n" if($sjobid eq "jubl.19755");
		if (($depjobstate ne "ready") && ($depjobstate ne "removed") && ($depjobstate ne "completed") ) {
		    print PROTO "[$jobid:$sjobid:$depjobid:$depstepname:$depjobstate]";
		    return(-5);
		}
	}
    }

    # check against MAINTENANCE
    my $isinmaint=0;
    for($i=0;$i<=$#{$self->{MAINTENANCE_START}};$i++) {
	$isinmaint=1 if($starth<$self->{MAINTENANCE_START}->[$i]) && ($endh>$self->{MAINTENANCE_END}->[$i]);
	$isinmaint=1 if($starth>$self->{MAINTENANCE_START}->[$i]) && ($starth<$self->{MAINTENANCE_END}->[$i]);
	$isinmaint=1 if($endh>$self->{MAINTENANCE_START}->[$i])   && ($endh<$self->{MAINTENANCE_END}->[$i]);
	print PROTO "[$startts:$starth..$endh in ",$self->{MAINTENANCE_START}->[$i],"..",
	             $self->{MAINTENANCE_END}->[$i],"->$nummachines]" if($self->{PROTO});
	return(-3) if($isinmaint==1);
    }

    if(!$bgl) {
	# check only if enough nodes free
	for($nodenr=1;(($nodenr<=$dataobj->{FRAMES}) && ($nummachines>0));$nodenr++) {
	    if($taskspernode<=$nodestartersref->[$nodenr]->{$jclass}) {
		# found a node which can host this job
		$nummachines--;
	    }
	    print PROTO "$nodenr:$nummachines " if($self->{PROTO});
	}
    } else {
	# check shape against free BGL nodes
#	printf( PROTO "[shapemax=%dx%dx%d]",$self->{SHAPE3DXMAX}+1,$self->{SHAPE3DYMAX}+1,$self->{SHAPE3DZMAX}+1);
	my(@freemp);
	my($x,$y,$z,$shape,$help);
	for($x=0;$x<=$self->{SHAPE3DXMAX};$x++) {
	    for($y=0;$y<=$self->{SHAPE3DYMAX};$y++) {
		for($z=0;$z<=$self->{SHAPE3DZMAX};$z++) {
		    $nodenr=$self->{SHAPE3D}->[$x][$y][$z];
#		    print PROTO "WF:checkfree $x:$y:$z $taskspernode<=$nodestartersref->[$nodenr]->{$jclass} $nummachines\n";
		    $freemp[$x][$y][$z]=($taskspernode<=$nodestartersref->[$nodenr]->{$jclass})?1:0;
		    $nummachines-- if($freemp[$x][$y][$z]);
		}
	    }
	}
	
	# too few free midplanes 
	if($nummachines>0) {
	    print PROTO "=0" if($self->{PROTO});
	    return(0);
	}
	
	$nummachines=$dataobj->{JOBSTATE}->{$jobid}{"job_nummachines"};
	$shape=$dataobj->{JOBSTATE}->{$jobid}{job_bgl_shaperequ};
	if($shape eq "0x0x0") {
	    $shape="1x1x1" if ($nummachines==1);
	    $shape="1x1x2" if ($nummachines==2);
	    $shape="3x1x1" if ($nummachines==3);
	    $shape="1x2x2" if ($nummachines==4);
	    $shape="2x2x2" if ($nummachines==8);
	    $shape="4x2x2" if ($nummachines==16);
	}
	$shape=~/(\d)+x(\d)+x(\d)+/;($x,$y,$z)=($1,$2,$3);
	for($i=0;$i<2;$i++) {
	    printf( PROTO "[testshape=%dx%dx%d]",$x,$y,$z);
	    ($rc,$nodenumbers)=$self->check_bgl_shape(\@freemp,$x,$y,$z);
	    if($rc==1) {
		if($self->{PROTO}) {
		    print PROTO "=1\n";
		    foreach my $nodenr (split(/,/,$nodenumbers)) {
			print PROTO "schedule on $nodenr ",$dataobj->{NODESTATE}->[$nodenr]->{"node_name"},"\n";
		    }
		}
		$dataobj->{JOBSTATE}->{$jobid}{"job_schednodenumbers"}=$nodenumbers;
		return(1);
	    }
	    $help=$x;$x=$y;$y=$z;$z=$help; # rotate
	}
	print PROTO "=-4" if($self->{PROTO});
	return(-4);

    }


    if($nummachines==0) {
	print PROTO "=1" if($self->{PROTO});
	return(1);
    } else {
	print PROTO "=0" if($self->{PROTO});
	return(0);
    }
}

sub check_bgl_shape {
    my($self) = shift;
    my($frempref,$dx,$dy,$dz)=@_;
    my($rc,$nodenumbers,$found);
    my($x,$y,$z,$lx,$ly,$lz);
    
    LOOP:
    for($x=0;$x<=$self->{SHAPE3DXMAX}-$dx+1;$x++) {
	for($y=0;$y<=$self->{SHAPE3DYMAX}-$dy+1;$y++) {
	    for($z=0;$z<=$self->{SHAPE3DZMAX}-$dz+1;$z++) {
		# for each starting position check all midplanes in shape
#		print "check_bgl_shape: startpos $x,$y,$z\n";
		$found=1;
		for($lx=$x;$lx<$x+$dx;$lx++) {
		    for($ly=$y;$ly<$y+$dy;$ly++) {
			for($lz=$z;$lz<$z+$dz;$lz++) {
			    $found=0 if($frempref->[$lx][$ly][$lz]==0);
			}
		    }
		}
		last LOOP if($found);
	    }
	}
    }
    if($found) {
	my(@list);
	$rc=1;
	for($lx=$x;$lx<$x+$dx;$lx++) {
	    for($ly=$y;$ly<$y+$dy;$ly++) {
		for($lz=$z;$lz<$z+$dz;$lz++) {
		    push(@list,$self->{SHAPE3D}->[$lx][$ly][$lz]);
		}
	    }
	}
	$nodenumbers=join(",",@list);
    } else {
	$rc=0;
	$nodenumbers="";
    }
#    print "[check_bgl_shape $nodenumbers]";
    return($rc,$nodenumbers);
}

# state of nodes is described in vectors $freecpusref,$nodestartersref
#                                         eg: $self->{FREECPUS},$self->{NODEACTSTARTERS}
# parameter doinsert describes if job should really inserted in timeline (not needed for topdog search)
sub do_job_placement {
    my($self) = shift;
    my($ts,$jobid,$freecpusref,$nodestartersref,$actstarterref,$actstarteruserref,$doinsert)=@_;
    my($wall,$endh,$user);
    my($nummachines,$taskspernode,$class,$jclass,$nodenr,$i,$insertpos,$copypos);
    my $dataobj=$self->{DATAOBJECT};
    my $actdate=$dataobj->{MACHSTATE}->{"system_time"};
    my @nodelist=();

    my $bgl=0;  $bgl=1 if ($dataobj->{JOBSTATE}->{$jobid}{job_bgl_shaperequ});

    $nummachines=$dataobj->{JOBSTATE}->{$jobid}{"job_nummachines"};
    $taskspernode=$dataobj->{JOBSTATE}->{$jobid}{"job_taskspernode"}*$dataobj->{JOBSTATE}->{$jobid}{"job_conscpu"};
    $jclass=$dataobj->{JOBSTATE}->{$jobid}{"job_queue"};
    $wall=$dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600;
    $endh=$self->{TIMELINE_TS}->[$ts]+$wall;
    $user=$dataobj->{JOBSTATE}->{$jobid}{"job_owner"};

    # check against max start per class/user
    if($self->{CHECKMAXSTARTER}) {
	$actstarterref->{$jclass}++;
	if($self->{MAXSTARTERCLASSUSER}->{$jclass}!=-1) {
	    $actstarteruserref->{$jclass}->{$user}++;
	}
    }    

    # insert in timeline, not when working on topdog update
    if($doinsert) {
	# insert end marker for last timestamp  
	$insertpos=$ts;
	while ( ($insertpos<$#{$self->{TIMELINE_TS}})  
		&& ($self->{TIMELINE_TS}->[$insertpos]<=$endh) ) { 
	    $insertpos++;
	}
	# copy this element (timestep after end of job)
	$copypos=$insertpos;
	# last element: insert behind this element
	$insertpos++ if ( ($insertpos==$#{$self->{TIMELINE_TS}}) 
			  && ($self->{TIMELINE_TS}->[$insertpos]<=$endh) ); 
	
	print PROTO "WF:   insert end point at ts=$insertpos timestamp=$endh copy from $copypos\n" if($self->{PROTO});
	splice(@{$self->{TIMELINE_TS}},$insertpos,0,$endh);
	splice(@{$self->{TIMELINE_FREE}},$insertpos,0,$self->{TIMELINE_FREE}->[$copypos]);
	{
	    my @help=(@{$self->{TIMELINE_STARTERS}->[$copypos]});
	    splice(@{$self->{TIMELINE_STARTERS}},$insertpos,0,\@help);
	}
	splice(@{$self->{TIMELINE_JEND}},$insertpos,0,$jobid);
    }

    my %nodenumbers=();
    if($bgl) {
	print PROTO "WF: found job_schednodenumbers: ",$dataobj->{JOBSTATE}->{$jobid}{"job_schednodenumbers"},"\n";
	foreach my $nr (split(/,/,$dataobj->{JOBSTATE}->{$jobid}{"job_schednodenumbers"})) {
	    $nodenumbers{$nr}=1;
	}
    }
    

    print PROTO "WF: nummachines=$nummachines taskspernode=$taskspernode \n" if($self->{PROTO});
    for($nodenr=1;(($nodenr<=$dataobj->{FRAMES}) && ($nummachines>0));$nodenr++) {
	if (
	    ( (!$bgl) && ($taskspernode<=$nodestartersref->[$nodenr]->{$jclass})) ||
	    ( ($bgl)  && ($nodenumbers{$nodenr}) )
	   ) {
	    # node can host a part of this job
	    print PROTO "WF: put job on node $nodenr ",$dataobj->{NODESTATE}->[$nodenr]->{"node_name"},"\n" 
		if($self->{PROTO});
	    $freecpusref->[$nodenr]-=$taskspernode;
	    push(@nodelist,"(".$dataobj->{NODESTATE}->[$nodenr]->{"node_name"}.",".$taskspernode.")");
	    # adjust starters of other classes on the job nodes
	    foreach $class (keys(%{$self->{NODESTARTERS}->[$nodenr]})) {
		my $classnr=$self->{CLASS2NR}->{$class};
		my $diff=$nodestartersref->[$nodenr]->{$class}-$freecpusref->[$nodenr];
		print PROTO "WF: on node nodenr=$nodenr is for class $class diff $diff\n"   if($self->{PROTO}); 
		if($diff>0) {
		    if($doinsert) {
			for($i=$ts+1;( ($i<$#{$self->{TIMELINE_TS}})  
				       && ($self->{TIMELINE_TS}->[$i]<=$endh) ); $i++) {
			    # adjust starters counter for all following timesteps
			    my $help=$self->{TIMELINE_STARTERS}->[$i+1]->[$classnr];
			    print PROTO "WF: remove at ts=$i from class $class $diff cpus: "  if($self->{PROTO}); 
			    print PROTO $self->{TIMELINE_STARTERS}->[$i]->[$classnr]," -> "  if($self->{PROTO});
			    $self->{TIMELINE_STARTERS}->[$i]->[$classnr]-=$diff;
			    print PROTO $self->{TIMELINE_STARTERS}->[$i]->[$classnr],"\n"  if($self->{PROTO});
			}
		    }
		    $nodestartersref->[$nodenr]->{$class}-=$diff;
		}
	    }

	    # found a node which can host this job
	    $nummachines--;
	}
    }

    if($doinsert) {
	# set nodelist of waiting job, needed for removing job at endtimestamp
	$dataobj->{JOBSTATE}->{$jobid}{"job_prednodelist"}=join(",",@nodelist);
	$dataobj->{JOBSTATE}->{$jobid}{"job_dispatchdate"} =&sec_to_date(&date_to_sec($actdate)+
									  $self->{TIMELINE_TS}->[$ts]*3600);
;	$dataobj->{JOBSTATE}->{$jobid}{"job_dispatchdateh"} =$self->{TIMELINE_TS}->[$ts];
	$dataobj->{JOBSTATE}->{$jobid}{"job_enddate"} =&sec_to_date(&date_to_sec($actdate)+$endh*3600);
	$dataobj->{JOBSTATE}->{$jobid}{"job_enddateh"} =$endh;

    }
}



sub create_timescale {
    my($self) = shift;
    my($canvas,$now,$dx,$dy)=@_;
    my($id,$px,$py,$h,$step,$diffh);
    my($now2l,$now0,$daysb,$d);
    $px=$self->{POSX}+$self->{LEFTPAD}+$self->{TIMEBACK}*$dx;
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};

    # adjust step width
    $step=1;
    if($dx<20) {
	for($step=2;$step<($self->{TIMEBACK}+$self->{TIMEFORWARD});$step+=2) {
	    last if ($step*$dx>20);
	}
    }

    # print hour marker
    for($h=-$self->{TIMEBACK};$h<$self->{TIMEFORWARD};$h++) {
	if($h%$step==0) {
	    $id=$canvas->createLine( $px+$h*$dx, $py+1,
				     $px+$h*$dx, $py+5,
				     -width => 1,
				     -fill => "grey10", 
				     -tags => ["forecast","forecastmarkerarea"]
				     );
	    push(@{$self->{ITEMS}},$id);
	    $id=$canvas->createText( $px+$h*$dx, $py+9,
				     -text => ($h<=0)?"${h}h":"+${h}h",
				     -anchor => 'c',
				     -font => $self->{FONT1}, 
				     -tags => ["forecast","forecastmarkerarea"]);
	    push(@{$self->{ITEMS}},$id);
	} else {
	    $id=$canvas->createLine( $px+$h*$dx, $py+1,
				     $px+$h*$dx, $py+2,
				     -width => 1,
				     -fill => "grey10", 
				     -tags => ["forecast","forecastmarkerarea"]
				     );
	    push(@{$self->{ITEMS}},$id);
	}
    }
    # time/date at 0-marker
#    $now2l=$now;$now2l=~s/-/\n/g;
    $now2l=$now;$now2l=~s/-/|/g;
    $id=$canvas->createText( $px, $py+$self->{BOTTOMPADTOP}+8,
			     -text => $now2l,
			     -anchor => 'c',
			     -font => $self->{FONT1}, 
			     -tags => ["forecast","forecastmarkerarea"]);
    push(@{$self->{ITEMS}},$id);

    $now0=$now;$now0=~s/\d\d:\d\d:\d\d/00:00:00/gs;
    $diffh=&timediff($now,$now0)/3600;
    $daysb=0;  $daysb++ while($diffh+24*$daysb<$self->{TIMEBACK}); $daysb--;
    for($d=-($diffh+24*$daysb);$d<$self->{TIMEFORWARD};$d+=24) {
	$id=$canvas->createLine( $px+$d*$dx, $py+00,
				 $px+$d*$dx, $py+40,
				 -width => 2,
				 -fill => "grey40",
				 , -tags => ["forecast","forecastmarkerarea"]
				 );
	push(@{$self->{ITEMS}},$id);

	if($self->{SHOWWEEKDAY}) {
	    if($px+$d*$dx+2+25<$self->{POSX}+$self->{WIDTH}) {
		$id=$canvas->createRectangle($px+$d*$dx+2, $py-2+30,
					     $px+$d*$dx+2+25, $py-3-10+30, -outline => "black",
					     -fill => "DarkGoldenrod", -tags => ["forecast","forecastmarkerarea"]);
		push(@{$self->{ITEMS}},$id);
		# +2*3600 fix problem with summer time shift
		my $wdaystr=&sec_to_day(&date_to_sec($now)+$d*3600+2*3600);
		$id=$canvas->createText( $px+$d*$dx+2, $py-7+30,
					 -text => " $wdaystr ->",
					 -anchor => 'w',
					 -font => $self->{FONT1}, -tags => ["forecast","forecastmarkerarea"]);
		push(@{$self->{ITEMS}},$id);
	    }
	}
    }
}

sub update_reservations_stack {
    my($self) = shift;
    my($nodelist,$starts,$ends,$starth,$endh,$cpus,$nummidplanes,$resid,$node,$user,$ucolor,$unr,$j,$textcolor,$color);
    my($bg_bps);
    my $dataobj=$self->{DATAOBJECT};
    my $canvas=$self->{CANVAS};
    my $infoobj=$self->{INFOOBJECT};
    my $colorobj=$self->{COLOROBJECT};
    my $frames=$dataobj->{FRAMES};
    my $dx=$self->{DX};
    my $dy=$self->{DY};
    my $sectoh=1.0/(60*60);
    my $htosec=(60*60);

    open(PROTO,">> schedule.log") if($self->{PROTO});

    # get information about all reservations
    $j=0;
    foreach $resid (keys( %{$dataobj->{RESERVATION}} )) {
	my $prio=$dataobj->{RESERVATION}->{$resid}{'priority'};
	$nodelist=$dataobj->{RESERVATION}->{$resid}{'nodelist'};
	$bg_bps=$dataobj->{RESERVATION}->{$resid}{'res_bg_bps'};
	$starts=int(&timediff($dataobj->{RESERVATION}->{$resid}{'starttime'},$dataobj->{MACHSTATE}->{"system_time"}));
	$ends=int(&timediff($dataobj->{RESERVATION}->{$resid}{'endtime'},$dataobj->{MACHSTATE}->{"system_time"}));
	$starth=$starts*$sectoh;
	$endh=$ends*$sectoh;
# 	print "WF: $resid $starts*$sectoh\n";
	
	# only reservation which are not already started
	if (($starth>0) && ($starth<$self->{TIMEFORWARD}) ) {
	    $j++;
	    $endh=$self->{TIMEFORWARD} if ( ($ends*$sectoh)>$self->{TIMEFORWARD});
	    
	    # a BGL reservation?
	    $nodelist=$bg_bps if($bg_bps);

	    # determine number of midplanes
	    $nummidplanes=0;
	    foreach $node (split(/,/,$nodelist)) {
		# position of next rectangle
		if($node=~/(R\d\d-M\d)/) {
		    # it's a BGL node
		    if($node=~/(R\d\d-M\d)-N(.)/) {
			# it's a BGL nodebook
			$nummidplanes+=1/16;
		    } else {
			# it's a BGL midplane
			$nummidplanes+=1;
		    }
		} else {
		    # LL node, no BGL node
		    $nummidplanes+=2;
		}
	    }
	    $user=$dataobj->{RESERVATION}->{$resid}{'user'};
	    printf(PROTO "WF: put reservation %2d user=%-10s from %10.4fh to %10.4fh nummidplanes=%5.2f of %d\n",$j,
		       $user,$starth,$endh,$nummidplanes,$frames) if($self->{PROTO});
	    
	    # get nr for user and reservation
	    $color=$colorobj->get_color("RESERVATION",$resid);
	    $unr=$colorobj->colortonr("RESERVATION",$color);
	    $textcolor="black";
	    $cpus=512*$nummidplanes;
	    if( ($user!~/(loadl|root)/)  || ($nummidplanes==$frames) )  {
		# it's a maintenance
		if( ($user=~/(loadl|root)/) && ($nummidplanes==$frames)) {
		    push(@{$self->{MAINTENANCE_START}},$starth);
		    push(@{$self->{MAINTENANCE_END}},$endh);

		    # insert timestamp for end of maintenance_end
		    {
			my $insertpos=1;
			while ( ($insertpos<$#{$self->{TIMELINE_TS}})  
				&& ($self->{TIMELINE_TS}->[$insertpos]<=$endh) ) { 
			    $insertpos++;
			}
			$insertpos=0 if ($#{$self->{TIMELINE_TS}}==0); # no running job
			my $copypos=$insertpos;
			# last element: insert behind this element
			$insertpos++ if ( ($insertpos==$#{$self->{TIMELINE_TS}}) 
					  && ($self->{TIMELINE_TS}->[$insertpos]<=$endh) ); 
#			print "WF: $copypos\n";
			my @help=(@{$self->{TIMELINE_STARTERS}->[$copypos]});
			splice(@{$self->{TIMELINE_STARTERS}},$insertpos,0,\@help);
			splice(@{$self->{TIMELINE_TS}},$insertpos,0,$endh);
			splice(@{$self->{TIMELINE_FREE}},$insertpos,0,$self->{TIMELINE_FREE}->[$copypos]);
			print PROTO "WF:   insert end point at ts=$insertpos timestamp=$endh copy from $copypos\n"  if($self->{PROTO});
			splice(@{$self->{TIMELINE_JEND}},$insertpos,0,undef);
		    }

		    $self->{BOTTOMHULLOBJ}->put($self->{MIDXX}+$starth*$dx,$self->{MIDXX}+$endh*$dx,
						$cpus*$dy/$self->{NODESIZE},
						"T${unr}R","T${unr}B","autogrey","MAINT","MAINTENANCE");

		} else {
		    $self->{BOTTOMHULLOBJ}->put($self->{MIDXX}+$starth*$dx,$self->{MIDXX}+$endh*$dx,
						$cpus*$dy/$self->{NODESIZE},
						"T${unr}R","T${unr}B","autogrey","$j","$j:$user");

		}
	    }
	    last if($j>2000);
	}
    }
    close(PROTO) if($self->{PROTO});
}

sub generateinfo {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$name,$xpos,$ypos,$category)=@_;
    my($runtime);
    my $infostr="forecast: no info for $name in $category\n";
    
    
    ###########################################################################
    # reservation
    ###########################################################################
    if($category eq "RES") {
	my $resid=$name;
	$infostr=sprintf("Reservation: %5d:\n",$resid);
	$infostr.=sprintf("-------------------------------\n");
	if(exists($dataobj->{RESERVATION}->{$resid})) {
	    my $o=$dataobj->{RESERVATION}->{$resid};
	    my $duration=&timediff($o->{"endtime"},$o->{"starttime"});
	    $infostr.=sprintf("  User:        %s\n", $o->{"user"});
	    $infostr.=sprintf("  Priority:    %s\n", $o->{"priority"});
	    $infostr.=sprintf("  Nodelist:    %s\n", $o->{"nodelist"});
	    $infostr.=sprintf("  start time:  %s\n", $o->{"starttime"});
	    $infostr.=sprintf("  end   time:  %s\n", $o->{"endtime"});
	    $infostr.=sprintf("  duration:    %5.2fh  (%4.2f days)\n",
			      $duration/3600,$duration/3600/24);
	    $runtime=&timediff($o->{"starttime"},$dataobj->{MACHSTATE}->{"system_time"});
	    if($runtime<0) {
		$infostr.=sprintf("  running:     %5.2fh  (%4.2f days)\n",
				  -$runtime/3600,-$runtime/3600/24);
		$infostr.=sprintf("  rest time:   %5.2fh  (%4.2f days)\n",
				  ($duration+$runtime)/3600,($duration+$runtime)/3600/24);
	    } else {
		$infostr.=sprintf("  starting in: %5.2fh  (%4.2f days)\n",
				  $runtime/3600,$runtime/3600/24);
	    }
	    if($o->{"user"}=~/^ERROR/) {
		$infostr.=sprintf("  Color:       red\n");
	    } else {
		$infostr.=sprintf("  Color:       %s\n",$self->{COLOROBJECT}->get("WAIT",$o->{"user"}));
	    }
	}
	return($infostr);
    }
    
    ###########################################################################
    # Waiting job
    ###########################################################################
    if(($category eq "WAIT") || ($category eq "WAITNOCONT") || $category eq "OWNJOBS") {
	my $jobid=$name;
	
	$infostr=sprintf("Info for Waiting Jobstep %8s [%s] (%s)\n",
			 $jobid,substr($dataobj->{JOBSTATE}->{$jobid}{"job_name"},0,30),$jobid);
	$infostr.=sprintf("--------------------------------------------------------------\n");
	$infostr.=sprintf("  User: %s (%s) ", $dataobj->{JOBSTATE}->{$jobid}{"job_owner"},lc($category));
	$infostr.=sprintf("  CPUs: %d ", $dataobj->{JOBSTATE}->{$jobid}{"job_totaltasks"}
			  *$dataobj->{JOBSTATE}->{$jobid}{"job_conscpu"});
	$infostr.=sprintf("  Wall: %6.2f h\n", $dataobj->{JOBSTATE}->{$jobid}{"job_wall"}/3600);
	my $unicore=($dataobj->{JOBSTATE}->{$jobid}{"job_comment"}=~/NOT\s?Unicore/);
	$infostr.=sprintf("  Class:   %s    restart=%s %s\n", $dataobj->{JOBSTATE}->{$jobid}{"job_queue"},
			  $dataobj->{JOBSTATE}->{$jobid}{"job_restart"},
			  ($unicore)?"submitted by Unicore":"");
	$infostr.=sprintf("  Exec:      ...%s \n", substr($dataobj->{JOBSTATE}->{$jobid}{"job_taskexec"},-30));
	
	$infostr.=sprintf("  Prediction\n");
	$infostr.=sprintf("   last reason: '%s'\n",
                          $dataobj->{JOBSTATE}->{$jobid}{"job_last_not_schedule_reason"});
	$infostr.=sprintf("   Time: start %s, in %6.2f h\n", 
			  $dataobj->{JOBSTATE}->{$jobid}{"job_dispatchdate"},
			  $dataobj->{JOBSTATE}->{$jobid}{"job_dispatchdateh"});
	$infostr.=sprintf("   Time: end   %s, in %6.2f h\n", 
			  $dataobj->{JOBSTATE}->{$jobid}{"job_enddate"},
			  $dataobj->{JOBSTATE}->{$jobid}{"job_enddateh"});
	$infostr.=sprintf("   Nodelist:  %s\n", 
			  format_bracket_list($dataobj->{JOBSTATE}->{$jobid}{"job_prednodelist"},$self->{WIDTH}-18,"\n           ") 
			  );
#	$infostr.=sprintf("  Color:     %s (%d)\n",$self->{COLOROBJECT}->get_color("WAIT",$jobid),
#                                                  $self->{COLOROBJECT}->idtonr("WAIT",$jobid));
        return($infostr);
    }

    return($infostr) if (!$self->{DX}); # not ready for callback
    return($infostr) if ($xpos<$self->{POSX}+$self->{LEFTPAD});
    return($infostr) if ($xpos>$self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD});
#    print "WF: generateinfo $name $xpos,$ypos ",caller(),"\n";

    ###########################################################################
    # marker line
    ###########################################################################
    if($name eq "forecastmarkerarea") {
        my $showit=1;
        # check border
        $showit=0 if($xpos<=($self->{POSX}+$self->{LEFTPAD}+1));
        $showit=0 if($xpos>=($self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD})-1);
        $showit=0 if($ypos<=($self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD})+$self->{BOTTOMPADTOP});
        $showit=0 if($ypos>=($self->{POSY}+$self->{HEIGHT})-1);

        $showit=1 if($self->{SHOWMARKERPERMANENT});

        if(!$showit) {
          $canvas->delete($self->{MARKERLINE}) if($self->{MARKERLINE});
          $self->{MARKERLINE}=undef;
          return;
        }
 	if(!$self->{MARKERLINE}) {
	    $self->{MARKERLINE}=$canvas->createLine(      $xpos, $self->{POSY},
							  $xpos, $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
							  -width => 2,
						          -fill => "red", 
							  -tags => ["FOREMARKERLINE"]
							  );
#	push(@{$self->{FIXEDITEMS}},$id);
	} else {
	    my($oldx,$oldy)=$self->{CANVAS}->coords('FOREMARKERLINE');
	    $self->{CANVAS}->move('FOREMARKERLINE',$xpos-$oldx,0);
	    $self->{CANVAS}->raise('FOREMARKERLINE');
	}

	my $disth=($xpos-$self->{MIDX})/$self->{DX};
	my $actdate=$dataobj->{MACHSTATE}->{"system_time"};
	my $destdate=&sec_to_date(&date_to_sec($actdate)+$disth*3600);
	my $i=0;
	while( ($self->{TIMELINE_TS}->[$i]<$disth) && ($i < $#{$self->{TIMELINE_TS}}) ) {
#	    print "WF: $i -> $self->{TIMELINE_TS}->[$i]<$disth\n";
	    $i++;
	}
        print "WF: disth $i -> $self->{TIMELINE_TS}->[$i]<$disth\n";
	$infostr= sprintf("  Node Usage at:        %5.2f h -> %s [#%d of %d] %12.8f %12.8f\n", 
                          $disth,$destdate,$i,$#{$self->{TIMELINE_TS}},$xpos,$ypos);
	$infostr.=sprintf("  Used CPUS:            %6d of %d (%d free)\n", 
			  $self->{CPUS}-$self->{TIMELINE_FREE}->[$i],
			  $self->{CPUS},
			  $self->{TIMELINE_FREE}->[$i]);
	foreach my $class (sort {$self->{NODESTARTERS}->[0]->{$b} 
				 <=> $self->{NODESTARTERS}->[0]->{$a} } (keys(%{$self->{NODESTARTERS}->[0]}))) {
	    $infostr.=sprintf("   Starter in %-8s: %6d of %6d\n",$class,
			      $self->{TIMELINE_STARTERS}->[$i]->[$self->{CLASS2NR}->{$class}],
			      $self->{NODESTARTERS}->[0]->{$class}
			      );
	}

    }


    if($name=~/R(\d+)[RB]/) {
	my $nr=$1;
	my $resid=$colorobj->nrtoid("WAIT",$nr);
#	print "WF: generateinfo forecast $nr,$resid\n";
	$infostr=sprintf("Info for reservation %4d\n",$resid);
	$infostr.=sprintf("-------------------------------\n");
	if(exists($dataobj->{RESERVATION}->{$resid})) {
	    my $o=$dataobj->{RESERVATION}->{$resid};
	    my $duration=&timediff($o->{"endtime"},$o->{"starttime"});
	    $infostr.=sprintf("  User:        %s\n", $o->{"user"});
	    $infostr.=sprintf("  Priority:    %s\n", $o->{"priority"});
	    $infostr.=sprintf("  Nodelist:    %s\n", $o->{"nodelist"});
	    $infostr.=sprintf("  start time:  %s\n", $o->{"starttime"});
	    $infostr.=sprintf("  end   time:  %s\n", $o->{"endtime"});
	    $infostr.=sprintf("  duration:    %5.2fh  (%4.2f days)\n",
			      $duration/3600,$duration/3600/24);
	    $runtime=&timediff($o->{"starttime"},$dataobj->{MACHSTATE}->{"system_time"});
	    if($runtime<0) {
		$infostr.=sprintf("  running:     %5.2fh  (%4.2f days)\n",
				  -$runtime/3600,-$runtime/3600/24);
		$infostr.=sprintf("  rest time:   %5.2fh  (%4.2f days)\n",
				  ($duration+$runtime)/3600,($duration+$runtime)/3600/24);
	    } else {
		$infostr.=sprintf("  starting in: %5.2fh  (%4.2f days)\n",
				  $runtime/3600,$runtime/3600/24);
	    }
	    if($o->{"user"}=~/^ERROR/) {
		$infostr.=sprintf("  Color:       red\n");
	    } else {
		$infostr.=sprintf("  Color:       %s\n",$self->{COLOROBJECT}->get($o->{"WAIT","user"}));
	    }

	}
    }

    return($infostr);
}

# will bwe called by colorobject if the color mapping was changed
sub updatecoloredobjects {
    my($self) = shift;
    my($category)=@_;
    my($nr,$color);

#    print "WF: updatecoloredobjects in forecast was called for category $category\n";
    foreach $nr ($self->{COLOROBJECT}->getusednrs($category)) {
	$color=$self->{COLOROBJECT}->nrtocolor($category,$nr);
	$self->{CANVAS}->itemconfigure("T${nr}R", -fill => "$color"); 
#	print "   updatecoloredobjects T${nr}R -> $color\n";

    }

}

sub scale {
    my($n)=@_;
#    return($n);
#    printf("log: %2d -> %f\n",$n,log($n)/log(10));
    return(log($n+1)/log(10));
}


sub sec_to_day {
    my ($lsec)=@_;
    my($wdaystr);
    my ($sec,$min,$hours,$mday,$mon,$year,$wday,$rest)=localtime($lsec);
    $wdaystr=("Su","Mo","Tu","We","Th","Fr","Sa")[$wday];
#    my $llsec=$lsec/3600;
#    print "WF: sec_to_day $lsec $llsec -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> wday=$wday wdaystr=$wdaystr\n";
    return($wdaystr);
}

sub format_bracket_list {
    my($in,$width,$delim)=@_;
    my $out="";
    my $len=0;
    while($in=~s/^([^\)]+\))//) {
	$out.=$1;
	$len+=length($1);
	if($len>$width) {
	    $out.=$delim;
	    $len=0;
	}
    }
    return($out);
}

sub date_to_sec {
    my ($date)=@_;
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year $^O\n";
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
    return($timesec);
}

sub sec_to_date {
    my ($lsec)=@_;
    my($date);
    my ($sec,$min,$hours,$mday,$mon,$year,$rest)=localtime($lsec);
    $year=sprintf("%02d",$year % 100);
    $mon++;
    $date=sprintf("%02d/%02d/%02d-%02d:%02d:%02d",$mon,$mday,$year,$hours,$min,$sec);
#    print "WF: sec_to_date $lsec -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $date\n";
    return($date);
}

sub timediff {
    my ($date1,$date2)=@_;
#    print"WF: timediff $date1 $date2\n";
    my $timesec1=&date_to_sec($date1);
    my $timesec2=&date_to_sec($date2);
    return($timesec1-$timesec2);
}


sub update_left_cb {
    my($x,$y,$amount)=@_;
    my $self=$$selfref;
    my $dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    my $midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
#    print "WF: update_left_cb: $x,$y\n";
    if($x<$midx) {
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","TIMEBACK",$self->{TIMEBACK}+$amount);
    } else {
	if($self->{TIMEBACK}-$amount>=0) {
	    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","TIMEFORWARD",$self->{TIMEFORWARD}-$amount);
	}
    }
}

sub update_right_cb {
    my($x,$y,$amount)=@_;
    my $self=$$selfref;
    my $dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{TIMEBACK}+$self->{TIMEFORWARD});
    my $midx=$self->{POSX} + $self->{LEFTPAD}  + ($self->{TIMEBACK}*$dx);
#    print "WF: update_right_cb: $x,$y\n";
    if($x<$midx) {
	if($self->{TIMEBACK}-$amount>=0) {
	    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","TIMEBACK",$self->{TIMEBACK}-$amount);
	}
    } else {
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","TIMEFORWARD",$self->{TIMEFORWARD}+$amount);
    }
}

sub update_left_left_cb {
    my $self=$$selfref;
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","TIMEBACK",$self->{TIMEBACK}+2);
}
sub update_left_right_cb {
    my $self=$$selfref;
    if($self->{TIMEBACK}-2>=0) {
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","TIMEBACK",$self->{TIMEBACK}-2);
    }
}

sub update_right_left_cb {
    my $self=$$selfref;
    if($self->{TIMEFORWARD}-2>=0) {
	$self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","TIMEFORWARD",$self->{TIMEFORWARD}-2);
    }
}
sub update_right_right_cb {
    my $self=$$selfref;
    $self->{OPTIONOBJECT}->update_optval_direct($self->{CLUSTERNAME},"Forecast","TIMEFORWARD",$self->{TIMEFORWARD}+2);
}

sub sort_for_forecast   {    
    my($o)=@_;
    my($enda,$endb)=($o->{JOBSTATE}->{$a}{"job_wall"}/3600 - $o->{RUNNINGDATA}->{$a}{FL_USEDH},
		     $o->{JOBSTATE}->{$b}{"job_wall"}/3600 - $o->{RUNNINGDATA}->{$b}{FL_USEDH});
    $enda=0.01 if($enda<0);
    $endb=0.01 if($endb<0);
    if($enda == $endb) {
	if($o->{RUNNINGDATA}->{$b}{FL_ALLCPU} == $o->{RUNNINGDATA}->{$a}{FL_ALLCPU}) {
	    $o->{JOBSTATE}->{$a}{"job_wall"} <=> $o->{JOBSTATE}->{$b}{"job_wall"};
	} else {
	    $o->{RUNNINGDATA}->{$b}{FL_ALLCPU} <=> $o->{RUNNINGDATA}->{$a}{FL_ALLCPU};
	}
    } else {
	$endb <=> $enda;
    }
}

sub sort_waiting_for_forecast   {    
    my($o)=@_;
    my $favoreda=$o->{JOBSTATE}->{$a}{"job_comment"} =~ "FAVORED";
    my $favoredb=$o->{JOBSTATE}->{$b}{"job_comment"} =~ "FAVORED";
    my $oka=$o->{JOBSTATE}->{$a}{"job_state"} eq "IDLE";
    my $okb=$o->{JOBSTATE}->{$b}{"job_state"} eq "IDLE";
    if($favoreda == $favoredb) {
	if($oka == $okb) {
	    $o->{JOBSTATE}->{$b}{"job_sysprio"} <=> $o->{JOBSTATE}->{$a}{"job_sysprio"};
	} else {
	    $okb <=> $oka;
	}
    } else {
	$favoredb <=> $favoreda;
    }
}



sub PROTO_clear  {
    my($self) = shift;
    my ($c,$nodenr);
    my $dataobj=$self->{DATAOBJECT};
    return() if(!$self->{PROTO});
    open(PROTO,"> schedule.log");
    print PROTO "Update at ",$dataobj->{TIMESTR},"\n\n";
    close(PROTO);
}

sub PROTO_print_node_state  {
    my($self) = shift;
    my($isopen)=@_;
    $self->PROTO_print_node_state_($isopen,$self->{NODEACTSTARTERS},$self->{FREECPUS});
}

sub PROTO_print_node_state_  {
    my($self) = shift;
    my($isopen,$nodeactstartersref,$freecpusref)=@_;
    my ($c,$nodenr);
    my $dataobj=$self->{DATAOBJECT};
    my (@sum);
    return() if(!$self->{PROTO});

    open(PROTO,">> schedule.log")  if($isopen eq $ISNOTOPEN);
    printf(PROTO "CLASS map: ");
    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	printf(PROTO "CLASS[%2d]=%-16s ",$c,$self->{NR2CLASS}->[$c]);
	    printf(PROTO "\nCLASS map: ") if ($c%4==3);
    }
    print PROTO "\n";
    printf(PROTO "CLASS nr. -> r/t     ");
    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	printf(PROTO " %4d",$c);
    }
    printf(PROTO "\n");
    for($nodenr=1;$nodenr<=$dataobj->{FRAMES};$nodenr++) {
	my $cpu_total=$dataobj->{NODESTATE}->[$nodenr]->{"cpu_total"};
	my $cpu_run=$dataobj->{NODESTATE}->[$nodenr]->{"cpu_run"};
	printf(PROTO "NODE[%2d]: free=%4d |",$nodenr,$freecpusref->[$nodenr]);
	for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	    my $val=$nodeactstartersref->[$nodenr]->{$self->{NR2CLASS}->[$c]};
	    printf(PROTO " %4d",$val) if($val!=0);
	    printf(PROTO " %4s",".") if($val==0);
	    $sum[$c]+=$val;
	}
	printf(PROTO " (%s) \n",$dataobj->{NODESTATE}->[$nodenr]->{"node_name"});
    }

    printf(PROTO "SUM                 |",);
    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	    printf(PROTO " %4d",$sum[$c]);
    }
    printf(PROTO "\n");
    printf(PROTO "\n");
    close(PROTO) if($isopen eq $ISNOTOPEN);
}



sub PROTO_print_timeline  {
    my($self) = shift;
    my($start,$isopen)=@_;
    my ($c,$ts,$jobid);
    my $dataobj=$self->{DATAOBJECT};
    return() if(!$self->{PROTO});
    $start=0 if(!$start);
    open(PROTO,">> schedule.log") if($isopen eq $ISNOTOPEN);

    printf(PROTO "running jobs on timeline:\n");
    printf(PROTO "CLASS nr. ->       ");
    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	printf(PROTO " %4d",$c);
    }
    printf(PROTO "\n");
    for($ts=$start;$ts<=$#{$self->{TIMELINE_TS}};$ts++) {
	printf(PROTO "%04d-TIME[%5.2f h]:",$ts,$self->{TIMELINE_TS}->[$ts]);
	for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	    my $val=$self->{TIMELINE_STARTERS}->[$ts]->[$c];
	    printf(PROTO " %4d",$val) if($val!=0);
	    printf(PROTO " %4s",".") if($val==0);
	}
	$jobid=$self->{TIMELINE_JEND}->[$ts];
	printf(PROTO " %s cpus=%d\n",$jobid,$dataobj->{JOBSTATE}->{$jobid}{"job_totaltasks"});
    }
    printf(PROTO "\n");
    close(PROTO)  if($isopen eq $ISNOTOPEN);

}

1;

