# $Source: /cvs/cvsroot/llview/lib/LLview_manage_elements.pm,v $
# $Author: zdv087 $
# $Revision: 1.57 $
# $Date: 2007/07/24 07:54:31 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2005, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#

package LLview_manage_elements;
use strict;

use Data::Dumper;
#use Devel::Size::Report qw/report_size/;

use LLview_manage_colors;

use LLview_get_locdata;
use LLview_get_www;
use LLview_get_exec;

#my $enable_grid=1;
#use LLview_get_grid;

my $enable_grid=0;

use LLview_parse_xml;

use LLview_gui_main;
use LLview_gui_scala;
use LLview_gui_nodes;
use LLview_gui_joblist;
use LLview_gui_waiting;
use LLview_gui_running;
use LLview_gui_graph;
use LLview_gui_histogram;
use LLview_gui_info;
use LLview_gui_status;

use LLview_gui_scalahist;

use LLview_gui_partlist;
use LLview_gui_resgraph;
use LLview_gui_forecast;
use LLview_gui_forecastdisplay;
use LLview_gui_usage;

my($debug)=0;
my($selfref)=-1;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_manage_elements: new %s\n",ref($proto)) if($debug>=3);

    $self->{INSTPATH}      = "";
    $self->{INIFILE}       = "";
    $self->{VERBOSE}       = 0;
    $self->{SHOWPM}        = 0;

    $self->{COLORMANAGER}  = undef;
    $self->{RECEIVER}      = undef;
    $self->{PARSER}        = undef;
    $self->{MAINWIN}       = undef;
    $self->{INFO}          = undef;
    $self->{STATUS}        = undef;
    $self->{SCALA}         = undef;
    $self->{NODES}         = undef;
    $self->{JOBLIST}       = undef;
    $self->{RUNNING}       = undef;
    $self->{WAITING}       = undef;
    $self->{GRAPH}         = undef;
    $self->{HISTOGRAM}     = undef;
    $self->{SCALAHIST}     = undef;

    $self->{SOURCE}        = "locdata";
    $self->{DOINFO}        = 1;
    $self->{DOSTATUS}      = 1;
    $self->{DOSCALA}       = 1;
    $self->{DONODES}       = 1;
    $self->{DOJOBLIST}     = 1;
    $self->{DORUNNING}     = 1;
    $self->{DOWAITING}     = 1;
    $self->{DOGRAPH}       = 1;
    $self->{DOHISTOGRAM}   = 1;
    $self->{DOHISTORY}     = 1;
    $self->{DOPARTLIST}    = 0;
    $self->{DORESGRAPH}    = 0;
    $self->{DOFORECAST}    = 0;
    $self->{DOFORECASTDISPLAY} = 0;
    $self->{DOUSAGEGRAPH}  = 0;
    $self->{REMOTECONTROL} = 0;
    $self->{TIMER}         = -1;
    $self->{SEARCHSTR}     = "";
    $self->{SELECTNODES}   = ".*";
    $self->{SELECTUID}     = ".*";
    $self->{DEMOVERSION}   = 0;
    $self->{ERRFILE}       = undef;
    $self->{PREFIX}        = "";

    bless $self, $class;
    if($selfref==-1)  {
	$selfref=\$self;
    } else {
	printf("WARNING: double constructor call to LLview_manage_elements ...\n")
    }
    return $self;
}

sub settings {
    my($self) = shift;
    my($instpath,$verbose,$source,$inifile,$history,$timer,$search,$errfile,$prefix)=@_;
    $self->{INSTPATH}=$instpath if($instpath);
    $self->{VERBOSE}=$verbose if($verbose);
    $self->{SOURCE}=$source if($source);
    $self->{INIFILE}=$inifile if($inifile);
    $self->{DOHISTORY}=$history if($history);
    $self->{TIMER}=$timer if($timer);
    $self->{SEARCHSTR}=$search if($search);
    $self->{ERRFILE}=$errfile if($errfile);
    $self->{PREFIX}=$prefix if($prefix);
    return 1;
}


sub build {
    my($self) = shift;
    my($objname,$objref,$section);
    my($mainwin,$instpath,$optobj);
    $instpath=$self->{INSTPATH};
    my $multicluster=0;


    $self->{COLORMANAGER}=LLview_manage_colors->new();

    $mainwin=$self->{MAINWIN} = LLview_gui_main->new($self->{INSTPATH},$self->{INIFILE},$multicluster,0,"-",$self->{PREFIX});

    $self->{MAINWIN}->register_steptimer_function("steptimer",\&update_steptimer);

    # creates also the option object
    $optobj=$self->{OPTIONOBJECT}=$mainwin->{OPTIONOBJECT};

    # now we can build elements options
    $section="General";

    if($enable_grid) {
	$optobj->register_option($section,"SOURCE", -label => "data source", 
				 -caller => $self, -pack => 1, 
				 -values => ["www","exec","locdata","grid"],
				 -labels => ["WWW: from Web-Server",
					     "llqxml: Execute local command",
					     "LocalData: tar file on local machine",
					     "Grid Web Service: Usage records" ],
				 -type => "radiogroup", -default => $self->{SOURCE},
				 -updatereq => 1);
    } else {
	$optobj->register_option($section,"SOURCE", -label => "data source", 
				 -caller => $self, -pack => 1, 
				 -values => ["www","exec","locdata"],
				 -labels => ["WWW: from Web-Server",
					     "llqxml: Execute local command",
					     "LocalData: tar file on local machine"],
				 -type => "radiogroup", -default => $self->{SOURCE},
				 -updatereq => 1);
    }

    $optobj->register_option($section,"VERBOSE", -label => "verbose", 
			     -caller => $self, -pack => 1,
			     -type => "radio", -default => $self->{VERBOSE});

    $optobj->register_option($section,"DEMOVERSION", -label => "demo version", 
			     -caller => $self, -pack => 3,
			     -type => "radio", -default => $self->{DEMOVERSION});

    $optobj->register_option($section,"SHOWPM", -label => "show +/- buttons", 
			     -caller => $self, -pack => 3,
			     -type => "radio", -default => $self->{SHOWPM});

    $optobj->register_option($section,"SELECTNODES", -label => "Node selection regexp", -labelwidth => 30,
			     -caller => $self, -pack => 1,
			     -type => "string", -default => $self->{SELECTNODES});
    $optobj->register_option($section,"SELECTUID", -label => "Job selection regexp (uid)", -labelwidth => 30,
			     -caller => $self, -pack => 1,
			     -type => "string", -default => $self->{SELECTUID});

    $optobj->register_option($section,"REMOTECONTROL", -label => "RC", 
			     -caller => $self, -pack => 2,
			     -type => "radio", -default => $self->{REMOTECONTROL});

    $section="Elements";

    $optobj->register_comment($section,"COMMENT1", 
			      -text => "\n!!! changes on following options have only effect !!!\n!!!     after save options and restart llview     !!!\n", 
			      -type => "comment");
    $optobj->register_option($section,"DOSCALA", -label => "show usage bar", 
			     -caller => $self, -pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOSCALA});

    $optobj->register_option($section,"DONODES", -label => "show nodes", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DONODES});

    $optobj->register_option($section,"DOJOBLIST", -label => "show joblist", 
			     -caller => $self, -pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOJOBLIST});

    $optobj->register_option($section,"DORUNNING", -label => "show running", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DORUNNING});

    $optobj->register_option($section,"DOWAITING", -label => "show waiting", 
			     -caller => $self, -pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOWAITING});

    $optobj->register_option($section,"DOGRAPH", -label => "show graph", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOGRAPH});

    $optobj->register_option($section,"DOHISTOGRAM", -label => "show histogram", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOHISTOGRAM});

    $optobj->register_option($section,"DOSTATUS", -label => "show status", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOSTATUS});

    $optobj->register_option($section,"DOINFO", -label => "show info", 
			     -caller => $self, -pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOINFO});

    $optobj->register_option($section,"DOHISTORY", -label => "show history", 
			     -caller => $self, -pack => 1, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOHISTORY});

    $optobj->register_option($section,"DOPARTLIST", -label => "show partition (BGL)", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOPARTLIST});

    $optobj->register_option($section,"DORESGRAPH", -label => "show reservations (BGL)", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DORESGRAPH});

    $optobj->register_option($section,"DOFORECAST", -label => "show prediction of usage", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOFORECAST});

    $optobj->register_option($section,"DOFORECASTDISPLAY", -label => "show prediction of usage (new)", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOFORECASTDISPLAY});

    $optobj->register_option($section,"DOUSAGEGRAPH", -label => "show usage history (BGL)", 
			     -caller => $self, -pack => 2, -labelwidth => 25,
			     -type => "radio", -default => $self->{DOUSAGEGRAPH});
    

    # create parser
    $self->enable_parser();
    $self->enable_receiver();


    $mainwin->register_data_object("getdata",$self->{PARSER});
    $mainwin->register_timer_function("getdata",\&update_data);
    $mainwin->register_color_object("managecolor",$self->{COLORMANAGER});


    printf("\t\LLview_manage_elements: start enable_info\n") if($debug>=4);
    $self->enable_info()    if($self->{DOINFO});
    printf("\t\LLview_manage_elements: start enable_status\n") if($debug>=4);
    $self->enable_status()  if($self->{DOSTATUS});
    printf("\t\LLview_manage_elements: start enable_scala\n") if($debug>=4);
    $self->enable_scala()   if($self->{DOSCALA});
    printf("\t\LLview_manage_elements: start enable_nodes\n") if($debug>=4);
    $self->enable_nodes()   if($self->{DONODES});
    printf("\t\LLview_manage_elements: start enable_joblist\n") if($debug>=4);
    $self->enable_joblist() if($self->{DOJOBLIST});
    printf("\t\LLview_manage_elements: start enable_running\n") if($debug>=4);
    $self->enable_running() if($self->{DORUNNING});
    printf("\t\LLview_manage_elements: start enable_waiting\n") if($debug>=4);
    $self->enable_waiting() if($self->{DOWAITING});
    printf("\t\LLview_manage_elements: start enable_graph\n") if($debug>=4);
    $self->enable_graph()   if($self->{DOGRAPH});
    printf("\t\LLview_manage_elements: start enable_histogram\n") if($debug>=4);
    $self->enable_histogram()   if($self->{DOHISTOGRAM});
    printf("\t\LLview_manage_elements: start enable_history\n") if($debug>=4);
    $self->enable_history() if($self->{DOHISTORY});
    printf("\t\LLview_manage_elements: start enable_partlist\n") if($debug>=4);
    $self->enable_partlist() if($self->{DOPARTLIST});
    printf("\t\LLview_manage_elements: start enable_reservation\n") if($debug>=4);
    $self->enable_reservation() if($self->{DORESGRAPH});
    printf("\t\LLview_manage_elements: start enable_forecast\n") if($debug>=4);
    $self->enable_forecast() if($self->{DOFORECAST});
    printf("\t\LLview_manage_elements: start enable_forecast\n") if($debug>=4);
    $self->enable_forecastdisplay() if($self->{DOFORECASTDISPLAY});
    printf("\t\LLview_manage_elements: start enable_usagegraph\n") if($debug>=4);
    $self->enable_usagegraph() if($self->{DOUSAGEGRAPH});

    # initialize sort order of known batch queues
    $self->init_objects();

    $self->set_global_vars();

    $self->set_datatype_text();

    $mainwin->build_gui();

    # for highlight
    $self->{MAINWIN}->{FONT1}=$self->{JOBLIST}->{FONT1};
    $self->{MAINWIN}->{BFONT1}=$self->{JOBLIST}->{BFONT1};

}

sub set_global_vars {
    my($self) = shift;
    my($objname);
    foreach $objname (keys(%{$self->{OBJECTS}})) {
#	print "WF: set_global_vars $objname\n" if($self->{VERBOSE}); 
	$self->{OBJECTS}->{$objname}->{INSTPATH}=$self->{INSTPATH};
	$self->{OBJECTS}->{$objname}->{VERBOSE}=$self->{VERBOSE};
    }
    $self->{OPTIONOBJECT}->{SHOWPM}=$self->{SHOWPM};
    $self->{PARSER}->{SELECTNODES}=$self->{SELECTNODES};
    $self->{PARSER}->{SELECTUID}=$self->{SELECTUID};
    $self->{PARSER}->{DEMOVERSION}=$self->{DEMOVERSION};
}

sub enable_parser {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{PARSER}           = LLview_parse_xml->new();
    $self->{OBJECTS}->{PARSER}=$self->{PARSER};
    return(1);
}

sub enable_receiver {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};

    $self->{RECEIVER_LOCDATA} = LLview_get_locdata->new();
    $self->{RECEIVER_LOCDATA}->{DATAOBJ}=$self->{PARSER};
    $self->{RECEIVER_LOCDATA}->init_options($mainwin->{OPTIONOBJECT});
    $self->{OBJECTS}->{RECEIVER_LOCDATA}=$self->{RECEIVER_LOCDATA};

    $self->{RECEIVER_WWW}     = LLview_get_www->new();
    $self->{RECEIVER_WWW}->{DATAOBJ}=$self->{PARSER};
    $self->{RECEIVER_WWW}->init_options($mainwin->{OPTIONOBJECT});
    $self->{OBJECTS}->{RECEIVER_WWW}=$self->{RECEIVER_WWW};

    $self->{RECEIVER_EXEC}    = LLview_get_exec->new();
    $self->{RECEIVER_EXEC}->{DATAOBJ}=$self->{PARSER};
    $self->{RECEIVER_EXEC}->init_options($mainwin->{OPTIONOBJECT});
    $self->{OBJECTS}->{RECEIVER_EXEC}=$self->{RECEIVER_EXEC};

    if($enable_grid) {
	$self->{RECEIVER_GRID}     = LLview_get_grid->new();
	$self->{RECEIVER_GRID}->{DATAOBJ}=$self->{PARSER};
	$self->{RECEIVER_GRID}->init_options($mainwin->{OPTIONOBJECT});
	$self->{OBJECTS}->{RECEIVER_GRID}=$self->{RECEIVER_GRID};
    }

    return(1);
}

sub enable_info {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{INFO}       = LLview_gui_info->new();
    $mainwin->register_canvas_object("info",$self->{INFO});
    $mainwin->register_info_object("info",$self->{INFO});
    $self->{OBJECTS}->{INFO}=$self->{INFO};
    return(1);
}

sub enable_status {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{STATUS}    = LLview_gui_status->new();
    $mainwin->register_canvas_object("status",$self->{STATUS});
    $self->{OBJECTS}->{STATUS}=$self->{STATUS};
    $self->{STATUS}->set_errfile($self->{ERRFILE});
    return(1);
}

sub enable_scala {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{SCALA}  = LLview_gui_scala->new();
    $mainwin->register_canvas_object("scala",$self->{SCALA});
    $self->{OBJECTS}->{SCALA}=$self->{SCALA};
    return(1);
}

sub enable_nodes {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{NODES}  = LLview_gui_nodes->new();
    $mainwin->register_canvas_object("nodes",$self->{NODES});
    $self->{OBJECTS}->{NODES}=$self->{NODES};
    return(1);
}

sub enable_joblist {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{JOBLIST}    = LLview_gui_joblist->new();
    $self->{JOBLIST}->register_data_object("getdata",$self->{PARSER});
    $self->{JOBLIST}->register_color_object("managecolor",$self->{COLORMANAGER});

    $mainwin->register_canvas_object("joblist",$self->{JOBLIST});
    $mainwin->register_subcanvas_object("joblistsb",$self->{JOBLIST});
    $mainwin->register_scroll_object("joblistscroll",$self->{JOBLIST});
    $mainwin->register_search_object("joblistsearch",$self->{JOBLIST});
    $self->{OBJECTS}->{JOBLIST}=$self->{JOBLIST};
    return(1);
}

sub enable_running {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{RUNNING}   = LLview_gui_running->new();
    $mainwin->register_notebook_object("Running",$self->{RUNNING});
    $mainwin->register_search_object("runningsearch",$self->{RUNNING});
    $self->{OBJECTS}->{RUNNING}=$self->{RUNNING};
    return(1);
}

sub enable_waiting {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{WAITING}   = LLview_gui_waiting->new();
    $mainwin->register_notebook_object("Waiting",$self->{WAITING});
    $mainwin->register_search_object("waitingsearch",$self->{WAITING});
    $self->{OBJECTS}->{WAITING}=$self->{WAITING};
    return(1);
}

sub enable_graph {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{GRAPH}  = LLview_gui_graph->new();
    $mainwin->register_canvas_object("graph",$self->{GRAPH});
    $self->{OBJECTS}->{GRAPH}=$self->{GRAPH};
    return(1);
}

sub enable_histogram {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{HISTOGRAM}  = LLview_gui_histogram->new();
    $mainwin->register_canvas_object("histogram",$self->{HISTOGRAM});
    $self->{OBJECTS}->{HISTOGRAM}=$self->{HISTOGRAM};
    $mainwin->register_steptimer_function("histogram",\&autoupdate_histogram);

    return(1);
}

sub autoupdate_histogram {
    my $self=$$selfref;
    return(1) if(!$self->{MAINWIN}->{AUTOPLAY});
    $self->{HISTOGRAM}->stepdiagramcnt();
}


sub enable_history {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{SCALAHIST} = LLview_gui_scalahist->new();
    $mainwin->register_notebookcanvas_object("History",$self->{SCALAHIST});
    # a hack
    $self->{SCALAHIST}->{MAINWIN} = $mainwin;
    $self->{OBJECTS}->{HISTORY}=$self->{SCALAHIST};
    return(1);
}

sub disable_history {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    if($self->{SCALAHIST}) {
	$self->{SCALAHIST}->destroy();
	$mainwin->deregister_notebookcanvas_object("history");
	$self->{SCALAHIST}=undef;
	delete($self->{OBJECTS}->{SCALAHIST});
    }
    return(1);
}

sub enable_partlist {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{PARTLIST}    = LLview_gui_partlist->new();
    $mainwin->register_canvas_object("partlist",$self->{PARTLIST});
    $self->{PARTLIST}->register_color_object("managecolor",$self->{COLORMANAGER});

    $mainwin->register_subcanvas_object("partlistsb",$self->{PARTLIST});
    $mainwin->register_scroll_object("partlistscroll",$self->{PARTLIST});
    $mainwin->register_search_object("partlistsearch",$self->{PARTLIST});

    $self->{OBJECTS}->{PARTLIST}=$self->{PARTLIST};

    return(1);
}

sub enable_reservation {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{RESGRAPH}    = LLview_gui_resgraph->new();
    $mainwin->register_canvas_object("resgraph",$self->{RESGRAPH});
    $self->{RESGRAPH}->register_color_object("managecolor",$self->{COLORMANAGER});
    $self->{OBJECTS}->{RESGRAPH}=$self->{RESGRAPH};

    return(1);
}

sub enable_forecast {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{FORECAST}    = LLview_gui_forecast->new();
    $mainwin->register_canvas_object("forecast",$self->{FORECAST});
    $self->{FORECAST}->register_color_object("managecolor",$self->{COLORMANAGER});
    $self->{OBJECTS}->{FORECAST}=$self->{FORECAST};
    $mainwin->register_search_object("forecast",$self->{FORECAST});
    $self->{FORECAST}->{MAINWIN}=$mainwin;
    return(1);
}

sub enable_forecastdisplay {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{FORECAST}    = LLview_gui_forecastdisplay->new();
    $mainwin->register_canvas_object("forecast",$self->{FORECAST});
    $self->{FORECAST}->register_color_object("managecolor",$self->{COLORMANAGER});
    $self->{OBJECTS}->{FORECAST}=$self->{FORECAST};
    $mainwin->register_search_object("forecast",$self->{FORECAST});
    $self->{FORECAST}->{MAINWIN}=$mainwin;
    return(1);
}

sub enable_usagegraph {
    my($self) = shift;
    my $mainwin=$self->{MAINWIN};
    $self->{USAGEGRAPH}    = LLview_gui_usagegraph->new();
    $mainwin->register_canvas_object("usagegraph",$self->{USAGEGRAPH});
    $self->{USAGEGRAPH}->register_color_object("managecolor",$self->{COLORMANAGER});
    $self->{OBJECTS}->{USAGEGRAPH}=$self->{USAGEGRAPH};

    return(1);
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id,$objname);
#    print "manage_elements,optvalchanged: $section,$name -> $val  ...\n" if($self->{VERBOSE});
    $self->{$name}=$val;
    $self->set_global_vars();

    if($name eq "SOURCE") {
	$self->set_datatype_text();
    }

# only future, currently only after restart
#    if($name eq "DOHISTORY") {
#	$self->enable_history() if($val);
#	$self->disable_history() if(!$val);
#    }
}


sub set_datatype_text {
    my($self) = shift;
    $self->{MAINWIN}->set_datatype_text("FILE") if ($self->{SOURCE} eq "locdata");
    $self->{MAINWIN}->set_datatype_text("WWW")  if ($self->{SOURCE} eq "www");
    $self->{MAINWIN}->set_datatype_text("GRID") if ($self->{SOURCE} eq "grid");
    $self->{MAINWIN}->set_datatype_text("SSH") if ($self->{SOURCE} eq "ssh");
}


sub update_steptimer {
    my $self=$$selfref;
    my($tend,$value)=@_;
    print "WF LLview_manage_elements:update_steptimer \n" if($debug>=4); 
    if($self->{"DOSTATUS"}) {
	$self->{STATUS}->progress(0,$tend,$value);
    }
    return(1);
}

sub update_data {
    my $self=$$selfref;
    my($rc,$receiver);

    if($self->{REMOTECONTROL}==1) {
	if(-f "$self->{INSTPATH}/RESTARTNOW") {
	    unlink("$self->{INSTPATH}/RESTARTNOW");
	    exit(0);
	}
	if(-f "$self->{INSTPATH}/STOPNOW") {
	    unlink("$self->{INSTPATH}/STOPNOW");
	    exit(100);
	}
    }

    $receiver=$self->{RECEIVER_LOCDATA} if ($self->{SOURCE} eq "locdata");
    $receiver=$self->{RECEIVER_WWW}     if ($self->{SOURCE} eq "www");
    $receiver=$self->{RECEIVER_EXEC}    if ($self->{SOURCE} eq "exec");
    $receiver=$self->{RECEIVER_GRID}    if ($self->{SOURCE} eq "grid");
    $rc=$receiver->getdata();
    if($rc) {
	my $addstr="";
	$rc=$self->{PARSER}->parse_data($receiver->{DATA});
	$self->{MAINWIN}->set_normal_display();
	
	$addstr.=" node=~/$self->{SELECTNODES}/" if($self->{SELECTNODES} ne ".*");
	$addstr.=" uid=~/$self->{SELECTUID}/" if($self->{SELECTUID} ne ".*");

	$self->{MAINWIN}->set_window_name(uc($self->{PARSER}->{MACHSTATE}->{"system_name"})." source: ".$self->{SOURCE}.$addstr);
    } else {
	print "update_data: ERROR:$receiver->{ERRSTRING}\n";
	$self->{PARSER}->{DEFAULTINFO}=$receiver->{ERRSTRING};
	$self->{MAINWIN}->set_error_text("<ERROR>");
	$self->{MAINWIN}->set_error_display();
	$self->{INFO}->defaultinfo();
    }

#    $self->doDump();

    return $rc;
}

sub init_objects {
    my($self) = shift;
    $self->{PARSER}->{CLASSPRIO} = {
			    'system'  => 2,
			    'c_serial' => 3,
			    'c_inter' => 4,
			    'c_short' => 5,
			    'c_med'   => 6,
			    'c_long'  => 7,
			    'c_xlong'  => 8,
			    
			    'n_short'  => 9,
			    'n_med'  => 10,
			    'n_long'  => 11,
			    
			    'm_short'  => 12,
			    'm_med'  => 13,			    
			    'm_meds'  => 14,			    
			    'm_long'  => 15,

			    'init'     => 16,
			    'boot'     => 17,
			    'running'  => 18,

			    'n0512'     => 19,
			    'n1024'     => 20,
			    'n2048'     => 21,
			    'n4096'     => 22,
			    'n8192'     => 23,
			    'small'     => 24,
			    'nocsmall'  => 25,

			    'nocont'  => 0,
			    'norun'   => 1
			    };
    return(1);
}



sub doDump {
    my($self) = shift;
    $Data::Dumper::Indent=1;
        open(OUT,">self.dump");            print OUT $self->mydumper($self);               close(OUT);
	open(OUT,">option.dump");          print OUT $self->mydumper($self->{OPTIONOBJECT}); close(OUT);
	open(OUT,">COLORMANAGER.dump");    print OUT $self->mydumper(      $self->{COLORMANAGER} ); close(OUT);
	open(OUT,">RECEIVER.dump");        print OUT $self->mydumper(          $self->{RECEIVER} ); close(OUT);
	open(OUT,">PARSER.dump");          print OUT $self->mydumper(            $self->{PARSER} ); close(OUT);
	
	open(OUT,">MAINWIN.dump");         print OUT $self->mydumper(           $self->{MAINWIN} ); close(OUT);
	open(OUT,">INFO.dump");            print OUT $self->mydumper(              $self->{INFO} ); close(OUT);
	open(OUT,">STATUS.dump");          print OUT $self->mydumper(            $self->{STATUS} ); close(OUT);
	open(OUT,">SCALA.dump");           print OUT $self->mydumper(             $self->{SCALA} ); close(OUT);
	open(OUT,">NODES.dump");           print OUT $self->mydumper(             $self->{NODES} ); close(OUT);
	open(OUT,">JOBLIST.dump");         print OUT $self->mydumper(           $self->{JOBLIST} ); close(OUT);
	open(OUT,">RUNNING.dump");         print OUT $self->mydumper(           $self->{RUNNING} ); close(OUT);
	open(OUT,">WAITING.dump");         print OUT $self->mydumper(           $self->{WAITING} ); close(OUT);
	open(OUT,">GRAPH.dump");           print OUT $self->mydumper(             $self->{GRAPH} ); close(OUT);
	open(OUT,">SCALAHIST.dump");       print OUT $self->mydumper(         $self->{SCALAHIST} ); close(OUT);
	open(OUT,">FORECAST.dump");        print OUT $self->mydumper(          $self->{FORECAST} ); close(OUT);

	open(OUT,">FORECASTBOSMALL.dump");  print OUT $self->mydumper($self->{FORECAST}->{BOTTOMHULLOBJSMALL} ); close(OUT);
	open(OUT,">FORECASTBO.dump");       print OUT $self->mydumper($self->{FORECAST}->{BOTTOMHULLOBJ} ); close(OUT);
	open(OUT,">FORECASTTOPSMALL.dump"); print OUT $self->mydumper($self->{FORECAST}->{TOPHULLOBJSMALL} ); close(OUT);
	open(OUT,">FORECASTTOP.dump");      print OUT $self->mydumper($self->{FORECAST}->{TOPHULLOBJ} ); close(OUT);

    if(0) {
	my $dumper = Data::Dumper->new();
	open(OUT,">option.dump");          print OUT $dumper->Dump  (      $self->{OPTIONOBJECT} ); close(OUT);
	open(OUT,">COLORMANAGER.dump");    print OUT $dumper->Dump  (      $self->{COLORMANAGER} ); close(OUT);
	open(OUT,">RECEIVER.dump");        print OUT $dumper->Dump  (          $self->{RECEIVER} ); close(OUT);
	open(OUT,">PARSER.dump");          print OUT $dumper->Dump  (            $self->{PARSER} ); close(OUT);
	
	open(OUT,">MAINWIN.dump");         print OUT $dumper->Dump  (           $self->{MAINWIN} ); close(OUT);
	open(OUT,">INFO.dump");            print OUT $dumper->Dump  (              $self->{INFO} ); close(OUT);
	open(OUT,">STATUS.dump");          print OUT $dumper->Dump  (            $self->{STATUS} ); close(OUT);
	open(OUT,">SCALA.dump");           print OUT $dumper->Dump  (             $self->{SCALA} ); close(OUT);
	open(OUT,">NODES.dump");           print OUT $dumper->Dump  (             $self->{NODES} ); close(OUT);
	open(OUT,">JOBLIST.dump");         print OUT $dumper->Dump  (           $self->{JOBLIST} ); close(OUT);
	open(OUT,">RUNNING.dump");         print OUT $dumper->Dump  (           $self->{RUNNING} ); close(OUT);
	open(OUT,">WAITING.dump");         print OUT $dumper->Dump  (           $self->{WAITING} ); close(OUT);
	open(OUT,">GRAPH.dump");           print OUT $dumper->Dump  (             $self->{GRAPH} ); close(OUT);
	open(OUT,">SCALAHIST.dump");       print OUT $dumper->Dump  (         $self->{SCALAHIST} ); close(OUT);
	open(OUT,">FORECAST.dump");        print OUT $dumper->Dump  (          $self->{FORECAST} ); close(OUT);
    } 

}


sub mydumper {
    my($self) = shift;
    my($hashref)=@_;

#    my $dumper = Data::Dumper->new([$hashref],["Dump"]);
#    $dumper->Seen({'*c' => $self->{COLORMANAGER}});

#    print "ID=",$ID,report_size($hashref, { indent => "  " } )


    return(report_size($hashref, { indent => "  " }));
}

sub mydumper_test {
    my($self) = shift;
    my($hashref)=@_;
    my ($key,$str,%sizehash,%type);

    foreach $key (sort(keys(%$hashref))) {
	if ($key=~/(INFOOBJECT|COLOROBJECT|OPTIONOBJECT|DATAOBJECT|CANVAS|EXTUPDATER)/) { 
	    $type{$key}="REF";
	} elsif ($key=~/(BINDING|CALLER)/) {
	    $type{$key}="HASH";
	    $sizehash{$key}=scalar keys(%{$hashref->{$key}});
	} elsif ($key=~/(OBJECTS)/) {
#		print "WF: OBJECTS -> ",ref($hashref->{$key}),"\n";
	    if(ref($hashref->{$key}) eq "ARRAY") {
		$type{$key}="REF";
		$sizehash{$key}=scalar (@{$hashref->{$key}});
	    } else {
		$type{$key}="HASH";
		$sizehash{$key}=scalar keys(%{$hashref->{$key}});
	    }
	} else {
	    $sizehash{$key}=length(Dumper($hashref->{$key}));
	    $type{$key}="N";
	}
    }

    $str="Keys ans size of $hashref\n";
    foreach $key (sort {$sizehash{$b} <=> $sizehash{$a}} (keys(%sizehash))) {
	$str.=sprintf("%20s=%14d (%s)\n",$key,$sizehash{$key},$type{$key});
    }

    $str.="\n\n";
    $str.="Contents of $hashref\n";
    foreach $key (sort {$sizehash{$b} <=> $sizehash{$a}} (keys(%sizehash))) {
	if($type{$key} eq "N") {
	    $str.=sprintf("%20s=",$key);
	    $str.=Dumper($hashref->{$key});
	    $str.="\n";
	} elsif($type{$key} eq "REF") {
	    $str.=sprintf("%20s=REF\n",$key);
	} elsif($type{$key} eq "HASH") {
	    $str.=sprintf("%20s=(%s)\n",$key,join(",",keys(%{$hashref->{$key}})));
	} else {
	    $str.=sprintf("%20s=unknown\n",$key);
	}
    }

    return($str);
}

sub doExit {
    exit();
}

sub doMainLoop {
    my($self) = shift;

    if($self->{SEARCHSTR}) {
	print "LLview_manage_elements: set search string to $self->{SEARCHSTR}\n";
 	$self->{MAINWIN}->{SEARCHSTR}=$self->{SEARCHSTR};
	$self->{MAINWIN}->updatesearch();
    }

    if($self->{TIMER}!=-1) {
	print "LLview_manage_elements: set end timer to $self->{TIMER} seconds\n";
	$self->{MAINWIN}->{MAIN}->after($self->{TIMER}*1000,\&doExit);
    }



    $self->{MAINWIN}->doMainLoop;
}


1;




