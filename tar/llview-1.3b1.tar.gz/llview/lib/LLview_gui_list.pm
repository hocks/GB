# $Source: /cvs/cvsroot/llview/lib/LLview_gui_list.pm,v $
# $Author: zdv087 $
# $Revision: 1.23 $
# $Date: 2007/07/12 20:49:16 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_list;
use strict;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_gui_list: new %s\n",ref($proto)) if($debug>=3);
    $self->{PARENT}  = -1;
    $self->{VERBOSE} = 0;
    $self->{POSX}    = 480;
    $self->{POSY}    = 50; #50
    $self->{WIDTH}   = 450;
    $self->{HEIGHT}  = 672; # 672
    $self->{LINEHEIGHT} = 14;
    $self->{TOPPAD}     = 20;
    $self->{HEADER_MARKPOS}= [];
    $self->{HEADER_TEXT}   = [];
    $self->{SORT}          = [];
    $self->{HEADER}        = [];
    $self->{SORT_TYPE}    = 1;
    $self->{SORT_ROUTINE} = \&sort_alpha;
    $self->{SORT_DIR}     = "DOWN";
    $self->{SORT_CPOS}    = 1;
    $self->{SORT_MARKER}  = undef;
    $self->{DATAOBJECT}      = "";
    $self->{COLOROBJECT}     = "";
    $self->{BUILDREADY}      = 0;
    $self->{CATEGORY}        = "RUN";
    $self->{FONT1}       = "-*-Courier-Medium-R-Normal--*-100-*-*-*-*-*-*";
    $self->{BFONT1}      = "-*-Courier-Bold-R-Normal--*-100-*-*-*-*-*-*";
#    $self->{FONT1}          = "6x13"; 
#    $self->{BFONT1}          = "6x13bold"; 
    $self->{IDTOYPOS}       = {};
    $self->{MAXYPOS}        = 100;

    $self->{AUTOSCROLL}     = 1;


    $self->{SEARCHSTR}      = "";
    bless $self, $class;
    return $self;
}

sub register_data_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{DATAOBJECT}=$objref;
    return 1;
}

sub register_parent {
    my($self) = shift;
    my($parent) = @_;
    $self->{PARENT}=$parent;
    return 1;
}

sub register_category {
    my($self) = shift;
    my($category) = @_;
    $self->{CATEGORY}=$category;
    return 1;
}

sub register_hash {
    my($self) = shift;
    my($objref) = @_;
    $self->{HASHREF}=$objref;
    return 1;
}

sub register_column {
    my($self) = shift;
    my($cpos,$ckeyname,$cheader_name,$cformatstr,$csort_type,$cwidth,$default,$cut) = @_;

    push(@{$self->{CPOS}},$cpos);
    $self->{CKEYNAME}[$cpos]=$ckeyname;
    $self->{CHEADER_NAME}[$cpos]=$cheader_name;
    $self->{CFORMATSTR}[$cpos]=$cformatstr; 
    $self->{CSORTREF}[$cpos]=\&sort_alpha;
    $self->{CSORTREF}[$cpos]=\&sort_alpha   if($csort_type eq "alpha");
    $self->{CSORTREF}[$cpos]=\&sort_numeric if($csort_type eq "numeric");
    $self->{CSORTREF}[$cpos]=\&sort_tend    if($csort_type eq "tend");
    $self->{CWIDTH}[$cpos]=$cwidth;
    $self->{SORT_CPOS}    = $cpos if($default eq "SORT_DEFAULT");
    if($cut) {$self->{CCUT}[$cpos]=$cut;}
    else     {$self->{CCUT}[$cpos]=-1;}

   return 1;
}

sub register_column_cnt {
    my($self) = shift;
    my($cpos) = @_;

    push(@{$self->{CPOS}},$cpos);
    $self->{CKEYNAME}[$cpos]="__COUNT";
    $self->{CHEADER_NAME}[$cpos]=0;
    $self->{CFORMATSTR}[$cpos]=0; 
    $self->{CSORTREF}[$cpos]=0;
    $self->{CWIDTH}[$cpos]=0;
   return 1;
}

sub register_column_rectangle {
    my($self) = shift;
    my($cpos) = @_;

    push(@{$self->{CPOS}},$cpos);
    $self->{CKEYNAME}[$cpos]="__RECT";
    $self->{CHEADER_NAME}[$cpos]=0;
    $self->{CFORMATSTR}[$cpos]=0; 
    $self->{CSORTREF}[$cpos]=0;
    $self->{CWIDTH}[$cpos]=0;
   return 1;
}

sub register_color_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{COLOROBJECT}=$objref;
    return 1;
}

sub set_searchstr {
    my($self) = shift;
    my($str) = @_;
    $self->{SEARCHSTR}=$str;
    return 1;
}

sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj,$marker)=@_;
    my($i,$name,$cpos,$id);
    my $frames=$dataobj->{FRAMES};

    $optobj->register_option($marker,"POSX", -label => "posx", 
			     -caller => $self, -pack => 1,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option($marker,"POSY", -label => "posy", 
			     -caller => $self, -pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSY}, -step => 10);

    $optobj->register_option($marker,"HEIGHT", -label => "Height", 
			     -caller => $self, -pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option($marker,"WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option($marker,"Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option($marker,"BoldFont", -label => "BoldFont", 
			     -caller => $self, -pack => 1,
			     -type => "string", -default => $self->{BFONT1});

    $optobj->register_option($marker,"LINEHEIGHT", -label => "Lineheight", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 4, -max => 40, -default => $self->{LINEHEIGHT}, -step => 1);

    $optobj->register_option($marker,"AUTOSCROLL", -label => "auto scroll", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{AUTOSCROLL});

#    print "WF: list, create subcanvas with height $self->{HEIGHT} $self->{TOPPAD}\n";
    my $subcanvas = $canvas->Scrolled('Canvas', -scrollbars => 'osoe', -relief => 'sunken', -bd => 0, 
				      -height => $self->{HEIGHT}-$self->{TOPPAD}, -width => $self->{WIDTH},
				      -background => "grey85",-highlightbackground => "grey85");
    my $subwidget = $canvas->createWindow($self->{POSX},$self->{POSY}+$self->{TOPPAD}, -window =>$subcanvas, -anchor => "nw");

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;

    $self->{SUBCANVAS}=$subcanvas;
    $self->{SUBWIDGET}=$subwidget;
    $self->{YSCROLLBAR}=$subcanvas->Subwidget("yscrollbar");
#    $self->BindMouseWheel($subcanvas);

    # bug fix for arranging scrolled height, wrong setting after creating
    $self->{CANVAS}->itemconfigure($self->{SUBWIDGET},-height => $self->{HEIGHT}-$self->{TOPPAD});

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{BUILDREADY}      = 1;    
    return(1);
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($cpos,$posx,$posy,$id);
    # header of job list with sort buttons
    $posx=$self->{POSX}+0; 
    $posy=$self->{POSY};

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

#    $id=$canvas->createRectangle($self->{POSX},$self->{POSY},
#				 $self->{POSX}+$self->{WIDTH},
#				 $self->{POSY}+$self->{HEIGHT},
#				 -fill => "grey60", -tags => ["list"]);
#    push(@{$self->{FIXEDITEMS}},$id);

    foreach $cpos (@{$self->{CPOS}}) {
	if($self->{CKEYNAME}[$cpos] !~"^__") {
	    $id=$canvas->createRectangle($posx,$posy+2,
					 $posx+$self->{CWIDTH}[$cpos],
					 $posy+12+2,
					 -fill => "grey85", -tags => ["list"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	    $self->{HEADER_MARKPOS}[$cpos]=$posx+$self->{CWIDTH}[$cpos]/2;
	    $id=$self->{HEADEROBJ}[$cpos]=$canvas->createText($posx+$self->{CWIDTH}[$cpos]/2,$posy+2,
							      -text => $self->{CHEADER_NAME}[$cpos], 
							      -font => $self->{BFONT1},
							      , -anchor => 'n');
	    $canvas->bind($self->{HEADEROBJ}[$cpos],'<ButtonPress-1>' => [ \&change_sort, $cpos, $self ]);
	    push(@{$self->{FIXEDITEMS}},$id);
	    $posx+=$self->{CWIDTH}[$cpos];
	} else {
	    $posx+=25 if($self->{CKEYNAME}[$cpos] eq "__COUNT");
	    $posx+=20 if($self->{CKEYNAME}[$cpos] eq "__RECT");
	}
    }
#    print "WF: ref->=",ref($self->{CSORTREF}[1]),"\n";
    $self->{SORT_ROUTINE}=$self->{CSORTREF}[$self->{SORT_CPOS}];
    $self->{SORT_DIR}="DOWN";
    $self->set_marker($canvas,$self->{SORT_CPOS},$self->{SORT_DIR});

#    $self->{JOBHEADER_MARKPOS}->{"CPU"}=-7;
#    $self->{JOBHEADER_TEXT}->{"CPU"}="CPU";
#    $self->{JOBSORT}->{"CPU"}{"UP"}=\&sort_jobs_cpu_up;
#    $self->{JOBSORT}->{"CPU"}{"DOWN"}=\&sort_jobs_cpu_down;
#    $self->{JOBHEADER}->{"CPU"}=$canvas->createText($posx-7,$posy,-text => $self->{JOBHEADER_TEXT}->{"CPU"}, -font => $self->{BFONT1});
#    $canvas->bind($self->{JOBHEADER}->{"CPU"},'<ButtonPress-1>' => [ \&change_jobsort, "CPU", $self ]);


}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my $subcanvas=$self->{SUBCANVAS};
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
    while ($id=shift(@{$self->{SUBITEMS}})) {
	$subcanvas->delete($id);
    }

    foreach $id (keys(%{$self->{IDTOYPOS}})) {
	delete($self->{IDTOYPOS}->{$id});
    }

}


sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($key,$nr,$num,$color,$mark,$text,$id);
    my($str,$cpos);
    my $subcanvas=$self->{SUBCANVAS};
    my $posx=0; 
    my $posy=15;
    my $tcolor;
    my $loginname=getlogin();
    $num=0;

    $self->clean($dataobj,$colorobj,$canvas);
    
    foreach $key (sort {&{$self->{SORT_ROUTINE}}($self)} keys(%{$self->{HASHREF}})) {
	$posx=0;
	$num++;
	$str="";
	$nr=-1;
	foreach $cpos (@{$self->{CPOS}}) {
#	    $str.=$self->{HASHREF}->{$self->{CKEYNAME}[$cpos]};
	    if($self->{CKEYNAME}[$cpos] !~"^__") {
		$str.=" " if($str ne "");
		if($self->{CCUT}[$cpos]!=-1) {
		    $str.=sprintf($self->{CFORMATSTR}[$cpos],
				  substr($self->{HASHREF}->{$key}->{$self->{CKEYNAME}[$cpos]},0,$self->{CCUT}[$cpos])
				  );
		} else {
		    $str.=sprintf($self->{CFORMATSTR}[$cpos],$self->{HASHREF}->{$key}->{$self->{CKEYNAME}[$cpos]});
		}

	    } else {
		$str.=sprintf("%3d.",$num) if($self->{CKEYNAME}[$cpos] eq "__COUNT");
		$posx+=20 if($self->{CKEYNAME}[$cpos] eq "__RECT");
	    }
	}
	if($self->{CKEYNAME}[$cpos] eq "__RECT") {
	    $color=$colorobj->get_color($self->{CATEGORY},$key);
	    $nr=$colorobj->idtonr($self->{CATEGORY},$key);
	    $id=$subcanvas->createRectangle($posx-15,$posy-3,$posx-5,$posy-13, -fill => $color, -tags => ["T${nr}R"]);
	    push(@{$self->{SUBITEMS}},$id);

	}

	$tcolor="black";
	if($self->{SEARCHSTR}) {
	    $tcolor="blue" if ($str=~/$self->{SEARCHSTR}/);
	}
	$self->{IDTOYPOS}->{$key}=$posy-$self->{LINEHEIGHT};

	$id=$subcanvas->createRectangle($posx,$posy,$posx+$self->{WIDTH}*0.9,$posy-$self->{LINEHEIGHT}-2, 
					-width => 1, 
					-fill => "grey85",
					-outline => "grey85",
					-tags => ["T${nr}F"]);
	push(@{$self->{SUBITEMS}},$id);
	$id=$subcanvas->createText($posx,$posy,-text => $str, -anchor => 'sw', -font => $self->{FONT1},-tags => ["T${nr}B"], 
				   -fill => $tcolor);
	push(@{$self->{SUBITEMS}},$id);

#	print "WF: >$str<\n";
	$posy+=$self->{LINEHEIGHT};
    }
    $self->{MAXYPOS}=$posy;

    if($num==0) {
	# no entry
	$id=$subcanvas->createText($posx,$posy,-text => "<no jobs>", -anchor => 'sw', -font => $self->{FONT1},-fill => $tcolor);
	push(@{$self->{SUBITEMS}},$id);
    } else {
	$subcanvas->configure(-scrollregion => [ $subcanvas->bbox("all") ]);
    }

    return();
}

sub change_sort {
    my($canvas, $cpos, $self)=@_;
#    print "WF: change_sort >",ref($self),"<\n" if($debug>=3);

    if($cpos != $self->{SORT_CPOS}) {
	$self->{SORT_CPOS}=$cpos;
	$self->{SORT_DIR} ="UP";
    } else {
	if($self->{SORT_DIR} eq "DOWN") {
	    $self->{SORT_DIR} ="UP";
	} else {
	    $self->{SORT_DIR} ="DOWN";
	}
    }
    $self->{SORT_ROUTINE}=$self->{CSORTREF}[$cpos];
    print "change_sort: $cpos -> ",$self->{CHEADER_NAME}[$cpos],",",$self->{SORT_DIR}," ref:",ref($self->{SORT_ROUTINE}),"\n" if($debug>=3);
    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
    $self->set_marker($canvas,$self->{SORT_CPOS},$self->{SORT_DIR});
    return();
}

sub set_marker {
    my($self) = shift;
    my ($canvas,$cpos,$dir)=@_;
    my $posx=$self->{HEADER_MARKPOS}[$cpos]; 
    my $posy=$self->{POSY}+20;

#    print "WF: cpos=$cpos set_marker at $posx,$posy\n";
    if($self->{SORT_MARKER}) {
	$canvas->delete($self->{SORT_MARKER});
    }
    if($dir eq "UP") {
	$self->{SORT_MARKER}=$canvas->createPolygon($posx-6,$posy-2,
						    $posx+6,$posy-2,
						    $posx,$posy-8,
						    $posx-6,$posy-2);
    } else {
	$self->{SORT_MARKER}=$canvas->createPolygon($posx-5,$posy-5,
						    $posx+5,$posy-5,
						    $posx,$posy,
						    $posx-5,$posy-5);
    }
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diff,$id);
    print "list_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY})\n" if($self->{VERBOSE});
    if ($name eq "Font") {
	$self->{FONT1}=$val;
	$self->{PARENT}->{FONT1}  = $self->{FONT1}; # needed for highlighting
    } elsif ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
	$self->{PARENT}->{BFONT1}  = $self->{BFONT1}; # needed for highlighting
    } else {
	$self->{$name}=$val;
    }

    if ( ($name eq "POSX") || ($name eq "POSY") ) {
	$diff=$val-$self->{$name};
	$self->{$name}=$val;
	$self->{CANVAS}->coords($self->{SUBWIDGET},$self->{POSX},$self->{POSY}+$self->{TOPPAD})  if ($self->{BUILDREADY});
    }
    if($name eq "HEIGHT") {
	$self->{$name}=$val;
	$self->{CANVAS}->itemconfigure($self->{SUBWIDGET},-height => $self->{HEIGHT}-$self->{TOPPAD}) if ($self->{BUILDREADY});
    }
    if($name eq "WIDTH") {
	$self->{$name}=$val;
	$self->{CANVAS}->itemconfigure($self->{SUBWIDGET},-width => $self->{WIDTH})  if ($self->{BUILDREADY});
    }


    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
 
}

sub sort_alpha   {    
    my($self)=@_;
    my $ckeyname=$self->{CKEYNAME}[$self->{SORT_CPOS}];
    my $aa=$self->{HASHREF}->{$a}->{$ckeyname};
    my $bb=$self->{HASHREF}->{$b}->{$ckeyname};
    if($self->{SORT_DIR} eq "UP") {
	return($aa cmp $bb);
    } else {
	return($bb cmp $aa);
    }
}

sub sort_numeric   {    
    my($self)=@_;
    my $ckeyname=$self->{CKEYNAME}[$self->{SORT_CPOS}];
    my $aa=$self->{HASHREF}->{$a}->{$ckeyname};
    my $bb=$self->{HASHREF}->{$b}->{$ckeyname};
    if($self->{SORT_DIR} eq "UP") {
	return($aa <=> $bb);
    } else {
	return($bb <=> $aa);
    }
}

sub sort_tend   {    
    my($self)=@_;
    my $ckeyname="FL_RESTSEC";
    my $aa=$self->{HASHREF}->{$a}->{$ckeyname};
    my $bb=$self->{HASHREF}->{$b}->{$ckeyname};
    if($self->{SORT_DIR} eq "UP") {
	return($aa <=> $bb);
    } else {
	return($bb <=> $aa);
    }
}

sub scroll_to {
    my($self) = shift;
    my($jobid) = shift;
    my($fraction,$ymin,$ymax);
#    $self->{SUBCANVAS};
    return if(!$self->{AUTOSCROLL});
    $fraction=$self->{IDTOYPOS}->{$jobid}/$self->{MAXYPOS};
    ($ymin,$ymax)=$self->{YSCROLLBAR}->get();
#    printf( "joblist: scroll to id: %s --> %8.4f %f %f\n",$jobid,$fraction,$ymin,$ymax);
    if($fraction<$ymin) {
	$self->{SUBCANVAS}->yviewMoveto($fraction);
    } 
    if($fraction>$ymax) {
	my $newval=$ymin-($fraction-$ymax);
	$newval=0 if $newval<0;
	$self->{SUBCANVAS}->yviewMoveto($fraction);
    } 
}

sub BindMouseWheel {
     my($self) = shift;
     my($w) = @_;
 
     if ($^O eq 'MSWin32') {
	 $w->bind('<MouseWheel>' =>
		  [ sub { $_[0]->yview('scroll', -($_[1] / 120) * 3, 'units') },
		    Ev('D') ]
		  );
     } else {
	 
       # Support for mousewheels on Linux commonly comes through
       # mapping the wheel to buttons 4 and 5.  If you have a
       # mousewheel ensure that the mouse protocol is set to
       # "IMPS/2" in your /etc/X11/XF86Config (or XF86Config-4)
       # file:
       #
       # Section "InputDevice"
       #     Identifier  "Mouse0"
       #     Driver      "mouse"
       #     Option      "Device" "/dev/mouse"
       #     Option      "Protocol" "IMPS/2"
       #     Option      "Emulate3Buttons" "off"
       #     Option      "ZAxisMapping" "4 5"
       # EndSection
	 
	 $w->bind('<4>' => sub {
	     $_[0]->yview('scroll', -3, 'units') unless $Tk::strictMotif;
	 });
 
	 $w->bind('<5>' => sub {
	     $_[0]->yview('scroll', +3, 'units') unless $Tk::strictMotif;
	 });
    }
 
} # end BindMouseWheel


1;
