# $Source: /cvs/cvsroot/llview/lib/LLview_parse_xml.pm,v $
# $Author: zdv087 $
# $Revision: 1.75 $
# $Date: 2007/06/05 17:35:19 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2005, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_parse_xml;
use LLview_analyse;
use Time::Local;
use Lite;
use Data::Dumper;
use Time::HiRes qw ( time );
my($debug)=0;
use strict;


my @hex = ("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
my %hextod = ("0" => 0,"1" => 1,"2" => 2,"3" => 3,"4" => 4,"5" => 5,"6" => 6,"7" => 7,
	      "8" => 8,"9" => 9,"A" => 10,"B" => 11,"C" => 12,"D" => 13,"E" => 14,"F" => 15);

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_parse_xml: new %s\n",ref($proto)) if($debug>=3);
    $self->{TIMESTR}      = "<null>";
    $self->{RUNNING}      = "<no running jobs>";
    $self->{MACHINFO}     = "<no machine info>";
    $self->{RUNNINGDATA}  = {};
    $self->{PROCSTATE}    = [];
    $self->{NODES}        = {};
    $self->{NODESTATE}    = [];
    $self->{QUEUESTATE}   = {};
    $self->{PARTITION}    = {};
    $self->{CLASSPRIO}    = {"tt" => 2};
    $self->{ACTNODENR}    = -1;
    $self->{ACTQUEUENAME} = "-";
    $self->{FRAMES}       = 0;
    $self->{LLNUMRJOBS}      = 0;
    $self->{LLNUMWJOBS}      = 0;
    $self->{LLNODES}      = 0;
    $self->{LLCPUS}       = 0; # all cpus, not down 
    $self->{ALLCPUS}      = 0; # all cpus, incl. down nodes 
    $self->{LLUSEDCPUS}   = 0; # all used cpus
    $self->{LLOVERALLCPUS}= 0; # all used cpus, incl. cpus on not shared nodes

    $self->{SELECTNODES}   = ".*";
    $self->{SELECTUID}     = ".*";
    $self->{DEMOVERSION}   = 0;

    $self->{DEFAULTINFO}  = "<no default info>";
    $self->{FREEINFO}     = "<no info about free cpus>";

    $self->{LASTSIZE}     = 0;
    $self->{SIZEINFO}     = {};
    $self->{SIZEINFOC}    = {};

    $self->{SORTNODEMODE} = 0;

    $self->{PARSERVERSION} = 1; # 0 -> own 1 -> XML parser

    $self->{ANALYSE}    = LLview_analyse->new();
    $self->{ANALYSEDONEFORSTEP}=0;

    bless $self, $class;
    return $self;

}


sub parse_data {
    my($self) = shift;
    my($xml)=@_;
    my ($id,$p,$key,$jobid,$i,$n,$node,$tstart,$tdiff,$nbytes);

    return(0) if($xml!~/<\/system>\s*$/s);

    $self->{NODESTATE}=[];

    $self->printsize("parse_data: start") if($debug==5);

    foreach $id (keys(%{$self->{NODES}}))       {	delete($self->{NODES}->{$id});          }
    foreach $id (keys(%{$self->{MACHSTATE}}))   {	delete($self->{MACHSTATE}->{$id});      }
    foreach $id (keys(%{$self->{QUEUESTATE}}))  {	delete($self->{QUEUESTATE}->{$id});     }
    foreach $id (keys(%{$self->{PARTITION}}))   {	delete($self->{PARTITION}->{$id});      }
    foreach $id (keys(%{$self->{RESERVATION}})) {	delete($self->{RESERVATION}->{$id});    }
    foreach $id (keys(%{$self->{JOBSTATE}}))    {	delete($self->{JOBSTATE}->{$id});       }
    foreach $id (keys(%{$self->{WAITINGJOBS}})) {	delete($self->{WAITINGJOBS}->{$id});    }
    foreach $id (keys(%{$self->{RUNNINGJOBS}})) {	delete($self->{RUNNINGJOBS}->{$id});    }
    foreach $id (keys(%{$self->{RUNNINGDATA}})) {	delete($self->{RUNNINGDATA}->{$id});    }
    foreach $id (keys(%{$self->{USAGE}}))       {	delete($self->{USAGE}->{$id});    }
    foreach $id (keys(%{$self->{CLASSES}}))     {	delete($self->{CLASSES}->{$id});    }

    # fix xml problem
    $xml=~s/job_name="<jobname>"/job_name="jobname"/gs;
    $nbytes=length($xml);

    $tstart=time;
    if($self->{PARSERVERSION}==1)  {
	$p = new XML::Parser::Lite(Style => 'Debug');
	$p->setHandlers(
			Start => sub { my $slite=shift; &xml_start($slite,$self,@_) },
			End => sub { my $slite=shift; &xml_end($slite,$self,@_) },
			);
	$p->parse($xml);
    } else {

	# light-weight self written xml parser, only working for simple XML files  
	$xml=~s/\n/ /gs;
	$xml=~s/\s\s+/ /gs;
	my ($tag,$tagname,$rest,$ctag,$nrc);
	foreach $tag (split(/\>\s*/,$xml)) {
	    $ctag.=$tag;
	    $nrc=($ctag=~ tr/\"/\"/);
	    if($nrc%2==0) {
		$tag=$ctag;
		$ctag="";
	    } else {
		next;
	    }
	
	    next if($tag=~/^<[\/\?]/);
	    if($tag=~/<([^\s]+)(\s(.*)\s)?\/?/) {
		$tagname=$1;
		$rest=$2;$rest=~s/^\s*//gs;$rest=~s/\s*$//gs;
#	    print "TAG: '$tagname' '$rest'\n";
		$self->xml_start($self,$tagname,split(/=?\"\s*/,$rest));
	    }
	}
    }
    $tdiff=time-$tstart;
    printf("llview: parse XML data (%9d bytes) in %10.4f sec\n",$nbytes,$tdiff) if($self->{VERBOSE});

    $self->{TIMESTR}=$self->{MACHSTATE}->{"system_time"};
    $i=0;
#    foreach $id (keys(%{$self->{JOBSTATE}}))    {	
#	printf("%2d: %12s -> %12s %12s %22s %22s %s\n",$i,$id,$self->{JOBSTATE}->{$id}{"job_type"},
#	                                     $self->{JOBSTATE}->{$id}{"job_queue"},
#	                                     $self->{JOBSTATE}->{$id}{"job_dispatchdate"},
#	                                     $self->{JOBSTATE}->{$id}{"job_queuedate"},
#	       $self->{CLASSPRIO}->{$self->{JOBSTATE}->{$id}{"job_queue"}}
#	       );
#	$i++;
#    }

    if($self->{SELECTNODES} ne ".*") {
	my ($jobstep,$spec,$num);
	print "WF: scanning nodes: regexp='$self->{SELECTNODES}'\n";
	foreach $node (keys(%{$self->{NODES}}))   {
	    if($node!~/$self->{SELECTNODES}/) {
		delete($self->{NODES}->{$node});
	    }	
	}
	foreach $jobstep  (keys(%{$self->{RUNNINGJOBS}})) {
	    my $remove=0;
	    if($self->{JOBSTATE}->{$jobstep}{"job_type"} eq "running") {
		my $nodelist=$self->{JOBSTATE}->{$jobstep}{"job_nodelist"};
		foreach $spec (split(/\),?\(/,$nodelist)) {
		    $spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;
		    $remove=1 if ($node!~/$self->{SELECTNODES}/);
		}
	    }
	    if($remove) {
		delete($self->{JOBSTATE}->{$jobstep});
		delete($self->{RUNNINGJOBS}->{$jobstep});
	    }
	}
    }
    if($self->{SELECTUID} ne ".*") {
	my($jobstep);
#	print "WF: scanning waiting jobs: regexp='$self->{SELECTUID}'\n";
	foreach $jobstep (keys(%{$self->{WAITINGJOBS}})) {	
	    my $remove=0;
	    if($self->{SELECTUID}=~/^[\^]/) {
		my $pattern=substr($self->{SELECTUID},1);
		$remove=$self->{JOBSTATE}->{$jobstep}->{'job_owner'}=~/$pattern/;
	    } else {
		$remove=$self->{JOBSTATE}->{$jobstep}->{'job_owner'}!~/$self->{SELECTUID}/;
	    }
	    if($remove) {
		delete($self->{JOBSTATE}->{$jobstep});
		delete($self->{WAITINGJOBS}->{$jobstep});    
	    }
	}
	foreach $jobstep (keys(%{$self->{RUNNINGJOBS}})) {	
	    my $remove=0;
	    if($self->{SELECTUID}=~/^[\^]/) {
		my $pattern=substr($self->{SELECTUID},1);
		$remove=$self->{JOBSTATE}->{$jobstep}->{'job_owner'}=~/$pattern/;
	    } else {
		$remove=$self->{JOBSTATE}->{$jobstep}->{'job_owner'}!~/$self->{SELECTUID}/;
	    }

	    if($remove) {
#		print "WF: deleting $jobstep\n";
		delete($self->{JOBSTATE}->{$jobstep});
		delete($self->{RUNNINGJOBS}->{$jobstep});    
	    }
	}
	
    }
    $self->printsize("parse_data: after parse") if($debug==5);

    $self->patch();
#    print "WF: after patch \n";
    $self->printsize("parse_data: after patch") if($debug==5);
    
    $self->generate_runningdata();
    $self->printsize("parse_data: after runningdata") if($debug==5);
#    print "WF: after running \n";

    $self->generate_nodedata();
    $self->printsize("parse_data: after nodedata") if($debug==5);
#    print "WF: after genodedata \n";

    $self->generate_info();
    $self->printsize("parse_data: after generate_info") if($debug==5);
#    print "WF: after info \n";


    $self->{LLNUMRJOBS}= scalar keys(%{$self->{RUNNINGJOBS}});

    $self->{LLNUMWJOBS}=0;
    foreach my $jobstep (keys(%{$self->{WAITINGJOBS}})) {	
	next if($self->{JOBSTATE}->{$jobstep}{"job_statuslong"} eq "HOLD");
	next if($self->{JOBSTATE}->{$jobstep}{"job_statuslong"} eq "REMOVED");
	
	$self->{LLNUMWJOBS}++;
    }
#    print "WF: $self->{LLNUMRJOBS} , $self->{LLNUMWJOBS}\n";


    $self->{ANALYSEDONEFORSTEP}=0;

    my $help=$self->{TIMESTR};
#    $help=~s/\ /_/gs;
#    $help=~s/\//_/gs;
#    open(OUT,"> data.dump_$help");
#    print OUT $xml;
#    print OUT Dumper($self);
#    close(OUT);
#    print "WF: after all $self->{TIMESTR} $self->{FRAMES}\n";
    return(1);
}

sub xml_start {
    my $self=shift; # object reference
    my $o   =shift;
    my $name=shift;
#    print "WF:",ref($o),"<\n";
    my($k,$actnodename);
    my %attr=(@_);

    if($name eq "system") {
	foreach $k (sort keys %attr) {
#	    print "$k: $attr{$k}\n";
	    $o->{MACHSTATE}->{$k}=$attr{$k};
	}

    } elsif($name eq "node") {
	$actnodename=$attr{"node_name"};
	$o->{ACTNODENAME}=$actnodename;
	if(defined($o->{ACTNODENR})) {
	    foreach $k (sort keys %attr) {
#		print "'$k': $attr{$k}\n";
		$o->{NODES}->{$o->{ACTNODENAME}}->{$k}=$attr{$k};
		}
	}
    } elsif($name eq "mem") {
	foreach $k (sort keys %attr) {
	    $o->{NODES}->{$o->{ACTNODENAME}}->{$k}=$attr{$k};
	}
    } elsif($name eq "cpu") {
	foreach $k (sort keys %attr) {
	    $o->{NODES}->{$o->{ACTNODENAME}}->{$k}=$attr{$k};
	}
    } elsif($name eq "load") {
	foreach $k (sort keys %attr) {
	    $o->{NODES}->{$o->{ACTNODENAME}}->{$k}=$attr{$k};
	}

    } elsif($name eq "queue") {
	$o->{ACTQUEUENAME}=$attr{"queue_name"};
	if(defined($o->{ACTQUEUENAME})) {
	    foreach $k (sort keys %attr) {
		$o->{QUEUESTATE}->{$o->{ACTQUEUENAME}}{$k}=$attr{$k};
	    }
	}
    } elsif($name eq "partition") {
	$o->{ACTPARTITION}=$attr{"part_name"};
	if(defined($o->{ACTPARTITION})) {
	    foreach $k (sort keys %attr) {
		$o->{PARTITION}->{$o->{ACTPARTITION}}{$k}=$attr{$k};
	    }
	}
    } elsif($name eq "reservation") {
	$o->{ACTRESERVATION}=$attr{"resid"};
	if(defined($o->{ACTRESERVATION})) {
	    foreach $k (sort keys %attr) {
		$o->{RESERVATION}->{$o->{ACTRESERVATION}}{$k}=$attr{$k};
	    }
	}
    } elsif($name eq "usage") {
	foreach $k (sort keys %attr) {
#	    print "$k: $attr{$k}\n";
	    $o->{USAGE}->{$k}=$attr{$k};
	}
    }
    elsif($name eq "classes") {
	foreach $k (sort keys %attr) {
#	    print "$k: $attr{$k}\n";
	    $o->{CLASSES}->{$k}=$attr{$k};
	}
    } elsif($name eq "running") {
	foreach $k (sort keys %attr) {
	    $o->{QUEUESTATE}->{$o->{ACTQUEUENAME}}{$k}=$attr{$k};
	}
    } elsif($name eq "waiting") {
	foreach $k (sort keys %attr) {
	    $o->{QUEUESTATE}->{$o->{ACTQUEUENAME}}{$k}=$attr{$k};
	}

    } elsif($name eq "job") {
	my $jobstep=$attr{"job_step"};
	my $jobnodelist=$attr{"job_nodelist"};
	my $jobqdate=$attr{"job_queuedate"};
	my $jobddate=$attr{"job_dispatchdate"};
	my $jobqueue=$attr{"job_queue"};

	if(exists($o->{JOBSTATE}->{$jobstep})) {
	    # on Blue Gene possible, if error jobs on partition
	    $jobstep.="_".$attr{"job_name"}; # extending jobstep to unique id
	}
	if (!exists($o->{CLASSPRIO}->{$jobqueue})) {
	    printf("LLview_parse_xml: new class: %s\n",$jobqueue);
#	    print "WF:",(sort {$a <=> $b} (values(%{$o->{CLASSPRIO}}))),"\n";
	    $o->{CLASSPRIO}->{$jobqueue}= (sort {$a <=> $b} (values(%{$o->{CLASSPRIO}})))[0]-1;
	}
	if(($jobnodelist eq "-") || ($jobnodelist eq "")) {
	    $o->{JOBSTATE}->{$jobstep}{"job_type"}="waiting";
	    $o->{WAITINGJOBS}->{$jobstep}=$jobqdate;
#	    foreach $k (sort keys %attr) {
#		print "$jobstep: >$k< ",$attr{$k},"\n";
#	    }
	} else {
	    $o->{JOBSTATE}->{$jobstep}{"job_type"}="running";
	    $o->{RUNNINGJOBS}->{$jobstep}=$jobddate;
#	    print "$jobstep: set running >$jobnodelist<\n";
	}
	if((defined($jobstep)) && (defined($jobnodelist))) {
	    foreach $k (sort keys %attr) {
#		print "$k: $attr{$k}\n";
		$o->{JOBSTATE}->{$jobstep}{$k}=$attr{$k};
	    }
	}

    } else {
	print "Lstat:XML:Parser: WARNING unknown tag $name\n";
    }
}

sub xml_end {
    my $self=shift; # object reference
    my $name=shift;
}

sub sort_jobs_class_date   {    
    my($self) = shift;
#    print "WF: $a,$b",$self->{JOBSTATE}->{$a}{"job_type"}," ",$self->{JOBSTATE}->{$b}{"job_type"},"\n";
    if($self->{JOBSTATE}->{$a}{"job_type"} eq $self->{JOBSTATE}->{$b}{"job_type"}) {
	if($self->{JOBSTATE}->{$a}{"job_queue"} eq $self->{JOBSTATE}->{$b}{"job_queue"}) {
	    if($self->{JOBSTATE}->{$a}{"job_type"} eq "running") {
		&date_to_sec($self->{JOBSTATE}->{$a}{"job_dispatchdate"}) <=> 
		    &date_to_sec($self->{JOBSTATE}->{$b}{"job_dispatchdate"});
	    } else {
		&date_to_sec($self->{JOBSTATE}->{$a}{"job_queuedate"}) <=>  
		    &date_to_sec($self->{JOBSTATE}->{$b}{"job_queuedate"});
	    }
	} else {
	    $self->{CLASSPRIO}->{$self->{JOBSTATE}->{$b}{"job_queue"}} <=> $self->{CLASSPRIO}->{$self->{JOBSTATE}->{$a}{"job_queue"}};
	}

    } else {
	$self->{JOBSTATE}->{$a}{"job_type"} cmp $self->{JOBSTATE}->{$b}{"job_type"};
    }
}

sub generate_info  {
    my($self)=shift;
    my($running,$waiting,$machinfo,$wnum,$rnum);
    my($lastqueue,$jobstep,$queue,$shared,$unicore,$str);
    
    $self->{MACHINFO}=sprintf("Machine: %s \n  Memory: %s, #cpus: %s, \n  speed=%s type=%s,\n  #frames: %s, peak=%s \n  type=%s\n",
				$self->{MACHSTATE}->{"system_name"},
				$self->{MACHSTATE}->{"system_mem"},
				$self->{MACHSTATE}->{"system_cpucount"},
				$self->{MACHSTATE}->{"system_cpuspeed"},
				$self->{MACHSTATE}->{"system_cputype"},
				$self->{MACHSTATE}->{"system_frames"},
				$self->{MACHSTATE}->{"system_perform"},
				$self->{MACHSTATE}->{"system_type"}
				);
    $self->{MACHINFO}.=sprintf("Date/Time:    %s\nUsable Nodes: %2d",$self->{MACHSTATE}->{"system_time"},
			       $self->{LLNODES});
    $self->{DEFAULTINFO}=$self->{MACHINFO};
    return(1);
}

# only for first 10 waiting jobs in nodes oject 
sub analyse_data  {
    my($self)=shift;
    $self->{ANALYSE}->update($self) if(!$self->{ANALYSEDONEFORSTEP});
    $self->{ANALYSEDONEFORSTEP}=1;
}

sub patch  {
    my($self)=shift;
    my $rnum=0;
    my($jobstep);
    my(%userlist,$demoidcnt,$demoid,$partition,$reservation);
    printf("LLview_parse_xml: patch, checking data\n") if($debug==3);

    print "WF: demoversion ->  $self->{DEMOVERSION}\n" if($debug==3); 
    if($self->{DEMOVERSION}) {
	$demoidcnt=0;
	foreach $jobstep  (keys(%{$self->{JOBSTATE}})) {
	    my $user=$self->{JOBSTATE}->{$jobstep}{"job_owner"};
	    if($userlist{$user}) { $demoid=$userlist{$user};} 
	    else                 { $demoid=$userlist{$user}=sprintf("User#%03d",$demoidcnt++);}
	    $self->{JOBSTATE}->{$jobstep}{"job_owner"}=$demoid;
	    print "WF: demouser ->  $user $demoid (job)\n" if($debug==3); 
	}
	foreach $partition  (keys(%{$self->{PARTITION}})) {
	    my $user=$self->{PARTITION}->{$partition}{"part_owner"};
	    if($userlist{$user}) { $demoid=$userlist{$user};} 
	    else                 { $demoid=$userlist{$user}=sprintf("User#%03d",$demoidcnt++);}
	    $self->{PARTITION}->{$partition}{"part_owner"}=$demoid;
	    print "WF: demouser ->  $user $demoid (partition)\n" if($debug==3); 
	}
	foreach $reservation  (keys(%{$self->{RESERVATION}})) {
	    my $user=$self->{RESERVATION}->{$reservation}{"user"};
	    if($userlist{$user}) { $demoid=$userlist{$user};} 
	    else                 { $demoid=$userlist{$user}=sprintf("User#%03d",$demoidcnt++);}
	    $self->{RESERVATION}->{$reservation}{"user"}=$demoid;
	    print "WF: demouser ->  $user $demoid (reservation)\n" if($debug==3); 
	}
    }

    # scan for waiting jobs with taskspernode > nodesize
    if(0) { 
	my($node,$jobstep);
	my $maxnodesize=0;
	foreach $node (keys(%{$self->{NODES}})) {
	    $maxnodesize=$self->{NODES}->{$node}->{"cpu_total"} if($maxnodesize<$self->{NODES}->{$node}->{"cpu_total"});
	 }
 	foreach $jobstep (keys(%{$self->{WAITINGJOBS}})) {	
	    if (($self->{JOBSTATE}->{$jobstep}{"job_nummachines"}==1) && 
		($self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}>$maxnodesize)) {
		print "patch: fix job $jobstep: ",$self->{JOBSTATE}->{$jobstep}{"job_nummachines"},"x",
		$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"},"->";
		if($self->{JOBSTATE}->{$jobstep}{"job_taskspernode"} % $maxnodesize==0) {
		    $self->{JOBSTATE}->{$jobstep}{"job_nummachines"}=
			$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}/$maxnodesize;
		} else {
		    $self->{JOBSTATE}->{$jobstep}{"job_nummachines"}=
			int($self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}/$maxnodesize)+1;
		}
		$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}=$maxnodesize;
		print $self->{JOBSTATE}->{$jobstep}{"job_nummachines"},"x",
		$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"},"\n";
	    }
	}

    }

    # scan for running jobs with job_dispatchdate not set, hack
    { 
	foreach $jobstep (keys(%{$self->{RUNNINGJOBS}})) {	
	    $self->{JOBSTATE}->{$jobstep}{"job_dispatchdate"}=$self->{MACHSTATE}->{"system_time"} 
	    if($self->{JOBSTATE}->{$jobstep}{"job_dispatchdate"} eq "-");
	}
    }


    # scan for waiting jobs with job_nummachines="-" not set
    { 
	foreach $jobstep (keys(%{$self->{WAITINGJOBS}})) {	
	    $self->{JOBSTATE}->{$jobstep}{"job_nummachines"}="1" if $self->{JOBSTATE}->{$jobstep}{"job_nummachines"} eq "-";
	    $self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}="1" if $self->{JOBSTATE}->{$jobstep}{"job_taskspernode"} eq "-";
	}
    }

    # scan for running jobs with corresponding reservation (BGL) and adjust end time of job
    if(0) 
    { 
	my($node,$jobstep,%res_ets);
	foreach $reservation  (keys(%{$self->{RESERVATION}})) {
	    next if($self->{RESERVATION}->{$reservation}{"user"} eq "loadl");
	    my $res_st=$self->{RESERVATION}->{$reservation}{"starttime"};
	    my $res_et=$self->{RESERVATION}->{$reservation}{"endtime"};
	    if(&timediff($res_st,$self->{MACHSTATE}->{"system_time"})<0) {
		my $firstnode=(split(/,/,$self->{RESERVATION}->{$reservation}{"nodelist"}))[0];
#		print "WF: found running reservation $reservation st=$res_st et=$res_et $firstnode\n";
		$res_ets{$firstnode}=$res_et;
	    }
	}
	foreach $jobstep (keys(%{$self->{RUNNINGJOBS}})) {	
	    my $firstnode=(split(/,/,$self->{JOBSTATE}->{$jobstep}{"job_nodelist"}))[0];
	    $firstnode=~s/^\(//gs;
	    if($res_ets{$firstnode}) {
		print "WF: found running job $jobstep  $firstnode $res_ets{$firstnode} wall ",
		$self->{JOBSTATE}->{$jobstep}{"job_wall"}/3600,"->";
		# WF bugfix: additional marge of 180 
		$self->{JOBSTATE}->{$jobstep}{"job_wall"}=timediff($res_ets{$firstnode},
								   $self->{JOBSTATE}->{$jobstep}{"job_dispatchdate"})-180;
		print $self->{JOBSTATE}->{$jobstep}{"job_wall"}/3600,"\n";
		$self->{JOBSTATE}->{$jobstep}{"job_enddate"}=$res_ets{$firstnode};
	    }
	}

    }
    return();
}


sub generate_runningdata  {
    my($self)=shift;
    my $rnum=0;
    my($jobstep,$shared,$unicore,$restart);
    foreach $jobstep  (sort {sort_jobs_node($self)} (keys(%{$self->{RUNNINGJOBS}}))) {
	if($self->{JOBSTATE}->{$jobstep}{"job_type"} eq "running") {
#	    print "AA: $jobstep\n";
	    $rnum++;
	    $shared=($self->{JOBSTATE}->{$jobstep}{"job_node_usage"}=~/NOT_SHARED/)?"no":"yes";
	    $unicore=($self->{JOBSTATE}->{$jobstep}{"job_comment"}=~/NOT\s?Unicore/)?" ":"U";
	    $restart=($self->{JOBSTATE}->{$jobstep}{"job_restart"}=~/yes/)?"Y":"N";
	    $self->{RUNNINGDATA}->{$jobstep}{FL_JOBID}       =$jobstep;
	    $self->{RUNNINGDATA}->{$jobstep}{FL_JOBNAME}     =$self->{JOBSTATE}->{$jobstep}{"job_name"};
	    $self->{RUNNINGDATA}->{$jobstep}{FL_TASKEXEC}    =$self->{JOBSTATE}->{$jobstep}{"job_taskexec"};
	    $self->{RUNNINGDATA}->{$jobstep}{FL_USER}        =$self->{JOBSTATE}->{$jobstep}{"job_owner"};
	    $self->{RUNNINGDATA}->{$jobstep}{FL_DISPATCH}    =$self->{JOBSTATE}->{$jobstep}{"job_dispatchdate"};
	    $self->{JOBSTATE}->{$jobstep}{"job_wall"}=0 if(!$self->{JOBSTATE}->{$jobstep}{"job_wall"});
	    $self->{RUNNINGDATA}->{$jobstep}{FL_WALL}        =sprintf("%2d:%02d",int($self->{JOBSTATE}->{$jobstep}{"job_wall"}/3600),
							     $self->{JOBSTATE}->{$jobstep}{"job_wall"}/60-
							     (int($self->{JOBSTATE}->{$jobstep}{"job_wall"}/3600)*60));
#	    print "WF: fehler at $jobstep".$self->{MACHSTATE}->{"system_time"}."::".."\n";
	    $self->{RUNNINGDATA}->{$jobstep}{FL_USEDH}       =sprintf("%3.1f",
							      &timediff($self->{MACHSTATE}->{"system_time"},
									$self->{JOBSTATE}->{$jobstep}{"job_dispatchdate"})/3600);
	    $self->{RUNNINGDATA}->{$jobstep}{FL_CLASS}       =$self->{JOBSTATE}->{$jobstep}{"job_queue"};    
	    $self->{RUNNINGDATA}->{$jobstep}{FL_RESTART}     =$restart;  
	    $self->{RUNNINGDATA}->{$jobstep}{FL_ENDTIME}     = ((substr($self->{JOBSTATE}->{$jobstep}{"job_enddate"},0,8) 
								 eq substr($self->{MACHSTATE}->{"system_time"},0,8))?" ":"+").
								     substr($self->{JOBSTATE}->{$jobstep}{"job_enddate"},9,5);
	    $self->{RUNNINGDATA}->{$jobstep}{FL_STARTHOST}   =$self->{JOBSTATE}->{$jobstep}{"job_nodelist"};
	    $self->{RUNNINGDATA}->{$jobstep}{FL_NODES}       =$self->{JOBSTATE}->{$jobstep}{"job_nummachines"};       
	    $self->{RUNNINGDATA}->{$jobstep}{FL_CONSCPU}     =$self->{JOBSTATE}->{$jobstep}{"job_conscpu"}; 
	    $self->{RUNNINGDATA}->{$jobstep}{FL_UNICORE}     =$unicore; 
#	    $self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU}      =($self->{JOBSTATE}->{$jobstep}{"job_nummachines"}
#							       *$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}
#							       *$self->{JOBSTATE}->{$jobstep}{"job_conscpu"});  
#	    $self->{RUNNINGDATA}->{$jobstep}{FL_OVERALL}     =($self->{JOBSTATE}->{$jobstep}{"job_nummachines"}
#							       *$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}
#							       *$self->{JOBSTATE}->{$jobstep}{"job_conscpu"}); 
	    $self->{RUNNINGDATA}->{$jobstep}{FL_TASKPN}      =$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"};  
	    $self->{RUNNINGDATA}->{$jobstep}{FL_SPEC}        =sprintf("n%02d.p%02d.t%02d",
							     ($self->{JOBSTATE}->{$jobstep}{"job_nummachines"} ne "-")
								      ?$self->{JOBSTATE}->{$jobstep}{"job_nummachines"}:0,
							     ($self->{JOBSTATE}->{$jobstep}{"job_taskspernode"} ne "-")
								      ?$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}:0,
							     ($self->{JOBSTATE}->{$jobstep}{"job_conscpu"} ne "-")
								      ?$self->{JOBSTATE}->{$jobstep}{"job_conscpu"}:0);
	    $self->{RUNNINGDATA}->{$jobstep}{FL_WALLSEC}     =$self->{JOBSTATE}->{$jobstep}{"job_wall"}; 
	    $self->{RUNNINGDATA}->{$jobstep}{FL_RESTSEC}     =$self->{JOBSTATE}->{$jobstep}{"job_wall"}-&timediff($self->{MACHSTATE}->{"system_time"},
							       $self->{JOBSTATE}->{$jobstep}{"job_dispatchdate"}); 
	    

#	    if($self->{JOBSTATE}->{$jobstep}{"job_queue"}=~/^[n]\_/) {
#		$self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU}=32;
#		$self->{JOBSTATE}->{$jobstep}{"all_cpus"}=32;
#	    } elsif($self->{JOBSTATE}->{$jobstep}{"job_queue"}=~/^[m]\_/) {
#		if($self->{JOBSTATE}->{$jobstep}{"job_nummachines"}>1) {
#		    $self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU}=$self->{JOBSTATE}->{$jobstep}{"job_nummachines"}*32;
#		    $self->{JOBSTATE}->{$jobstep}{"all_cpus"}=$self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU};
#		} 
#	    } elsif($self->{JOBSTATE}->{$jobstep}{"job_queue"} eq "system") {
#		$self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU}=$self->{JOBSTATE}->{$jobstep}{"job_nummachines"}*32;
#		$self->{JOBSTATE}->{$jobstep}{"all_cpus"}=$self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU};
#	    } 
	}
    }


#    foreach $jobstep  (sort {sort_jobs_node($self,$a,$b)} (keys(%{$self->{WAITINGJOBS}}))) {
#	$self->{JOBSTATE}->{$jobstep}{"all_cpus"}=($self->{JOBSTATE}->{$jobstep}{"job_nummachines"}
#						   *$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"}
#						   *$self->{JOBSTATE}->{$jobstep}{"job_conscpu"});  
#	if($self->{JOBSTATE}->{$jobstep}{"job_queue"}=~/^[n]\_/) {
#	    $self->{JOBSTATE}->{$jobstep}{"all_cpus"}=32;
#	} elsif($self->{JOBSTATE}->{$jobstep}{"job_queue"}=~/^[m]\_/) {
#	    if($self->{JOBSTATE}->{$jobstep}{"job_nummachines"}>1) {
#		$self->{JOBSTATE}->{$jobstep}{"all_cpus"}=$self->{JOBSTATE}->{$jobstep}{"job_nummachines"}*32;
#	    } 
#	    } elsif($self->{JOBSTATE}->{$jobstep}{"job_queue"} eq "system") {
#		$self->{JOBSTATE}->{$jobstep}{"all_cpus"}=$self->{JOBSTATE}->{$jobstep}{"job_nummachines"}*32;
#	    } 
#	
#    }
    
}


sub generate_nodedata  {
    my($self)=shift;
    my ($nodenr);
    my @proccnt=();
    my($i,$jobstep,$spec,$num,$c,$p);
    my(%freenodes,%freecpus,$node,$book,$errcode,$pos);
    %freenodes=();
    %freecpus=();
    $self->{FRAMES} =scalar keys(%{$self->{NODES}});
    $self->{LLNODES}   =0;
    $self->{LLCPUS}    =0;
    $self->{ALLCPUS}   =0;
    $self->{LLUSEDCPUS}=0;
    $self->{LLOVERALLCPUS}=0;
    $nodenr=0;

    # adjust node cpu counter
    foreach $node (keys(%{$self->{NODES}})) {
	# only for old data necessary
	if(!defined($self->{NODES}->{$node}->{"node_cpus"})) {
	    if(($self->{NODES}->{$node}->{"cpu_total"}>16) && ($self->{NODES}->{$node}->{"cpu_total"}<=32)) {
		# seems to a big node (32PEs)
		$self->{NODES}->{$node}->{"node_cpus"}=32;
	    } else {
		$self->{NODES}->{$node}->{"node_cpus"}=$self->{NODES}->{$node}->{"cpu_total"};
	    }
	} elsif($self->{NODES}->{$node}->{"cpu_total"}<0) {
	    $self->{NODES}->{$node}->{"cpu_total"}=$self->{NODES}->{$node}->{"node_cpus"}
	}
	if($self->{NODES}->{$node}->{"node_state"} eq "Down") {
	    if(($self->{NODES}->{$node}->{"node_cpus"}==0) 
	       && ($self->{NODES}->{$node}->{"node_maxtasks"}>0)) {
		$self->{NODES}->{$node}->{"node_cpus"}=$self->{NODES}->{$node}->{"node_maxtasks"};
		$self->{NODES}->{$node}->{"cpu_total"}=$self->{NODES}->{$node}->{"node_maxtasks"};
	    }
	}
	# recalculate used cpus with job information
	$self->{NODES}->{$node}->{"cpu_avail"}=$self->{NODES}->{$node}->{"cpu_total"};
	$self->{NODES}->{$node}->{"cpu_run"}=0;
    }

    # generate nodedata 
    foreach $node (sort {sort_nodes($self)} (keys(%{$self->{NODES}}))) {
	$nodenr++;
	$self->{NODESTATE}->[$nodenr]=$self->{NODES}->{$node};
	$self->{NODESTATE}->[$nodenr]->{"node_name"}=$node;
	$self->{NODESTATE}->[$nodenr]->{"node_nr"}=$nodenr;
	$self->{NODESTATE}->[$nodenr]->{"num_jobs"}=0;
	$self->{NODESTATE}->[$nodenr]->{"job_list"}="";
	$proccnt[$nodenr]=0;
	my $cpu_total=$self->{NODESTATE}->[$nodenr]->{"cpu_total"};
	my $cpu_run=$self->{NODESTATE}->[$nodenr]->{"cpu_run"};
	
	$self->{ALLCPUS} += $self->{NODESTATE}->[$nodenr]->{"cpu_total"};
	if(($self->{NODESTATE}->[$nodenr]->{"node_state"} ne "None") && 
	   ($self->{NODESTATE}->[$nodenr]->{"node_state"} ne "Down")) {
	    $self->{LLNODES}++;
	    $self->{LLCPUS} += $self->{NODESTATE}->[$nodenr]->{"cpu_total"};
	}
	
	if($self->{NODESTATE}->[$nodenr]->{"node_arch"}!~/BGL/) {
	    for($i=0;$i<32;$i++) {	            $self->{PROCSTATE}->[$nodenr][$i]=" ";	}
	    if($self->{NODESTATE}->[$nodenr]->{"node_state"} eq "None") {
		# not under control of LoadLeveler
		for($i=0;$i<$cpu_total;$i++) {	    $self->{PROCSTATE}->[$nodenr][$i]="!";	}
	    } else {
		for($i=0;$i<$cpu_total;$i++) {	    $self->{PROCSTATE}->[$nodenr][$i]="-";	}
	    }
	} else {
	    for($i=0;$i<16;$i++) {	            $self->{PROCSTATE}->[$nodenr][$i]="-";	}
	}
	$self->{NODESTATE}->[$nodenr]->{"state"}=substr($self->{NODESTATE}->[$nodenr]->{"node_state"},0,2);

	if($self->{NODESTATE}->[$nodenr]->{"node_failed_parts"}) {
	    foreach $spec (split(/\),?\(/,$self->{NODESTATE}->[$nodenr]->{"node_failed_parts"})) {
		$spec=~/\(?N([^,]+):(.+)\)?/;$book=$1;$errcode=$2;
		$pos=$hextod{$book};
#		print "WF: node failed: $nodenr $spec >$book $errcode $pos<\n";
		$self->{PROCSTATE}->[$nodenr][$pos]="%";		

	    }
	}

	if($self->{NODESTATE}->[$nodenr]->{"cpu_total"}>0) {
	    my $load=$self->{NODESTATE}->[$nodenr]->{"load_avg"}/$self->{NODESTATE}->[$nodenr]->{"cpu_total"}*100.0;
	    $load=100.0 if($load>100.0);
	    $self->{NODESTATE}->[$nodenr]->{"val1"}=$load;
	    $self->{NODESTATE}->[$nodenr]->{"cpuusage"}=$load;
	} else {
	    $self->{NODESTATE}->[$nodenr]->{"val1"}=0.0;
	    $self->{NODESTATE}->[$nodenr]->{"cpuusage"}=0.0;
	}
	if ( ($self->{NODESTATE}->[$nodenr]->{"mem_total"}) &&
	     ($self->{NODESTATE}->[$nodenr]->{"mem_used"} ) &&
	     ($self->{NODESTATE}->[$nodenr]->{"consmem_used"} ) &&
	     ($self->{NODESTATE}->[$nodenr]->{"mem_total"}>0)) {
	    $self->{NODESTATE}->[$nodenr]->{"val2"}=    $self->{NODESTATE}->[$nodenr]->{"mem_used"}
	                                              /$self->{NODESTATE}->[$nodenr]->{"mem_total"}*100.0;
	    $self->{NODESTATE}->[$nodenr]->{"memreq"}  =$self->{NODESTATE}->[$nodenr]->{"consmem_used"}
	                                              /$self->{NODESTATE}->[$nodenr]->{"mem_total"}*100.0; 
	    $self->{NODESTATE}->[$nodenr]->{"memused"} =$self->{NODESTATE}->[$nodenr]->{"mem_used"}
	                                              /$self->{NODESTATE}->[$nodenr]->{"mem_total"}*100.0;
	} else {
	    $self->{NODESTATE}->[$nodenr]->{"val2"}=0.0;
	    $self->{NODESTATE}->[$nodenr]->{"memreq"}=0.0; 
	    $self->{NODESTATE}->[$nodenr]->{"memused"}=0.0;
	}
    }

    # examine jobs, extract informations about running nodes 
    foreach $jobstep  (sort { sort_jobs_node($self) } (keys(%{$self->{RUNNINGJOBS}}))) {
	if($self->{JOBSTATE}->{$jobstep}{"job_type"} eq "running") {
	    my $nodelist=$self->{JOBSTATE}->{$jobstep}{"job_nodelist"};
	    my $conscpu=$self->{JOBSTATE}->{$jobstep}{"job_conscpu"};
	    my $owner=$self->{JOBSTATE}->{$jobstep}{"job_owner"};
	    $self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU}=0;
	    $self->{RUNNINGDATA}->{$jobstep}{Fl_OVERALL}=0;
	    foreach $spec (split(/\),?\(/,$nodelist)) {
		$spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;
		my $pcnt=0;
		if($node=~/(R\d\d-M\d)/) {
		    # it's a BGL node
		    if($node=~/(R\d\d-M\d)-N(.)/) {
			# it's a BGL nodebook
			$node=$1;my $book=$2;
			$nodenr=$self->{NODES}->{$node}->{"node_nr"};
			$proccnt[$nodenr]++;
			my $pos=$hextod{$book};
			$self->{PROCSTATE}->[$nodenr][$pos]=$jobstep;
			$pcnt++;
		    } else {
			# it's a BGL midplane
			$node=$1;
			$nodenr=$self->{NODES}->{$node}->{"node_nr"};
			for($p=1;$p<=16;$p++) {
			    $proccnt[$nodenr]++;$pcnt++;
			    $self->{PROCSTATE}->[$nodenr][$p-1]=$jobstep;
			}
		    }
		    $self->{LLUSEDCPUS} += $pcnt*32*2;
		    $self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU}+=$pcnt*32*2;
		    $self->{RUNNINGDATA}->{$jobstep}{FL_OVERALL}+=$pcnt*32*2;
		    $self->{RUNNINGDATA}->{$jobstep}{FL_BGLBOOKS}+=$pcnt;
		    $self->{RUNNINGDATA}->{$jobstep}{FL_BGLNODES}+=$pcnt*32;
		    $self->{RUNNINGDATA}->{$jobstep}{FL_BGLTASKS}+=$num*(($self->{JOBSTATE}->{$jobstep}{'job_bgl_mode'} eq "V")?2:1);
		    $self->{RUNNINGDATA}->{$jobstep}{FL_BGLMODE}=$self->{JOBSTATE}->{$jobstep}{'job_bgl_mode'};
		    $self->{RUNNINGDATA}->{$jobstep}{FL_BGLISTORUS}=$self->{JOBSTATE}->{$jobstep}{'job_bgl_istorus'};

		    $self->{LLOVERALLCPUS} += $pcnt*32*2;
		    $self->{NODESTATE}->[$nodenr]->{"cpu_avail"}-=$pcnt*32*2;
		    $self->{NODESTATE}->[$nodenr]->{"cpu_run"}+=$pcnt*32*2;
		    $self->{NODESTATE}->[$nodenr]->{"num_jobs"}++;
		    $self->{NODESTATE}->[$nodenr]->{"job_list"}.="(".$owner.",".($pcnt*32*2).")";
		} else {
		    # it's a LL node
		    $nodenr=$self->{NODES}->{$node}->{"node_nr"};
		    my $tpn=$self->{JOBSTATE}->{$jobstep}{"job_taskspernode"};
#		    print "WF $jobstep: \"$spec\" node=$node num=$num nodenr=$nodenr\n";
		    if($num%$conscpu!=0) {
			print "generate_nodedata: $jobstep: \"$spec\" not divisible by cons_cpus=$conscpu\n";
			$num=$conscpu if($num==1);
			$num=int($num/$conscpu);
		    } else {
			$num=$num/$conscpu;
		    }
		    for($i=0;$i<$num;$i++) {
			for($c=0;$c<$conscpu;$c++) {
			    $proccnt[$nodenr]++;
			    if($proccnt[$nodenr]<=$self->{NODESTATE}->[$nodenr]->{"cpu_total"}) {
				if($c==0) { $self->{PROCSTATE}->[$nodenr][$proccnt[$nodenr]-1]=$jobstep;}
				else      { $self->{PROCSTATE}->[$nodenr][$proccnt[$nodenr]-1]="&";}
				$pcnt++;
			    } else {
				printf("generate_nodedata[$nodenr]: %s error alloc #%d >= avail #%d $num,$conscpu,$node\n",
				       $jobstep,$proccnt[$nodenr],$self->{NODESTATE}->[$nodenr]->{"cpu_total"});
#			    $proccnt[$nodenr]--;
#			    $pcnt--;
			    }
			}
		    }
		    $self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU}+=$pcnt;
		    $self->{LLUSEDCPUS} += $pcnt;
#    		    printf("WF $jobstep add %d cpus for machine %s -> %d\n",$pcnt,$node,$self->{RUNNINGDATA}->{$jobstep}{FL_ALLCPU});
		    if($self->{JOBSTATE}->{$jobstep}{"job_node_usage"}=~/NOT_SHARED/) {
			if($self->{NODESTATE}->[$nodenr]->{"node_arch"}!~/BGL/) {
			    for($i=$proccnt[$nodenr];$i<$self->{NODESTATE}->[$nodenr]->{"cpu_total"};$i++) {
				$self->{PROCSTATE}->[$nodenr][$i]="=";
				$pcnt++;
			    }
			}
		    }
		    $self->{RUNNINGDATA}->{$jobstep}{FL_OVERALL}+=$pcnt;
		    $self->{LLOVERALLCPUS} += $pcnt;
		    $self->{NODESTATE}->[$nodenr]->{"cpu_avail"}-=$pcnt;
		    $self->{NODESTATE}->[$nodenr]->{"cpu_run"}+=$pcnt;
		    $self->{NODESTATE}->[$nodenr]->{"num_jobs"}++;
		    $self->{NODESTATE}->[$nodenr]->{"job_list"}.="(".$owner.",".$pcnt.")";
		}


	    }
	}
    }

    # free nodes
    {
	for($nodenr=1;$nodenr<=$self->{FRAMES};$nodenr++) {
	    my $cpu_total=$self->{NODESTATE}->[$nodenr]->{"cpu_total"};
	    my $cpu_run=$self->{NODESTATE}->[$nodenr]->{"cpu_run"};
#	    print "WF: $nodenr $cpu_run, $cpu_total\n" if ($cpu_total<$cpu_run);
	    if(($self->{NODESTATE}->[$nodenr]->{"node_state"} ne "None") && 
	       ($self->{NODESTATE}->[$nodenr]->{"node_state"} ne "Down")) {
		$freenodes{$cpu_total}++ if($cpu_run==0);
		$freecpus{$cpu_total-$cpu_run}++ if($cpu_run!=0);
	    }
#	    print "WF: $nodenr $cpu_run/$cpu_total",$self->{NODESTATE}->[$nodenr]->{"node_name"},",",
#	    $self->{NODESTATE}->[$nodenr]->{"node_state"},"\n";
	}
	my($num);
	my $cnum=0;
	$self->{FREEINFO} = "Informations about free Nodes/cpus:\n";
	$self->{LLFREENODES}=0;
	$self->{LLFREENODESSUM}=0;
	$self->{FREEINFO}     .= sprintf("    free NODES:");
	foreach $num (sort {$b <=> $a} (keys(%freenodes))) {
	    $cnum++;
	    if($cnum>3) {
		$self->{FREEINFO}     .= "\n    free nodes:";
		$cnum=0;
	    }
	    $self->{FREEINFO}     .= sprintf("[%2d * %2d cpus] ",$freenodes{$num},$num);
	    $self->{LLFREENODES}+=$freenodes{$num};
	    $self->{LLFREENODESSUM}+=$freenodes{$num}*$num;
	}
	$self->{FREEINFO}     .= sprintf("\n       --> %d NODES with acc. %d cpus\n\n",
					 $self->{LLFREENODES},$self->{LLFREENODESSUM});
	$self->{FREEINFO} .= "";
	$self->{LLFREEPARTS}=0;
	$self->{LLFREEPARTSSUM}=0;
	$self->{FREEINFO}     .= sprintf("    free PARTS:");
	$cnum=0;
	foreach $num (sort {$b <=> $a} (keys(%freecpus))) {
	    next if($num<=0);
	    $cnum++;
	    if($cnum>3) {
		$self->{FREEINFO}     .= "\n     free parts:";
		$cnum=0;
	    }
	    $self->{FREEINFO}     .= sprintf(" [%2d * %2d cpus]",$freecpus{$num},$num);
	    $self->{LLFREEPARTS}+=$freecpus{$num};
	    $self->{LLFREEPARTSSUM}+=$freecpus{$num}*$num;
	}
	$self->{FREEINFO}     .= sprintf("\n                --> %d PARTS with acc. %d cpus\n",
					 $self->{LLFREEPARTS},$self->{LLFREEPARTSSUM});
    }


}

sub date_to_sec {
    my ($date)=@_;
#    print"WF: date_to_sec $date\n";
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year $^O\n";
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $timesec\n";
    return($timesec);
}

sub timediff {
    my ($date1,$date2)=@_;
#    print"WF: timediff >$date1< >$date2<\n";
    return(-1) if((!$date1) || (!$date2));
    my $timesec1=&date_to_sec($date1);
    my $timesec2=&date_to_sec($date2);
#    if((($timesec1-$timesec2)/3600)>100) {
#	printf("timediff: %20s - %20s -> %d\n",$date1,$date2,$timesec1-$timesec2);
#    }
    return($timesec1-$timesec2);
}

sub printsize {
    my($self)=shift;
    my($mark)=@_;
    my($out,@out,$diff,$size);
    $out=`ps l $$|grep $$`;
    @out=split(/\s+/,$out);
    $size=$out[6];
#    $size=$out[9];
    printf("  Process Size at %-40s: %10d KB",$mark,$size);
    $diff=$size-$self->{LASTSIZE};
    printf("  --> +%d KB\n",$diff) if($diff>0);
    printf("  --> %d KB\n",$diff) if($diff<0);
    printf("\n") if($diff==0);
    if($diff!=0) {
	$self->{SIZEINFOC}->{$mark}++;
	$self->{SIZEINFO}->{$mark}+=$diff;
	$self->{LASTSIZE}=$size;
    }
}

sub reportsize {
    my($self)=shift;
    my($c,$mark);

    $c=1;
    print "-"x80,"\n";
    foreach $mark (sort {$self->{SIZEINFO}->{$b} <=> $self->{SIZEINFO}->{$a}} (keys(%{$self->{SIZEINFO}})) ) {
	printf("%03d: %-40s  %8d KB   #%6d\n",$c,$mark,$self->{SIZEINFO}->{$mark},$self->{SIZEINFOC}->{$mark});
	    $c++;
    }
    print "-"x80,"\n";
}

sub sort_jobs_node   {    
    my($self) = shift;
    for my $q ($a,$b) {
	return(0) if($self->{JOBSTATE}->{$q}{"job_nummachines"} eq "-");
	return(0) if($self->{JOBSTATE}->{$q}{"job_taskspernode"} eq "-");
	return(0) if($self->{JOBSTATE}->{$q}{"job_conscpu"} eq "-");
    }
#    print "WF $a error\n" if($self->{JOBSTATE}->{$a}{"job_nummachines"} eq "-");
#    print "WF $a error\n" if($self->{JOBSTATE}->{$a}{"job_taskspernode"} eq "-");
#    print "WF $a error\n" if($self->{JOBSTATE}->{$a}{"job_conscpu"} eq "-");
    my $numproca=$self->{JOBSTATE}->{$a}{"job_nummachines"}
                 *$self->{JOBSTATE}->{$a}{"job_taskspernode"}
                 *$self->{JOBSTATE}->{$a}{"job_conscpu"};
    my $numprocb=$self->{JOBSTATE}->{$b}{"job_nummachines"}
                 *$self->{JOBSTATE}->{$b}{"job_taskspernode"}
                 *$self->{JOBSTATE}->{$b}{"job_conscpu"};
    $numprocb <=> $numproca;
}

sub sort_nodes   {    
    my($self) = shift;
    if($self->{SORTNODEMODE}==0) {
	if($self->{NODES}->{$a}->{"node_cpus"} != $self->{NODES}->{$b}->{"node_cpus"}) {
	    $self->{NODES}->{$b}->{"node_cpus"} <=> $self->{NODES}->{$a}->{"node_cpus"};
	} else {
	    if($a=~/^l\df/) {
		my ($aa)=($a=~/^l\df(\d+)$/);
		my ($bb)=($b=~/^l\df(\d+)$/);
		$aa <=> $bb;
	    } else {
		$a cmp $b;
	    }
	}
    } else {
	# mode=1
	if($self->{NODES}->{$a}->{"node_cpus"} != $self->{NODES}->{$b}->{"node_cpus"}) {
	    $self->{NODES}->{$b}->{"node_cpus"} <=> $self->{NODES}->{$a}->{"node_cpus"};
	} else {
	    if($a=~/^l\df/) {
		my ($aa)=($a=~/^l\df(\d+)$/);
		my ($bb)=($b=~/^l\df(\d+)$/);
		$aa <=> $bb;
	    } else {
		$b cmp $a;
	    }
	}
    }
}

1;





