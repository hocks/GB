# $Source: /cvs/cvsroot/llview/lib/LLview_gui_running.pm,v $
# $Author: zdv087 $
# $Revision: 1.9 $
# $Date: 2007/04/17 13:13:45 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_running;
use Time::Local;
use strict;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_gui_scala: new %s\n",ref($proto)) if($debug>=3);
    $self->{POSX}    = 5;
    $self->{POSY}    = 0;
    $self->{WIDTH}   = 790;
    $self->{HEIGHT}  = 16;
    $self->{RUNNING}      = " \n"x200;
    $self->{SEARCHSTR}      = "";
    $self->{ITEMS}   = [];
    bless $self, $class;
    return $self;
}

sub set_searchstr {
    my($self) = shift;
    my($str) = @_;
    $self->{SEARCHSTR}=$str;
    return 1;
}

sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$textwidget)=@_;
    my($string);
    my $frames=$dataobj->{FRAMES};
    $self->replace($dataobj,$colorobj,$textwidget,$self->{RUNNING});
    $textwidget->tagConfigure('search',-foreground => "blue");
    return();
}

sub replace {
    my($self) = shift;
    my($dataobj,$colorobj,$textwidget,$string)=@_;
    my $frames=$dataobj->{FRAMES};
    my($str);
    $textwidget->delete("1.0", 'end'); 
    $textwidget->insert('end', $string);     
    return(1);
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$textwidget)=@_;
    my($rnum,$lnum,$lastqueue,$jobstep,$queue,$shared,$unicore,$str);
    my(@marked);
    $self->{RUNNING}=""; 
    $rnum=0;$lnum=0;

    $dataobj->printsize("running upd: start of routine") if($debug==5);

    $self->{RUNNING}.=sprintf("  queue %2s| %12s %8s %8s [%-18s] %5s [%3s %3s %3s]  %10s %4s %s | %s \n",
		      "#","Jobstep","Userid","Class","Queue Date","Rest.",
		      "#N","#T","#C","Memory","Shared","U","Hosts");
    $self->{RUNNING}.="          +"."-"x102;    $self->{RUNNING}.="+\n";
    $lnum+=2;
    $lastqueue="";
    foreach $jobstep  (sort { sort_jobs_class_date($dataobj) } (keys(%{$dataobj->{RUNNINGJOBS}}))) {
	if($dataobj->{JOBSTATE}->{$jobstep}{"job_type"} eq "running") {
	    $queue=$dataobj->{JOBSTATE}->{$jobstep}{"job_queue"};
	    if($lastqueue ne $queue ) {
		$self->{RUNNING}.="$queue";		
		$self->{RUNNING}.="-"x(10-length($queue));		
		$self->{RUNNING}.="+\n";
		$lastqueue=$queue;
		$lnum+=1;
	    }
	    $rnum++;
	    $shared=($dataobj->{JOBSTATE}->{$jobstep}{"job_node_usage"}=~/NOT_SHARED/)?"no":"yes";
	    $unicore=($dataobj->{JOBSTATE}->{$jobstep}{"job_comment"}=~/NOT ?Unicore/)?" ":"U";
	    $str=$dataobj->{JOBSTATE}->{$jobstep}{"job_nodelist"};
	    $str=~s/\(//gs;
	    $str=~s/,\d+\)//gs;
	    $self->{RUNNING}.=sprintf("        %2d| %12s %8s %8s [%10s] %4s  [%3d %3d %3d]  %10s %5s %s | %s\n",
				      $rnum,
				      substr($jobstep,0,12),
				      $dataobj->{JOBSTATE}->{$jobstep}{"job_owner"},
				      $dataobj->{JOBSTATE}->{$jobstep}{"job_queue"},
				      
				      $dataobj->{JOBSTATE}->{$jobstep}{"job_queuedate"},
				      $dataobj->{JOBSTATE}->{$jobstep}{"job_restart"},
				      $dataobj->{JOBSTATE}->{$jobstep}{"job_nummachines"},
				      $dataobj->{JOBSTATE}->{$jobstep}{"job_taskspernode"},
				      $dataobj->{JOBSTATE}->{$jobstep}{"job_conscpu"},
				      
				      $dataobj->{JOBSTATE}->{$jobstep}{"job_consmem"}/1024,
				      $shared,
				      $unicore,
				      $str,
				      );
	    if($self->{SEARCHSTR}) {
		push(@marked,$lnum+1) if ($dataobj->{JOBSTATE}->{$jobstep}{"job_owner"}=~/$self->{SEARCHSTR}/);
	    }
	    $lnum+=1;
	}
    }
    $dataobj->printsize("running upd: after loop") if($debug==5);
  
    $self->replace($dataobj,$colorobj,$textwidget,$self->{RUNNING});
    foreach $lnum (@marked) {
	$textwidget->tagAdd("search","$lnum.0","$lnum.0 lineend");
    }
    $dataobj->printsize("running upd: end of routine") if($debug==5);

    return(1);
}

sub date_to_sec {
    my ($date)=@_;
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $timesec\n";
    return($timesec);
}

sub sort_jobs_class_date   {    
    my($dataobj) = shift;
#    print "WF: $a,$b",$dataobj->{JOBSTATE}->{$a}{"job_type"}," ",$dataobj->{JOBSTATE}->{$b}{"job_type"},"\n";
    if($dataobj->{JOBSTATE}->{$a}{"job_type"} eq $dataobj->{JOBSTATE}->{$b}{"job_type"}) {
	if($dataobj->{JOBSTATE}->{$a}{"job_queue"} eq $dataobj->{JOBSTATE}->{$b}{"job_queue"}) {
	    if($dataobj->{JOBSTATE}->{$a}{"job_type"} eq "running") {
		&date_to_sec($dataobj->{JOBSTATE}->{$a}{"job_dispatchdate"}) <=> 
		    &date_to_sec($dataobj->{JOBSTATE}->{$b}{"job_dispatchdate"});
	    } else {
#		&date_to_sec($dataobj->{JOBSTATE}->{$a}{"job_queuedate"}) <=>  
#		    &date_to_sec($dataobj->{JOBSTATE}->{$b}{"job_queuedate"});
		$dataobj->{JOBSTATE}->{$a}{"job_sysprio"} <=>  
		    $dataobj->{JOBSTATE}->{$b}{"job_sysprio"};
	    }
	} else {
	    $dataobj->{CLASSPRIO}->{$dataobj->{JOBSTATE}->{$b}{"job_queue"}} 
	    <=> $dataobj->{CLASSPRIO}->{$dataobj->{JOBSTATE}->{$a}{"job_queue"}};
	}

    } else {
	$dataobj->{JOBSTATE}->{$a}{"job_type"} cmp $dataobj->{JOBSTATE}->{$b}{"job_type"};
    }
}


1;
