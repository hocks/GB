# $Source: /cvs/cvsroot/llview/lib/LLview_gui_jobstackhull.pm,v $
# $Author: zdv087 $
# $Revision: 1.16 $
# $Date: 2007/04/17 13:13:45 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
#
package LLview_gui_jobstackhull;
use strict;
use IO::File;
my($debug)=2;

#
# this object is responsible for the positioning of rectangles representing jobs 
# on the canvas. The jobs are stacked. the direction of stacking can be to bottom or to top
# of the canvas region
#

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_gui_jobstackhull: new %s\n",ref($proto)) if($debug>=3);
    $self->{POSX}    = 5;
    $self->{POSY}    = 0;
    $self->{WIDTH}   = 790;
    $self->{HEIGHT}  = 16;
    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}     = "-*-Helvetica-Bold-R-Normal--*-80-*-*-*-*-*-*";
    $self->{ITEMS}   = [];
    $self->{DIRECTION}="bottom";
    $self->{TAG}="DUMMY";
    $self->{PROTO}=0;
    $self->{PROTOOPEN}=0;
    $self->{PROTOFILE} = new IO::File;
    $self->{COLORGREYCNT} =20; # for autogrey
    $self->{COLORGREYMIN} =30; # for autogrey
    $self->{COLORGREYMAX} =90; # for autogrey
    $self->{COLORGREYSTEP}=1; # for autogrey
    # vector: Y[i] describes y-value of hull at posititions between X[i-1]..X[i]
    $self->{HULLPOSX}=[];
    $self->{HULLPOSY}=[];

    bless $self, $class;
    return $self;
}


# general build method, nothing to do in this case, store only pointer to main objects
sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($i,$name);
    my $frames=$dataobj->{FRAMES};
    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;
    $self->{OPTIONOBJECT}=$optobj;

    $self->{BUILDREADY}=1;

    return();
}

# sets size of region which can be used by jobstackhull
# 
sub setsize {
    my($self) = shift;
    my($px,$py,$dx,$dy)=@_;
    $self->{POSX}=$px;
    $self->{POSY}=$py;
    $self->{WIDTH}=$dx;
    $self->{HEIGHT}=$dy;
    return();
}

# sets counter and parameters for autogrey
# 
sub setautogrey {
    my($self) = shift;
    my($min,$max,$step)=@_;
    $self->{COLORGREYCNT} =$min-$step; # for autogrey
    $self->{COLORGREYMIN} =$min; # for autogrey
    $self->{COLORGREYMAX} =$max; # for autogrey
    $self->{COLORGREYSTEP}=$step; # for autogrey
    return();
}

sub init {
    my($self) = shift;
    my($marker)=@_;
    $self->clean();
    # init hull at points outside the drawable region
    $self->{HULLPOSX}->[0]=-1;
    $self->{HULLPOSY}->[0]=0;
    $self->{HULLPOSX}->[1]=$self->{WIDTH}+1;
    $self->{HULLPOSY}->[1]=0;
    if($self->{PROTO}) {
	if($self->{PROTOOPEN}) {
	    $self->{PROTOFILE}->close();
	}
	$self->{PROTOFILE}->open("> hullproto.".$marker.".log") || die "can't open file in jobstackhull\n";
	$self->{PROTOOPEN}=1;
	
	my $fh=$self->{PROTOFILE};
	printf($fh "WF: setsize: posx=%10.4f posy=%10.4f width=%10.4f height=%10.4f %s\n",    
	       $self->{POSX},$self->{POSY},$self->{WIDTH},$self->{HEIGHT});
    }
    return();
}


# sets size of region which can be used by jobstackhull
# 
sub setdirection {
    my($self) = shift;
    my($dir)=@_;
    $self->{DIRECTION}=$dir;
    return();
}

sub settag {
    my($self) = shift;
    my($tag)=@_;
    $self->{TAG}=$tag;
    return();
}

sub clean {
    my($self) = shift;
    my $canvas=$self->{CANVAS};
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
    $self->{HULLPOSX}=[];
    $self->{HULLPOSY}=[];
}



# plots rectangle for job
# splits rectangle if necessary in mor rectangles
#
# $startx,$endx: position of rectangle relative to startpos of canvas region og hull object
# $dy:           height of rectangle
# $ridframe:     descriptor for info obj of rectangle
# $ridtext:      descriptor for info obj of text inside the rectangle
# $color:        color of rectangle or "autogrey"
# $descr_short, $descr_long
# $outlinewidth optional
sub put {
    my($self) = shift;
    my($startx,$endx,$dy,$ridframe,$ridtext,$color,$descr_short,$descr_long,$outlinewidth,$outlinecolor,$textcolor)=@_;
    my($s,$i,$j,$starty);
    my $fh=$self->{PROTOFILE};
    $outlinewidth=1 if(!defined($outlinewidth));
    $outlinecolor="black" if(!defined($outlinecolor));
    $textcolor="black" if(!defined($textcolor));

    if($color=~/autogr[ea]y/) {
	$self->{COLORGREYCNT}+=$self->{COLORGREYSTEP};
	$self->{COLORGREYCNT}-=($self->{COLORGREYMAX}-$self->{COLORGREYMIN}) if($self->{COLORGREYCNT}>$self->{COLORGREYMAX});
	$color=sprintf("grey%02d",$self->{COLORGREYCNT});
    }

    printf($fh "WF: put: startx=%10.4f endx=%10.4f dy=%10.4f %s\n",$startx,$endx,$dy,$descr_long) if($self->{PROTO});
    if($startx==$endx) {
	printf($fh "WF: put: do nothing, startx=%10.4f = endx=%10.4f\n\n",$startx,$endx) if($self->{PROTO});
	return();
    }

    # search start
    $starty=$self->{HULLPOSY}->[0];
    for($s=0;$s<=$#{$self->{HULLPOSX}};$s++) {
	$starty=$self->{HULLPOSY}->[$s];
	last if($self->{HULLPOSX}->[$s]>=$startx);
    }
    # insert start point
    if($self->{HULLPOSX}->[$s] != $startx) {
	printf($fh  "WF: put:   [%2d]     gen new start pos at x=%10.4f starty=%10.4f before x[%d]=%10.4f (%10.4f)\n",
	       $s,$startx,$starty,$s,$self->{HULLPOSX}->[$s],$self->{HULLPOSY}->[$s]) if($self->{PROTO});
	splice(@{$self->{HULLPOSX}},$s,0,$startx);
	splice(@{$self->{HULLPOSY}},$s,0,$starty); # +$dy
    } else {
	printf($fh "WF: put:   [%2d]     reuse start pos at x=%10.4f starty=%10.4f %s\n",$s,$startx,$starty) if($self->{PROTO});
#	$self->{HULLPOSY}->[$s]=$starty+$dy; # 
    }
    $s++;

    # walk through timeline
    printf($fh "WF: put:   [%2d]     start walk at position %d of %d \n",$s,$s,$#{$self->{HULLPOSX}}) if($self->{PROTO});
    for($i=$s;$i<=$#{$self->{HULLPOSX}};$i++) {
	printf($fh "WF: put:   [%2d]     look in  x=%10.4f y=%10.4f",$i,
	       $self->{HULLPOSX}->[$i],$self->{HULLPOSY}->[$i]) if($self->{PROTO});
	if($self->{HULLPOSX}->[$i]<$endx) {
	    print $fh " is in time range";
	    # draw rectangle if next element has not the same y-pos
	    my $drawrect=1;
	    if($i<$#{$self->{HULLPOSX}}) {
		$drawrect=0 if($self->{HULLPOSY}->[$i]==$self->{HULLPOSY}->[$i+1]);
	    }
	    if($drawrect) {
		$starty=$self->{HULLPOSY}->[$i];
		print $fh " next has another y-pos\n" if($self->{PROTO});
		printf($fh "WF: put:   [%2d]     part x=%10.4f..%10.4f starty=%10.4f %s\n",$i,
		       $startx,$self->{HULLPOSX}->[$i],$starty+$dy,$descr_long) if($self->{PROTO});
		$self->gen_rect($startx,$starty+$dy,
				$self->{HULLPOSX}->[$i],$starty,$ridframe,$ridtext,$color,$descr_long,$descr_short,
				$outlinewidth,$outlinecolor,$textcolor);
		$startx=$self->{HULLPOSX}->[$i];
		$self->{HULLPOSY}->[$i]+=$dy;
	    } else {
		print $fh " same y-pos, do nothing\n" if($self->{PROTO});
		$self->{HULLPOSY}->[$i]+=$dy;
	    }
	} else {
	    print $fh " not in time range\n" if($self->{PROTO});
	    # after last element inside job time range
	    last;
	}
    }
    printf($fh "WF: put:   [%2d]     end of walk at position %d of %d \n",$i,$i,$#{$self->{HULLPOSX}}) if($self->{PROTO});
    
    # insert end point
    $starty=$self->{HULLPOSY}->[$i];
    if($self->{HULLPOSX}->[$i] > $endx) {
	if(($i>0) && ($self->{HULLPOSY}->[$i-1]==$starty+$dy)) {
	    printf($fh "WF: put:   [%2d]     move last pos to new end pos at x=%10.4f starty=%10.4f %s\n",
		   $i,$endx,$starty+$dy) if($self->{PROTO});
	    $self->{HULLPOSX}->[$i-1]=$endx;
	} else {
	    printf($fh "WF: put:   [%2d]     gen new end pos at x=%10.4f starty=%10.4f %s\n",
		   $i,$endx,$starty+$dy) if($self->{PROTO});
	    splice(@{$self->{HULLPOSX}},$i,0,$endx);
	    splice(@{$self->{HULLPOSY}},$i,0,$starty+$dy);
	}
    } else {
	printf($fh "WF: put:   [%2d]     reuse end pos at x=%10.4f starty=%10.4f %s\n",
	       $i,$endx,$starty+$dy) if($self->{PROTO});
	$self->{HULLPOSY}->[$i]=$starty+$dy;
    }

    # draw last rectangle
    printf($fh "WF: put:   [%2d]     part x=%10.4f..%10.4f starty=%10.4f %s last\n",$i,
		   $startx,$self->{HULLPOSX}->[$i],$starty+$dy,$descr_long) if($self->{PROTO});
    $self->gen_rect($startx,$starty+$dy,
		    $endx,$starty,$ridframe,$ridtext,$color,$descr_long,$descr_short,
		    $outlinewidth,$outlinecolor,$textcolor);
    
    if($self->{PROTO}) {
	printf($fh "WF: put: ylist");
	for($j=0;$j<=$#{$self->{HULLPOSY}};$j++) {printf($fh " %7.2f",$self->{HULLPOSY}->[$j])};
	printf($fh "\n");
	
	printf($fh "WF: put: xlist");
	for($j=0;$j<=$#{$self->{HULLPOSX}};$j++) {printf($fh " %7.2f",$self->{HULLPOSX}->[$j])};
	printf($fh "\n\n");

	$fh->flush();
    }
}

sub gen_rect {
    my($self) = shift;
    my($startx,$starty,$endx,$endy,$ridframe,$ridtext,$color,$descr_long,$descr_short,$outlinewidth,$outlinecolor,$textcolor)=@_;
    my($id,$dx,$dy);
    my $fh=$self->{PROTOFILE};
    $textcolor="black" if(!defined($textcolor));

#    $startx=int($startx)+1; 	    $endx=int($endx)+1;
#    $starty=int($starty)+1; 	    $endy=int($endy)+1;

    # add origin position
    $startx+=$self->{POSX};
    $endx+=$self->{POSX};
 
    if($self->{DIRECTION} eq "bottom") {
	$starty=$self->{POSY}+$self->{HEIGHT}-$starty;
	$endy=$self->{POSY}+$self->{HEIGHT}-$endy;
    } else {
	$starty=$self->{POSY}+$starty;
	$endy=$self->{POSY}+$endy;
    }
    if($starty>$endy) {
	my $help=$endy;	$endy=$starty;	$starty=$help;
    }
    if($startx>$endx) {
	my $help=$endx;	$endx=$startx;	$startx=$help;
    }
    $dx=$endx-$startx;              $dy=$endy-$starty;
    
#    printf($fh "WF:         -> rectangle: %10s  from %6.2f,%6.2f to %6.2f,%6.2f rid=%s,%s col=%s,$outlinewidth >$descr_long< %d %d\n",
#	   $descr_long,$startx,$starty,$endx,$endy,$ridframe,$ridtext,$color,$dx,$dy) if($self->{PROTO});
    $id=$self->{CANVAS}->createRectangle($startx,$endy,$endx,$starty, 
					 -fill => $color, 
					 -outline => $outlinecolor, 
					 -width => $outlinewidth,
					 -tags => [$ridframe, $self->{TAG}]);
    push(@{$self->{ITEMS}},$id);
    $self->{INFOOBJECT}->register_bind($ridtext,$self);
    $self->{INFOOBJECT}->register_bind($ridframe,$self);
    if(($dx>40) && ($dy>10) && ($descr_long ne "")) {
#	printf($fh "dx=%10.4f dy=%10.4f text=>$descr_long<\n",($startx+$endx)/2,($starty+$endy)/2+0) if($self->{PROTO});
	$id=$self->{CANVAS}->createText(($startx+$endx)/2,($starty+$endy)/2+0,
					-text => $descr_long,
					-anchor => 'c',
					-fill => $textcolor,
					-font => $self->{FONT1},
					-tags => [$ridtext, $self->{TAG}]);
#	print $fh "dx=$dx dy=$dy text=>$descr_long<\n" if($self->{PROTO});
	push(@{$self->{ITEMS}},$id);
    } elsif (($dx>10) && ($dy>70) && ($descr_long ne "")) {
	$descr_long=~s/(.)/$1\n/gs;
	$id=$self->{CANVAS}->createText(($startx+$endx)/2,($starty+$endy)/2+0,
					-text => $descr_long,
					-anchor => 'c',
					-fill => $textcolor,
					-font => $self->{FONT1},
					-tags => [$ridtext, $self->{TAG}]);
	push(@{$self->{ITEMS}},$id);
    } elsif(($dx>10) && ($dy>10)) {
	$id=$self->{CANVAS}->createText(($startx+$endx)/2,($starty+$endy)/2+0,
					-text => $descr_short,
					-anchor => 'c',
					-fill => $textcolor,
					-font => $self->{FONT1},
					-tags => [$ridtext, $self->{TAG}]);
	push(@{$self->{ITEMS}},$id);
    }
}

sub generateinfo {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$name,$xpos,$ypos)=@_;
    my($runtime);
    my $infostr="no info for $name\n";

}


1;
