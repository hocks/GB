# $Source: /cvs/cvsroot/llview/lib/LLview_get_exec.pm,v $
# $Author: zdv087 $
# $Revision: 1.14 $
# $Date: 2007/04/17 13:13:45 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
package LLview_get_exec;
use strict;
use Time::HiRes qw ( time );
my($debug)=0;

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_get_ssh: new %s\n",ref($proto)) if($debug>=3);
    $self->{VERBOSE} = 0;
    $self->{FILENAMEMASK}  = "llqxml_%08d.xml";
    $self->{FILENAME}      = "llqxml_00000001.xml";

    $self->{CLUSTERNAME} = shift||"-"; # needed for button callback function 

    $self->{OPTSECTION} ="llqxml";

    $self->{CMD}      = "/home1/admin/parateam/bin/llqxml";
    $self->{STOREFILE}=0;
    $self->{STOREDIR} = "../data";

    $self->{DOSSH} = 0;
    $self->{SSHHOST}   = "jump.fz-juelich.de";
    $self->{SSHUSERID} = "";

    $self->{STORETAR} =0;
    $self->{STORETARFILE} = "../data_test1.tar.gz";
    $self->{CNT} = 0;
    $self->{TARCMD} = "tar";

    $self->{DATA}          = "";
    bless $self, $class;
    return $self;
}

sub init_options {
    my($self) = shift;
    my($optobj) = shift;
    $self->{OPTIONOBJECT}=$optobj;
    $optobj->register_option($self->{OPTSECTION},"CMD", -label => "path to llqxml", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{CMD});


    $optobj->register_option($self->{OPTSECTION},"DOSSH", -label => "use ssh to execute llqxml", 
			     -caller => $self,-pack => 1, -labelwidth => 30,
			     -type => "radio", -default => $self->{DOSSH});

    $optobj->register_option($self->{OPTSECTION},"SSHHOST", -label => "host", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{SSHHOST});

    $optobj->register_option($self->{OPTSECTION},"SSHUSERID", -label => "userid on host", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{SSHUSERID});


    $optobj->register_option($self->{OPTSECTION},"FILENAMEMASK", -label => "Filename Mask", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FILENAMEMASK});

    $optobj->register_option($self->{OPTSECTION},"STOREFILE", -label => "Store in Files", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{STOREFILE});

    $optobj->register_option($self->{OPTSECTION},"STOREDIR", -label => "Directory", 
			     -caller => $self,-pack => 2,
			     -type => "string", -default => $self->{STOREDIR});

    $optobj->register_option($self->{OPTSECTION},"STORETAR", -label => "Store in Tar-File", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{STORETAR});

    $optobj->register_option($self->{OPTSECTION},"STORETARFILE", -label => "File (tar.gz)", 
			     -caller => $self,-pack => 2,
			     -type => "string", -default => $self->{STORETARFILE});

    $optobj->register_option($self->{OPTSECTION},"CNT", -label => "actual number", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 0, -max => 200000, -default => $self->{CNT}, -step => 100);
    $optobj->register_option($self->{OPTSECTION},"FILENAME", -label => "actual filename", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FILENAME});

}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id,$objname);
    print "locdata,optvalchanged: $section,$name -> $val\n" if($self->{VERBOSE});
    $self->{$name}=$val;
 
}


sub getdata {
    my($self) = shift;
    my($nr,$fname);
    my($tstart,$tdiff,$cmd);
    
    
    if($self->{DOSSH}) {
	$cmd="ssh $self->{SSHUSERID}\@$self->{SSHHOST} $self->{CMD} ";
    } else {
	$cmd=$self->{CMD};
    }
    $tstart=time;
    $self->{DATA}=`$cmd`;
    $tdiff=time-$tstart;

    $self->{DATA}=~/system_time=\"(\d+)\/(\d+)\/(\d+)-(\d+):(\d+):(\d+)\"/s;
    my ($month,$day,$year,$hour,$min,$sec)=($1,$2,$3,$4,$5,$6);
    printf("llview: got data for (%02d/%02d/%02d %02d:%02d:%02d) in %10.4f sec from $cmd\n",
	   $month,$day,$year,$hour,$min,$sec,$tdiff) if($self->{VERBOSE});

    if($self->{STOREFILE}) {
	my $dir=$self->{STOREDIR};
	my $nrfile="$dir/NR.dat";

	if(-f $nrfile) {
	    open(IN,$nrfile);
	    $nr=<IN>;
	    chomp($nr);
	    close(IN);
	} else {
	    $nr=0;
	}
	$nr++;
	$self->{CNT}=$nr;
	$self->{FILENAME}=sprintf($self->{FILENAMEMASK},$self->{CNT});
	open(OUT,"> $dir/$self->{FILENAME}");
	print OUT $self->{DATA};
	close(OUT);
	open(OUT,"> $nrfile");
	print OUT $nr;
	close(OUT);
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},$self->{OPTSECTION},"CNT",$self->{CNT});
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},$self->{OPTSECTION},"FILENAME",$self->{FILENAME});

    } # storefile

    if($self->{STORETAR}) {
	my $tarfile=$self->{STORETARFILE};
	my ($tarcmd,$gz,$cmd);
	my $dir=$tarfile;
	$dir=~s/[^\/]*$//gs;

	$nr=0;
	if(-f $tarfile) {
	    my($fn);
	    open(IN,"tar tf $tarfile|");
	    while($fn=<IN>) {
		if($fn=~/_(\d+)./) {
		    $nr=$1*1 if ($1>$nr);
		}
	    }
	    close(IN);
	    $tarcmd="tar uf "; 
	} else {
	    $nr=0;
	    $tarcmd="tar cf "; 
	}
	$nr++;
	$self->{CNT}=$nr;
	$self->{FILENAME}=sprintf($self->{FILENAMEMASK}.".gz",$self->{CNT});
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},$self->{OPTSECTION},"CNT",$self->{CNT});
	$self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},$self->{OPTSECTION},"FILENAME",$self->{FILENAME});
	$gz = gzopen("$dir/$self->{FILENAME}","wb") ;
	$gz->gzwrite($self->{DATA});
	$gz->gzclose();
	$cmd="(cd $dir;$tarcmd $tarfile $self->{FILENAME})";
	print $cmd,"\n";
	system($cmd);
	unlink("$dir/$self->{FILENAME}");

    } # storetar
    
    return(1);
}

1;







