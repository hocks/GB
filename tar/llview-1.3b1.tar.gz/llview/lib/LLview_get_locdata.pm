# $Source: /cvs/cvsroot/llview/lib/LLview_get_locdata.pm,v $
# $Author: zdv087 $
# $Revision: 1.24 $
# $Date: 2007/07/05 15:48:49 $
#
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_get_locdata;
use strict;
use Time::HiRes qw ( time );
use Compress::Zlib;
use Archive::Tar;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_get_locdata: new %s\n",ref($proto)) if($debug>=3);

    $self->{CLUSTERNAME} = shift||"-"; # needed for button callback function 

    $self->{VERBOSE}      = 0;
     $self->{PATHTOFILE}    = "~/data/llview";
#    $self->{PATHTOFILE}    = "/home/zam/zdv087/data/llview";
    $self->{FILENAME}      = "llqxml_00000001.xml";
    $self->{FILENAMEMASK}  = "llqxml_%08d.xml";
    $self->{READTAR} =1;
    $self->{READTARFILE} = "../../data/llview/llview_data_23.02.05.tar";
    $self->{LASTTARFILE} = "";
    $self->{LASTFILE} = "";
    $self->{READFILE}=0;
    $self->{READDIR} = "../data_www";
    $self->{LOOP}=0;
    $self->{START}        = 1;
    $self->{CNT}          = 1;
    $self->{LASTCNT}      = 1;
    $self->{STEP}         = 1;
    $self->{MAXCNT}       = 2999;
    $self->{DATA}          = "";
    $self->{DATAOBJ}       = ""; # only for memory size debugging
    $self->{ERRSTRING} = "<>";
    $self->{TAROBJ} = Archive::Tar->new;
    bless $self, $class;
    return $self;
}

sub init_options {
    my($self) = shift;
    my($optobj) = shift;
    $self->{OPTIONOBJECT}=$optobj;
    $optobj->register_option("LocalData","START", -label => "starting number", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 200000, -default => $self->{START}, -step => 100);
    $optobj->register_option("LocalData","MAXCNT", -label => "max number", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 200000, -default => $self->{MAXCNT}, -step => 100);
    $optobj->register_option("LocalData","STEP", -label => "step #", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 1, -max => 1000, -default => $self->{STEP}, -step => 10);
    $optobj->register_option("LocalData","LOOP", -label => "Loop over data", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{LOOP});

    $optobj->register_option("LocalData","READFILE", -label => "Read from Files", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{READFILE});
    $optobj->register_option("LocalData","PATHTOFILE", -label => "Path to File", 
			     -caller => $self,-pack => 1,
			     -type => "dirselect", -default => $self->{PATHTOFILE},-updatereq => 1);
    $optobj->register_option("LocalData","READTAR", -label => "Read from Tar-File", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{READTAR});
    $optobj->register_option("LocalData","READTARFILE", -label => "File (tar)", 
			     -caller => $self,-pack => 1,
			     -type => "fileselect", -default => $self->{READTARFILE},-updatereq => 1);
    $optobj->register_option("LocalData","FILENAMEMASK", -label => "Filename Mask", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FILENAMEMASK});
    $optobj->register_option("LocalData","CNT", -label => "actual number", 
			     -caller => $self,-pack => 1,
			     -type => "intscale", -min => $self->{START}, -max => $self->{MAXCNT}, 
			     -default => $self->{CNT}, -step => 100,
			     -updatereq => 1);
    $optobj->register_option("LocalData","FILENAME", -label => "actual filename", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FILENAME});

}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id,$objname);
    print "locdata,optvalchanged: $section,$name -> $val\n" if($self->{VERBOSE});
    if($name eq "START") {
	$self->{$name}=$val;
	$self->{"CNT"}=$self->{"START"} if($self->{"CNT"}<$self->{"START"});
    }
    if($name eq "CNT") {
	$self->{"LASTCNT"}=$self->{"CNT"};
	$self->{"CNT"}=$val;
	$self->{"CNT"}=$self->{"MAXCNT"} if($self->{"CNT"}>$self->{"MAXCNT"});
	$self->{"CNT"}=$self->{"START"} if($self->{"CNT"}<$self->{"START"});
    }
    if($name eq "MAXCNT") {
	$self->{$name}=$val;
	$self->{"CNT"}=$self->{"MAXCNT"} if($self->{"CNT"}>$self->{"MAXCNT"});
    }
    if($name eq "STEP") {
	$self->{$name}=$val;
    }

    if (   ($name eq "PATHTOFILE")
	   || ($name eq "FILENAMEMASK")
	   || ($name eq "READFILE")
	   || ($name eq "READDIR")
	   || ($name eq "READTAR")
	   || ($name eq "READTARFILE")
	   || ($name eq "LOOP")
	   )  {
	print "WF: $name->$val\n" if($debug==5);
	$self->{$name}=$val;
    }
 
}


sub getdata {
    my($self) = shift;
    my($line,$sep,$rc);
    my($apath);
    $self->{DATAOBJ}->printsize("getdata: start of routine") if($debug==5);


    if($self->{READFILE}) {
	my ($minnr,$maxnr,$buffer,$file);
	$minnr=100000;
	$maxnr=0;
	$self->{FILENAME}=sprintf($self->{FILENAMEMASK},$self->{CNT});
	$apath=$self->{PATHTOFILE};
	$apath=~s/^~/$ENV{HOME}/se;

	if($self->{FILENAME} ne $self->{LASTFILE}) {
	    if(-d $apath) {
		my($fn);
		$rc=opendir(DIR,$apath);
		while($fn=readdir(DIR)) {
		    if($fn=~/_(\d+)./) {
			$minnr=$1*1 if ($1<$minnr);
			$maxnr=$1*1 if ($1>$maxnr);
		    }
		}
		closedir(DIR);
		$self->{LASTFILE}=$self->{FILENAME};
		$self->{START}=$minnr;
		$self->{MAXCNT}=$maxnr;
	    }
	}


	printf("\t LLview_get_locdata: reading %s\n",$apath."/".$self->{FILENAME}) if($self->{VERBOSE});
	$sep=$/; $/="\0";
	open(IN,$apath."/".$self->{FILENAME});
	$self->{DATA}=<IN>;
	close(IN);
#	print $self->{DATA};
	$/=$sep;
	# CNT not change through option panel since last update
	print "WF: CNT<>LASTCNT ",$self->{CNT},",",$self->{LASTCNT},"\n" if($debug>=3);
	if($self->{CNT}==$self->{LASTCNT}) {
	    $self->{CNT}+=$self->{STEP};
	    $self->{CNT}=$self->{START} if($self->{CNT}>=$self->{MAXCNT});
	    $self->{CNT}=$self->{START} if($self->{CNT}<=$self->{START});
	    $self->{LASTCNT}=$self->{CNT};
	}
	if(exists($self->{OPTIONOBJECT})) {
	    $self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"LocalData","START",$self->{START});
	    $self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"LocalData","MAXCNT",$self->{MAXCNT});
	    $self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"LocalData","CNT",$self->{CNT});
	    $self->{OPTIONOBJECT}->update_scale_minmax($self->{CLUSTERNAME},"LocalData","CNT",$self->{START},$self->{MAXCNT});
	    $self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"LocalData","FILENAME",$self->{FILENAME});
	}
	$self->{DATAOBJ}->printsize("getdata: end of routine") if($debug==5);
    } 
    if($self->{READTAR}) {
	my $tarfile=$self->{READTARFILE};
	my ($tarcmd,$gz,$cmd,$minnr,$maxnr,$buffer,$file);
	my $dir=$tarfile;
	$dir=~/([^\/]*)$/s;
	$file=$1;
	$dir=~s/[^\/]*$//gs;
	$minnr=100000;
	$maxnr=0;

	if($tarfile ne $self->{LASTTARFILE}) {
	    if(-f $tarfile) {
		my($fn);
		print "new tar file: $tarfile\n" if($self->{VERBOSE});
		$self->{TAROBJ}->read($tarfile);

#		$rc=open(IN,"tar tf $tarfile|");
		foreach $fn ($self->{TAROBJ}->list_files()) {
		    if($fn=~/_(\d+)./) {
			$minnr=$1*1 if ($1<$minnr);
			$maxnr=$1*1 if ($1>$maxnr);
		    }
		}
		$self->{LASTTARFILE}=$tarfile;
		$self->{START}=$minnr;
		$self->{MAXCNT}=$maxnr;
	    }
	}
	
	# CNT not change through option panel since last update
	if($self->{CNT}==$self->{LASTCNT}) {
	    print "WF: CNT==LASTCNT ",$self->{CNT},",",$self->{LASTCNT},",$self->{STEP}\n" if($self->{VERBOSE});
	    $self->{CNT}+=$self->{STEP};
	    $self->{CNT}=$self->{START} if($self->{CNT}>=$self->{MAXCNT});
	    $self->{CNT}=$self->{START} if($self->{CNT}<=$self->{START});
	} else {
	    print "WF: CNT<>LASTCNT ",$self->{CNT},",",$self->{LASTCNT},"\n" if($self->{VERBOSE});
	}
	$self->{LASTCNT}=$self->{CNT};
	$self->{FILENAME}=sprintf($self->{FILENAMEMASK}.".gz",$self->{CNT});
	if(exists($self->{OPTIONOBJECT})) {
	    $self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"LocalData","START",$self->{START});
	    $self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"LocalData","MAXCNT",$self->{MAXCNT});
	    $self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"LocalData","CNT",$self->{CNT});
	    $self->{OPTIONOBJECT}->update_scale_minmax($self->{CLUSTERNAME},"LocalData","CNT",$self->{START},$self->{MAXCNT});
	    $self->{OPTIONOBJECT}->update_optval($self->{CLUSTERNAME},"LocalData","FILENAME",$self->{FILENAME});
	}
	print "WF: get_locdata tarfile=$tarfile\n" if($self->{VERBOSE});
	if(-f $tarfile) {
	    print "self->{TAROBJ}->get_content($self->{FILENAME});\n" if($debug>=3);
	    my $gzdata=$self->{TAROBJ}->get_content($self->{FILENAME});
	    $self->{DATA}=Compress::Zlib::memGunzip($gzdata);
#	    print "WF: ",length($gzdata),"\n";
#	    print "WF: ",$self->{DATA},"\n";
#	    $cmd="(cd $dir;tar xvf $file $self->{FILENAME})";
#	    print $cmd,"\n";
#	    system($cmd);
#	    if(-f "$dir/$self->{FILENAME}") {
#		$gz = gzopen("$dir/$self->{FILENAME}","rb") ;
#		$self->{DATA}="";
#		$self->{DATA}.=$buffer while $gz->gzread($buffer) > 0 ;
#		$gz->gzclose();
#		unlink("$dir/$self->{FILENAME}");
#	    }
	} else {return(0);}
    }
    return(1);
}

1;
