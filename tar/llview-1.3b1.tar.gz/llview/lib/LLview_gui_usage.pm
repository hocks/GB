# $Source: /cvs/cvsroot/llview/lib/LLview_gui_usage.pm,v $
# $Author: zdv087 $
# $Revision: 1.22 $
# $Date: 2007/07/12 20:49:16 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_usagegraph;
use strict;
use Time::Local;
use Data::Dumper;

# for callback functions
#my($selfref)=-1;

my($debug)=0;

my @hex = ("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
my %hextod = ("0" => 0,"1" => 1,"2" => 2,"3" => 3,"4" => 4,"5" => 5,"6" => 6,"7" => 7,
	      "8" => 8,"9" => 9,"A" => 10,"B" => 11,"C" => 12,"D" => 13,"E" => 14,"F" => 15);

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_gui_usage: new %s\n",ref($proto)) if($debug>=3);
    $self->{HAVEINFOMSG} = 0;
    $self->{POSX}       = 668;
    $self->{POSY}       = 288;
    $self->{WIDTH}      = 326;
    $self->{HEIGHT}     = 130;
    $self->{FONT1}      = "-*-Helvetica-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}     = "-*-Helvetica-Bold-R-Normal--*-80-*-*-*-*-*-*";
    $self->{ITEMS}      = [];
    $self->{LEFTPAD}    = 25;
    $self->{RIGHTPAD}    = 0;
    $self->{BOTTOMPAD}  = 25;
    $self->{COLORRUNNING} = "RoyalBlue";
    $self->{COLORALLOC}   = "Lightskyblue";
    $self->{RUNNINGTEXT}  = "running";
    $self->{ALLOCTEXT}    = "allocated";

    $self->{NUMENTRIES}   = 0;
    $self->{STEP}         = 0.25;
    $self->{STEPSEC}      = 900;
    $self->{MAXLOGENTRIES}= 288;  # hours
    $self->{STARTDATE}    = "";
    $self->{ENDDATE}      = "";
    $self->{DATEHIST}     = []; # only for local history
    $self->{NODESHIST}    = [];
    $self->{RUNNINGHIST}  = [];
    $self->{ALLOCHIST}    = [];
    $self->{NUMHIST}      = [];
    $self->{DX}           = 1;
    $self->{DY}           = 1;
    $self->{BUILDREADY}=0;
    bless $self, $class;
#    if($selfref==-1)  {
#	$selfref=\$self;
#    } else {
#	printf("WARNING: double constructor call to LLview_gui_usagegraph ...\n")
#    }
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj,$tabname)=@_;
    my($i,$name,$section);
    my $frames=$dataobj->{FRAMES};

#    print "WF: usagegraph, build: ",caller(),"\n";

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;
    $self->{OPTIONOBJECT}=$optobj;

    $section="UsageGraph" if (!$tabname);
    $section="UGraph_$tabname" if ($tabname);

    $optobj->register_option($section,"POSX", -label => "posx", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option($section,"POSY", -label => "posy", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSY}, -step => 10);

    $optobj->register_option($section,"HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 400, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option($section,"WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option($section,"COLORRUNNING", -label => "Color for running jobs", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{COLORRUNNING});

    $optobj->register_option($section,"COLORALLOC", -label => "Color for allocated blocks", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{COLORALLOC});

    $optobj->register_option($section,"RUNNINGTEXT", -label => "Text for Running", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{RUNNINGTEXT});

    $optobj->register_option($section,"ALLOCTEXT", -label => "Text for Allocated", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{ALLOCTEXT});

    $optobj->register_option($section,"MAXLOGENTRIES", -label => "max. Log Entries", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 50, -max => 200, -default => $self->{MAXLOGENTRIES}, -step => 10);

    $optobj->register_option($section,"STEPSEC", -label => "sample step in seconds", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 0, -max => 24, -default => $self->{STEPSEC}, -step => 1);

    $optobj->register_option($section,"Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option($section,"BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT1});
   
   
    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{BUILDREADY}=1;

    return();
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id);
#    print "resgraph_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY}) #$#{$self->{USAGE}}\n";

    if ($name eq "Font") {
	$self->{FONT1}=$val;
    } elsif ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
    } else {
	$self->{$name}=$val;
    }

    if ($name eq "STEPSEC") {
	$self->{STEP}=$self->{$name}/3600;
	$self->init_local_buffer()  if ($self->{BUILDREADY});
    }

    if ($name eq "MAXLOGENTRIES") {
	$self->init_local_buffer() if ($self->{BUILDREADY});
    }
    
    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS}) if ($self->{BUILDREADY});
    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{INFOOBJECT},$self->{CANVAS},1) if ($self->{BUILDREADY});
 
}

sub register_color_object {
    my($self) = shift;
    my($name,$objref) = @_;
    $self->{COLOROBJECT}=$objref;
    return 1;
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name);
    my($LEFT_ICON,$left,$leftsubwidget,$leftframe);
    my($RIGHT_ICON,$right,$rightsubwidget,$rightframe);
    my($percent,$px,$py,$dx,$dy);

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    $id=$canvas->createRectangle($self->{POSX},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH},
				 $self->{POSY}+$self->{HEIGHT},
				 -fill => "grey80", -tags => ["usagegraph"]);
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createRectangle($self->{POSX}+$self->{LEFTPAD},$self->{POSY},
				 $self->{POSX}+$self->{WIDTH}-$self->{RIGHTPAD},
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD},
				 -fill => "grey60", -tags => ["usagegraph"]);
    push(@{$self->{FIXEDITEMS}},$id);
    
    foreach $percent  (0,25,50,75,100) {
	$id=$canvas->createText( $self->{POSX}+$self->{LEFTPAD}-2,
				 $self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD}
				 -$percent/100.0
				 *($self->{HEIGHT}-$self->{BOTTOMPAD})
				 -(($percent==0)?5:0)
				 +(($percent==100)?5:0),
				 -text => "$percent%",
				 -anchor => 'e',
				 -font => $self->{FONT1});
	push(@{$self->{FIXEDITEMS}},$id);
    }
#    $self->{INFOOBJECT}->register_bind("usagegraph",$self);
    $self->{INFOOBJECT}->register_bind_motion("usagegraph",$self);


    $py=$self->{POSY}+$self->{HEIGHT};
    $px=$self->{POSX}+10;
    $dx=($self->{WIDTH}-10)/200;
    $id=$canvas->createRectangle($px+50*$dx,$py-12,
				 $px+70*$dx,$py-8,
				 -fill => $self->{COLORRUNNING});
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createText($px+72*$dx,$py-15, -anchor => "nw",
			    -text => $self->{RUNNINGTEXT},-fill => "grey30",-font => $self->{FONT1});
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createRectangle($px+110*$dx,$py-12,
				 $px+130*$dx,$py-8,
				 -fill => $self->{COLORALLOC});
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createText($px+132*$dx,$py-15, -anchor => "nw",
			    -text => $self->{ALLOCTEXT},-fill => "grey30",-font => $self->{FONT1});
    push(@{$self->{FIXEDITEMS}},$id);

}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$nonewdata)=@_;
    my($i,$cpus,$jobid,$id,$maxnodes,$maxnumber,$nodes,$nodelist,$spec,$node,$book);
    my($px,$py,$dx,$dy,$ldy1,$ldy2);
    my($s);
    my(@rpoints);
    my(@apoints);
    return() if (!exists($dataobj->{USAGE}));
    my $usageref=$dataobj->{USAGE};

    
    if(exists($usageref->{numhist})) {
	# get history from xml file
	$self->update_from_xml($usageref);
    } else {
	$self->update_from_xml_local($usageref);
    }
    return() if($self->{NUMENTRIES}<=0);
    $self->{DX}=$dx=($self->{WIDTH}-$self->{LEFTPAD})/($self->{NUMENTRIES});
    $self->{DY}=$dy=($self->{HEIGHT}-$self->{BOTTOMPAD});

    $dataobj->printsize("resgraphupdate: start") if($debug==5);
    $self->clean($dataobj,$colorobj,$canvas);
    $dataobj->printsize("resgraphupdate: after clean") if($debug==5);
    $px=$self->{POSX}+$self->{LEFTPAD};
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    push(@rpoints,$px, $py);
    for($s=0;$s<$self->{NUMENTRIES};$s++) {
	if($self->{NODESHIST}[$s]>0) {
	    $ldy1=$self->{RUNNINGHIST}->[$s]/$self->{NODESHIST}->[$s]*$dy;
	    $ldy2=$self->{ALLOCHIST}->[$s]/$self->{NODESHIST}->[$s]*$dy;
	} else {
	    $ldy1=$ldy2=0.0;
	}
#	$id=$canvas->createRectangle($px,$py,
#				     $px+$dx, $py-$ldy1, -outline => $self->{COLORRUNNING},
#				     -fill => $self->{COLORRUNNING}, -tags => ["usagegraph"]);
#	push(@{$self->{ITEMS}},$id);
	push(@rpoints,$px, $py-$ldy1);
	push(@rpoints,$px+$dx, $py-$ldy1);
#	$id=$canvas->createRectangle($px,$py-$ldy1,
#				     $px+$dx, $py-$ldy1-$ldy2, -outline => $self->{COLORALLOC},
#				     -fill => $self->{COLORALLOC}, -tags => ["usagegraph"]);
#	push(@{$self->{ITEMS}},$id);
	unshift(@apoints,$px,     $py-$ldy1-$ldy2);
	unshift(@apoints,$px+$dx, $py-$ldy1-$ldy2);
	push(@apoints,$px,     $py-$ldy1);
	push(@apoints,$px+$dx, $py-$ldy1);
	$px+=$dx;
    }
    
    push(@rpoints,$px, $py);
    $id=$canvas->createPolygon(@rpoints,
			       -fill => $self->{COLORRUNNING},
			       -outline => "black", 
			       -tags => ["usagegraph"]
			       );
    push(@{$self->{ITEMS}},$id);

    $id=$canvas->createPolygon(@apoints,
			       -fill => $self->{COLORALLOC},
			       -outline => "black", 
			       -tags => ["usagegraph"]
			       );
    push(@{$self->{ITEMS}},$id);
    
    $self->create_timescale($canvas);
    
    $dataobj->printsize("resgraphupdate: end") if($debug==5);
    
    return();
}

sub update_from_xml {
    my($self) = shift;
    my($usageref)=@_;
    if(exists($usageref->{'nodeshist'})) {
	$self->{NUMENTRIES}   = $usageref->{'numentries'};
	$self->{STEP}         = $usageref->{'step'};
	$self->{STARTDATE}    = $usageref->{'startdate'};
	$self->{ENDDATE}      = $usageref->{'enddate'};
	$self->{DATEHIST}     = []; # only for local history
	$self->{NODESHIST}    = [split(":",$usageref->{'nodeshist'})];
	$self->{RUNNINGHIST}  = [split(":",$usageref->{'runninghist'})];
	$self->{ALLOCHIST}    = [split(":",$usageref->{'allochist'})];
	$self->{NUMHIST}      = [split(":",$usageref->{'numhist'})];
    } else {
	$self->{ENDDATE}      = $self->{DATAOBJ}->{MACHSTATE}->{"system_time"};
	$self->{STARTDATE}    = &sec_to_date(&date_to_sec($self->{ENDDATE})-3600*$self->{STEP}*$self->{MAXLOGENTRIES});
    }
#	print "WF: $self->{STARTDATE} .. $self->{ENDDATE}\n";
    


}

sub init_local_buffer {
    my($self) = shift;
    my($enddate,$i,$date);
    if(exists($self->{DATAOBJECT}->{USAGE}->{'date'})) {
	$date=$self->{DATAOBJECT}->{USAGE}->{'date'};
	$enddate=$date;$enddate=~s/:\d\d:\d\d$/:00:00/;
	$self->{ENDDATE}      = $enddate;
	$self->{STARTDATE}    = &sec_to_date(&date_to_sec($self->{ENDDATE})-3600*$self->{STEP}*$self->{MAXLOGENTRIES});
	$self->{NUMENTRIES}   = $self->{MAXLOGENTRIES};
	#init fields
	for($i=0;$i<$self->{MAXLOGENTRIES};$i++) {
	    $self->{NODESHIST}->[$i]    = 0;
	    $self->{RUNNINGHIST}->[$i]  = 0;
	    $self->{ALLOCHIST}->[$i]    = 0;
	    $self->{NUMHIST}->[$i]      = 0;
	}
#	print "WF: init buffer $self->{STARTDATE} .. $self->{ENDDATE}\n";
    }
}

sub update_from_xml_local {
    my($self) = shift;
    my($usageref)=@_;
    my($td,$date,$num,$enddate,$i);
    $date  = $usageref->{'date'};

    # init first log entry?
    if($self->{NUMENTRIES}==0) {
	$self->init_local_buffer();
    }

    # reinit if date is outside current range
    if ( (&timediff($date,$self->{ENDDATE})>3600) || 
	 (&timediff($self->{STARTDATE},$date)>0) ) {
	$self->init_local_buffer();
    }
    
    # new log entry?
    $td=&timediff($date,$self->{ENDDATE});
    while($td>0) {
	# remove oldest entry
	shift(@{$self->{NODESHIST}});
	shift(@{$self->{RUNNINGHIST}});
	shift(@{$self->{ALLOCHIST}});
	shift(@{$self->{NUMHIST}});
	# add new entry
	push(@{$self->{NODESHIST}},0);
	push(@{$self->{RUNNINGHIST}},0);
	push(@{$self->{ALLOCHIST}},0);
	push(@{$self->{NUMHIST}},0);
	$td=&timediff($date,$self->{ENDDATE});
	$self->{STARTDATE}    = &sec_to_date(&date_to_sec($self->{STARTDATE})+3600*$self->{STEP});
	$self->{ENDDATE}    = &sec_to_date(&date_to_sec($self->{ENDDATE})+3600*$self->{STEP});
#    	print "WF: shift buffer $self->{STARTDATE} .. $self->{ENDDATE}\n";
    }
    $td=&timediff($date,$self->{STARTDATE});
    $num=int($td/($self->{STEP}*3600));
    if(($num>=0) && ($num<$self->{MAXLOGENTRIES})) {
	$self->{NODESHIST}->[$num]  +=$usageref->{'nodes'};
	$self->{RUNNINGHIST}->[$num]+=$usageref->{'running'};
	$self->{ALLOCHIST}->[$num]  +=$usageref->{'alloc'};
	$self->{NUMHIST}->[$num]    ++;;
    } else {
	print "LLview_gui_usagegraph: update_from_xml_local wrong index $num $self->{STARTDATE},$date,$self->{ENDDATE}\n";
    }
}

sub generateinfo {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$name,$xpos,$ypos)=@_;
    my($infostr,$nr,$date,$num,$enddate,$id);
    $nr=int(($xpos-$self->{POSX}-$self->{LEFTPAD})/$self->{DX});

#    print "WF: generateinfo $xpos,$ypos $self->{POSX}-$self->{LEFTPAD} $nr\n";
#    $id=$canvas->createRectangle($xpos-1, $ypos-1,
#				 $xpos+1, $ypos+1, -outline => "black",
#				 -fill => "DarkGoldenrod");
#    push(@{$self->{ITEMS}},$id);


    if(($nr>=0) && ($nr<$self->{NUMENTRIES})) {
	$date=&sec_to_date(&date_to_sec($self->{STARTDATE})+$nr*$self->{STEP}*3600);
	$enddate=&sec_to_date(&date_to_sec($self->{STARTDATE})+($nr+1)*$self->{STEP}*3600);
   	$infostr=sprintf("Usage:   date=%s \n",$date);
	$infostr.=sprintf("-------------------------------\n");
	$num=$self->{NUMHIST}->[$nr];
	if($num>0) {
	    $infostr.=sprintf("number of samples   :      %2d\n",$num);
	    $infostr.=sprintf("start date of sample:      %s\n",$date);
	    $infostr.=sprintf("end   date of sample:      %s\n",$enddate);
	    $infostr.=sprintf("number of nodes: (avg.)  %6d \n",$self->{NODESHIST}->[$nr]/$num);
	    $infostr.=sprintf("%-20s: (avg.)  %6d      %5.2f%%\n",$self->{RUNNINGTEXT},
			      $self->{RUNNINGHIST}->[$nr]/$num,
			      $self->{RUNNINGHIST}->[$nr]/$self->{NODESHIST}->[$nr]*100.0
			      );
	    $infostr.=sprintf("%-20s: (avg.)  %6d      %5.2f%%\n",$self->{ALLOCTEXT},
			      $self->{ALLOCHIST}->[$nr]/$num,
			      $self->{ALLOCHIST}->[$nr]/$self->{NODESHIST}->[$nr]*100.0
			      );
	    $infostr.=sprintf("%-20s: (avg.)  %6d      %5.2f%%\n", "free nodes",
			      ($self->{NODESHIST}->[$nr]-$self->{RUNNINGHIST}->[$nr]-$self->{ALLOCHIST}->[$nr])/$num,
			      ($self->{NODESHIST}->[$nr]-$self->{RUNNINGHIST}->[$nr]-$self->{ALLOCHIST}->[$nr])
			      /$self->{NODESHIST}->[$nr]*100.0
			      );	
	}
    }
    
    return($infostr);
}

sub create_timescale {
    my($self) = shift;
    my($canvas)=@_;
    my($id,$px,$py,$h,$step,$diffh);
    my($dx,$now,$now0,$now2l,$daysb,$d,$start0,$start2l,$end2l,$hdx,$maxh);
    my($wdaystr);
    $px=$self->{POSX}+$self->{LEFTPAD};
    $py=$self->{POSY}+$self->{HEIGHT}-$self->{BOTTOMPAD};
    
    $start0=$self->{STARTDATE};$start0=~s/:\d\d:\d\d/:00:00/gs;
    $diffh=&timediff($self->{STARTDATE},$start0)/3600;
    $hdx=$self->{DX}/$self->{STEP};
    $maxh=($self->{NUMENTRIES}*$self->{STEP});
    # adjust step width
    $step=1;
    if($hdx<20) {
	for($step=2;$step<$maxh;$step+=2) {
	    last if ($step*$hdx>20);
	}
    }

    # print hour marker
    for($h=1-$diffh;$h<$maxh;$h++) {
	$id=$canvas->createLine( $px+$h*$hdx, $py+1,
				 $px+$h*$hdx, $py+5,
				 -width => 1,
				 -fill => "grey10",
				 -tags => ["usagegraph"]
				 );
	push(@{$self->{ITEMS}},$id);
#	if($h%$step==0) {
#	    $id=$canvas->createText( $px+$h*$hdx, $py+9,
#				     -text => ($h<=0)?"${h}h":"+${h}h",
#				     -anchor => 'c',
#				     -font => $self->{FONT1});
#	    push(@{$self->{ITEMS}},$id);
#	}
    }


    # time/date at start and end
    $start2l=$self->{STARTDATE};$start2l=~s/-/\n/g;
    $id=$canvas->createText( $px, $py+15,
			     -text => $start2l,
			     -anchor => 'c',
			     -tags => ["usagegraph"],
			     -font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);
    $end2l=$self->{ENDDATE};$end2l=~s/-/\n/g;
    $id=$canvas->createText( $px+$self->{WIDTH}-30, $py+15,
			     -text => $end2l,
			     -anchor => 'e',
			     -tags => ["usagegraph"],
			     -font => $self->{FONT1});
    push(@{$self->{ITEMS}},$id);

    $start0=$self->{STARTDATE};$start0=~s/\d\d:\d\d:\d\d/00:00:00/gs;
    $diffh=&timediff($self->{STARTDATE},$start0)/3600;
    $hdx=$self->{DX}/$self->{STEP};
    for($d=-$diffh+24;$d<$maxh;$d+=24) {
#	print "WF: $d\n";
	$id=$canvas->createLine( $px+$d*$hdx, $py,
				 $px+$d*$hdx, $self->{POSY},
				 -width => 2,
				 -tags => ["usagegraph"],
				 -fill => "grey20"
				 );
	push(@{$self->{ITEMS}},$id);
	$id=$canvas->createRectangle($px+$d*$hdx+2, $py-2,
				     $px+$d*$hdx+2+30, $py-3-10, -outline => "black",
				     -fill => "DarkGoldenrod", -tags => ["usagegraph"]);
	push(@{$self->{ITEMS}},$id);
	$wdaystr=&sec_to_day(&date_to_sec($self->{STARTDATE})+$d*3600);
	$id=$canvas->createText( $px+$d*$hdx+2, $py-7,
				 -text => " $wdaystr ->",
				 -anchor => 'w',
				 -font => $self->{FONT1});
	push(@{$self->{ITEMS}},$id);
	
    }
    return();

}


sub scale {
    my($n)=@_;
#    return($n);
#    printf("log: %2d -> %f\n",$n,log($n)/log(10));
    return(log($n+1)/log(10));
}



sub date_to_sec {
    my ($ldate)=@_;
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$ldate);
    $mon--;
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
#    print "WF: date_to_sec $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $timesec\n";
    return($timesec);
}

sub sec_to_date {
    my ($lsec)=@_;
    my($date);
    my ($sec,$min,$hours,$mday,$mon,$year,$rest)=localtime($lsec);
    $year=sprintf("%02d",$year % 100);
    $mon++;
    $date=sprintf("%02d/%02d/%02d-%02d:%02d:%02d",$mon,$mday,$year,$hours,$min,$sec);
#    print "WF: sec_to_date $lsec -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $date\n";
    return($date);
}

sub sec_to_day {
    my ($lsec)=@_;
    my($wdaystr);
    my ($sec,$min,$hours,$mday,$mon,$year,$wday,$rest)=localtime($lsec);
    
    $wdaystr=("Su","Mo","Tu","We","Th","Fr","Sa")[$wday];
#    print "WF: sec_to_day $lsec -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> wday=$wday wdaystr=$wdaystr\n";
    return($wdaystr);
}

sub timediff {
    my ($date1,$date2)=@_;
#    print"WF: timediff $date1 $date2\n";
    return(-1) if((!$date1) || (!$date2));
    my $timesec1=&date_to_sec($date1);
    my $timesec2=&date_to_sec($date2);
    return($timesec1-$timesec2);
}


1;

