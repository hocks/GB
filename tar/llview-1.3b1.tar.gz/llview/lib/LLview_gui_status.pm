# $Source: /cvs/cvsroot/llview/lib/LLview_gui_status.pm,v $
# $Author: zdv087 $
# $Revision: 1.20 $
# $Date: 2007/07/17 13:04:50 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_status;
use strict;
use Tk::StatusBar;

my($debug)=0;
my($instancecnt)=-1;
my(@selfref)=(-1);
my($progressvalue0,$progressvalue1,$progressvalue2,$progressvalue3)=(0,0,0,0);

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
#    print  "WF: LLview_gui_status new from ",caller(),"\n";
    printf("\t\LLview_gui_status: new %s\n",ref($proto)) if($debug>=3);
    $self->{HAVEINFOMSG} = 0;
    $self->{VERBOSE} = 0;
    $self->{POSX}    = 0;
    $self->{POSY}    = 860;
    $self->{WIDTH}   = 70;
    $self->{PROGRESSWIDTH} = 400;
    $self->{PROGRESSSTART} = 0;
    $self->{PROGRESSSTOP} =  100;
    $self->{PROGRESSBLOCKS} =  10;
    $self->{HEIGHT}  = 1;
    $self->{TEXT}    = "<no information>";
    $self->{FGCOL}   = "grey20";
    $self->{BGCOL}   = "grey85";
    $self->{TEXT}="<no status>";
    $self->{STARTEDAT}=localtime(time());
    chomp($self->{STARTEDAT});
    $self->{UPDATES}=0;
    $self->{ERRFILE}=undef;
    $self->{ERRFILETEXT}="";
    $self->{ITEMS}      = [];
    $self->{FIXEDITEMS} = [];
    $self->{FONT0}       = "-*-Courier-Medium-R-Normal--*-100-*-*-*-*-*-*";
    $self->{BFONT0}      = "-*-Courier-Bold-R-Normal--*-100-*-*-*-*-*-*";

    $self->{BUILDREADY}=0;

    bless $self, $class;
    $instancecnt++;
    $self->{INSTANCENR} = $instancecnt;
    $selfref[$instancecnt]=\$self;
    $self->{PROGRESSVALREF} = \$progressvalue0 if($instancecnt==0);
    $self->{PROGRESSVALREF} = \$progressvalue1 if($instancecnt==1);
    $self->{PROGRESSVALREF} = \$progressvalue2 if($instancecnt==2);
    $self->{PROGRESSVALREF} = \$progressvalue3 if($instancecnt==3);
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj)=@_;
    my($i,$name);
    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;

    my $frames=$dataobj->{FRAMES};


    $optobj->register_option("Status","POSX", -label => "posx", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option("Status","POSY", -label => "posy", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSY}, -step => 10);

    $optobj->register_option("Status","HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option("Status","WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option("Status","FGCOL", -label => "Foreground color", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FGCOL});

    $optobj->register_option("Status","BGCOL", -label => "Background color", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BGCOL});

    $optobj->register_option("Status","PROGRESSWIDTH", -label => "Width of ProgressBar", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 1200, -default => $self->{PROGRESSWIDTH}, -step => 10);

    $optobj->register_option("Status","Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT0});
    $optobj->register_option("Status","BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT0});

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});

    $self->{BUILDREADY}=1;

    return(1);
}

sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id);
#    print "status_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY})\n"  if($self->{VERBOSE});
    if(($name eq "HEIGHT") || ($name eq "WIDTH")) {
	$self->{$name}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    if( ($name eq "POSX") || ($name eq "POSY")) {
	$diffx=$diffy=0;
	$diffx=$val-$self->{$name} if ($name eq "POSX");
	$diffy=$val-$self->{$name} if ($name eq "POSY");
	$self->{$name}=$val;
	foreach $id (@{$self->{FIXEDITEMS}}) {
	    $self->{CANVAS}->move($id,$diffx,$diffy)  if ($self->{BUILDREADY});
	}
	if ($self->{BUILDREADY}) {
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    if (($name eq "FGCOL") || ($name eq "BGCOL")) {
	$self->{$name}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }

    if ($name=~/^PROGRESS/) {
	$self->{$name}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    if ($name eq "Font") {
	$self->{FONT0}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    if ($name eq "BoldFont") {
	$self->{BFONT0}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
 
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name);

#    $self->{PROGRESSBAR}->destroyed() if($self->{PROGRESSBAR});
    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    $id=$self->{STATUSBAR}=$canvas->StatusBar(-width          => $self->{WIDTH});
    push(@{$self->{FIXEDITEMS}},$id);
    $id=$canvas->createWindow($self->{POSX},$self->{POSY}, 
			      -window => $self->{STATUSBAR}, -anchor => "nw");
    push(@{$self->{FIXEDITEMS}},$id);

    $id=$self->{LABEL}=$self->{STATUSBAR}->addLabel(-anchor         => 'w',
						    -width          => $self->{WIDTH}, 
						    -textvariable   => \$self->{TEXT},
						    -font => $self->{FONT0}, 
						    -background => $self->{BGCOL},
						    -foreground => $self->{FGCOL},
						    );
    push(@{$self->{FIXEDITEMS}},$id);

    $id=$self->{PROGRESSBAR}=$self->{STATUSBAR}->addProgressBar(-length  => $self->{PROGRESSWIDTH},
							  -from => $self->{PROGRESSSTART},
							  -to =>   $self->{PROGRESSSTOP},
							  -blocks => $self->{PROGRESSBLOCKS},
							  -colors => [0, 'grey30', 50, 'grey30' , 80, 'grey30'],
							  -variable => \$progressvalue0,
							  -background => $self->{BGCOL}
							 );
    push(@{$self->{FIXEDITEMS}},$id);
#    $progressvalue0=0;
    if(0) {
	$id=$self->{MSGAREA}=$canvas->Label(-borderwidth => 1, -relief => "flat", 
					    -width => $self->{WIDTH}, 
					    -height => $self->{HEIGHT}, 
					    -font => $self->{FONT0}, 
					    -anchor => "nw",-justify => 'left',
					    -background => $self->{BGCOL},
					    -foreground => $self->{FGCOL},
					    -textvariable => \$self->{TEXT});
	push(@{$self->{FIXEDITEMS}},$id);
	$id=$canvas->createWindow($self->{POSX},$self->{POSY}, 
				  -window => $self->{MSGAREA}, -anchor => "nw");
	push(@{$self->{FIXEDITEMS}},$id);
    }

}

sub set_errfile {
    my($self) = shift;
    my($errfile)=@_;
    my($txt);
    if($errfile) {
	$self->{ERRFILE}=$errfile;
	if(open(ERRFILE,$self->{ERRFILE})) {
	    $txt=<ERRFILE>;
	    chomp($txt);
	    if($txt) {
		$self->{ERRFILETEXT}=", last err: ".$txt;
	    }
	    close(ERRFILE);
	}
    }
    $self->{TEXT}=sprintf("#%d updates, started at %s %s",$self->{UPDATES},$self->{STARTEDAT},$self->{ERRFILETEXT});
        
    return();
}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;

    $self->{UPDATES}++;
    $self->{TEXT}=sprintf("#%d updates, started at %s %s",$self->{UPDATES},$self->{STARTEDAT},$self->{ERRFILETEXT});
        
    return();
}

sub progress {
    my($self) = shift;
    my($start,$stop,$value)=@_;
    if(($self->{PROGRESSSTART}!=$start) || ($self->{PROGRESSSTOP}!=$stop)) {
#	print "WF: set progress $self->{PROGRESSSTART},$self->{PROGRESSSTOP} to $start,$stop value=$value\n";
	$self->{PROGRESSSTART}=$start;
	$self->{PROGRESSSTOP}=$stop;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS},1);
	}
    }
    ${$self->{PROGRESSVALREF}}=$value;
    return();
}


1;
