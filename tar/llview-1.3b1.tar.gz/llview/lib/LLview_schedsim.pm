# $Source: /cvs/cvsroot/llview/lib/LLview_schedsim.pm,v $
# $Author: zdv087 $
# $Revision: 1.37 $
# $Date: 2007/07/18 08:09:56 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_schedsim;
use strict;
use Time::Local;
use Time::HiRes qw ( time );
use Data::Dumper;
my($debug)=2;
my($instancecnt)=-1;
my(@selfref)=(-1);

sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_schedsim: new %s\n",ref($proto)) if($debug>=3);
    $self->{VERBOSE}        = 0;

    # options
    $self->{PROTO}          = 1;
    $self->{PROTOOPEN}      = 0;
    $self->{PRINTPROGRESS}  = 1;
    $self->{PRINTSTAT}      = 1;
    $self->{PROTOPREFIX}    = "> ";
    $self->{PROTO_FILENAME} = "schedsim.log";

    # scheduler option
    $self->{BACKFILLING}    = 1;
    $self->{NUMTOPDOGS}     = 1;

    # for debugging
    $self->{MAXNUMJOBS}         = 80000;

    
    # optimization features
    $self->{KINDCHECKING}   = 1;
    
    # INTERNAL DATA STRUCTURES
    
    # system specific
    $self->{SYSTEMTIME} = "";
    $self->{SYSTEM_IS_BGL} = 0;

    # node based
    $self->{DEFAULTSTATE}={};
    $self->{ACTSTATE}={};
    $self->{NODESTATEREF}    = [];      # pointer to node information
    $self->{NODESTATENAME}   = [];      # name of node
    $self->{NODESTATENR}     = {};

    # BGL special
    $self->{SHAPE3D}       = ();        # BGL: three-dimensional array containing number of node for pos x,y,z
    $self->{SHAPE3DXMAX}   = -1;        # BGL: dim in x-direction 
    $self->{SHAPE3DYMAX}   = -1;        # BGL: dim in y-direction 
    $self->{SHAPE3DZMAX}   = -1;        # BGL: dim in z-direction 

    $self->{FRAMES}          = -1;
    $self->{CHECKMAXSTARTER} = 0;
    $self->{OUTDATA}         = {};

    $self->{MAXJOBS}         = [];
    $self->{MAXJOBSUSER}     = [];


    $self->{TIMELINE}        = [];
    $self->{TOPDOGS} = {};    

    $self->{STAT}    = {};

    bless $self, $class;

    $instancecnt++;
    $self->{INSTANCENR} = $instancecnt;
    $selfref[$instancecnt]=\$self;

    return $self;
}


################################################################################################################
# description of internal variables
################################################################################################################
# 
# Node based:
# $self->{NODESTATEREF}->[$n];              pointer to node information
# $self->{NODESTATENAME}->[$n];             name of node
# $self->{NODESTATENR}->{$node} = $nodenr;

# Data structure derscribing state of nodes 
#
# {STATE} -> {STARTERS}->[$classnr]               starters per class on all nodes     (#cpus)
#         -> {STARTERS_ONNODE}->[$n]->[$classnr]  starters per class on node $n       (#cpus)
#         -> {FREECPUS}                           number of free cpus on all nodes    (#cpus)
#         -> {FREECPUS_ONNODE}->[$n]              number of free cpus on node $n      (#cpus)
#         -> {USEDCPUS}                           number of used cpus on all nodes    (#cpus)
#         -> {USEDCPUS_ONNODE}->[$n]              number of used cpus on node $n      (#cpus)
#         -> {TIMESTAMPH}                         timestamp in hours 
#         -> {STARTEDJOBS}->[$c]                  act. starter per class              (#jobs)
#         -> {STARTEDJOBSUSER}->[$class]->{$user} act. starter per user in this class (#jobs)
#         -> 
# $self->{TOPDOGS}->{$jobid}                      hash of actual defined topdogs
#   
# $self->{CHECKMAXSTARTER}                        Flag, if max starters info is available
# $self->{MAXJOBS}->[$class]                      max. starter per class
# $self->{MAXJOBSUSER}->[$class]                  max. starter per user in this class
#
# needed for scheduling:
# $self->{DEFAULTSTATE} status of nodes at actual time point
# $self->{ACTSTATE} status of nodes at actual time point
#
# information at starting time of first topdog
# $self->{NODEACTSTARTERSTOPDOG}->[$n]->{$class}: number of starters of this class on this node 
# $self->{FREECPUSTOPDOG}->[$n]:                  number of free cpus on node          
#
#
# for dependency check
# $self->{STEPNAMES}->{$sjobid}->{$stepname}=$jobid   sjobid jobid without stepnumber
#
# $self->{CLASS2NR}->{$class}=$i;
# $self->{NR2CLASS}->[$i]=$class;
#

#
# Node base, dynamic:
# $self->{TIMELINE_CLASSFREE}->[$i]->[$classnr]=$starters
#
#
# $self->{MAINTENANCE_START}                 vector of maintenance times
# $self->{MAINTENANCE_END}
#
#



################################################################################################################
# Documentation of data structure indata, describing system, node and job state 
#
# indataref -> 
#           {MACHSTATE}->{system_time}                     : timestamp of snapshot of system state
#           {MACHSTATE}->{system_type}                     : type of system (BG/L)
#       
#           {NODES}->{$node}->{node_avail_classes}         : list of classes and starters available for this node    
#       
#           {CLASSES}->{ConfiguredClasses}                 : list of classes and maxstarters (maxclass,maxuser)
#                                                          : e.g. "n4096(1,-1) n2048(2,2) n1024(7,-1)"
#           
#
# simulate() returns data structure reference:
#       
# $self->{OUTDATA}->{JOBINFO}->{$jobid} ->{starttimeH}
#                                       ->{endtimeH}
#                                       ->{usedH}
#                                       ->{cpus}
#                                       ->{prednodelist}  
#                                       ->{TopDogLevel}    : 0 not scheduled as topdog, 1++ topdog
# $self->{OUTDATA}->{JOBSTATE}->{$jobid}                   : state (running,waiting,hold,removed,completed,ready)

#       
################################################################################################################


sub simulate {
    my($self) = shift;
    my($indataref)=shift;
    my(%params)=@_;
    my($helpref);

    $self->set_params(%params);

    $self->PROTO_clear();
    $self->PROTO_open();

    $self->PROTO_header($indataref);

    $self->PROTO_setprefix("Cleanup:     ");
    $self->clean();
    $self->{OUTDATA}={};

    $self->PROTO_setprefix("Initialize:  ");
    $self->scan_system($indataref);

    $helpref={};
    $self->scan_nodedata($indataref,$helpref);
    $self->{ACTSTATE}    = $self->copy_state($helpref,"ALL");
    $self->{DEFAULTSTATE}= $self->copy_state($helpref,"ALL");
    # class mapipng is now defined
    $helpref=undef;

    $self->scan_reservations($indataref,$self->{DEFAULTSTATE});

    $self->PROTO_print_node_state($self->{DEFAULTSTATE},"DEFAULT node state");
    $self->PROTO_print_node_state($self->{ACTSTATE},"ACT node state");

    $self->scan_classlimits($indataref);

    $self->PROTO_setprefix("ScanJobs:    ");
    $self->scan_jobs($indataref);

    $self->PROTO_setprefix("RunningJobs: ");
    $self->insert_running_jobs($indataref,$self->{ACTSTATE},$self->{TIMELINE});

    $self->PROTO_print_timeline($self->{TIMELINE},$indataref,0,"after inserting all running jobs");

    $self->PROTO_setprefix("RunningJobs: ");
    $self->insert_reservations($indataref,$self->{ACTSTATE},$self->{TIMELINE});

    $self->PROTO_print_timeline($self->{TIMELINE},$indataref,0,"after inserting reservation");

    $self->PROTO_setprefix("Simulate:    ");

    $self->insert_waiting_jobs($indataref,$self->{ACTSTATE},$self->{TIMELINE});

    $self->PROTO_close();

    return($self->{OUTDATA});
}


################################################################################################################
# extract data 
################################################################################################################
sub scan_system  {
    my($self) = shift;
    my($indataref) = @_;

    $self->{SYSTEMTIME}    = $indataref->{'MACHSTATE'}->{'system_time'};
    $self->{SYSTEM_IS_BGL} = 1 if($indataref->{'MACHSTATE'}->{'system_type'} eq "BG/L");
   
}

sub scan_nodedata  {
    my($self) = shift;
    my($indataref,$stateref) = @_;
    my($n,$node,$name,$frames,$nodenr,$pair,$cpus);
    my(%classnames);
    $frames=scalar keys(%{$indataref->{NODES}});

    
    # scan for class names
    foreach $node (sort (keys(%{$indataref->{NODES}}))) {
	my $classes=$indataref->{NODES}->{$node}->{"node_avail_classes"};
	my @classes=split(/\),?\(/,$classes);
	foreach $pair (@classes) {
	    my($class,$num)=($pair=~/\(?(.*),(\d+)\)?/gs);
	    $classnames{$class}++;
	}
    }
    if(defined($indataref->{CLASSES})) {
	if(defined($indataref->{CLASSES}->{"ConfiguredClasses"})) {
	    foreach my $spec (split(/\s+/,$indataref->{CLASSES}->{"ConfiguredClasses"})) {
		$spec=~/(.*)\((.*),(.*)\)/gs;
		my ($class,$maxclass,$maxuser)=($1,$2,$3);
		$classnames{$class}++;
	    }    
	}
    }
    # build list of classes and mapping between classnr and classname
    my $classnr=0;
    foreach my $class (sort(keys(%classnames))) {
	$self->{CLASS2NR}->{$class}=$classnr;
	$self->{NR2CLASS}->[$classnr]=$class;
	$classnr++;
    }

    foreach $node (sort (keys(%{$indataref->{NODES}}))) {
	$nodenr++;
	$self->{NODESTATEREF}->[$nodenr]  = $indataref->{NODES}->{$node};
	$self->{NODESTATENAME}->[$nodenr] = $node;
	$self->{NODESTATENR}->{$node}     = $nodenr;
    }

    $stateref->{FREECPUS}=0;
    $stateref->{USEDCPUS}=0;
    $stateref->{TIMESTAMPH}=0;

    # scan nodes
    for($n=1;$n<=$frames;$n++) {
 	$name=$self->{NODESTATENAME}->[$n];
	
	# Blue Gene Torus information
 	if( $self->{SYSTEM_IS_BGL}) {
	    $name=~/R(\d)(\d)-M(\d)/;
	    my ($x,$y,$z)=($1,$2,$3);
	    $self->{SHAPE3D}->[$x][$y][$z]=$n;
	    $self->{SHAPE3DXMAX}=$x if($self->{SHAPE3DXMAX}<$x);
	    $self->{SHAPE3DYMAX}=$y if($self->{SHAPE3DYMAX}<$y);
	    $self->{SHAPE3DZMAX}=$z if($self->{SHAPE3DZMAX}<$z);
	}
	
	# node size
	$cpus=$self->{NODESTATEREF}->[$n]->{"cpu_total"};
	$cpus/=2 if( $self->{SYSTEM_IS_BGL}); 
	$stateref->{FREECPUS_ONNODE}->[$n]=$cpus;
	$stateref->{USEDCPUS_ONNODE}->[$n]=0;
	$stateref->{FREECPUS}+=$cpus;

	# store starter/class information in state
	my $classes=$self->{NODESTATEREF}->[$n]->{"node_avail_classes"};
	my @classes=split(/\),?\(/,$classes);
	foreach $pair (@classes) {
	    my($class,$num)=($pair=~/\(?(.*),(\d+)\)?/gs);
	    my $c=$self->{CLASS2NR}->{$class};
	    $stateref->{STARTERS_ONNODE}->[$n]->[$c]+=$num;
	    $stateref->{STARTERS}->[$c]+=$num;
	}

	
    }
    $self->{FRAMES}=$frames;

    $self->PROTO_print_marker();
    $self->PROTO_print("found $frames nodes\n");
    $self->PROTO_print_marker();
    $self->PROTO_print_classlist();
    $self->PROTO_print("\n");
}

sub scan_classlimits  {
    my($self) = shift;
    my($indataref) = @_;
    my($spec,$class,$maxclass,$maxuser,$c);
   
    # init max/act starter per class/user
    return if(!defined($indataref->{CLASSES}));
    return if(!defined($indataref->{CLASSES}->{"ConfiguredClasses"}));
    
    $self->PROTO_print("\n");
    $self->{CHECKMAXSTARTER}=1;
    
    foreach $spec (split(/\s+/,$indataref->{CLASSES}->{"ConfiguredClasses"})) {
	$spec=~/(.*)\((.*),(.*)\)/gs;
	($class,$maxclass,$maxuser)=($1,$2,$3);
	$c=$self->{CLASS2NR}->{$class};
	$self->{MAXJOBS}->[$c]=$maxclass;
	$self->{MAXJOBSUSER}->[$c]=$maxuser;
	$self->PROTO_printf(" max starter for class %-15s(%d) -> %2d (class) %2d (user)\n",$class,$c,$maxclass,$maxuser);
    }

    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	$self->{MAXJOBS}->[$c]=0 if(!$self->{MAXJOBS}->[$c]);
	$self->{MAXJOBSUSER}->[$c]=0 if(!$self->{MAXJOBSUSER}->[$c]);
    }


}

sub scan_reservations  {
    my($self) = shift;
    my($indataref,$stateref) = @_;
    my($resid,$jobid,$nodelist,$bg_bps,$starth,$endh,$j,$part,$node,$pnum,$pnr,$cpus);
    
    $j=0;
    foreach $resid (keys( %{$indataref->{RESERVATION}} )) {
	$j++;
	$nodelist="";
	if(exists($indataref->{RESERVATION}->{$resid}->{'nodelist'})) {
	    $nodelist=$indataref->{RESERVATION}->{$resid}->{'nodelist'}; 
	} else {
	    $nodelist=$indataref->{RESERVATION}->{$resid}->{'res_bg_bps'};
	}

	$starth=&timediff($indataref->{RESERVATION}->{$resid}->{'starttime'},
			  $self->{SYSTEMTIME})/3600;
	$endh=&timediff($indataref->{RESERVATION}->{$resid}->{'endtime'},
			$self->{SYSTEMTIME})/3600;

	$self->{OUTDATA}->{RESINFO}->{$resid}->{"starttimeH"}=$starth;
	$self->{OUTDATA}->{RESINFO}->{$resid}->{"endtimeH"}=$endh;

	$self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"}="";
	$cpus=0;
	if( $self->{SYSTEM_IS_BGL} ) {
	    foreach $part  (split(/,/,$nodelist)) {
		$pnum=$self->get_partition_size($part);
		$cpus+=$pnum;
		$node=$self->specnodename_to_nodename($part);
		$self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"}.="($node,$pnum)";
	    }
	} else {
	    foreach $part  (split(/,/,$nodelist)) {
		$pnr=$self->{NODESTATENR}->{$part};
		$pnum=$stateref->{FREECPUS_ONNODE}->[$pnr];
		$cpus+=$pnum;
		$node=$part;
		$self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"}.="($node,$pnum)";
	    }
	}
	$self->{OUTDATA}->{RESINFO}->{$resid}->{"cpus"}=$cpus;

	$self->PROTO_printf("%02d: scan found reservation %-10s  starting at %6.2fh ending at %6.2fh nodelist=%s\n",$j,$resid,
			    $self->{OUTDATA}->{RESINFO}->{$resid}->{"starttimeH"},
			    $self->{OUTDATA}->{RESINFO}->{$resid}->{"endtimeH"},
			    $self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"});
	

	if(exists($indataref->{RESERVATION}->{$resid}{'resjobs'})) {
	    foreach $jobid (keys( %{$indataref->{JOBSTATE}} )) {
		$self->{OUTDATA}->{JOBSTATE}->{$jobid}->{"resid"}=$resid;
	    }
	}
    }
}
sub scan_jobs  {
    my($self) = shift;
    my($indataref) = @_;
    my($jobid,$sjobid,$stepname,$j,$spec,$node,$num);
    
    $self->PROTO_print("\n");

    foreach $jobid (keys( %{$indataref->{JOBSTATE}} )) {

	# check state
	if(   ($indataref->{JOBSTATE}->{$jobid}->{"job_nodelist"} eq "-") 
	   || ($indataref->{JOBSTATE}->{$jobid}->{"job_nodelist"} eq "")) {
	    $self->{OUTDATA}->{JOBSTATE}->{$jobid}="waiting";
	    $self->{OUTDATA}->{JOBINFO} ->{$jobid}->{"starttimeH"}="-";
	    $self->{OUTDATA}->{JOBINFO} ->{$jobid}->{"endtimeH"}  ="-";
	    push(@{$self->{WAITINGJOBS}},$jobid);
	}  else {
	    $self->{OUTDATA}->{JOBSTATE}->{$jobid}="running";
	    $self->{OUTDATA}->{JOBINFO} ->{$jobid}->{"starttimeH"}=$indataref->{JOBSTATE}->{$jobid}->{"job_dispatchdate"};
	    $self->{OUTDATA}->{JOBINFO} ->{$jobid}->{"usedH"}    =
		&timediff($self->{SYSTEMTIME},$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"starttimeH"})/3600;
	    $self->{OUTDATA}->{JOBINFO} ->{$jobid}->{"endtimeH"}   =$indataref->{JOBSTATE}->{$jobid}->{"job_wall"}/3600
		-$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"usedH"};
	    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"starttimeH"} =-$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"usedH"};
	    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"}=$indataref->{JOBSTATE}->{$jobid}{"job_nodelist"};
	    push(@{$self->{RUNNINGJOBS}},$jobid);
	}

	# determine job state 
	if($indataref->{JOBSTATE}->{$jobid}->{"job_statuslong"} eq "HOLD") {
	    $self->{OUTDATA}->{JOBSTATE}->{$jobid}="hold";
	}
	# determine job state for job in job chains
	if($indataref->{JOBSTATE}->{$jobid}->{"job_statuslong"} eq "REMOVED") {
	    $self->{OUTDATA}->{JOBSTATE}->{$jobid}="removed";
	}
	if($indataref->{JOBSTATE}->{$jobid}->{"job_statuslong"} eq "COMPLETED") {
	    $self->{OUTDATA}->{JOBSTATE}->{$jobid}="completed";
	}

	# is it a job step of a job chain, store stepnames for later
	if($indataref->{JOBSTATE}->{$jobid}{"job_stepname"}) {
	    if($indataref->{JOBSTATE}->{$jobid}{"job_stepname"}=~/([^\:]+):([^\:]+)/s) {
		($sjobid,$stepname)=($1,$2);
	    } else {
		$sjobid=$jobid;
		$stepname=$indataref->{JOBSTATE}->{$jobid}{"job_stepname"};
	    }
	    $sjobid=~s/\.\d+$//gs;
	    $self->{STEPNAMES}->{$sjobid}->{$stepname}=$jobid;
	    $self->PROTO_printf("   found step_name %s\n",$indataref->{JOBSTATE}->{$jobid}->{"job_stepname"});
	}

	# determine number of cpus, WF TODO: improve
	if ($self->{OUTDATA}->{JOBSTATE}->{$jobid} eq "running") {
	    # get number of cpus from nodelist
	    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"}=0;
	    
	    foreach $spec (split(/\),?\(/,$indataref->{JOBSTATE}->{$jobid}->{"job_nodelist"})) {
		$spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;
		if( $self->{SYSTEM_IS_BGL}) {
		    # BGL: partition on bgl is in start state
		    my $pnum=$self->get_partition_size($node);
		    $num=$pnum if($pnum>0);
		}
		$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"}+=$num;
	    }

	} else {
	    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"}=(
							     $indataref->{JOBSTATE}->{$jobid}->{"job_totaltasks"}
							     *$indataref->{JOBSTATE}->{$jobid}{"job_conscpu"}
							     );
	}
    }

    $self->PROTO_printf("found %3d running jobs and %3d waiting jobs\n",
			scalar(@{$self->{RUNNINGJOBS}}),scalar(@{$self->{WAITINGJOBS}}));
}

sub insert_running_jobs  {
    my($self) = shift;
    my($indataref,$stateref,$timelineref) = @_;
    my($jobid,$sjobid,$stepname,$j);

    # push first last entry in timeline in list, containing an empty system state 
    $stateref->{TIMESTAMPH}   = 1e20;
    $stateref->{JOBENDINGHERE}= "";
    unshift(@{$timelineref},$self->copy_state($stateref,"GLOBAL"));

    # build timeline, start with job which ends last
    $j=0;
    foreach $jobid (sort { $self->{OUTDATA}->{JOBINFO}->{$b}->{"endtimeH"} 
			   <=> $self->{OUTDATA}->{JOBINFO}->{$a}->{"endtimeH"}}  (@{$self->{RUNNINGJOBS}})) {
	$j++;
	
	$self->PROTO_printf("%02d: insert now running job %-10s of user %-10s ending at %6.2fh cpus=%d\n",$j,$jobid,
			    $indataref->{JOBSTATE}->{$jobid}->{"job_owner"},
			    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"endtimeH"},
			    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"});
	
	# set state at time line position
	# this state describes the state AFTER removing the job
	$stateref->{TIMESTAMPH}   = $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"endtimeH"};
	$stateref->{JOBENDINGHERE}= $jobid;
	unshift(@{$timelineref},$self->copy_state($stateref,"GLOBAL"));
	$self->PROTO_print_node_state($timelineref->[0],"State after ending of job $jobid");

	# add job to state
	$self->add_job_to_state($indataref,$stateref,$jobid);
    }
    # first entry in timeline, it's a dummy entry, because there is no job ending here
    $stateref->{TIMESTAMPH}   = 0.0;
    $stateref->{JOBENDINGHERE}= "";
    unshift(@{$timelineref},$self->copy_state($stateref,"GLOBAL"));
    
}


sub insert_reservations  {
    my($self) = shift;
    my($indataref,$stateref,$timelineref) = @_;
    my($resid,$jobid,$stepname,$j);

    $j=0;
    foreach $resid (keys( %{$indataref->{RESERVATION}} )) {
	$j++;
	
	$self->PROTO_printf("%02d: insert now reservation %-10s  starting at %6.2fh ending at %6.2fh nodelist=%s\n",$j,$resid,
			    $self->{OUTDATA}->{RESINFO}->{$resid}->{"starttimeH"},
			    $self->{OUTDATA}->{RESINFO}->{$resid}->{"endtimeH"},
			    $self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"},
			    );
	$self->PROTO_print_timeline($timelineref,$indataref,0,"before insert of reservation \#$j");
	$self->insert_reservation_in_timeline($indataref,$timelineref,$resid);
	$self->PROTO_print_timeline($timelineref,$indataref,0,"after insert of reservation \#$j");
	
    }
}

################################################################################################################
# simulation of Job Scheduler
################################################################################################################
sub insert_waiting_jobs  {
    my($self) = shift;
    my($indataref,$stateref,$timelineref) = @_;
    my($jobid,$sjobid,$stepname,$j,$posintimeline,$rc,$c,$numinserted,$numwaitjobs,$key,$kind_of_job,$kind_of_lastjob);
    my @waitingjobs=();
    my @topdoglist=();
    my(%reservstates);
    my(%jobs_scheduled);

    # we have now a timeline containing all running jobs
    # 0. determine ranking of waiting jobs

    # Simulation of Scheduler will be done by a iteration over following steps:
    # 1. search topdog(s), build topdog list 
    # 2. place waiting jobs until first topdog is placed, by iteration over:
    #    -> 2a. remove job ending at current timeline position
    #    -> 2b. if possible place waiting job
    #    -> 2c. recalculate ranking of waiting jobs, if necessary
    
    # get list of waiting jobs
    $self->PROTO_setprefix("SIM,SORT:   ");
    @waitingjobs=$self->sort_waiting_jobs($indataref,$stateref,$self->{WAITINGJOBS});
    $numwaitjobs=scalar @waitingjobs;

    $posintimeline=0;

    # search topdogs
    if($self->{BACKFILLING}) {
	$self->PROTO_setprefix("SIM,TOPDOG: ");
	@topdoglist=$self->search_and_place_topdogs($indataref,$stateref,\@waitingjobs,
						    $timelineref,$posintimeline,
						    \%reservstates);
    }
    $self->PROTO_setprefix("SIM,WAITING:");
    # run through timelime, try to schedule jobs
    $posintimeline=0;
    $numinserted=0;
    while ( ($posintimeline<=$#{$timelineref}) 
	     && ($numinserted<$self->{MAXNUMJOBS}) ) {
	%jobs_scheduled=();
	# search startable jobs
	$c=0;
	$kind_of_job=$kind_of_lastjob="-";
	foreach $jobid (@waitingjobs) {
	    # can job be started at current position in time line?
	    if($self->{OUTDATA}->{JOBSTATE}->{$jobid} ne "waiting") {
		# job is already running, remove it from list (e.g. pre schedule job, topdog)
		$self->PROTO_printf(" --> job %s already scheduled, removing from list ...(%s)\n",$jobid,$self->{OUTDATA}->{JOBSTATE}->{$jobid});
		splice(@waitingjobs,$c,1);
		next;
	    }
	    # optimization: check job only if different from precessor, TODO: enhance for BGL
	    if($self->{KINDCHECKING}) {
		$kind_of_job=$indataref->{JOBSTATE}->{$jobid}->{"job_owner"}
		.$indataref->{JOBSTATE}->{$jobid}->{"job_wall"}
		.$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"}
		.$indataref->{JOBSTATE}->{$jobid}{"job_queue"};
		if($kind_of_job eq $kind_of_lastjob) {
		    $self->{STAT}->{KINDEQUAL}++;
		    $self->PROTO_printf(" --> [%3d] job %s has same kind as job before >%s< >%s<\n",$c,
					$jobid,$kind_of_job,$kind_of_lastjob);
		    $c++;
		    next;
		} else {
		    $self->{STAT}->{KINDNOTEQUAL}++;
		    $kind_of_lastjob=$kind_of_job;
		}
	    }

	    if($rc=$self->check_job_placement_in_state($indataref,$stateref,$self->{OUTDATA}->{JOBSTATE},$jobid)) {
		$self->{STAT}->{STARTFOUND}++;
		# check if job fits in timeline 
		$self->PROTO_printf("%2d,STARTFND job %s, which can be started here state=%s\n",$numinserted,$jobid,
				    $self->{OUTDATA}->{JOBSTATE}->{$jobid});
		$self->PROTO_print_node_state($stateref,"situation before chek timeline at pos $posintimeline");
		$self->PROTO_setprefix("SIM,FWD,$numinserted:");
		$rc=$self->check_and_do_job_placement_in_timeline($indataref,$stateref,$jobid,$timelineref,$posintimeline,
								  $self->{OUTDATA}->{JOBSTATE},
								  \%reservstates);
		$self->PROTO_setprefix("SIM,WAITING:");
		if($rc) {
		    # remove it from list, rest will be done by move_forward_onestep_in_timeline
		    $numinserted++;
		    $self->PROTO_printf("%2d,FOUND job %s, which can be scheduled here\n",$numinserted,$jobid);
 		    $self->PROTO_print_timeline($timelineref,$indataref,$posintimeline,"after insert of job $jobid");
#		    splice(@waitingjobs,$c,1);
		    $self->{STAT}->{WAITJOBSSCHEDULED}++;
		    if($self->{PRINTPROGRESS}) {
			$|=1;print "($posintimeline:$numinserted/$numwaitjobs)";$|=0;
		    } 
		    last;
		} else {
		    $self->{STAT}->{COULDNOTPLACE}++;
		}
	    }
	    $self->PROTO_printf(" --> [%3d] job %s could not scheduled ... %s\n",$c,$jobid,
				$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"});
	    $c++;
	}

	
	# go forward
	$posintimeline++;
	if($posintimeline<=$#{$timelineref}) {
	    my $skip=1;
	    while($skip) {
#		$self->PROTO_print_node_state($stateref,"situation before moveto timelime pos $posintimeline");
		$self->move_forward_onestep_in_timeline($indataref,$posintimeline,$timelineref,$stateref,
							\%reservstates,$self->{OUTDATA}->{JOBSTATE});
		$self->PROTO_print_node_state($stateref,"situation after  moveto timelime pos $posintimeline");
		$self->PROTO_print_timeline($timelineref,$indataref,$posintimeline,"after move to $posintimeline");
		
		# is there a ending job at this time point 
		# remove this job from waitingjobs
		$jobid=$timelineref->[$posintimeline]->{JOBENDINGHERE};
		$jobid=$timelineref->[$posintimeline]->{JOBSTARTINGHERE} if(!$jobid);
		if($jobid) {
		    $c=0;
		    # WF: hier Fehler
		    while( ($c<=$#waitingjobs) && ($waitingjobs[$c] ne $jobid)) {
#			$self->PROTO_printf(" -->-> (%d) %s<=>%s\n", $c,$waitingjobs[$c],$jobid);
			$c++;
		    }
		    if($c<=$#waitingjobs) {
			$self->PROTO_printf(" --> removing job %s from list at pos ...(%s) of $#waitingjobs\n",
					    $jobid,$c,$self->{OUTDATA}->{JOBSTATE}->{$jobid});
			splice(@waitingjobs,$c,1);
		    }
		    
		}
		# Reservation handling: if a reservation starts at this point, build a new state, which has 
		# only starters on reserverd nodes and do a timeline simulation for this state and jobs of waiting 
		# job list depending to this reservation. In the global timeline, the reservation could be handled
		# like a a dummy job of this size
		# WF: TODO implement this

		# is there a starting topdog at this time point 
		$jobid=$timelineref->[$posintimeline]->{JOBSTARTINGHERE};
		if($jobid) {
		    if($self->{TOPDOGS}->{$jobid}) {
			$self->PROTO_printf("Top Dog \#%d %s scheduled, recalculating ...\n",$self->{TOPDOGS}->{$jobid},$jobid);
			$self->{OUTDATA}->{JOBINFO}->{$jobid}->{TopDogLevel}=$self->{TOPDOGS}->{$jobid};
			delete($self->{TOPDOGS}->{$jobid});

			# remove remaining top dogs, will be computed again
			$self->PROTO_print_timeline($timelineref,$indataref,$posintimeline,"before removing Topdogs to $posintimeline");
			$self->remove_topdogs($indataref,$timelineref,$posintimeline+1);			
			$self->PROTO_print_timeline($timelineref,$indataref,$posintimeline,"after removing Topdogs to $posintimeline");
			# calculate new topdogs

			# reset temporally timeline at this point, because job is already started and inserted in current state
			$timelineref->[$posintimeline]->{JOBSTARTINGHERE}="";

			$self->PROTO_setprefix("SIM,TOPDOG: ");
			@topdoglist=$self->search_and_place_topdogs($indataref,$stateref,\@waitingjobs,
								    $timelineref,$posintimeline,
								    \%reservstates);

			$self->PROTO_setprefix("SIM,WAITING:");
			$timelineref->[$posintimeline]->{JOBSTARTINGHERE}=$jobid;
			
			$numinserted++;
			if($self->{PRINTPROGRESS}) {
			    $|=1;print "($posintimeline:$numinserted/$numwaitjobs)";$|=0;
			} 


		    } else {
			$self->{OUTDATA}->{JOBINFO}->{$jobid}->{TopDogLevel}=0;
		    }
		    
		}
		# skip further checks if the next time has an action for the same time, state not changed
		$skip=0;
		if($posintimeline<$#{$timelineref}) {
		    if($timelineref->[$posintimeline]->{TIMESTAMPH} == $timelineref->[$posintimeline+1]->{TIMESTAMPH}) {
			$posintimeline++;
			$skip=1;
		    } 
		}
	    }
	}

    }

    if($self->{PRINTPROGRESS}) {
	print "\n";
    }

    if($self->{PRINTSTAT}) {
	print "Simulator Statistics:\n";
	for $key (keys(%{$self->{STAT}})) {
	    printf("   %-30s : %10d\n",$key,$self->{STAT}->{$key});
	}	
    }

    
}

sub sort_waiting_jobs  {
    my($self) = shift;
    my($indataref,$stateref,$idsref) = @_;
    my($jobid,@waitingjobs,$i);
    
    # currently take system prio given by Scheduler
    # the prio may change if the number of starters are part of the formula 
    # for calculating the sysprio
    # TODO: recalculate sysprio before do this

    $self->PROTO_print_marker();
    $self->PROTO_printf("Job prio list at time %6.2f\n",$stateref->{TIMESTAMPH});
    $self->PROTO_print_marker();
    $i=0;
    foreach $jobid (sort{ &sort_waiting_for_forecast($indataref) } (@{$idsref})) {
	next if($self->{OUTDATA}->{JOBSTATE}->{$jobid}=~/(hold|removed|completed)/);
	push(@waitingjobs,$jobid);
	$i++;
	$self->PROTO_printf("%03d: %-10s #cpus=%6d user=%-10s (%s) wall=%s %s\n",$i,$jobid,
			    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"},
			    $indataref->{JOBSTATE}->{$jobid}->{"job_owner"},
			    $self->{OUTDATA}->{JOBSTATE}->{$jobid},
			    $indataref->{JOBSTATE}->{$jobid}->{"job_wall"},
			    $indataref->{JOBSTATE}->{$jobid}->{"job_comment"}
			    );
    }
    return(@waitingjobs);
}


# search topdogs
# $stateref is state at position $posintimeline in timeline
sub search_and_place_topdogs  {
    my($self) = shift;
    my($indataref,$stateref,$idsref,$timelineref,$posintimeline,$reservstatesref) = @_;
    my($jobid,$j,$user,$wall,$cpus,$class,$classnr,$ts,$rc,$fit,$mystate,$starttimepos,$endtimepos,$nodenumberlist);
    my($starttimeH,$endtimeH);
    my $changetimeline=0;
    my ($NOTFOUND,$STARTFOUND,$ENDFOUND)=(0,1,2);

    $self->PROTO_print_marker();
    $self->PROTO_printf("Search for %d TopDogs at time %6.2f h\n",$self->{NUMTOPDOGS},$stateref->{TIMESTAMPH});
    $self->PROTO_print_marker();


    $j=0;
    foreach $jobid (@{$idsref}) {

	$user=$indataref->{JOBSTATE}->{$jobid}{"job_owner"};
	$wall=$indataref->{JOBSTATE}->{$jobid}{"job_wall"}/3600.0;
	$cpus=$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"};
	$class=$indataref->{JOBSTATE}->{$jobid}{"job_queue"};	$classnr=$self->{CLASS2NR}->{$class};
	
	$self->PROTO_printf("\n");
	$self->PROTO_printf(" %2d: examine job %10s in class %s (%d): user=%s cpus=%d wall=%5.2f\n",$j,
			    $jobid,$class,$classnr,$user,$cpus,$wall);

	# check if job can be started, a job can only be a top dog if maxstarters allows this
	if(!$self->is_job_startable_maxstarter($indataref,$jobid,$stateref)) {
	    $self->PROTO_printf("    --> maxstarter of class or user allows not the start of this job, skipping\n");
	    next; 
	}

	# work on a copy of the system and job state
 	my $tdstateref = $self->copy_state($stateref,"ALL");
 	my ($tdminstateref,$tdsavestateref,$tdsavejobstateref);
	my $tdjobstateref = $self->copy_job_state($self->{OUTDATA}->{JOBSTATE});


	# search position for topdog
	$mystate=$NOTFOUND;

	# start for every job at the beginning of timeline part 
	$ts=$posintimeline;
	while( ($ts<=$#{$timelineref}) && ($mystate!=$ENDFOUND) ) {
	    $self->{STAT}->{TOPDOGSTEPS}++;

	    # advance pointer in timeline, changes only $tdstateref, $tdjobstateref
	    $self->PROTO_print_node_state($tdstateref,"node state before move to timelinepos $ts");
	    $self->move_forward_onestep_in_timeline($indataref,$ts,$timelineref,$tdstateref,
						    $reservstatesref,$tdjobstateref);
	    $self->PROTO_print_node_state($tdstateref,"node state after move to timelinepos $ts");

	    # skip further checks if the next time has an action for the same time, state not changed
	    if($ts<$#{$timelineref}) {
		if($timelineref->[$ts]->{TIMESTAMPH} == $timelineref->[$ts+1]->{TIMESTAMPH}) {
		    $ts++;
		    next;
		}
	    }


	    #############################
	    if($mystate==$NOTFOUND) {
		# check if job fits in current node state
		$self->PROTO_printf("STATE=NOTFOUND --> check job %s\n",$jobid);
		if($rc=$self->check_job_placement_in_state($indataref,$tdstateref,$tdjobstateref,$jobid)) {
		    $nodenumberlist=$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"job_schednodenumbers"};
		    $mystate=$STARTFOUND;
		    $starttimeH=$timelineref->[$ts]->{TIMESTAMPH};
		    $endtimeH  =$timelineref->[$ts]->{TIMESTAMPH}+$wall;
		    
		    # save state and jobstate at beginning of job, to restart from this point, if job does not fit
		    $starttimepos      = $ts;
		    $tdsavestateref    = $self->copy_state($tdstateref,"ALL");
		    $tdsavejobstateref = $self->copy_job_state($tdjobstateref);

		    # initialize min. free state
		    $tdminstateref = $self->copy_state($tdstateref,"ALL");
		    $self->PROTO_printf("  --> position found: %10.4fh switching to state STARTFOUND\n",$starttimepos);
		} else {
		    $self->PROTO_printf("  --> could not place reason: %s\n",$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"});
		}

		# advance in timeline
		$ts++;
		next;

	    } 
	    ##############################
	    elsif($mystate==$STARTFOUND) {
		# timeline point is after end of job, job fits in system
		if($timelineref->[$ts]->{TIMESTAMPH}>$endtimeH) {
		    $endtimepos=$ts-1;
		    $mystate=$ENDFOUND;
		    next;
		}
		
		# adjust state containing minimal free starters on nodes in the duration of the job 
		$self->adjust_min_free_state($tdstateref,$tdminstateref);
		
		# check job against minimal free node state up to this timepoint
		$rc=$self->check_job_placement_in_state($indataref,$tdminstateref,$tdjobstateref,$jobid);
		
		if(!$rc) {
		    # job does not fit in this state, return to beginning of job
		    $mystate=$NOTFOUND;
		    $ts=$starttimepos;
		    $tdstateref=$tdsavestateref;       $tdsavestateref=undef;
		    $tdjobstateref=$tdsavejobstateref; $tdsavejobstateref=undef;

		    # advance in timeline, and try again from next point in timeline
		    $ts++;
		    next;
		} else {
		    $ts++;
		}
	    } else {
		$self->PROTO_printf("  --> error, wrong graph state: %d\n",$mystate);
	    }
	}
	if($mystate==$ENDFOUND) {
	    $self->PROTO_printf("  --> job %s fits at position %6.2fh to %6.2fh %s, %s (TopDog)\n",$jobid,
				$starttimeH,$endtimeH,
				$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"job_schednodenumbers"},
				$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"});
	    # set info for job
	    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"endtimeH"}=$endtimeH;
	    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"starttimeH"}=$starttimeH;
	    # and insert it into timeline
	    $self->{TOPDOGS}->{$jobid}=$j+1;
	    $self->PROTO_print_timeline($timelineref,$indataref,$posintimeline,"before insert of topdog #$j");
	    $self->insert_job_in_timeline($indataref,$timelineref,$jobid,$starttimepos,$endtimepos);
	    $self->PROTO_print_timeline($timelineref,$indataref,$posintimeline,"after insert of topdog \#$j");
	}

	$j++;
	last if($j>=$self->{NUMTOPDOGS});
    }
}


# remove topdogs from timeline
sub remove_topdogs  {
    my($self) = shift;
    my($indataref,$timelineref,$posintimeline) = @_;
    my($ts,$jobid);

    foreach $jobid (keys(%{$self->{TOPDOGS}})) {
	$self->remove_job_from_timeline($indataref,$timelineref,$jobid,$posintimeline);
	delete($self->{TOPDOGS}->{$jobid});
    }
}

# check_job_placement_in_timeline
# $stateref is state at position $posintimeline in timeline
sub check_and_do_job_placement_in_timeline  {
    my($self) = shift;
    my($indataref,$stateref,$jobid,$timelineref,$posintimeline,$jobstateref,$reservstatesref) = @_;
    my($wall,$mystate,$ts,$tmpstateref,$tmpjobstateref,$minstateref);
    my($starttimeH,$endtimeH,$rc,$endtimepos);
    my $changetimeline=0;
    my ($NOTFIT,$FIT)=(0,1);

    $wall=$indataref->{JOBSTATE}->{$jobid}{"job_wall"}/3600;

    $starttimeH=$timelineref->[$posintimeline]->{TIMESTAMPH};
    $endtimeH  =$timelineref->[$posintimeline]->{TIMESTAMPH}+$wall;
		    
    # save state and jobstate at beginning of job, to restart from this point, if job does not fit
    $tmpstateref    = $self->copy_state($stateref,"ALL");
    $tmpjobstateref = $self->copy_job_state($jobstateref);

    # initialize min. free state
    $minstateref = $self->copy_state($stateref,"ALL");

    $self->PROTO_printf("%s start looking forward\n","*"x80);

    # 1 Step: dry run without checking state, jobs fit if only timeline entries with ending jobs occur
    $ts=$posintimeline+1;
    $mystate=$FIT;
    while(($timelineref->[$ts]->{TIMESTAMPH}<=$endtimeH) && ($mystate==$FIT)) {
	$mystate=$NOTFIT if($timelineref->[$ts]->{JOBSTARTINGHERE});
	$mystate=$NOTFIT if($timelineref->[$ts]->{RESSTARTINGHERE});
	# advance in timeline
	$ts++;
    }
    if($mystate==$FIT) {
	$self->{STAT}->{DRYCHECKSOK}++;
	$self->PROTO_printf("  --> job %s fits after drycheck at position %6.2fh to %6.2fh %s, %s\n",$jobid,
			    $starttimeH,$endtimeH,
			    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"job_schednodenumbers"},
			    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"});
    } else {
    
	# 2 step: run with construction of state for each time line position
	# adjust state containing minimal free starters on nodes in the duration of the job 
	$self->PROTO_print_node_state($tmpstateref,"tmpstateref a");
	$self->adjust_min_free_state($tmpstateref,$minstateref);
	$self->PROTO_print_node_state($minstateref,"minstateref a");

	$mystate=$FIT;
	$ts=$posintimeline+1;
	while($timelineref->[$ts]->{TIMESTAMPH}<=$endtimeH) {
	    $self->{STAT}->{FWDSTEPS}++;
	    
	    # advance pointer in timeline, changes only $tmpstateref, $tmpjobstateref
	    $self->move_forward_onestep_in_timeline($indataref,$ts,$timelineref,$tmpstateref,
						    $reservstatesref,$tmpjobstateref);
#	    $self->PROTO_print_node_state($tmpstateref,"tmpstateref");
	    
	    # adjust state containing minimal free starters on nodes in the duration of the job 
	    # not necessary if there is a ending job
	    if(!$timelineref->[$ts]->{JOBENDINGHERE}) {
		$self->adjust_min_free_state($tmpstateref,$minstateref);
#	    $self->PROTO_print_node_state($minstateref,"minstateref");
	    }
	    
	# check job against minimal free node state up to this timepoint
	    $rc=$self->check_job_placement_in_state($indataref,$minstateref,$jobstateref,$jobid);
	    if(!$rc) {
		$mystate=$NOTFIT;
		last;
	    }    
	    
	    # advance in timeline
	    $ts++;
	}
    }
    if($mystate==$FIT) {
	$endtimepos=$ts-1;
	$self->PROTO_printf("  --> job %s fits at position %6.2fh to %6.2fh %s, %s\n",$jobid,
			    $starttimeH,$endtimeH,
			    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"job_schednodenumbers"},
			    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"});
	
	# set info for job
	$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"endtimeH"}=$endtimeH;
	$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"starttimeH"}=$starttimeH;
	
	
	# and insert it into timeline
	$self->insert_job_in_timeline($indataref,$timelineref,$jobid,$posintimeline,$endtimepos);
    }
    $self->PROTO_printf("%s end   looking forward\n","*"x80);
    return($mystate==$FIT);
}

# check against limits of maxstarter of class and user
sub is_job_startable_maxstarter  {
    my($self) = shift;
    my($indataref,$jobid,$stateref) = @_;
    my($user,$wall,$cpus,$class,$classnr);
    my($rc);
    
    $rc=1;

    $user=$indataref->{JOBSTATE}->{$jobid}{"job_owner"};
    $cpus=$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"};
    $class=$indataref->{JOBSTATE}->{$jobid}{"job_queue"};	$classnr=$self->{CLASS2NR}->{$class};
    
    $rc=0 if($self->{MAXJOBS}->[$classnr]==0);
    $rc=0 if($self->{MAXJOBSUSER}->[$classnr]==0);
    
    return($rc);
}


# modify state acording the action on timeline position
sub move_forward_onestep_in_timeline {
    my($self) = shift;
    my($indataref,$posintimeline,$timelineref,$stateref,
       $reservstatesref,$jobstateref)=@_;
    my($jobid,$nodelist,$spec,$node,$num,$nodenr,$class,$jclass,$user,$resid);

    $self->PROTO_printf("MOVETO %3d [%5.2fh] move in timeline one timestep forward, act pos is %d\n",
			$posintimeline,$timelineref->[$posintimeline]->{TIMESTAMPH},$posintimeline);

    # is there an starting job?
    $jobid=$timelineref->[$posintimeline]->{JOBSTARTINGHERE};
    if($jobid) {
	$self->PROTO_printf("     -> found job %s starting at position %d in timeline\n",$jobid,$posintimeline);
	# mark this job as ready; for job dependencies
	$jobstateref->{$jobid}="running";
	if($indataref->{JOBSTATE}->{$jobid}->{"job_stepname"}) {
	    $self->PROTO_printf("       --> set WAITINGJOBSTATE of %s to 'running' (stepname=%s)\n",
				$jobid,$indataref->{JOBSTATE}->{$jobid}->{"job_stepname"});
	}
    
	$self->add_job_to_state($indataref,$stateref,$jobid);
    }

    # is there an ending job?
    $jobid=$timelineref->[$posintimeline]->{JOBENDINGHERE};
    if($jobid) {
	$self->PROTO_printf("     -> found job %s ending at position %d in timeline\n",$jobid,$posintimeline);
	# mark this job as ready; not only for job dependencies
	$jobstateref->{$jobid}="ready";
	if($indataref->{JOBSTATE}->{$jobid}->{"job_stepname"}) {
	    $self->PROTO_printf("       --> set WAITINGJOBSTATE of %s to 'ready' (stepname=%s)\n",
				$jobid,$indataref->{JOBSTATE}->{$jobid}->{"job_stepname"});
	}
	$self->remove_job_from_state($indataref,$stateref,$jobid);
    }

    # is there an starting reservation?
    $resid=$timelineref->[$posintimeline]->{RESSTARTINGHERE};
    if($resid) {
	$self->PROTO_printf("     -> found res %s starting at position %d in timeline\n",$resid,$posintimeline);
	$self->add_res_to_state($indataref,$stateref,$resid);
    }

    # is there an ending reservation?
    $resid=$timelineref->[$posintimeline]->{RESENDINGHERE};
    if($resid) {
	$self->PROTO_printf("     -> found res %s ending at position %d in timeline\n",$resid,$posintimeline);
	$self->remove_res_from_state($indataref,$stateref,$resid);
    }

    # set timestamp in state
    $stateref->{TIMESTAMPH}=$timelineref->[$posintimeline]->{TIMESTAMPH};
}


# allows the state the start of this job?
sub check_job_placement_in_state {
    my($self) = shift;
    my($indataref,$stateref,$jobstatesref,$jobid)=@_;


    my($nummachines,$taskspernode,$jclass,$nodenr,$i,$user,$rc,$nodenumbers,$wall,$cpus,$jc);

   
    # some information about the job to place
    $wall        = $indataref->{JOBSTATE}->{$jobid}{"job_wall"}/3600;
    $nummachines = $indataref->{JOBSTATE}->{$jobid}{"job_nummachines"};
    $taskspernode= $indataref->{JOBSTATE}->{$jobid}{"job_taskspernode"}*$indataref->{JOBSTATE}->{$jobid}{"job_conscpu"};
    $jclass      = $indataref->{JOBSTATE}->{$jobid}{"job_queue"};
    $user        = $indataref->{JOBSTATE}->{$jobid}{"job_owner"};
    $cpus        = $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"};
    $jc          = $self->{CLASS2NR}->{$jclass};
 
    $self->{STAT}->{CHECKJOB}++;

    # check against current starters in class
#    $self->PROTO_printf("  --> check starters for job %s jc=%d jclass=%s %d <= %d ? %d\n",$jobid,$jc,$jclass,
#			$stateref->{STARTERS}->[$jc],$cpus,
#			($stateref->{STARTERS}->[$jc]<=$cpus));
    if($stateref->{STARTERS}->[$jc]<$cpus) {
	$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"}="not enough starters ".
	    $self->{STARTERS}->[$jc]."in $jclass (".$stateref->{STARTERS}->[$jc].") for job with $cpus starters";
	$self->{STAT}->{CHECKJOB_NOSTARTERS}++;
	return(0);
    }
   
    # check against max started jobs per class/user
    if($self->{CHECKMAXSTARTER}) {
	# class limit
	if($stateref->{STARTEDJOBS}->[$jc]>=$self->{MAXJOBS}->[$jc]) {
	    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"}="max. started jobs in class is reached: ".
		$self->{MAXJOBS}->[$jc]."in $jclass";
	    $self->{STAT}->{CHECKJOB_MAXSTARTERS}++;
	    return(0);
	}
	# limit in class per user
	if($self->{MAXJOBSUSER}->[$jc]!=-1) {
	    if(exists($stateref->{STARTEDJOBSUSER}->[$jc]->{$user})) {
		if($stateref->{STARTEDJOBSUSER}->[$jc]->{$user}>=$self->{MAXJOBSUSER}->[$jc]) {
		    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"}="max. started jobs per user in class is reached: ".
			$self->{MAXJOBS}->[$jc]."in $jclass for user $user";
		    $self->{STAT}->{CHECKJOB_MAXSTARTERSUSERS}++;
		    return(0);
		}
	    }
	}
    }    

    # dependency check
    if($indataref->{JOBSTATE}->{$jobid}->{"job_dependency"}) {
	my($depstepname,$sjobid,$depjobid,$depjobstate);
	if($indataref->{JOBSTATE}->{$jobid}->{"job_dependency"}=~/\s*([^\s]+)\s*\>\= 0\s*/) {
	    $depstepname=$1;
	    $sjobid=$jobid; $sjobid=~s/\.\d+$//gs;
	    if(    (exists($self->{STEPNAMES}->{$sjobid})) 
		&& (exists($self->{STEPNAMES}->{$sjobid}->{$depstepname}))
		   ) { 
		$depjobid=$self->{STEPNAMES}->{$sjobid}->{$depstepname};
		$depjobstate=$jobstatesref->{$depjobid};
		$self->PROTO_print("found dependency for job $jobid: ".$indataref->{JOBSTATE}->{$jobid}->{"job_dependency"}."\n");
	    } else {
		$depjobstate="unknown"; # ready, but not listed in job lists
	    }

	    if (($depjobstate ne "ready") && ($depjobstate ne "removed") && ($depjobstate ne "completed")  
		&& ($depjobstate ne "unknown") ) {
		$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"}=
		    "job step depends on other jobstep, which is not ready: $depstepname:$depjobstate";
		$self->{STAT}->{CHECKJOB_DEPENDENCY}++;
		return(0);
	    }
	}
    }

    # check nodes
    if(!$self->{SYSTEM_IS_BGL}) {
	# check only if enough nodes free
	my @nodenumber=();
	for($nodenr=1;(($nodenr<=$self->{FRAMES}) && ($nummachines>0));$nodenr++) {
	    if($taskspernode<=$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]) {
		# found a node which can host this job
		push(@nodenumber,$nodenr);
		$nummachines--;
	    }
	}
	$nodenumbers=join(",",@nodenumber);
	$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"job_schednodenumbers"}=$nodenumbers;
	$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"}=join(",",map({$_="($self->{NODESTATENAME}->[$_],$taskspernode)"} @nodenumber));

    } else {
	# check shape against free BGL nodes

	# build map of nodes which can host this job
	my(@freemp);
	my($x,$y,$z,$shape,$help);
	for($x=0;$x<=$self->{SHAPE3DXMAX};$x++) {
	    for($y=0;$y<=$self->{SHAPE3DYMAX};$y++) {
		for($z=0;$z<=$self->{SHAPE3DZMAX};$z++) {
		    $nodenr=$self->{SHAPE3D}->[$x][$y][$z];
#		    $self->PROTO_printf("      --> checkfree %d:%d:%d %d<=%d (%d) nodenr=%d jc=%d\n",
#					$x,$y,$z,$taskspernode,$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc],
#					$nummachines,$nodenr,$jc);
		    $freemp[$x][$y][$z]=($taskspernode<=$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc])?1:0;
		    $nummachines-- if($freemp[$x][$y][$z]);
		}
	    }
	}
	
	# too few free midplanes 
	if($nummachines>0) {
	    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"}=
		"not enough free midplanes for this job";
	    $self->{STAT}->{CHECKJOB_MIDPLANES}++;
	    return(0);
	}
	
	$nummachines = $indataref->{JOBSTATE}->{$jobid}{"job_nummachines"};
	$shape=$indataref->{JOBSTATE}->{$jobid}->{"job_bgl_shaperequ"};
	if($shape eq "0x0x0") {
	    $shape="1x1x1" if ($nummachines==1);
	    $shape="1x1x2" if ($nummachines==2);
	    $shape="3x1x1" if ($nummachines==3);
	    $shape="1x2x2" if ($nummachines==4);
	    $shape="2x2x2" if ($nummachines==8);
	    $shape="4x2x2" if ($nummachines==16);
	}
	$shape=~/(\d)+x(\d)+x(\d)+/;($x,$y,$z)=($1,$2,$3);
	for($i=0;$i<2;$i++) {
#	    printf( PROTO "[testshape=%dx%dx%d]",$x,$y,$z);
	    ($rc,$nodenumbers)=$self->check_bgl_shape(\@freemp,$x,$y,$z);
	    if($rc==1) {
		$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"}="(";
		foreach my $nodenr (split(/,/,$nodenumbers)) {
		    if($taskspernode>=512) {
			$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"}.="(".
			    $self->{NODESTATENAME}->[$nodenr].",$taskspernode)";
		    } else {
			# split it up in 32 partitions
			for(my $i=0;$i<$taskspernode;$i+=32) {
			    $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"}.="(".
				$self->{NODESTATENAME}->[$nodenr]."-NX".",32)";
			}

		    }
		}
		$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"}.=")";

		# cache node numbers for scheduling of job 
		$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"job_schednodenumbers"}=$nodenumbers;
		return(1);
	    }
	    $help=$x;$x=$y;$y=$z;$z=$help; # rotate
	}

	$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"}=
	    "shape of BGL job does not fit in this state";
	$self->{STAT}->{CHECKJOB_SHAPE}++;
	return(0);

    }


    if($nummachines==0) {
	return(1);
    } else {
	$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"lastreason"}=
	    "not enough free nodes for this job";
	$self->{STAT}->{CHECKJOB_NODES}++;
	return(0);
    }
}

################################################################################################################
# job and timeline handling 
################################################################################################################
sub add_job_to_state {
    my($self) = shift;
    my($indataref,$stateref,$jobid)=@_;
    my($nodelist,$spec,$node,$num,$nodenr,$jclass,$jc,$diff);

    my $cpus=$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"};
    my $class=$indataref->{JOBSTATE}->{$jobid}{"job_queue"};
    my $c=$self->{CLASS2NR}->{$class};
    my $user=$indataref->{JOBSTATE}->{$jobid}->{"job_owner"};
    
    if(exists($self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"})) {
	# it's a waiting job with a predicted nodelist
	$nodelist=$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"};
    } else {
	# it's a running job
	$nodelist=$indataref->{JOBSTATE}->{$jobid}{"job_nodelist"};
    }

    # adjust starter per class
    if($self->{CHECKMAXSTARTER}) {
	$stateref->{STARTEDJOBS}->[$c]++;
	if($self->{MAXJOBSUSER}->[$c]!=-1) {
	    $stateref->{STARTEDJOBSUSER}->[$c]->{$user}++;
	}
    }
    
    # adjust class starter on each node
    foreach $spec (split(/\),?\(/,$nodelist)) {
	$spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;

	# BGL: partition on bgl is in start state
	if( $self->{SYSTEM_IS_BGL}) {
	    my $pnum=$self->get_partition_size($node);
	    $num=$pnum if($pnum>0);
	    $node=$self->specnodename_to_nodename($node);
	}

	
	$nodenr=$self->{NODESTATENR}->{$node};
	$self->PROTO_printf("  -> insert job %-20s class=%s num=%d on node=%s nodenr=%d\n",$jobid,$class,$num,$node,$nodenr);

	$stateref->{FREECPUS}-=$num;
	$stateref->{USEDCPUS}+=$num;

	$stateref->{FREECPUS_ONNODE}->[$nodenr]-=$num;
	$stateref->{USEDCPUS_ONNODE}->[$nodenr]+=$num;

	$stateref->{STARTERS}->[$c]-=$num;
	$stateref->{STARTERS_ONNODE}->[$nodenr]->[$c]-=$num;

	# adjust starters of other classes on the node, 
	# there could not be more starters in class as freecpus on node
	for($jc=0;$jc<=$#{$self->{NR2CLASS}};$jc++) {
	    $diff=$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]-$stateref->{FREECPUS_ONNODE}->[$nodenr];

	    # reduce to zero if diff greater as current starters
	    if(($stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]-$diff)<=0) {
		$diff=$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc];
	    }

	    if($diff>0) {
		$stateref->{STARTERS}->[$jc]-=$diff;
		$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]-=$diff;
	    }
	}
    }
}

sub remove_job_from_state {
    my($self) = shift;
    my($indataref,$stateref,$jobid)=@_;


    my $cpus=$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"};
    my $class=$indataref->{JOBSTATE}->{$jobid}{"job_queue"};
    my $c=$self->{CLASS2NR}->{$class};
    my $user=$indataref->{JOBSTATE}->{$jobid}->{"job_owner"};
    my($nodelist,$spec,$node,$num,$nodenr,$jclass,$jc,$diff);


    # adjust starter per class
    if($self->{CHECKMAXSTARTER}) {
	$stateref->{STARTEDJOBS}->[$c]--;
	if($self->{MAXJOBSUSER}->[$c]!=-1) {
	    $stateref->{STARTEDJOBSUSER}->[$c]->{$user}--;
	} 
    }

    if(exists($self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"})) {
	# it's a waiting job with a predicted nodelist
	$nodelist=$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"};
    } else {
	# it's a running job
	$nodelist=$indataref->{JOBSTATE}->{$jobid}->{"job_nodelist"};
    }


    $self->PROTO_printf("       --> removing now job %s, class=%s cpus=%d nodelist=%s\n",$jobid,$class,$cpus,$nodelist);

    # adjust class starter on each node
    foreach $spec (split(/\),?\(/,$nodelist)) {
	$spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;
	
	# BGL: partition on bgl is in start state
	if( $self->{SYSTEM_IS_BGL}) {
	    my $pnum=$self->get_partition_size($node);
	    $num=$pnum if($pnum>0);
	    $node=$self->specnodename_to_nodename($node);
	}

	$nodenr=$self->{NODESTATENR}->{$node};
	$self->PROTO_printf("           --> remove job %-20s class=%s(%d) num=%d on $node(%d)\n",$jobid,$class,$c,$num,$nodenr);


	$stateref->{FREECPUS}+=$num;
	$stateref->{USEDCPUS}-=$num;

	$stateref->{FREECPUS_ONNODE}->[$nodenr]+=$num;
	$stateref->{USEDCPUS_ONNODE}->[$nodenr]-=$num;

	$stateref->{STARTERS}->[$c]+=$num;
	$stateref->{STARTERS_ONNODE}->[$nodenr]->[$c]+=$num;

	# adjust starters of other classes on the node, 
	# there could not be more starters in class as freecpus on node
	for($jc=0;$jc<=$#{$self->{NR2CLASS}};$jc++) {
	    my $diff=$stateref->{FREECPUS_ONNODE}->[$nodenr]-$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc];
	    $diff=$num if($diff>$num); # add only cpus which freed by this job

#	    $self->PROTO_printf("          -->  on node %d diff is %d (%d-%d) for class %s num=%d\n",$nodenr,$diff,
#				$stateref->{FREECPUS_ONNODE}->[$nodenr],$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc],
#				$self->{NR2CLASS}->[$jc],$num);

	    # compare with default starter of class on this node
	    if(($stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]+$diff)>$self->{DEFAULTSTATE}->{STARTERS_ONNODE}->[$nodenr]->[$jc]) {
		# reduce it to default limit
		$diff=$self->{DEFAULTSTATE}->{STARTERS_ONNODE}->[$nodenr]->[$jc]
		    -$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc];
#		$self->PROTO_printf("              -->  on node %d reduce diff to %d for class %s %d,d\n",$nodenr,$diff,
#				    $self->{NR2CLASS}->[$jc],$self->{DEFAULTSTATE}->{STARTERS_ONNODE}->[$nodenr]->[$jc],
#				    $stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]);
	    }
	    if($diff>0) {
#		$self->PROTO_printf("              -->  on node %d change, diff is %d for class %s num=%d\n",$nodenr,$diff,
#				    $self->{NR2CLASS}->[$jc],$num);
		$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]+=$diff;
		$stateref->{STARTERS}->[$jc]+=$num;
	    }
	}
    }
}


################################################################################################################
# reservation handling 
################################################################################################################

sub add_res_to_state {
    my($self) = shift;
    my($indataref,$stateref,$resid)=@_;
    my($nodelist,$spec,$node,$num,$nodenr,$jclass,$jc,$diff);

    my $cpus=$self->{OUTDATA}->{RESINFO}->{$resid}->{"cpus"};
    my $class="reserv"; # assumed
    my $c=$self->{CLASS2NR}->{$class};
    $nodelist=$self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"};

    # adjust class starter on each node
    foreach $spec (split(/\),?\(/,$nodelist)) {
	$spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;

	# BGL: partition on bgl is in start state
	if( $self->{SYSTEM_IS_BGL}) {
	    my $pnum=$self->get_partition_size($node);
	    $num=$pnum if($pnum>0);
	    $node=$self->specnodename_to_nodename($node);
	}

	$nodenr=$self->{NODESTATENR}->{$node};
	$self->PROTO_printf("  -> insert res %-20s num=%d on node=%s nodenr=%d\n",$resid,$num,$node,$nodenr);

	$stateref->{FREECPUS}-=$num;
	$stateref->{USEDCPUS}+=$num;

	$stateref->{FREECPUS_ONNODE}->[$nodenr]-=$num;
	$stateref->{USEDCPUS_ONNODE}->[$nodenr]+=$num;

# TODO handling class reserv
#	$stateref->{STARTERS}->[$c]-=$num;
#	$stateref->{STARTERS_ONNODE}->[$nodenr]->[$c]-=$num;

	# adjust starters of other classes on the node, 
	# there could not be more starters in class as freecpus on node
	for($jc=0;$jc<=$#{$self->{NR2CLASS}};$jc++) {
	    $diff=$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]-$stateref->{FREECPUS_ONNODE}->[$nodenr];

	    # reduce to zero if diff greater as current starters
	    if(($stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]-$diff)<=0) {
		$diff=$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc];
	    }

	    if($diff>0) {
		$stateref->{STARTERS}->[$jc]-=$diff;
		$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]-=$diff;
	    }
	}
    }
}

sub remove_res_from_state {
    my($self) = shift;
    my($indataref,$stateref,$resid)=@_;
    my($nodelist,$spec,$node,$num,$nodenr,$jclass,$jc,$diff);


    my $cpus=$self->{OUTDATA}->{RESINFO}->{$resid}->{"cpus"};
    my $class="reserv"; # assumed
    my $c=$self->{CLASS2NR}->{$class};
    $nodelist=$self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"};

    $self->PROTO_printf("       --> removing res job %s, cpus=%d nodelist=%s\n",$resid,$cpus,$nodelist);

    # adjust class starter on each node
    foreach $spec (split(/\),?\(/,$nodelist)) {
	$spec=~/\(?([^,]+),(\d+)\)?/;$node=$1;$num=$2;
	
	# BGL: partition on bgl is in start state
	if( $self->{SYSTEM_IS_BGL}) {
	    my $pnum=$self->get_partition_size($node);
	    $num=$pnum if($pnum>0);
	    $node=$self->specnodename_to_nodename($node);
	}

	$nodenr=$self->{NODESTATENR}->{$node};
	$self->PROTO_printf("           --> remove res %-20s num=%d on $node(%d)\n",$resid,$num,$nodenr);

	$stateref->{FREECPUS}+=$num;
	$stateref->{USEDCPUS}-=$num;

	$stateref->{FREECPUS_ONNODE}->[$nodenr]+=$num;
	$stateref->{USEDCPUS_ONNODE}->[$nodenr]-=$num;

# TODO handling class reserv
#	$stateref->{STARTERS}->[$c]+=$num;
#	$stateref->{STARTERS_ONNODE}->[$nodenr]->[$c]+=$num;

	# adjust starters of other classes on the node, 
	# there could not be more starters in class as freecpus on node
	for($jc=0;$jc<=$#{$self->{NR2CLASS}};$jc++) {
	    my $diff=$stateref->{FREECPUS_ONNODE}->[$nodenr]-$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc];
	    $diff=$num if($diff>$num); # add only cpus which freed by this job

	    # compare with default starter of class on this node
	    if(($stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]+$diff)>$self->{DEFAULTSTATE}->{STARTERS_ONNODE}->[$nodenr]->[$jc]) {
		# reduce it to default limit
		$diff=$self->{DEFAULTSTATE}->{STARTERS_ONNODE}->[$nodenr]->[$jc]
		    -$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc];
	    }
	    if($diff>0) {
		$stateref->{STARTERS_ONNODE}->[$nodenr]->[$jc]+=$diff;
		$stateref->{STARTERS}->[$jc]+=$num;
	    }
	}
    }
}

# insert a job in timeline, adjust starters
sub insert_job_in_timeline {
    my($self) = shift;
    my($indataref,$timelineref,$jobid,$starttimepos,$endtimepos)=@_;
    my($newstartstateref,$newendstateref,$i);

    my $cpus=$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"cpus"};

    $self->PROTO_printf("  --> insert job %s from %d to %d\n",$jobid,$starttimepos,$endtimepos);

    # insert start of job after entry $starttimepos
    $newstartstateref=$self->copy_state($timelineref->[$starttimepos],"GLOBAL");
    $newstartstateref->{TIMESTAMPH}      = $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"starttimeH"};
    $newstartstateref->{JOBSTARTINGHERE} = $jobid;
    $newstartstateref->{JOBENDINGHERE}   = "";
    $newstartstateref->{RESSTARTINGHERE} = "";
    $newstartstateref->{RESENDINGHERE}   = "";
    splice(@{$timelineref},$starttimepos+1,0,$newstartstateref);

    # insert end of job after entry $endtimepos
    $newendstateref=$self->copy_state($timelineref->[$endtimepos+1],"GLOBAL");
    $newendstateref->{TIMESTAMPH}        = $self->{OUTDATA}->{JOBINFO}->{$jobid}->{"endtimeH"};
    $newendstateref->{JOBSTARTINGHERE}   = "";
    $newendstateref->{JOBENDINGHERE}     = $jobid;
    $newendstateref->{RESSTARTINGHERE} = "";
    $newendstateref->{RESENDINGHERE}   = "";
    splice(@{$timelineref},$endtimepos+2,0,$newendstateref);

    # adjust state in between the job
    for($i=$starttimepos+1;$i<=$endtimepos+1;$i++) {
#	$self->PROTO_printf("used_cpus[$i]+=$cpus\n");
	$timelineref->[$i]->{USEDCPUS}+=$cpus;
	$timelineref->[$i]->{FREECPUS}-=$cpus;
    }
}

# insert a job in timeline, adjust starters
sub insert_reservation_in_timeline {
    my($self) = shift;
    my($indataref,$timelineref,$resid)=@_;
    my($newstartstateref,$newendstateref,$i,$starth,$endh,$cpus,$starttimepos,$endtimepos,$ts);

    $starth=$self->{OUTDATA}->{RESINFO}->{$resid}->{"starttimeH"},
    $endh=$self->{OUTDATA}->{RESINFO}->{$resid}->{"endtimeH"},
    $cpus=$self->{OUTDATA}->{RESINFO}->{$resid}->{"cpus"};

    for($ts=0;$ts<=$#{$timelineref};$ts++) {
	$self->PROTO_printf("  -->    check %d (%8.2fh) > (%8.2fh)\n",$ts,$timelineref->[$ts]->{TIMESTAMPH},$starth);
	if($timelineref->[$ts]->{TIMESTAMPH} > $starth) {
	    $starttimepos=$ts-1;
	    last;
	}
    }

    for($ts=0;$ts<=$#{$timelineref};$ts++) {
	if($timelineref->[$ts]->{TIMESTAMPH} > $endh) {
	    $endtimepos=$ts-1;
	    last;
	}
    }

    $self->PROTO_printf("  --> insert reservation %s from %d (%8.2fh) to %d (%8.2fh)\n",$resid,$starttimepos,$starth,$endtimepos,$endh);

    # insert start of job after entry $starttimepos
    $newstartstateref=$self->copy_state($timelineref->[$starttimepos],"GLOBAL");
    $newstartstateref->{TIMESTAMPH}      = $starth;
    $newstartstateref->{JOBSTARTINGHERE} = "";
    $newstartstateref->{JOBENDINGHERE}   = "";
    $newstartstateref->{RESSTARTINGHERE} = $resid;
    $newstartstateref->{RESENDINGHERE}   = "";
    splice(@{$timelineref},$starttimepos+1,0,$newstartstateref);

    # insert end of job after entry $endtimepos
    $newendstateref=$self->copy_state($timelineref->[$endtimepos+1],"GLOBAL");
    $newendstateref->{TIMESTAMPH}      = $endh;
    $newendstateref->{JOBSTARTINGHERE} = "";
    $newendstateref->{JOBENDINGHERE}   = "";
    $newendstateref->{RESSTARTINGHERE} = "";
    $newendstateref->{RESENDINGHERE}   = $resid;
    splice(@{$timelineref},$endtimepos+2,0,$newendstateref);

    # adjust state in between the job
    for($i=$starttimepos+1;$i<=$endtimepos+1;$i++) {
#	$self->PROTO_printf("used_cpus[$i]+=$cpus\n");
	$timelineref->[$i]->{USEDCPUS}+=$cpus;
	$timelineref->[$i]->{FREECPUS}-=$cpus;
    }
}

# remove a job from timeline, adjust starters
sub remove_job_from_timeline {
    my($self) = shift;
    my($indataref,$timelineref,$sjobid,$posintimeline)=@_;
    my($status,$ts,$jobid);
    my ($NOTFOUND,$STARTFOUND,$ENDFOUND)=(0,1,2);

    my($newstartstateref,$newendstateref);

    my $cpus=$self->{OUTDATA}->{JOBINFO}->{$sjobid}->{"cpus"};

    $status=$NOTFOUND;
    for($ts=$posintimeline;$ts<=$#{$timelineref};$ts++) {
	if($status==$NOTFOUND) {
	    $jobid=$timelineref->[$ts]->{JOBSTARTINGHERE};
	    if($jobid) {
		if($jobid eq $sjobid) {
		    $self->PROTO_printf("  --> remove start of job %s from timeline at position %d\n",$jobid,$ts);
		    splice(@{$timelineref},$ts,1);
		    $status=$STARTFOUND;
		}
	    }
	}
	if($status==$STARTFOUND) {
	    
	    $self->PROTO_printf("  -->   substract %d cpus from timeline position %d\n",$cpus,$ts);
	    $timelineref->[$ts]->{USEDCPUS}-=$cpus;
	    $timelineref->[$ts]->{FREECPUS}+=$cpus;

	    $jobid=$timelineref->[$ts]->{JOBENDINGHERE};
	    if($jobid) {
		if($jobid eq $sjobid) {
		    $self->PROTO_printf("  --> remove end   of job %s from timeline at position %d\n",$jobid,$ts);
		    splice(@{$timelineref},$ts,1);
		    $status=$ENDFOUND;
		    last;
		}
	    }
	}
    }
}

################################################################################################################
# cleanups 
################################################################################################################
sub clean {
    my($self) = shift;
    my($id);

    while ($id=shift(@{$self->{FREELIST}})) {    }
    $self->{RUNNINGJOBS}=[];
    $self->{WAITINGJOBS}=[];
    $self->{DEFAULTSTATE}={};
    $self->{ACTSTATE}={};
    $self->{TOPDOGS} = {};    
    $self->{TIMELINE}=[];
    $self->{MAINTENANCE_START}=[];
    $self->{MAINTENANCE_END}=[];
    $self->{CLASS2NR}={};
    $self->{NR2CLASS}=[];
    $self->{STEPNAMES}={};
    $self->{WAITINGJOBSTATE}={};
    $self->{STAT}    = {};
    $self->{MAXJOBS} = [];
    $self->{MAXJOBSUSER} = [];

}

################################################################################################################
# params 
################################################################################################################
sub set_params  {
    my($self) = shift;
    my(%params) = @_;
    my($key,$value,$opt);
    foreach $key (keys(%params)) {
	$value=$params{$key};
	print "$key -> $value\n";
	for $opt ("PROTO", "PROTO_FILENAME", "BACKFILLING", "NUMTOPDOGS","PRINTPROGRESS","PRINTSTAT","MAXNUMJOBS") {
	    $self->{$opt}=$value if($key eq $opt);
	}
    }
    
}

sub check_bgl_shape {
    my($self) = shift;
    my($frempref,$dx,$dy,$dz)=@_;
    my($rc,$nodenumbers,$found);
    my($x,$y,$z,$lx,$ly,$lz);
    
    LOOP:
    for($x=0;$x<=$self->{SHAPE3DXMAX}-$dx+1;$x++) {
	for($y=0;$y<=$self->{SHAPE3DYMAX}-$dy+1;$y++) {
	    for($z=0;$z<=$self->{SHAPE3DZMAX}-$dz+1;$z++) {
		# for each starting position check all midplanes in shape
#		print "check_bgl_shape: startpos $x,$y,$z\n";
		$found=1;
		for($lx=$x;$lx<$x+$dx;$lx++) {
		    for($ly=$y;$ly<$y+$dy;$ly++) {
			for($lz=$z;$lz<$z+$dz;$lz++) {
			    $found=0 if($frempref->[$lx][$ly][$lz]==0);
			}
		    }
		}
		last LOOP if($found);
	    }
	}
    }
    if($found) {
	my(@list);
	$rc=1;
	for($lx=$x;$lx<$x+$dx;$lx++) {
	    for($ly=$y;$ly<$y+$dy;$ly++) {
		for($lz=$z;$lz<$z+$dz;$lz++) {
		    push(@list,$self->{SHAPE3D}->[$lx][$ly][$lz]);
		}
	    }
	}
	$nodenumbers=join(",",@list);
    } else {
	$rc=0;
	$nodenumbers="";
    }
#    print "[check_bgl_shape $nodenumbers]";
    return($rc,$nodenumbers);
}

################################################################################################################
# PROTOCOL function
################################################################################################################

sub PROTO_print_classlist  {
    my($self) = shift;
    my ($c);

    return() if(!$self->{PROTO});
    $self->PROTO_open() if(!$self->{PROTOOPEN});

    $self->PROTO_print_marker();
    printf(PROTO "$self->{PROTOPREFIX}CLASS map: ");
    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	printf(PROTO "CLASS[%2d]=%-16s ",$c,$self->{NR2CLASS}->[$c]);
	    printf(PROTO "\n$self->{PROTOPREFIX}CLASS map: ") if ($c%4==3);
    }
    print PROTO "\n";
    $self->PROTO_print_marker();
}

sub PROTO_print_node_state  {
    my($self) = shift;
    my($stateref,$remark)=@_;
    my ($c,$nodenr,@sum);

    return() if(!$self->{PROTO});
    $self->PROTO_open() if(!$self->{PROTOOPEN});

    $self->PROTO_print_marker();
    printf(PROTO "$self->{PROTOPREFIX}NODE_STATE at time %5.2f h (%s)\n",$stateref->{TIMESTAMPH},$remark);
    $self->PROTO_print_marker();
    printf(PROTO "$self->{PROTOPREFIX}CLASS nr.: used/a cpus |");
    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	printf(PROTO " %4d",$c);
    }
    print PROTO "\n";
    if(exists($stateref->{USEDCPUS_ONNODE})) {
	for($nodenr=1;$nodenr<=$self->{FRAMES};$nodenr++) {
	    printf(PROTO "$self->{PROTOPREFIX}NODE[%2d]: %4d of %4d |",$nodenr,
		   $stateref->{USEDCPUS_ONNODE}->[$nodenr],
		   $stateref->{USEDCPUS_ONNODE}->[$nodenr]+$stateref->{FREECPUS_ONNODE}->[$nodenr]);
	    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
		my $val=$stateref->{STARTERS_ONNODE}->[$nodenr]->[$c];
		$val=0 if(!defined($val));
		printf(PROTO " %4d",$val) if($val!=0);
		printf(PROTO " %4s",".") if($val==0);
		$sum[$c]+=$val;
	    }
	    printf(PROTO " (%s) \n",$self->{NODESTATENAME}->[$nodenr]);
	}
    }
#    printf(PROTO "$self->{PROTOPREFIX}SUM1      %4d of %4d |",
#	   $stateref->{USEDCPUS}, $stateref->{USEDCPUS}+$stateref->{FREECPUS});
#    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
#	    printf(PROTO " %4d",$sum[$c]);
#    }
#    print PROTO "\n";

    printf(PROTO "$self->{PROTOPREFIX}SUM2      %4d of %4d |",
	   $stateref->{USEDCPUS}, $stateref->{USEDCPUS}+$stateref->{FREECPUS});
    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	    printf(PROTO " %4d",$stateref->{STARTERS}->[$c]);
    }
    print PROTO "\n";
    $self->PROTO_print_marker();
}


sub PROTO_print_timeline  {
    my($self) = shift;
    my($timelineref,$indataref,$start,$remark)=@_;
    my ($c,$ts,$jobid,$resid);

    return() if(!$self->{PROTO});
    $self->PROTO_open() if(!$self->{PROTOOPEN});

    $start=0 if(!$start);

    $self->PROTO_print_marker();
    printf(PROTO "$self->{PROTOPREFIX}TIMELINE (%s)\n",$remark);
    $self->PROTO_print_marker();

    printf(PROTO "$self->{PROTOPREFIX} NR  TIME[       ]:     used/a cpus |");
#    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
#	printf(PROTO " %4d",$c);
#    }
    print PROTO "\n";

    for($ts=$start;$ts<=$#{$timelineref};$ts++) {
	printf(PROTO "$self->{PROTOPREFIX}%04d-TIME[%5.2f h]: %s%4d of %4d%s|",$ts,$timelineref->[$ts]->{TIMESTAMPH},
	       ($timelineref->[$ts]->{FREECPUS}<0)?">":" ",
	       $timelineref->[$ts]->{USEDCPUS},
	       $timelineref->[$ts]->{USEDCPUS}+$timelineref->[$ts]->{FREECPUS},
	       ($timelineref->[$ts]->{FREECPUS}<0)?"<":" ");
#	for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
#	    my $val=$timelineref->[$ts]->{STARTERS}->[$c];
#	    printf(PROTO " %4d",$val) if($val!=0);
#	    printf(PROTO " %4s",".") if($val==0);
#	}
	$jobid=$timelineref->[$ts]->{JOBSTARTINGHERE};
	if($jobid) {
	    printf(PROTO " start of job %-16s cpus=%4d on",$jobid,$indataref->{JOBSTATE}->{$jobid}->{"job_totaltasks"});
 	    printf(PROTO " %s",$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"}) 
		if($self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"});
	    printf(PROTO " TopDog\#%d",$self->{TOPDOGS}->{$jobid}) if($self->{TOPDOGS}->{$jobid});
	}

	$jobid=$timelineref->[$ts]->{JOBENDINGHERE};
	if($jobid) {
	    printf(PROTO " end of job   %-16s cpus=%4d on",$jobid,$indataref->{JOBSTATE}->{$jobid}->{"job_totaltasks"});
	    printf(PROTO " %s",$self->{OUTDATA}->{JOBINFO}->{$jobid}->{"prednodelist"});
	    printf(PROTO " TopDog\#%d",$self->{TOPDOGS}->{$jobid}) if($self->{TOPDOGS}->{$jobid});
	}

	$resid=$timelineref->[$ts]->{RESSTARTINGHERE};
	if($resid) {
	    printf(PROTO " start of res   %-16s cpus=%4d on",$resid,$self->{OUTDATA}->{RESINFO}->{$resid}->{"cpus"});
	    printf(PROTO " %s",$self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"});
	}

	$resid=$timelineref->[$ts]->{RESENDINGHERE};
	if($resid) {
	    printf(PROTO " end of res   %-16s cpus=%4d on",$resid,$self->{OUTDATA}->{RESINFO}->{$resid}->{"cpus"});
	    printf(PROTO " %s",$self->{OUTDATA}->{RESINFO}->{$resid}->{"prednodelist"});
	}

	printf(PROTO "\n");
    }
    printf(PROTO "\n");

}

sub PROTO_setprefix  {
    my($self) = shift;
    $self->{PROTOPREFIX}=shift;
}

sub PROTO_clear  {
    my($self) = shift;
    return() if(!$self->{PROTO});
    open(PROTO,"> $self->{PROTO_FILENAME}");
    print PROTO "\n";
    close(PROTO);
}

sub PROTO_print  {
    my($self) = shift;
    return() if(!$self->{PROTO});
    $self->PROTO_open() if(!$self->{PROTOOPEN});
    print PROTO $self->{PROTOPREFIX},@_;
}

sub PROTO_printf  {
    my($self) = shift;
    return() if(!$self->{PROTO});
    $self->PROTO_open() if(!$self->{PROTOOPEN});
    print PROTO $self->{PROTOPREFIX};
    printf PROTO @_;
}

sub PROTO_print_marker  {
    my($self) = shift;
    return() if(!$self->{PROTO});
    $self->PROTO_open() if(!$self->{PROTOOPEN});
    print PROTO $self->{PROTOPREFIX},"-"x80,"\n";
}

sub PROTO_open  {
    my($self) = shift;
    return() if(!$self->{PROTO});
    $self->{PROTOOPEN}=1;
    open(PROTO,"> $self->{PROTO_FILENAME}");
}

sub PROTO_header  {
    my($self) = shift;
    my($indataref)=@_;
    return() if(!$self->{PROTO});
    print PROTO "Starting simulation for timestamp: ",$indataref->{'MACHSTATE'}-> {'system_time'},"\n";
    }

sub PROTO_close  {
    my($self) = shift;
    close(PROTO);
    $self->{PROTOOPEN}=0;
}

################################################################################################################

sub copy_state {
    my($self) = shift;
    my($stateref,$what)=@_;
    # what = ALL|GLOBAL
    my($copyref)={};
    my($nodenr,$c);
    $copyref->{TIMESTAMPH}=$stateref->{TIMESTAMPH};
    $copyref->{USEDCPUS}=$stateref->{USEDCPUS};
    $copyref->{FREECPUS}=$stateref->{FREECPUS};

    $copyref->{JOBENDINGHERE}=$stateref->{JOBENDINGHERE} if (exists($stateref->{JOBENDINGHERE}));
    
    if($what eq "ALL") {
	# copy node information
	for($nodenr=1;$nodenr<=$self->{FRAMES};$nodenr++) {
	    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
		my $val=$stateref->{STARTERS_ONNODE}->[$nodenr]->[$c];
		$val=0 if(!defined($val));
		$copyref->{STARTERS_ONNODE}->[$nodenr]->[$c]=$val;
	    }
	    $copyref->{USEDCPUS_ONNODE}->[$nodenr]=$stateref->{USEDCPUS_ONNODE}->[$nodenr];
	    $copyref->{FREECPUS_ONNODE}->[$nodenr]=$stateref->{FREECPUS_ONNODE}->[$nodenr];
	}
    }

    for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	my $val=$stateref->{STARTERS}->[$c]; $val=0 if(!defined($val));
	$copyref->{STARTERS}->[$c]=$val;
	$val=$stateref->{STARTEDJOBS}->[$c]; $val=0 if(!defined($val));
	$copyref->{STARTEDJOBS}->[$c]=$val;
	foreach my $user (keys(%{$stateref->{STARTEDJOBSUSER}->[$c]})) {
	    $copyref->{STARTEDJOBSUSER}->[$c]->{$user}=$stateref->{STARTEDJOBSUSER}->[$c]->{$user};
	}
    }
    return($copyref);

}

# adjust state containing minimal free starters on nodes in the duration of the job 
sub adjust_min_free_state {
    my($self) = shift;
    my($stateref,$minstateref)=@_;
    my($nodenr,$c);

    $minstateref->{USEDCPUS}=$stateref->{USEDCPUS} if($minstateref->{USEDCPUS}<$stateref->{USEDCPUS});
    $minstateref->{FREECPUS}=$stateref->{FREECPUS} if($minstateref->{FREECPUS}>$stateref->{FREECPUS});

    # adjust node information
    for($nodenr=1;$nodenr<=$self->{FRAMES};$nodenr++) {
	for($c=0;$c<=$#{$self->{NR2CLASS}};$c++) {
	    my $val   =$stateref->{STARTERS_ONNODE}->[$nodenr]->[$c];
	    my $valmin=$minstateref->{STARTERS_ONNODE}->[$nodenr]->[$c];
	    $minstateref->{STARTERS_ONNODE}->[$nodenr]->[$c]=$val if($val<$valmin);
	}
    $minstateref->{USEDCPUS_ONNODE}->[$nodenr]=$stateref->{USEDCPUS_ONNODE}->[$nodenr] 
	if($minstateref->{USEDCPUS_ONNODE}->[$nodenr]<$stateref->{USEDCPUS_ONNODE}->[$nodenr]);
    $minstateref->{FREECPUS_ONNODE}->[$nodenr]=$stateref->{FREECPUS_ONNODE}->[$nodenr] 
	if($minstateref->{FREECPUS_ONNODE}->[$nodenr]<$stateref->{FREECPUS_ONNODE}->[$nodenr]);
    }
}

sub copy_job_state {
    my($self) = shift;
    my($jobstateref)=@_;
    my($copyref)={};
    my($jobid,$key);
    # copy job state information
    foreach $jobid (keys(%{$jobstateref})) {
	$copyref->{$jobid}=$jobstateref->{$jobid};
    }
    return($copyref);
}

sub copy_job_state_only {
    my($self) = shift;
    my($jobstateref)=@_;
    my($copyref)={};
    my($jobid,$key);
    # copy job state information
    foreach $jobid (keys(%{$jobstateref})) {
	foreach $key (keys(%{$jobstateref->{$jobid}})) {
	    $copyref->{$jobid}->{$key}=$jobstateref->{$jobid}->{$key};
	}
    }
    return($copyref);
}


sub sort_waiting_for_forecast   {    
    my($o)=@_;
    my $favoreda=$o->{JOBSTATE}->{$a}->{"job_comment"} =~ "FAVORED";
    my $favoredb=$o->{JOBSTATE}->{$b}->{"job_comment"} =~ "FAVORED";
    my $oka=$o->{JOBSTATE}->{$a}->{"job_statuslong"} eq "IDLE";
    my $okb=$o->{JOBSTATE}->{$b}->{"job_statuslong"} eq "IDLE";
    if($favoreda == $favoredb) {
	if($oka == $okb) {
	    $o->{JOBSTATE}->{$b}->{"job_sysprio"} <=> $o->{JOBSTATE}->{$a}->{"job_sysprio"};
	} else {
	    $okb <=> $oka;
	}
    } else {
	$favoredb <=> $favoreda;
    }
}

# on BG/L remove nodebook part
sub specnodename_to_nodename {
    my($self) = shift;
    my($node) = @_;
    if($node=~/(R\d\d-M\d)/) {
	# it's a BGL node
	if($node=~/(R\d\d-M\d)-N(.)/) {
	    # it's a BGL nodebook
	    $node=$1;
	} else {
	    # it's a BGL midplane
	    $node=$1;
	}
    } else {
	# LL node
    }
    return($node);
}

# on BG/L  partition size must be extracted from node name
sub get_partition_size {
    my($self) = shift;
    my($node) = @_;
    my($size);
    if($node=~/(R\d\d-M\d)/) {
	# it's a BGL node
	if($node=~/(R\d\d-M\d)-N(.)/) {
	    # it's a BGL nodebook
	    $size=32;
	} else {
	    # it's a BGL midplane
	    $size=512;
	}
    } else {
	# LL node
	$size=-1;
    }
    return($size);
}

sub date_to_sec {
    my ($date)=@_;
#    print"WF: date_to_sec $date\n";
    my ($mon,$mday,$year,$hours,$min,$sec)=split(/[ :\/\-]/,$date);
    $mon--;
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year $^O\n";
    my $timesec=timelocal($sec,$min,$hours,$mday,$mon,$year);
#    print "WF: $date -> sec=$sec,min=$min,hours=$hours,mday=$mday,mon=$mon,year=$year -> $timesec\n";
    return($timesec);
}

sub timediff {
    my ($date1,$date2)=@_;
#    print"WF: timediff >$date1< >$date2<\n";
    my $timesec1=&date_to_sec($date1);
    my $timesec2=&date_to_sec($date2);
#    if((($timesec1-$timesec2)/3600)>200) {
#       printf("timediff: %20s - %20s -> %d\n",$date1,$date2,$timesec1-$timesec2);
#    }
    return($timesec1-$timesec2);
}


1;
