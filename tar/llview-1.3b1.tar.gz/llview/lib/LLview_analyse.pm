# $Source: /cvs/cvsroot/llview/lib/LLview_analyse.pm,v $
# $Author: zdv087 $
# $Revision: 1.8 $
# $Date: 2007/04/17 13:13:45 $
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
package LLview_analyse;
use strict;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\t\LLview_gui_analyse: new %s\n",ref($proto)) if($debug>=3);
    $self->{LASTIN}       = "<no info about new jobs>";
    $self->{LASTOUT}      = "<no info about finished jobs>";
    $self->{FIRSTWAIT}    = "<no info about next scheduled jobs>";
    bless $self, $class;
    return $self;
}


sub sort_jobs_prio   {    
    my($dataobj) = shift;
    $dataobj->{JOBSTATE}->{$b}{"job_sysprio"} <=>  $dataobj->{JOBSTATE}->{$a}{"job_sysprio"};
}

sub update {
    my($self) = shift;
    my($dataobj)=@_;
    my($jobstep,$cnt,$shared,$unicore);
    $cnt=0;
    $self->{FIRSTWAIT}="";
    foreach $jobstep (sort { sort_jobs_prio($dataobj) } (keys(%{$dataobj->{WAITINGJOBS}}))) {
	$cnt++;
	last if ($cnt>10);
	$shared=($dataobj->{JOBSTATE}->{$jobstep}{"job_node_usage"}=~/NOT_SHARED/)?"no":"yes";
	$unicore=($dataobj->{JOBSTATE}->{$jobstep}{"job_comment"}=~/NOT Unicore/)?" ":"U";
	$self->{FIRSTWAIT}.=sprintf("%2d:%20s %8s %8s %3d %3d %3d %s wall=%s\n",
				    $cnt,
				    $jobstep,
				    $dataobj->{JOBSTATE}->{$jobstep}{"job_owner"},
				    $dataobj->{JOBSTATE}->{$jobstep}{"job_queue"},
				    $dataobj->{JOBSTATE}->{$jobstep}{"job_nummachines"},
				    $dataobj->{JOBSTATE}->{$jobstep}{"job_taskspernode"},
				    $dataobj->{JOBSTATE}->{$jobstep}{"job_conscpu"},
				    $unicore,
				    sprintf("%2d:%02d",int($dataobj->{JOBSTATE}->{$jobstep}{"job_wall"}/3600),
					    $dataobj->{JOBSTATE}->{$jobstep}{"job_wall"}/60-
					    (int($dataobj->{JOBSTATE}->{$jobstep}{"job_wall"}/3600)*60))

			      );
    }
    return();
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}


1;
