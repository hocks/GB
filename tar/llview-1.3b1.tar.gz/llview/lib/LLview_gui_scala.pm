# $Source: /cvs/cvsroot/llview/lib/LLview_gui_scala.pm,v $
# $Author: zdv087 $
# $Revision: 1.26 $
# $Date: 2007/07/12 20:49:16 $
#
#          LLview - supervising LoadLeveler batch queue utilization 
#
#   Copyright (C) 2007, Forschungszentrum Juelich GmbH, Federal Republic of
#   Germany. All rights reserved.
#
#   Redistribution and use in source and binary forms, with or without
#   modification, are permitted provided that the following conditions are met:
#
#   Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.
#
#     - Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.
#
#     - Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#
#     - Any publications that result from the use of this software shall
#       reasonably refer to the Research Centre's development.
#
#     - All advertising materials mentioning features or use of this software
#       must display the following acknowledgement:
#
#           This product includes software developed by Forschungszentrum
#           Juelich GmbH, Federal Republic of Germany.
#
#     - Forschungszentrum Juelich GmbH is not obligated to provide the user with
#       any support, consulting, training or assistance of any kind with regard
#       to the use, operation and performance of this software or to provide
#       the user with any updates, revisions or new versions.
#
#
#   THIS SOFTWARE IS PROVIDED BY FORSCHUNGSZENTRUM JUELICH GMBH "AS IS" AND ANY
#   EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
#   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#   DISCLAIMED. IN NO EVENT SHALL FORSCHUNGSZENTRUM JUELICH GMBH BE LIABLE FOR
#   ANY SPECIAL, DIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
#   RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
#   CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
#   CONNECTION WITH THE ACCESS, USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
package LLview_gui_scala;
use strict;
use LLview_manage_colors;
use LLview_parse_xml;
my($debug)=0;


sub new {
    my $self  = {};
    my $proto = shift;
    my $class = ref($proto) || $proto;
    printf("\tLLview_gui_scala: new %s\n",ref($proto)) if($debug>=3);
    $self->{HAVEINFOMSG} = 0;
    $self->{VERBOSE}    = 0;
    $self->{POSX}    = 5;
    $self->{POSY}    = 0;
    $self->{WIDTH}   = 790;
    $self->{HEIGHT}  = 20;
    $self->{DRAWFRAME}  = 1;
    $self->{DRAWNODEFRAME}  = 1;
    $self->{MARKNODES}= 1;
    $self->{MARKSTEP}= 1;
    $self->{MARKCPUSTEP}= 1;
    $self->{ITEMS}   = [];
    $self->{NODEIDS} = [];
    $self->{FIXEDITEMS} = [];
    $self->{DOTAGNAMES} = 1;

    $self->{BUILDREADY}=0;
    $self->{BUILDFIXEDREADY}=0;

    $self->{FONT1}       = "-*-Courier-Medium-R-Normal--*-80-*-*-*-*-*-*";
    $self->{BFONT1}      = "-*-Courier-Bold-R-Normal--*-80-*-*-*-*-*-*";

    bless $self, $class;
    return $self;
}


sub build {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas,$optobj,$tabname)=@_;
    my($marker);

    $self->{CANVAS}=$canvas;
    $self->{DATAOBJECT}=$dataobj;
    $self->{COLOROBJECT}=$colorobj;
    $self->{INFOOBJECT}=$infoobj;

    $marker="UsageBar" if (!$tabname);
    $marker="UBar_$tabname" if ($tabname);
    $self->{DOTAGNAMES}=0 if ($tabname);

    print "scale: build $marker >$tabname< $self->{DOTAGNAMES}\n";
    $optobj->register_option($marker,"POSX", -label => "posx", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 2000, -default => $self->{POSX}, -step => 10);

    $optobj->register_option($marker,"POSY", -label => "posy", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 0, -max => 1200, -default => $self->{POSY}, -step => 10);

    $optobj->register_option($marker,"HEIGHT", -label => "Height", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 1200, -default => $self->{HEIGHT}, -step => 10);

    $optobj->register_option($marker,"WIDTH", -label => "Width", 
			     -caller => $self,-pack => 2,
			     -type => "int", -min => 50, -max => 2000, -default => $self->{WIDTH}, -step => 10);

    $optobj->register_option($marker,"DRAWFRAME", -label => "Draw Frame", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{DRAWFRAME});
    $optobj->register_option($marker,"DRAWNODEFRAME", -label => "Draw Node Frame", 
			     -caller => $self,-pack => 2,
			     -type => "radio", -default => $self->{DRAWNODEFRAME});

    $optobj->register_option($marker,"MARKNODES", -label => "MARKNODES", 
			     -caller => $self,-pack => 1,
			     -type => "radio", -default => $self->{MARKNODES});

    $optobj->register_option($marker,"MARKSTEP", -label => "Marker node step", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 1, -max => 200, -default => $self->{MARKSTEP}, -step => 1);

    $optobj->register_option($marker,"MARKCPUSTEP", -label => "Marker cpu step", 
			     -caller => $self,-pack => 1,
			     -type => "int", -min => 1, -max => 256, -default => $self->{MARKCPUSTEP}, -step => 1);

    $optobj->register_option($marker,"Font", -label => "Font", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{FONT1});
    $optobj->register_option($marker,"BoldFont", -label => "BoldFont", 
			     -caller => $self,-pack => 1,
			     -type => "string", -default => $self->{BFONT1});

    $self->{BUILDREADY}=1;
    return();
}


sub optvalchanged {
    my($self) = shift;
    my($section,$name,$val)=@_;
    my($diffx,$diffy,$id);
    print "scala_sb,optvalchanged: $section,$name -> $val ($self->{BUILDREADY})\n" if($self->{VERBOSE});
    if(($name eq "HEIGHT") || ($name eq "WIDTH") || ($name=~/^MARK/) 
       || ($name eq "DRAWFRAME") || ($name eq "DRAWNODEFRAME") ) {
	$self->{$name}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	}
    }
    if( ($name eq "POSX") || ($name eq "POSY")) {
	$diffx=$diffy=0;
	$diffx=$val-$self->{$name} if ($name eq "POSX");
	$diffy=$val-$self->{$name} if ($name eq "POSY");
	$self->{$name}=$val;
	if ($self->{BUILDREADY}) {
	    foreach $id (@{$self->{FIXEDITEMS}}) {
		$self->{CANVAS}->move($id,$diffx,$diffy)  if ($self->{BUILDREADY});
	    }
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	}
    }
    if ($name eq "Font") {
	$self->{FONT1}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	}
    }
    if ($name eq "BoldFont") {
	$self->{BFONT1}=$val;
	if ($self->{BUILDREADY}) {
	    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	    $self->update($self->{DATAOBJECT},$self->{COLOROBJECT},$self->{COLOROBJECT},$self->{CANVAS});
	}
    }

 
}

sub clean {
    my($self) = shift;
    my($dataobj,$colorobj,$canvas)=@_;
    my($id);
    while ($id=shift(@{$self->{ITEMS}})) {
	$canvas->delete($id);
    }
}

sub update_fixed {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($id,$i,$name,$cpus,$deltax,$cpu);
    my $frames=$dataobj->{FRAMES};
    my $maxcpus=$dataobj->{LLCPUS};

    while ($id=shift(@{$self->{FIXEDITEMS}})) {
	$canvas->delete($id);
    }

    return if($dataobj->{ALLCPUS}==0);
    
    # Full scale 
    my $startx=$self->{POSX};
    my $starty=$self->{POSY};
    my $cdeltax=$self->{WIDTH}/$dataobj->{ALLCPUS};
    my $deltay=$self->{HEIGHT}/4;
    
    if(!$self->{DRAWNODEFRAME}) {
	# global frame
	$id=$canvas->createRectangle($startx-1,$starty+2.5*$deltay-2,$startx+$self->{WIDTH}+1,$starty+4.5*$deltay, -fill => "grey85");
	push(@{$self->{FIXEDITEMS}},$id);
	$id=$canvas->createRectangle($startx-1,$starty-1,$startx+$self->{WIDTH}+1,$starty+2.5*$deltay-2, -fill => "grey95");
	push(@{$self->{FIXEDITEMS}},$id);
    }
    for($i=1;$i<=$frames;$i++) {
	$cpus=$dataobj->{NODESTATE}->[$i]->{"cpu_total"};
	$deltax=$cpus*$cdeltax;
	if($self->{DRAWNODEFRAME}) {
	    $id=$canvas->createRectangle($startx,$starty+2*$deltay,$startx+$deltax,$starty+2.5*$deltay, -fill => "grey85",
					 -tags => ["NODE${i}"]);
	    push(@{$self->{FIXEDITEMS}},$id);
	    if($self->{DOTAGNAMES}) {
		$id=$self->{NODEIDS}->[$i]=$canvas->createRectangle($startx,$starty,$startx+$deltax,$starty+2*$deltay, 
								    -fill => "white", -tags => ["free"]);
	    } else {
		$id=$self->{NODEIDS}->[$i]=$canvas->createRectangle($startx,$starty,$startx+$deltax,$starty+2*$deltay, 
								    -fill => "white");
	    }
	    push(@{$self->{FIXEDITEMS}},$id);
	}

	if( ($self->{MARKNODES}) && ($i%$self->{MARKSTEP}==0)) {
	    $id=$canvas->createLine($startx,$starty,$startx,$starty+4*$deltay, -fill => "black");
	    push(@{$self->{FIXEDITEMS}},$id);
	    $name=sprintf("%2d",$i);
	    if($self->{DOTAGNAMES}) {
		$id=$canvas->createText($startx+0.5*$deltax,$starty+3*$deltay,-text => $name, -font => $self->{FONT1},
					-anchor => "n", -tags => ["NODE${i}"]);
	    } else {
		$id=$canvas->createText($startx+0.5*$deltax,$starty+3*$deltay,-text => $name, -font => $self->{FONT1},
					-anchor => "n");
	    }
	    push(@{$self->{FIXEDITEMS}},$id);
	}
	$startx+=$deltax;
    }
    if(!$self->{MARKNODES}) {
	for($cpu=0;$cpu<=$dataobj->{ALLCPUS};$cpu+=$self->{MARKCPUSTEP}) {
	    $startx=$self->{POSX}+$cpu*$cdeltax;
	    $id=$canvas->createLine($startx,$starty,$startx,$starty+3.5*$deltay, -fill => "black");
	    push(@{$self->{FIXEDITEMS}},$id);
	    $name=sprintf("%2d",$cpu);
	    $id=$canvas->createText($startx+0.5*$deltax,$starty+3*$deltay,-text => $name, -font => $self->{FONT1},
				    -anchor => "n");
	    push(@{$self->{FIXEDITEMS}},$id);
	}
    }
    $self->{BUILDFIXEDREADY}=1;

}

sub update {
    my($self) = shift;
    my($dataobj,$colorobj,$infoobj,$canvas)=@_;
    my($i,$deltax);
    my($id,$text,$cpusum);
    my($num,$jobid,$cpus,$color,$nr);

    return if($dataobj->{ALLCPUS}==0);
    my $frames=$dataobj->{FRAMES};
    return(-1) if($frames<=0);
    my $startx=$self->{POSX};
    my $starty=$self->{POSY};
    my $cdeltax=$self->{WIDTH}/$dataobj->{ALLCPUS};
    my $deltay=$self->{HEIGHT}/4;
    my $width =$self->{WIDTH};
    my $maxcpus=$dataobj->{LLCPUS};

    $self->update_fixed($self->{DATAOBJECT},$self->{COLOROBJECT},
			$self->{COLOROBJECT},$self->{CANVAS}) if(!$self->{BUILDFIXEDREADY});

    $self->clean($dataobj,$colorobj,$canvas);

    $cpusum=0;
#    print "WF:",ref($dataobj),"<\n";
#    print keys( %{$dataobj->{RUNNINGDATA}} );
    foreach $jobid (sort {sort_jobs_allcpu_up($dataobj)} keys( %{$dataobj->{RUNNINGDATA}} ) ) {
	$cpus=$dataobj->{RUNNINGDATA}->{$jobid}{FL_OVERALL};
	$color=$colorobj->get_color("RUN",$jobid);
	$nr=$colorobj->colortonr("RUN",$color);
	$deltax=$cpus*$cdeltax;
	$cpusum+=$cpus;
#	printf("WF: %20s %4d %4d %4d -> %4d %f\n",$jobid,$cpus,$width,$maxcpus,$deltax,$cdeltax);

	if($self->{DOTAGNAMES}) {
	    $id=$canvas->createRectangle($startx,$starty,$startx+$deltax,$starty+2*$deltay, -fill => $color, 
					 -outline => $self->{DRAWFRAME}?"black":$color, -tags => ["T${nr}R"]);
	} else {
	    $id=$canvas->createRectangle($startx,$starty,$startx+$deltax,$starty+2*$deltay, -fill => $color, 
					 -outline => $self->{DRAWFRAME}?"black":$color);
	}
	$startx+=$deltax;
	push(@{$self->{ITEMS}},$id);
    }

    # free cpus text
    if($dataobj->{LLCPUS}!=0) {
	$text=sprintf("used:  %02d%% %d/%d,\nfree: %d, %d nds (%d nshd)\n#jobs (run/wait): %d/%d",
		      $cpusum/($dataobj->{LLCPUS})*100,
		      $dataobj->{LLOVERALLCPUS},$dataobj->{LLCPUS},
		      $dataobj->{LLCPUS}-$dataobj->{LLOVERALLCPUS},
		      $dataobj->{LLFREENODES},
		      $dataobj->{LLOVERALLCPUS}-$dataobj->{LLUSEDCPUS},

		      $dataobj->{LLNUMRJOBS},$dataobj->{LLNUMWJOBS});
    }
    $id=$canvas->createText($self->{POSX}+$width+10,$starty+2.8*$deltay,-text => $text, -anchor => 'w', -font => $self->{BFONT1});
    push(@{$self->{ITEMS}},$id);

    # box for down cpus
    $startx=$self->{POSX}+($dataobj->{LLCPUS})*$cdeltax;
    $deltax=($dataobj->{ALLCPUS} - $maxcpus)*$cdeltax;
    if($deltax>0) {
	if($self->{DOTAGNAMES}) {
	    $id=$canvas->createRectangle($startx,$starty,$startx+$deltax,$starty+2*$deltay, -fill => "grey85",  
					 -outline => $self->{DRAWFRAME}?"black":"grey85", -tags => ["unusable"]);
	} else {
	    $id=$canvas->createRectangle($startx,$starty,$startx+$deltax,$starty+2*$deltay, -fill => "grey85",  
					 -outline => $self->{DRAWFRAME}?"black":"grey85");
	}
	push(@{$self->{ITEMS}},$id);
    }

    $canvas->configure(-scrollregion => [ $canvas->bbox("all") ]);
    
    if($self->{DRAWNODEFRAME}) {
	for($i=1;$i<=$dataobj->{LLNODES};$i++) {
	    if($self->{DOTAGNAMES}) {
		$canvas->itemconfigure($self->{NODEIDS}->[$i], -fill => "white", -tags => ["free"]);
	    } else {
		$canvas->itemconfigure($self->{NODEIDS}->[$i], -fill => "white");
	    }

	}
	for($i=$dataobj->{LLNODES}+1;$i<=$frames;$i++) {
	    if($self->{DOTAGNAMES}) {
		$canvas->itemconfigure($self->{NODEIDS}->[$i], -fill => "grey60", -tags => ["unusable"]);
	    } else {
		$canvas->itemconfigure($self->{NODEIDS}->[$i], -fill => "grey60");
	    }
	}
    }
    

    return();
}

sub sort_jobs_allcpu_up   { 
    my($dataobj) = shift;
#    printf("sort_jobs_allcpu_up: %s<>%s %d<>%d %d<>%d\n",$a,$b,
#	   $dataobj->{RUNNINGDATA}->{$b}{FL_ALLCPU},$dataobj->{RUNNINGDATA}->{$a}{FL_ALLCPU},
#	   $dataobj->{RUNNINGDATA}->{$b}{FL_WALLSEC},$dataobj->{RUNNINGDATA}->{$a}{FL_WALLSEC});
    if($dataobj->{RUNNINGDATA}->{$b}{FL_OVERALL} == $dataobj->{RUNNINGDATA}->{$a}{FL_OVERALL}) {
	if($dataobj->{RUNNINGDATA}->{$b}{FL_WALLSEC} == $dataobj->{RUNNINGDATA}->{$a}{FL_WALLSEC}) {
	    $dataobj->{RUNNINGDATA}->{$b}{FL_RESTSEC} <=> $dataobj->{RUNNINGDATA}->{$a}{FL_RESTSEC};
	} else {
	    $dataobj->{RUNNINGDATA}->{$b}{FL_WALLSEC} <=> $dataobj->{RUNNINGDATA}->{$a}{FL_WALLSEC};
	}
    } else {
	$dataobj->{RUNNINGDATA}->{$b}{FL_OVERALL} <=> $dataobj->{RUNNINGDATA}->{$a}{FL_OVERALL};
    }
}


1;
